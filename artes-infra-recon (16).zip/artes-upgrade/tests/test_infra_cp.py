"""infra_recon.py + verify_cp.py 검증. `python3 tests/test_infra_cp.py` 로 실행(pytest 불필요).

인프라 recon 은 네트워크를 치지 않는다 — 주입 FakeHTTP 로 어댑터 파싱/그래프/상관을 오프라인
검증한다. CP 는 폐형식·정의성질·(있으면)scipy 로 교차검증.
"""
from __future__ import annotations

import asyncio
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core.model import EntityType, Certainty, Graph
from artes.core.verify_cp import (
    reg_incomplete_beta as ib, cp_lower, cp_upper, VerificationGate,
    corroborate_edges, VERDICT_CONFIRMED, VERDICT_UNCONFIRMED, VERDICT_DROP,
)
from artes.core import infra_recon as IR
from artes.core.infra_recon import (
    classify_infra, InfraType, InfraTarget, HTTPResp, InfraRecon,
    CertTransparency, DoHDNS, RDAPDomain, RDAPIp, ASNPrefixes,
    correlate_same_operator, operator_clusters, _k, _SIGNAL_KINDS,
    CachingHTTP, expand_cidr_to_hosts, subdomain_candidates, COMMON_SUBDOMAINS,
    corroborate_resolution, HackerTargetHostSearch, AlienVaultPDNS,
)
from artes.core.scheduler import AdaptiveConcurrency
import time as _time
from artes.core.model import Entity, Edge, Evidence

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")


# ------------------------------------------------------------------ CP ------ #
def t_cp_math():
    for got, exp, name in [
        (ib(1,1,0.5), 0.5, "I_.5(1,1)"), (ib(2,1,0.5), 0.25, "I_x(2,1)=x^2"),
        (ib(1,2,0.5), 0.75, "I_x(1,2)"), (ib(5,5,0.5), 0.5, "sym")]:
        check(abs(got-exp) < 1e-12, f"betai {name} {got}")
    for n in (5, 10, 37, 100):
        a = 0.05
        check(abs(cp_upper(0,n,a) - (1-(a/2)**(1/n))) < 1e-12, f"cp_upper(0,{n}) 폐형식")
        check(abs(cp_lower(n,n,a) - (a/2)**(1/n)) < 1e-12, f"cp_lower(n,{n}) 폐형식")
    # 정의성질
    rng = random.Random(7); worst = 0.0
    for _ in range(1500):
        n = rng.randint(1,400); k = rng.randint(0,n); a = rng.choice([0.01,0.05,0.1])
        if k>0: worst = max(worst, abs(ib(k,n-k+1,cp_lower(k,n,a)) - a/2))
        if k<n: worst = max(worst, abs(ib(k+1,n-k,cp_upper(k,n,a)) - (1-a/2)))
    check(worst < 1e-9, f"CP 정의성질 잔차 {worst:.2e}")
    # 단조성: k 증가 → 하한 증가
    prev = -1
    for k in range(0, 21):
        lo = cp_lower(k, 20, 0.05)
        check(lo >= prev - 1e-12, f"cp_lower 단조성 k={k}")
        prev = lo
    print(f"  CP math: betai/폐형식/정의성질/단조성 OK (정의성질 잔차 {worst:.2e})")

def t_cp_scipy_crosscheck():
    try:
        from scipy.stats import beta
    except Exception:
        print("  CP scipy: (미설치, 스킵)")
        return
    rng = random.Random(11); w = 0.0
    for _ in range(3000):
        n = rng.randint(1,300); k = rng.randint(0,n); a = rng.choice([0.01,0.05,0.1])
        pL = 0.0 if k==0 else beta.ppf(a/2, k, n-k+1)
        pU = 1.0 if k==n else beta.ppf(1-a/2, k+1, n-k)
        w = max(w, abs(cp_lower(k,n,a)-pL), abs(cp_upper(k,n,a)-pU))
    check(w < 1e-9, f"scipy 교차 최대오차 {w:.2e}")
    print(f"  CP scipy 교차검증: 최대오차 {w:.2e}")

def t_cp_gate():
    g = VerificationGate(tau=0.80, floor=0.10, alpha=0.05)
    # k=n=8 → 하한 (0.025)^(1/8) ≈ 0.616 → tau 0.8 미만 → UNCONFIRMED, 점추정 아닌 하한
    v = g.judge(8, 8)
    check(v.verdict == VERDICT_UNCONFIRMED, f"judge(8,8) {v.verdict}")
    check(abs(v.lower - (0.05/2)**(1/8)) < 1e-9, "judge(8,8) 하한=폐형식")
    # 큰 표본 전원확인 → 하한이 tau 넘음 → CONFIRMED
    v2 = g.judge(60, 60)
    check(v2.verdict == VERDICT_CONFIRMED, f"judge(60,60) {v2.verdict} lower={v2.lower:.3f}")
    # 근거 거의 없음 → 상한 바닥 미만 → drop. k=0,n=40: 상한=1-(0.025)^(1/40)≈0.0905<0.1
    v3 = g.judge(0, 40)
    check(v3.verdict == VERDICT_DROP, f"judge(0,40) {v3.verdict} upper={v3.upper:.4f}")
    # 게이트가 만드는 confidence 는 '정확 하한'이지 임의 점추정이 아님
    check(v.lower <= 1.0 and v.upper >= v.lower, "구간 정합")
    print(f"  CP gate: (8,8)→불확실 하한 {v.lower:.3f} / (60,60)→확실 / (0,40)→drop OK")


# --------------------------------------------------------- classify ------- #
def t_classify():
    accept = {"example.com": InfraType.DOMAIN, "sub.example.co.uk": InfraType.DOMAIN,
              "8.8.8.8": InfraType.IP, "2001:4860:4860::8888": InfraType.IP,
              "AS15169": InfraType.ASN, "as13335": InfraType.ASN,
              "192.0.2.0/24": InfraType.CIDR, "https://example.com/x": InfraType.URL}
    for v, t in accept.items():
        check(classify_infra(v) == t, f"classify {v} → {t} (got {classify_infra(v)})")
    # 사람 selector 거부
    for v in ["hong@gmail.com", "+821012345678", "hong123", "홍길동",
              "John Smith", "01012345678", "15169"]:
        check(classify_infra(v) is None, f"사람/비자산 {v!r} 거부돼야 함 (got {classify_infra(v)})")
    print("  classify: 자산 8종 승인 / 사람·전화·순수숫자 거부 OK")


# --------------------------------------------------------- FakeHTTP -------- #
class FakeHTTP:
    """URL 부분일치 → 카드형 HTTPResp. 네트워크 0. delay 로 지연 시뮬."""
    def __init__(self, table, delay=0.0): self.table = table; self.calls = []; self.delay = delay
    async def __call__(self, url):
        self.calls.append(url)
        if self.delay:
            await asyncio.sleep(self.delay)
        for frag, resp in self.table.items():
            if frag in url:
                return resp
        return HTTPResp(status=404, text="", url=url)

import json as _json
def R(obj, status=200): return HTTPResp(status=status, text=_json.dumps(obj))


async def t_ct_parser():
    http = FakeHTTP({"crt.sh": R([
        {"issuer_name": "C=US, O=Let's Encrypt", "name_value": "example.com\n*.example.com\napi.example.com", "common_name": "example.com"},
        {"issuer_name": "C=US, O=Let's Encrypt", "name_value": "mail.example.com", "common_name": "mail.example.com"},
        {"issuer_name": "x", "name_value": "evil.com", "common_name": "evil.com"},  # 대상 외 → 무시
    ])})
    res = await CertTransparency().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
    vals = {e.value for e in res.entities}
    check("api.example.com" in vals and "mail.example.com" in vals, f"CT 하위도메인 {vals}")
    check("evil.com" not in vals, "CT 대상 외 도메인 누락 실패")
    check(all(e.certainty == Certainty.CONFIRMED for e in res.entities), "CT 확실성")
    check(any(e.relation == "하위도메인" for e in res.edges), "CT 하위도메인 간선")
    print(f"  crt.sh 파서: 하위도메인 {sorted(vals)}")

async def t_doh_parser():
    http = FakeHTTP({
        "type=A": R({"Answer": [{"name":"example.com","type":1,"data":"93.184.216.34"}]}),
        "type=NS": R({"Answer": [{"name":"example.com","type":2,"data":"a.iana-servers.net."}]}),
        "type=MX": R({"Answer": [{"name":"example.com","type":15,"data":"10 mail.example.com."}]}),
    })
    res = await DoHDNS().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
    ips = {e.value for e in res.entities if e.type == EntityType.IP}
    doms = {e.value for e in res.entities if e.type == EntityType.DOMAIN}
    check("93.184.216.34" in ips, f"DoH A 레코드 {ips}")
    check("a.iana-servers.net" in doms, f"DoH NS {doms}")
    check("mail.example.com" in doms, f"DoH MX 호스트 {doms}")
    check(any(e.relation == "해석됨(A)" for e in res.edges), "DoH A 간선")
    print(f"  DoH 파서: IP {ips}, 도메인 {sorted(doms)}")

async def t_rdap_domain_no_person():
    http = FakeHTTP({"rdap.org/domain": R({
        "nameservers": [{"ldhName": "NS1.EXAMPLE.NET"}, {"ldhName": "ns2.example.net"}],
        "entities": [
            {"roles": ["registrar"], "vcardArray": ["vcard", [["version",{},"text","4.0"],["fn",{},"text","BigRegistrar Inc"],["org",{},"text","BigRegistrar Inc"]]]},
            {"roles": ["registrant"], "vcardArray": ["vcard", [["version",{},"text","4.0"],["fn",{},"text","Hong Gildong"],["email",{},"text","hong@gmail.com"],["tel",{},"text","+821012345678"]]]},
        ]})})
    res = await RDAPDomain().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
    vals = {(e.type, e.value) for e in res.entities}
    check((EntityType.DOMAIN, "ns1.example.net") in vals, f"RDAP NS {vals}")
    check((EntityType.ORG, "BigRegistrar Inc") in vals, "RDAP 레지스트라 조직")
    # 사람 vCard 는 절대 안 뽑힘
    check(not any("hong" in str(v).lower() or "gildong" in str(v).lower() for _, v in vals),
          "등록자 사람정보가 새어나옴!")
    check(not any(e.type == EntityType.EMAIL or e.type == EntityType.PHONE for e in res.entities),
          "RDAP 에서 email/phone 엔티티 생성됨(경계 위반)")
    print("  RDAP 도메인: NS+레지스트라만, 등록자 사람 vCard 미수집 OK")

async def t_rdap_ip_and_asn():
    http = FakeHTTP({
        "rdap.org/ip": R({"name":"GOOGLE","cidr0_cidrs":[{"v4prefix":"8.8.8.0","length":24}],
                          "arin_originas0_originautnums":[15169]}),
        "announced-prefixes": R({"data":{"prefixes":[{"prefix":"8.8.8.0/24"},{"prefix":"8.8.4.0/24"}]}}),
    })
    res_ip = await RDAPIp().fetch(InfraTarget(InfraType.IP, "8.8.8.8"), http)
    check(any(e.type==EntityType.HOST and e.value=="8.8.8.0/24" for e in res_ip.entities), "RDAP IP CIDR")
    check(any(e.type==EntityType.ASN and e.value=="AS15169" for e in res_ip.entities), "RDAP IP ASN")
    res_asn = await ASNPrefixes().fetch(InfraTarget(InfraType.ASN, "AS15169"), http)
    cidrs = {e.value for e in res_asn.entities}
    check("8.8.8.0/24" in cidrs and "8.8.4.0/24" in cidrs, f"ASN prefixes {cidrs}")
    print(f"  RDAP IP + ASN prefixes: ASN15169 광고 {sorted(cidrs)}")


# ------------------------------------------------- throughput/scale ------- #
async def t_caching_http():
    calls = {"n": 0}
    async def inner(url):
        calls["n"] += 1
        await asyncio.sleep(0.01)
        return HTTPResp(status=200, text="{}", url=url)
    ch = CachingHTTP(inner, ttl=100)
    res = await asyncio.gather(*[ch("https://x/api") for _ in range(10)])
    check(calls["n"] == 1, f"single-flight: 동시 10개 동일 URL → 하부 {calls['n']} (1 기대)")
    check(ch.hits == 9, f"single-flight saved {ch.hits} (9 기대)")
    check(len(res) == 10, "결과 10개")
    await ch("https://x/api")
    check(calls["n"] == 1, f"캐시 히트인데 하부 증가 {calls['n']}")
    await ch("https://x/other")
    check(calls["n"] == 2, f"신규 URL 하부 {calls['n']} (2 기대)")
    print(f"  CachingHTTP: single-flight 10→1, 캐시히트 0증가, stats={ch.stats()}")

def t_scope_generators():
    hosts = expand_cidr_to_hosts("192.0.2.0/24")
    check(len(hosts) == 254, f"/24 호스트수 {len(hosts)}")
    check("192.0.2.1" in hosts and "192.0.2.0" not in hosts, "네트워크주소 제외")
    check(len(expand_cidr_to_hosts("10.0.0.0/8", limit=1000)) == 1000, "limit 적용")
    subs = subdomain_candidates("example.com", ["www", "api", "www", ""])
    check(subs == ["www.example.com", "api.example.com"], f"서브도메인 dedup {subs}")
    check(len(subdomain_candidates("example.com", COMMON_SUBDOMAINS)) >= 40, "내장 워드리스트")
    print(f"  scope 생성기: /24→254, /8 limit→1000, 서브도메인 후보 dedup OK")

async def t_doh_parallel():
    # 5개 타입 쿼리가 병렬이면 총 ≈1왕복 지연, 순차면 ≈5왕복.
    http = FakeHTTP({"type=": R({"Answer": []})}, delay=0.05)
    t0 = _time.perf_counter()
    await DoHDNS().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
    dt = _time.perf_counter() - t0
    # 병렬이면 ≈1왕복(0.05s), 순차면 6왕복(0.30s). 0.20 은 순차(0.30)와 뚜렷이 분리되면서
    # pytest 출력캡처·이벤트루프 스케줄링 지터에 강건(과거 0.15 는 캡처 부하에서 간헐 실패).
    check(dt < 0.20, f"DoH 타입쿼리 병렬 아님 dt={dt:.3f} (순차면 6×0.05=0.30)")
    check(len(http.calls) == 6, f"DoH 6타입 쿼리(A/AAAA/NS/MX/CNAME/TXT) {len(http.calls)}")
    print(f"  DoH 병렬: 6타입 @0.05s → {dt:.3f}s (병렬)")

async def t_pooled_http_smoke():
    from artes.core.infra_recon import default_http_get, close_http
    r = await default_http_get("http://127.0.0.1:9/nope", timeout=1.0)  # 거부/무응답
    check(isinstance(r, HTTPResp), "default_http_get HTTPResp 반환")
    check(r.status < 200 or r.status >= 400, f"닫힌 포트 status {r.status} (200 아님)")
    await close_http()
    print(f"  pooled HTTP smoke: aiohttp 경로 정상(닫힌 포트 status={r.status}, 예외 없음)")

async def t_large_lazy_intake():
    # 2000개 seed 를 제너레이터로 지연 인테이크 — 업프런트 리스트 materialize 없이 완주.
    http = FakeHTTP({
        "crt.sh": R([]), "type=": R({"Answer": []}),
        "rdap.org/domain": R({"nameservers": [], "entities": []}),
    })
    gov = AdaptiveConcurrency(start=16, min_limit=1, max_limit=64)
    rec = InfraRecon(http=http, governor=gov, concurrency=64, depth=1, max_seconds=30)
    def gen():
        yield "example.com"
        for i in range(2000):
            yield f"n{i}.example.com"
    t0 = _time.perf_counter()
    g = await rec.run_iter(gen(), hwm=256)      # 미결 상한 256 → 큐/메모리 유계
    dt = _time.perf_counter() - t0
    dom = sum(1 for e in g.entities if e.type == EntityType.DOMAIN)
    check(dom >= 2001, f"지연 인테이크 대상 수 {dom} (>=2001)")
    check(len(rec.skipped) == 0, f"거부 {len(rec.skipped)}")
    check(gov.max_in_flight <= 64, f"동시성 상한 {gov.max_in_flight}")
    print(f"  대규모 지연 인테이크: 2001 seed, hwm=256, {dt:.2f}s, peak {gov.max_in_flight}/64")

async def t_politeness_http():
    from artes.core.infra_recon import PolitenessHTTP
    calls = {"n": 0}
    async def flaky(url):
        calls["n"] += 1
        return HTTPResp(status=(429 if calls["n"] < 3 else 200), text="{}", url=url)
    ph = PolitenessHTTP(flaky, retries=3, base_delay=0.001, max_delay=0.01)
    r = await ph("https://h/x")
    check(r.status == 200, f"429 재시도 후 200 {r.status}")
    check(calls["n"] == 3, f"재시도 횟수 {calls['n']}")
    calls["n"] = 0
    async def always429(url):
        calls["n"] += 1
        return HTTPResp(status=429, url=url)
    r2 = await PolitenessHTTP(always429, retries=2, base_delay=0.001)("https://h/y")
    check(r2.status == 429 and calls["n"] == 3, f"재시도 소진 {r2.status},{calls['n']}")
    print("  PolitenessHTTP: 429 재시도→성공, 소진 시 마지막 결과 반환 OK")

async def t_bulk_sweep_scale():
    http = FakeHTTP({
        "crt.sh": R([]),
        "type=A": R({"Answer": [{"name":"h","type":1,"data":"1.2.3.4"}]}),
        "type=": R({"Answer": []}),
        "rdap.org/domain": R({"nameservers": [], "entities": []}),
        "rdap.org/ip": R({"name":"NET","cidr0_cidrs":[{"v4prefix":"1.2.3.0","length":24}],"arin_originas0_originautnums":[64500]}),
        "network-info": R({"data":{"prefix":"1.2.3.0/24","asns":["64500"]}}),
        "announced-prefixes": R({"data":{"prefixes":[]}}),
    }, delay=0.002)
    gov = AdaptiveConcurrency(start=16, min_limit=1, max_limit=64)
    rec = InfraRecon(http=http, governor=gov, concurrency=64, depth=2, max_seconds=30)
    words = [f"h{i}" for i in range(300)]                 # 스코프 몇백배: 301 대상
    t0 = _time.perf_counter()
    g = await rec.sweep_subdomains("example.com", words=words)
    dt = _time.perf_counter() - t0
    dom = {e.value for e in g.entities if e.type == EntityType.DOMAIN}
    check(len(dom) >= 301, f"대상 도메인 수 {len(dom)} (>=301 기대)")
    check(_k(EntityType.IP, "1.2.3.4") in {e.key for e in g.entities}, "공통 IP 수집")
    check(_k(EntityType.ASN, "AS64500") in {e.key for e in g.entities}, "확장: IP→ASN")
    check(len(rec.skipped) == 0, f"유효 서브도메인 거부됨 {len(rec.skipped)}")
    check(gov.max_in_flight > 1, f"병렬 안 됨 max_in_flight={gov.max_in_flight}")
    check(gov.max_in_flight <= 64, f"동시성 상한 위반 {gov.max_in_flight}")
    jobs = len(http.calls)
    print(f"  대량 스윕: 301대상, HTTP {jobs}회, {dt:.2f}s, "
          f"동시성 peak {gov.max_in_flight}/64, 처리량 {jobs/dt:,.0f} req/s, "
          f"캐시 {rec.http_cache.stats()}")

# ------------------------------------------------- end-to-end recon -------- #
async def t_recon_end_to_end():
    http = FakeHTTP({
        "crt.sh": R([{"issuer_name":"LE","name_value":"example.com\napi.example.com","common_name":"example.com"}]),
        "type=A": R({"Answer":[{"name":"example.com","type":1,"data":"93.184.216.34"}]}),
        "type=NS": R({"Answer":[{"name":"example.com","type":2,"data":"a.iana-servers.net."}]}),
        "rdap.org/domain": R({"nameservers":[{"ldhName":"a.iana-servers.net"}],"entities":[]}),
        "rdap.org/ip": R({"name":"EDGECAST","cidr0_cidrs":[{"v4prefix":"93.184.216.0","length":24}],"arin_originas0_originautnums":[15133]}),
        "network-info": R({"data":{"prefix":"93.184.216.0/24","asns":["15133"]}}),
        "announced-prefixes": R({"data":{"prefixes":[]}}),
    })
    # 사람 selector 섞어서 → 거부 확인
    rec = InfraRecon(http=http, depth=2, max_seconds=10)
    g = await rec.run(["example.com", "hong@gmail.com", "+821012345678"])
    ekeys = {e.key for e in g.entities}
    check(_k(EntityType.DOMAIN, "api.example.com") in ekeys, "recon 하위도메인 수집")
    check(_k(EntityType.IP, "93.184.216.34") in ekeys, "recon IP 수집")
    check(_k(EntityType.ASN, "AS15133") in ekeys, "recon 확장: IP→ASN")
    check(any("사람 selector" in r for _, r in rec.skipped), f"사람 selector 거부 {rec.skipped}")
    check(len(rec.skipped) == 2, f"거부 2건 기대 {rec.skipped}")
    # 간선 정합성: 모든 간선 끝점이 그래프에 존재(link 통과)
    for e in g.edges:
        check(e.src in ekeys and e.dst in ekeys, f"간선 끝점 미존재 {e.src}->{e.dst}")
    print(f"  end-to-end: 엔티티 {len(g.entities)} 간선 {len(g.edges)}, 사람 selector {len(rec.skipped)}건 거부")

async def t_passive_dns_corroborate():
    # DoH + HackerTarget + OTX 세 독립 소스가 같은 A레코드 확인 → 엣지 증거 합류(3출처)
    http = FakeHTTP({
        "crt.sh": R([]),
        "type=A": R({"Answer": [{"name":"example.com","type":1,"data":"1.2.3.4"}]}),
        "type=": R({"Answer": []}),
        "rdap.org/domain": R({"nameservers": [], "entities": []}),
        "hostsearch": HTTPResp(status=200, text="example.com,1.2.3.4\nwww.example.com,1.2.3.4"),
        "passive_dns": R({"passive_dns": [{"hostname":"example.com","address":"1.2.3.4"}]}),
        "rdap.org/ip": R({"cidr0_cidrs": [], "arin_originas0_originautnums": []}),
        "network-info": R({"data": {}}),
    })
    rec = InfraRecon(http=http, depth=1, max_seconds=15)
    g = await rec.run(["example.com"])
    key_e = [x for x in g.edges if x.relation == "해석됨(A)"
             and x.src == _k(EntityType.DOMAIN, "example.com")
             and x.dst == _k(EntityType.IP, "1.2.3.4")]
    check(len(key_e) == 1, f"apex A레코드 엣지 {len(key_e)}")
    srcs = {ev.source for ev in key_e[0].evidence}
    check({"doh-dns", "hackertarget", "otx-pdns"} <= srcs, f"A레코드 3독립출처 {srcs}")
    corroborate_resolution(g, n_sources=3)
    check(abs((key_e[0].confidence or 0) - cp_lower(3, 3, 0.05)) < 1e-9,
          f"corroborate confidence=CP하한 {key_e[0].confidence}")
    print(f"  passive-DNS corroborate: A레코드 3독립출처 → CP하한 {cp_lower(3,3,0.05):.3f}")

async def t_favicon_httpfp_signals():
    from artes.core.infra_recon import FaviconHash, HTTPHeaderFP
    async def fav(host): return b"ICONDATA-BYTES"
    r = await FaviconHash(fetch_bytes=fav).fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(r.ok and r.entities[0].attrs.get("favicon"), "favicon 해시 attr")
    async def http(url):
        return HTTPResp(status=200, text="", url=url,
                        headers={"Server": "nginx", "X-Powered-By": "php"})
    r2 = await HTTPHeaderFP().fetch(InfraTarget(InfraType.DOMAIN, "a.com"), http)
    check(r2.ok and r2.entities[0].attrs.get("httpfp"), "httpfp attr")
    check(r2.entities[0].attrs.get("server") == "nginx", "server 배너 attr")
    print("  favicon/httpfp 신호: attr 추출 OK")

async def t_tls_behavior():
    from artes.core.infra_recon import TLSBehaviorProbe, tls_behavior_digest
    obs = [("1.2", "c1", "e1"), ("1.3", "c2", "e2")]
    d1 = tls_behavior_digest(obs)
    check(d1 == tls_behavior_digest(obs) and d1.startswith("tlsfp:"), "digest 결정성")
    check(d1 != tls_behavior_digest([("1.2", "c1", "e9")]), "관측 다르면 다른 지문")
    async def probe(host): return obs
    r = await TLSBehaviorProbe(probe=probe).fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(r.ok and r.entities[0].attrs.get("tlsfp") == d1, "probe(list)→tlsfp attr")
    async def probe2(host): return "tlsfp:custom"
    r2 = await TLSBehaviorProbe(probe=probe2).fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(r2.entities[0].attrs["tlsfp"] == "tlsfp:custom", "probe(str) 그대로")
    r3 = await TLSBehaviorProbe().fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(not r3.ok, "probe 없으면 옵트인 실패")
    print("  TLS 행동지문: digest 결정성/probe(list·str)/옵트인 OK")

async def t_dmarc_ptr_adapters():
    from artes.core.infra_recon import DMARCLookup, ReverseDNS
    http = FakeHTTP({"_dmarc": R({"Answer": [{"type": 16,
        "data": "v=DMARC1; p=none; rua=mailto:agg@dmarc.example, mailto:x@third.io"}]})})
    r = await DMARCLookup().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
    check(r.ok and set(r.entities[0].attrs["dmarc"]) == {"dmarc.example", "third.io"},
          f"DMARC rua 호스트 {r.entities and r.entities[0].attrs.get('dmarc')}")
    http2 = FakeHTTP({"in-addr.arpa": R({"Answer": [{"type": 12, "data": "host12.provider.net."}]})})
    r2 = await ReverseDNS().fetch(InfraTarget(InfraType.IP, "1.2.3.4"), http2)
    check(r2.ok and r2.entities[0].attrs["ptr"] == "host12.provider.net"
          and r2.entities[0].attrs["ptr_domain"] == "provider.net",
          f"PTR {r2.entities and r2.entities[0].attrs}")
    print("  DMARC/PTR 어댑터: rua 호스트 / PTR 도메인 추출 OK")

async def t_recon_authz_infra_only():
    from artes.core.authz import AuthorizationScope, Authorization, BASIS_INFRA_TI
    scope = AuthorizationScope().authorize(Authorization(
        case_id="INF-1", operator="op", basis=BASIS_INFRA_TI,   # infra_only 강제
        selectors={"example.com"}, domain_suffixes={"example.com"}))
    http = FakeHTTP({
        "crt.sh": R([{"issuer_name":"LE","name_value":"api.example.com","common_name":"api.example.com"}]),
        "type=A": R({"Answer":[]}), "type=NS": R({"Answer":[]}),
        "rdap.org/domain": R({"nameservers":[],"entities":[]}),
    })
    rec = InfraRecon(http=http, scope=scope, depth=1, max_seconds=10)
    # 인가 도메인 + 미인가 도메인 동시 투입
    g = await rec.run(["example.com", "notauthorized.org"])
    ekeys = {e.key for e in g.entities}
    check(_k(EntityType.DOMAIN,"example.com") in ekeys, "인가 도메인 수집됨")
    check(_k(EntityType.DOMAIN,"notauthorized.org") not in ekeys, "미인가 도메인 거부됨")
    check(any("미인가" in r for _, r in rec.skipped), f"미인가 거부 기록 {rec.skipped}")
    print("  authz infra_only: 인가 도메인만 조회, 미인가 거부 OK")


# ----------------------------------------- same-operator + CP ------------- #
def _seed_graph_for_correlation():
    """두 도메인 a.com/b.com 이 NS·IP·ASN 3신호를 공유하도록 구성."""
    from artes.core.model import Entity, Edge, Evidence
    g = Graph()
    def add(t, v, **at):
        return g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED,
                            evidence=[Evidence("t","")], attrs=at))
    for v in ["a.com","b.com","ns.shared.net"]:
        add(EntityType.DOMAIN, v)
    add(EntityType.IP, "1.2.3.4")
    add(EntityType.ASN, "AS64500")
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED,
                    evidence=[Evidence("t","")]))
    # 공유 NS
    link(_k(EntityType.DOMAIN,"a.com"), _k(EntityType.DOMAIN,"ns.shared.net"), "네임서버")
    link(_k(EntityType.DOMAIN,"b.com"), _k(EntityType.DOMAIN,"ns.shared.net"), "네임서버")
    # 공유 IP
    link(_k(EntityType.DOMAIN,"a.com"), _k(EntityType.IP,"1.2.3.4"), "해석됨(A)")
    link(_k(EntityType.DOMAIN,"b.com"), _k(EntityType.IP,"1.2.3.4"), "해석됨(A)")
    # 그 IP 의 origin ASN → 두 도메인 asn 신호 공유
    link(_k(EntityType.IP,"1.2.3.4"), _k(EntityType.ASN,"AS64500"), "origin ASN")
    return g

def t_same_operator_cp():
    g = _seed_graph_for_correlation()
    gate = VerificationGate(tau=0.30, floor=0.05, alpha=0.05)
    edges = correlate_same_operator(g, gate=gate, n_signals=4,
                                    signal_kinds=("ns", "ip", "asn", "registrar"), link=True)
    check(len(edges) == 1, f"동일운영자 후보 1쌍 기대 {len(edges)}")
    e = edges[0]
    # 공유 신호 k=3 (ns, ip, asn), n=4 → CP 하한과 정확히 일치해야(점추정 아님)
    expect_lo = cp_lower(3, 4, 0.05)
    check(abs((e.confidence or 0) - expect_lo) < 1e-9 or e.certainty == Certainty.CONFIRMED,
          f"동일운영자 confidence=CP하한 {e.confidence} vs {expect_lo:.4f}")
    check("3/4" in e.evidence[0].detail, f"근거표기 {e.evidence[0].detail}")
    # 게이트 판정이 judge(3,4)와 일치
    verd = gate.judge(3, 4)
    if verd.verdict == VERDICT_CONFIRMED:
        check(e.certainty == Certainty.CONFIRMED, "판정=확정인데 엣지 확실 아님")
    else:
        check(e.certainty == Certainty.UNCONFIRMED, "판정=불확실인데 엣지 확실")
    print(f"  same-operator: 공유 3/4 → CP하한 {expect_lo:.3f}, 판정 {verd.verdict}")

def _graph_shared(kinds, cert_ids_a=None, cert_ids_b=None):
    """a.com/b.com 이 주어진 신호축들을 공유하도록 그래프 구성."""
    g = Graph()
    def add(t, v, **at):
        return g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED,
                            evidence=[Evidence("t","")], attrs=at))
    add(EntityType.DOMAIN, "a.com", cert_ids=list(cert_ids_a or []))
    add(EntityType.DOMAIN, "b.com", cert_ids=list(cert_ids_b or []))
    add(EntityType.DOMAIN, "ns.shared.net"); add(EntityType.DOMAIN, "mail.shared.net")
    add(EntityType.IP, "1.2.3.4"); add(EntityType.ASN, "AS64500")
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED,
                    evidence=[Evidence("t","")]))
    if "ns" in kinds:
        link(_k(EntityType.DOMAIN,"a.com"), _k(EntityType.DOMAIN,"ns.shared.net"), "네임서버")
        link(_k(EntityType.DOMAIN,"b.com"), _k(EntityType.DOMAIN,"ns.shared.net"), "네임서버")
    if "ip" in kinds or "asn" in kinds:
        link(_k(EntityType.DOMAIN,"a.com"), _k(EntityType.IP,"1.2.3.4"), "해석됨(A)")
        link(_k(EntityType.DOMAIN,"b.com"), _k(EntityType.IP,"1.2.3.4"), "해석됨(A)")
        link(_k(EntityType.IP,"1.2.3.4"), _k(EntityType.ASN,"AS64500"), "origin ASN")
    if "mx" in kinds:
        link(_k(EntityType.DOMAIN,"a.com"), _k(EntityType.DOMAIN,"mail.shared.net"), "메일서버")
        link(_k(EntityType.DOMAIN,"b.com"), _k(EntityType.DOMAIN,"mail.shared.net"), "메일서버")
    return g

def t_mx_and_cocert_signals():
    # 공유 MX
    g = _graph_shared({"mx"})
    e = correlate_same_operator(g, n_signals=6, link=False)
    check(len(e) == 1 and "mx:1" in e[0].evidence[0].detail, f"MX 신호 {e and e[0].evidence[0].detail}")
    # 공유 인증서 id(cert_ids 교차) → co_cert
    g2 = _graph_shared(set(), cert_ids_a=["777","888"], cert_ids_b=["888","999"])
    e2 = correlate_same_operator(g2, n_signals=6, link=False)
    check(len(e2) == 1 and "co_cert:1" in e2[0].evidence[0].detail, f"co_cert 신호 {e2 and e2[0].evidence[0].detail}")
    print("  MX / co_cert 신호: 각각 독립 축으로 잡힘 OK")

def t_more_signals_tightens_bound():
    # 5개 축(ns,ip,asn,mx,co_cert) 공유 → k=5,n=6
    g5 = _graph_shared({"ns","ip","asn","mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    e5 = correlate_same_operator(g5, n_signals=6, link=False,
            signal_kinds=("ns", "ip", "asn", "mx", "co_cert", "registrar"))
    check(len(e5) == 1, f"5축 공유 후보 {len(e5)}")
    lo5 = e5[0].confidence if e5[0].certainty != Certainty.CONFIRMED else 1.0
    exp5 = cp_lower(5, 6, 0.05)
    check(abs(lo5 - exp5) < 1e-9 or e5[0].certainty == Certainty.CONFIRMED,
          f"5/6 CP하한 {lo5} vs {exp5:.4f}")
    # 약한 축 3/4 케이스와 비교 → 하한이 실제로 조여져야 함
    lo_weak = cp_lower(3, 4, 0.05)
    check(exp5 > lo_weak, f"신호 늘려도 하한 안 조여짐 {exp5:.4f} !> {lo_weak:.4f}")
    print(f"  신호축 확대: 3/4 하한 {lo_weak:.3f} → 5/6 하한 {exp5:.3f} (조여짐 확인)")

def t_corroborate_edges():
    # 엣지 하나가 3개 독립 출처로 확증 → k=3,n=3 → CP 하한이 confidence 로
    e = Edge(src="domain:a.com", dst="ip:1.2.3.4", relation="해석됨(A)",
             certainty=Certainty.UNCONFIRMED,
             evidence=[Evidence("doh-dns","A"), Evidence("rdap-ip","A"),
                       Evidence("ripestat-ip-asn","A"), Evidence("cp-gate","무시됨")])
    gate = VerificationGate(tau=0.80, floor=0.10, alpha=0.05)
    rep = corroborate_edges([e], gate, n_sources=3, apply=True)
    check(rep[0]["k"] == 3 and rep[0]["n"] == 3, f"독립출처 카운트 {rep[0]}")
    check(abs((e.confidence or 0) - cp_lower(3,3,0.05)) < 1e-9, f"confidence=CP하한 {e.confidence}")
    check(rep[0]["verdict"] == VERDICT_UNCONFIRMED and not rep[0]["dropped"], "3/3 판정")
    # 근거 거의 없음(k=0, n=40) → drop 플래그
    e2 = Edge(src="domain:x.com", dst="ip:9.9.9.9", relation="해석됨(A)",
              certainty=Certainty.UNCONFIRMED, evidence=[Evidence("cp-gate","무시")])
    rep2 = corroborate_edges([e2], gate, n_sources=40, apply=False)
    check(rep2[0]["k"] == 0 and rep2[0]["dropped"], f"근거없음 drop {rep2[0]}")
    print(f"  corroborate: 3독립출처→CP하한 {cp_lower(3,3,0.05):.3f}, 무출처(0/40)→drop OK")

# 정적 인증서 DER 테스트벡터(결정적 EC 키로 사전생성) — cryptography 옵션 의존성 없이도 이 테스트가
# 돈다(과거엔 매 실행마다 _make_cert_der 로 인증서를 만들어 cryptography 없는 클린 머신에서 스위트 전체가
# 크래시했음). A/B 는 다른 키, A2 는 A 와 **같은 키·다른 인증서**(SPKI 핀 동일성 검증용).
import base64 as _b64
_DER_A = _b64.b64decode(
    "MIIBBDCBq6ADAgECAgEBMAoGCCqGSM49BAMCMAwxCjAIBgNVBAMMAWEwHhcNMjAwMTAxMDAwMDAwWhcNMzAw"
    "MTAxMDAwMDAwWjAMMQowCAYDVQQDDAFhMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAhfmF/C2RDkoJ4+W"
    "mZ5pojpPLBUr321s32bluAKC1O0ZSn3ry5dxLS3aPKhaqHZaVvRfx1hZllLyiXxlMG5XlDAKBggqhkjOPQQD"
    "AgNIADBFAiB4jZKtfedz13D7euQpvLrGihgawQ2hoIFGE8W5w1fZwAIhAONuO3rKn1QGzdWANobiR7wPK0Yc"
    "lBcXqebaCVaAYsRk")
_DER_B = _b64.b64decode(
    "MIIBAzCBq6ADAgECAgEBMAoGCCqGSM49BAMCMAwxCjAIBgNVBAMMAWIwHhcNMjAwMTAxMDAwMDAwWhcNMzAw"
    "MTAxMDAwMDAwWjAMMQowCAYDVQQDDAFiMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1lqTl3yqPRsIGFL/"
    "V6eeRl8WYFdzBLrq1QXdOkhYnPNQGF6JU3LfYiHqOhN1V+Rz/dtnVfBb1QfDxTP86ckShTAKBggqhkjOPQQD"
    "AgNHADBEAiBca+dHqDQttmfoqO/A1zUWoP30qGMbfVMgorjSaLVTGgIgWFRJ3dlLSHRJLCXmZRwBw9rDcySP"
    "x6CxuYqdiBbiJlM=")
_DER_A2 = _b64.b64decode(
    "MIIBDDCBs6ADAgECAgEBMAoGCCqGSM49BAMCMBAxDjAMBgNVBAMMBWEtYWx0MB4XDTIwMDEwMTAwMDAwMFoX"
    "DTMwMDEwMTAwMDAwMFowEDEOMAwGA1UEAwwFYS1hbHQwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAQCF+YX"
    "8LZEOSgnj5aZnmmiOk8sFSvfbWzfZuW4AoLU7RlKfevLl3EtLdo8qFqodlpW9F/HWFmWUvKJfGUwbleUMAoG"
    "CCqGSM49BAMCA0gAMEUCIHKjeEPBm4OX4oz4Rb0f4BMcqD9GXE20tDutw2KPxg5VAiEAtwlcLxf9Bo/PvGvl"
    "Vz8H9lO2ftvonfHlpMvPb2/y4Yc=")

def _make_cert_der(cn="x"):
    """정적 벡터 반환(하위호환용). cn='a'→A, 'b'→B, 'a-alt'→A2(=A와 같은 키)."""
    return {"a": _DER_A, "b": _DER_B, "a-alt": _DER_A2}.get(cn, _DER_A)

async def t_tls_spki():
    from artes.core.infra_recon import TLSProbe, spki_pin
    try:                                        # spki_pin 은 cryptography 없으면 cert:해시로 폴백
        import cryptography  # noqa: F401
        has_crypto = True
    except Exception:
        has_crypto = False
    der, der2, der_same_key = _DER_A, _DER_B, _DER_A2
    async def probe(host): return der
    res = await TLSProbe(probe=probe).fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(res.ok and res.entities, "TLSProbe 결과")
    pin_attr = res.entities[0].attrs.get("spki", "")
    if has_crypto:                              # SPKI 파싱 경로
        check(pin_attr.startswith("spki:"), f"SPKI 핀 attr {pin_attr[:12]}")
    else:                                       # cryptography 미설치 → 전체 인증서 해시 폴백(크래시 아님)
        check(pin_attr.startswith("cert:"), f"cert 해시 폴백 attr {pin_attr[:12]}")
    check(spki_pin(der) == spki_pin(der), "핀 결정성")
    check(spki_pin(der) != spki_pin(der2), "다른 키 → 다른 핀")
    if has_crypto:                              # 같은 키·다른 인증서 → 같은 SPKI 핀(SPKI 핀의 핵심 성질)
        check(spki_pin(der) == spki_pin(der_same_key), "같은 키·다른 인증서 → 같은 SPKI 핀")
    else:                                       # 폴백은 인증서 전체 해시라 다른 인증서면 다름(정직)
        check(spki_pin(der) != spki_pin(der_same_key), "폴백(cert해시): 다른 인증서 → 다른 핀")
    # probe None(인증서 없음) → 우아하게 실패
    async def none_probe(host): return None
    res2 = await TLSProbe(probe=none_probe).fetch(InfraTarget(InfraType.DOMAIN, "a.com"), None)
    check(not res2.ok, "인증서 없으면 실패(크래시 아님)")
    print(f"  TLS SPKI: 핀 추출/결정성/무인증서 처리 OK ({'spki' if has_crypto else 'cert폴백'} 경로, 정적벡터)")

def t_spf_parse_and_eight_axis():
    # DoH TXT → SPF include 파싱
    async def _doh():
        http = FakeHTTP({
            "type=TXT": R({"Answer": [{"type": 16,
                "data": "v=spf1 include:_spf.google.com include:sendgrid.net ~all"}]}),
            "type=": R({"Answer": []}),
        })
        res = await DoHDNS().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), http)
        dom = [e for e in res.entities if e.value == "example.com" and e.attrs.get("spf_includes")]
        return dom
    dom = asyncio.run(_doh())
    check(dom and set(dom[0].attrs["spf_includes"]) == {"_spf.google.com", "sendgrid.net"},
          f"SPF include 파싱 {dom and dom[0].attrs.get('spf_includes')}")

    # 8축: a,b 가 ns/ip/asn/mx/co_cert/spf/spki 7개 공유 → k=7, n=8
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    for key in (_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "b.com")):
        ent = g.get(key)
        ent.attrs.setdefault("spf_includes", []).append("_spf.shared.net")
        ent.attrs["spki"] = "spki:deadbeef"
    e = correlate_same_operator(g, n_signals=8, link=False,   # 8축 기준 고정
            signal_kinds=("ns", "ip", "asn", "registrar", "mx", "co_cert", "spf", "spki"))
    check(len(e) == 1, f"8축 후보 {len(e)}")
    lo = e[0].confidence if e[0].certainty != Certainty.CONFIRMED else 1.0
    exp = cp_lower(7, 8, 0.05)
    check(abs(lo - exp) < 1e-9 or e[0].certainty == Certainty.CONFIRMED, f"7/8 하한 {lo} vs {exp}")
    check(exp > cp_lower(5, 6, 0.05), f"8축이 6축보다 조여야 {exp:.3f}>{cp_lower(5,6,0.05):.3f}")
    print(f"  SPF 파싱 + 8축: 5/6 {cp_lower(5,6,0.05):.3f} → 7/8 {exp:.3f} (더 조임)")

def t_ten_axis_tighten():
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    for key in (_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "b.com")):
        ent = g.get(key)
        ent.attrs.setdefault("spf_includes", []).append("_spf.x")
        ent.attrs["spki"] = "spki:aa"; ent.attrs["favicon"] = "fav1"; ent.attrs["httpfp"] = "fp1"
    e = correlate_same_operator(g, link=False, n_signals=10,   # 10축 기준 고정
            signal_kinds=("ns", "ip", "asn", "registrar", "mx", "co_cert",
                          "spf", "spki", "favicon", "httpfp"))
    check(len(e) == 1, f"10축 후보 {len(e)}")
    lo = e[0].confidence if e[0].certainty != Certainty.CONFIRMED else 1.0
    exp = cp_lower(9, 10, 0.05)
    check(abs(lo - exp) < 1e-9 or e[0].certainty == Certainty.CONFIRMED, f"9/10 {lo} vs {exp}")
    check(exp > cp_lower(7, 8, 0.05), f"10축>8축 {exp:.3f}>{cp_lower(7,8,0.05):.3f}")
    print(f"  10축: 7/8 {cp_lower(7,8,0.05):.3f} → 9/10 {exp:.3f} (더 조임)")

def t_cypher_batch():
    from artes.core import graph_io
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="e'vil.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")]))
    g.add(Entity(type=EntityType.IP, value="1.2.3.4", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")]))
    g.link(Edge(src=_k(EntityType.DOMAIN, "e'vil.com"), dst=_k(EntityType.IP, "1.2.3.4"),
                relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    batches = list(graph_io.to_cypher_batch(g, batch_size=1000))
    node_rows = sum(len(b["parameters"]["rows"]) for b in batches if "MERGE (n:" in b["statement"])
    edge_rows = sum(len(b["parameters"]["rows"]) for b in batches if "MATCH (a:" in b["statement"])
    check(node_rows == 2 and edge_rows == 1, f"배치 커버리지 {node_rows},{edge_rows}")
    allstmt = " ".join(b["statement"] for b in batches)
    check("e'vil.com" not in allstmt, "값이 statement 에 박히면 injection")
    check(any(r.get("value") == "e'vil.com" for b in batches for r in b["parameters"]["rows"]),
          "값은 params 로")
    check("UNWIND $rows" in allstmt, "파라미터라이즈드")
    print("  Cypher 배치: UNWIND $rows, 값 params화(injection-safe) OK")

def t_gzip_shard():
    from artes.core import graph_io
    import tempfile, os, glob
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    ne, nl = len(g.entities), len(g.edges)
    with tempfile.TemporaryDirectory() as d:
        gz = os.path.join(d, "g.ndjson.gz")
        graph_io.stream_ndjson(g, gz)
        check(os.path.getsize(gz) > 0, "gzip 파일 생성")
        g2 = graph_io.load_ndjson(gz)
        check(len(g2.entities) == ne and len(g2.edges) == nl, f"gzip 라운드트립 {len(g2.entities)}/{len(g2.edges)}")
        sd = os.path.join(d, "shards")
        info = graph_io.shard_ndjson(g, sd, shards=3, gzip_out=True)
        check(info["entities"] == ne and info["edges"] == nl, f"샤드 기록 {info}")
        check(len(glob.glob(os.path.join(sd, "entities-*.gz"))) == 3, "엔티티 샤드 3개")
        g3 = graph_io.load_ndjson_dir(sd)
        check(len(g3.entities) == ne and len(g3.edges) == nl, f"샤드 라운드트립 {len(g3.entities)}/{len(g3.edges)}")
    print(f"  gzip+샤딩: gzip 라운드트립 + 3샤드 병렬로드용 라운드트립({ne}E/{nl}L) OK")

def t_twelve_axis_tighten():
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    for key in (_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "b.com")):
        ent = g.get(key)
        ent.attrs.setdefault("spf_includes", []).append("_spf.x")
        ent.attrs.update({"spki": "spki:aa", "favicon": "f1", "httpfp": "h1",
                          "tlsfp": "tlsfp:t1"})
    e = correlate_same_operator(g, link=False, n_signals=12,   # 12축 기준 고정
            signal_kinds=("ns", "ip", "asn", "registrar", "mx", "co_cert",
                          "spf", "spki", "favicon", "httpfp", "netblock", "tlsfp"))
    check(len(e) == 1, f"12축 후보 {len(e)}")
    lo = e[0].confidence if e[0].certainty != Certainty.CONFIRMED else 1.0
    exp = cp_lower(11, 12, 0.05)
    check(abs(lo - exp) < 1e-9 or e[0].certainty == Certainty.CONFIRMED, f"11/12 {lo} vs {exp}")
    check(exp > cp_lower(9, 10, 0.05), f"12축>10축 {exp:.3f}>{cp_lower(9,10,0.05):.3f}")
    check("공유 인프라 신호 11/12" in e[0].evidence[0].detail, f"신호수 표기 {e[0].evidence[0].detail}")
    print(f"  12축(+netblock/tlsfp): 9/10 {cp_lower(9,10,0.05):.3f} → 11/12 {exp:.3f} (더 조임)")

def t_neo4j_push():
    from artes.core import graph_io
    g = _graph_shared({"ns", "ip"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    st = {"n": 0, "failed": False}
    seen = []
    def run(stmt, params):
        st["n"] += 1
        seen.append((stmt, params))
        if st["n"] == 2 and not st["failed"]:      # 두번째 호출에서 한 번 일시장애
            st["failed"] = True
            raise RuntimeError("transient")
    info = graph_io.push_to_neo4j(g, run, batch_size=1000, retries=3, sleep=lambda s: None)
    check(info["retried"] == 1, f"재시도 1회 {info}")
    check(info["batches"] == 2, f"배치=노드+간선=2 {info}")
    check(all("UNWIND $rows" in s for s, _ in seen), "파라미터라이즈드 실행")
    check(all("rows" in p for _, p in seen), "params 전달")
    print(f"  neo4j push: 트랜잭션 적재 + 일시장애 재시도 {info}")

def t_parallel_shard_load():
    from artes.core import graph_io
    import tempfile, os
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    ne, nl = len(g.entities), len(g.edges)
    with tempfile.TemporaryDirectory() as d:
        graph_io.shard_ndjson(g, d, shards=3, gzip_out=True)
        gt = graph_io.parallel_load_shards(d, workers=2, use_processes=False)
        check(len(gt.entities) == ne and len(gt.edges) == nl, f"스레드 병렬로드 {len(gt.entities)}/{len(gt.edges)}")
        gp = graph_io.parallel_load_shards(d, workers=2, use_processes=True)
        check(len(gp.entities) == ne and len(gp.edges) == nl, f"프로세스 병렬로드 {len(gp.entities)}/{len(gp.edges)}")
    print(f"  샤드 병렬로드: thread+process 라운드트립({ne}E/{nl}L) OK")

def _graph_14():
    """a.com/b.com 이 13개 신호축을 공유하는 그래프(dmarc/ptr 포함)."""
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    g.get(_k(EntityType.IP, "1.2.3.4")).attrs["ptr_domain"] = "prov.net"
    for key in (_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "b.com")):
        ent = g.get(key)
        ent.attrs.setdefault("spf_includes", []).append("_spf.x")
        ent.attrs.update({"spki": "spki:aa", "favicon": "f1", "httpfp": "h1",
                          "tlsfp": "tlsfp:t1"})
        ent.attrs.setdefault("dmarc", []).append("agg.example")
    return g

def t_fourteen_axis_tighten():
    g = _graph_14()
    e = correlate_same_operator(g, link=False)          # 기본 n=14
    check(len(e) == 1, f"14축 후보 {len(e)}")
    lo = e[0].confidence if e[0].certainty != Certainty.CONFIRMED else 1.0
    exp = cp_lower(13, 14, 0.05)
    check(abs(lo - exp) < 1e-9 or e[0].certainty == Certainty.CONFIRMED, f"13/14 {lo} vs {exp}")
    check(exp > cp_lower(11, 12, 0.05), f"14축>12축 {exp:.3f}>{cp_lower(11,12,0.05):.3f}")
    check("13/14" in e[0].evidence[0].detail, f"신호수 {e[0].evidence[0].detail}")
    print(f"  14축(+dmarc/ptr): 11/12 {cp_lower(11,12,0.05):.3f} → 13/14 {exp:.3f} (더 조임)")

def t_incremental_same_operator():
    from artes.core.infra_recon import incremental_same_operator, OperatorIndex
    g = _graph_14()
    gate = VerificationGate(tau=0.5, floor=0.1, alpha=0.05)
    batch = correlate_same_operator(g, gate=gate, link=False)
    idx = incremental_same_operator(g, gate=gate)
    ip = idx.pairs()
    check(len(batch) == 1 and len(ip) == 1, f"쌍수 batch {len(batch)} inc {len(ip)}")
    check(ip[0]["k"] == 13, f"증분 k {ip[0]['k']} (13 기대)")
    check(abs(ip[0]["lower"] - cp_lower(13, 14, 0.05)) < 1e-6, "증분 lower=CP하한")
    # 증분 클러스터: 3-체인 동치(공유 ns/ip 2/2 → 확정 union)
    idx2 = OperatorIndex(gate=VerificationGate(tau=0.1, floor=0.01, alpha=0.05),
                         n_signals=2, signal_kinds=("ns", "ip"))
    for dv in ("d:a", "d:b", "d:c"):
        idx2.add(dv, {"ns": {"x"}, "ip": {"y"}})
    cl = idx2.clusters()
    check(len(cl) == 1 and set(cl[0]) == {"d:a", "d:b", "d:c"}, f"증분 클러스터 {cl}")
    print(f"  증분 same-operator: batch와 k=13 동치, 3체인 클러스터 동치(전체 재계산 없이)")

def t_stream_load_shards():
    from artes.core import graph_io
    import tempfile, os
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    ne, nl = len(g.entities), len(g.edges)
    with tempfile.TemporaryDirectory() as d:
        graph_io.shard_ndjson(g, d, shards=3, gzip_out=True)
        g2 = graph_io.stream_load_shards(d, workers=3)
        check(len(g2.entities) == ne and len(g2.edges) == nl,
              f"경량 스트림 로드 {len(g2.entities)}/{len(g2.edges)}")
    print(f"  stream_load_shards: 락보호 라인스트리밍 라운드트립({ne}E/{nl}L) OK")

def t_operator_clusters():
    # a-b, b-c 동일운영자(체인) → 한 클러스터 {a,b,c}
    g = Graph()
    for v in ["a.com","b.com","c.com","z.com"]:
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t","")]))
    from artes.core.infra_recon import SAME_OPERATOR_SIGNAL_REL
    def op(s,d,conf):
        g.link(Edge(src=_k(EntityType.DOMAIN,s), dst=_k(EntityType.DOMAIN,d),
                    relation=SAME_OPERATOR_SIGNAL_REL, certainty=Certainty.UNCONFIRMED,
                    confidence=conf, evidence=[Evidence("t","")]))
    op("a.com","b.com",0.50); op("b.com","c.com",0.60)   # z.com 은 무연결
    clusters = operator_clusters(g, min_lower=0.30)
    check(len(clusters) == 1, f"클러스터 1개 기대 {len(clusters)}")
    check(clusters[0]["size"] == 3, f"클러스터 크기 3 기대 {clusters[0]['size']}")
    check(abs(clusters[0]["min_edge_lower"] - 0.50) < 1e-9, "연결간선 최소 하한 0.50")
    # 문턱 올리면 약한 간선(0.50) 제외 → {b,c} 만
    clusters2 = operator_clusters(g, min_lower=0.55)
    check(len(clusters2) == 1 and clusters2[0]["size"] == 2, f"문턱0.55 → 크기2 {clusters2}")
    check("a.com" not in clusters2[0]["values"], "약한 간선 제외 실패")
    print(f"  operator_clusters: 체인 a-b-c → 1클러스터(3), 문턱↑ → {clusters2[0]['values']}")

def t_cli_dry():
    import io, contextlib
    from artes import cli_infra
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = cli_infra.main(["example.com", "8.8.8.8", "AS15169", "hong@gmail.com",
                             "--dry", "--case", "T-1", "--operator", "tester"])
    check(rc == 0, f"CLI rc {rc}")
    data = _json.loads(buf.getvalue())
    check(data["case"] == "T-1" and data["dry"] is True, "CLI 메타")
    skipped_vals = {s["value"] for s in data["skipped"]}
    check("hong@gmail.com" in skipped_vals, f"CLI 사람 selector 거부 {skipped_vals}")
    check(data["audit"]["chain_ok"] is True, "CLI 감사 체인 무결")
    check("clusters" in data and "signal_sharing_cp_clusters" in data and "graph" in data,
          "CLI 출력 구조(권위 clusters + 보조 CP + graph)")
    print(f"  CLI scan-infra --dry: rc=0, 사람 selector 거부 {sorted(skipped_vals)}, "
          f"audit_ok, stats={data['stats']}")

def t_cli_register_subparser():
    import argparse, io, contextlib
    from artes import cli_infra
    parser = argparse.ArgumentParser()
    subs = parser.add_subparsers()
    cli_infra.register_subparser(subs)
    args = parser.parse_args(["scan-infra", "example.com", "hong@gmail.com",
                              "--dry", "--case", "R"])
    check(hasattr(args, "_func"), "서브파서 _func 등록")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = args._func(args)
    check(rc == 0, f"서브커맨드 rc {rc}")
    data = _json.loads(buf.getvalue())
    check(data["case"] == "R" and any(s["value"] == "hong@gmail.com" for s in data["skipped"]),
          "서브커맨드 동작(사람 selector 거부 포함)")
    print("  CLI register_subparser: artes scan-infra 등록·디스패치 OK")

def t_graph_io():
    from artes.core import graph_io
    import tempfile, os
    g = _graph_shared({"ns", "ip", "asn", "mx"}, cert_ids_a=["c1"], cert_ids_b=["c1"])
    ne, nl = len(g.entities), len(g.edges)
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "g.ndjson")
        n = graph_io.stream_ndjson(g, p)
        check(n == ne + nl, f"NDJSON 레코드 {n} vs {ne+nl}")
        g2 = graph_io.load_ndjson(p)
        check(len(g2.entities) == ne and len(g2.edges) == nl,
              f"라운드트립 {len(g2.entities)}E/{len(g2.edges)}L vs {ne}/{nl}")
        cpath = os.path.join(d, "g.cypher")
        m = graph_io.write_cypher(g, cpath)
        check(m == ne + nl, f"Cypher 문수 {m}")
        text = open(cpath, encoding="utf-8").read()
        check("MERGE (n:Asset" in text, "Cypher 노드 MERGE")
        check("MATCH (a:Asset" in text and "-[r:LINK" in text, "Cypher 간선 MERGE")
    print(f"  graph_io: NDJSON 라운드트립({ne}E/{nl}L) + Cypher {ne+nl}문 OK")

def t_signals_100_registry():
    from artes.core.signals import SIGNAL_KINDS_100, gather_signals
    check(len(SIGNAL_KINDS_100) == 100, f"신호축 수 {len(SIGNAL_KINDS_100)}")
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")],
                 attrs={"txt_tokens": {"google-site-verification": "abc"},
                        "http_headers": {"strict-transport-security": "max-age=1"}}))
    g.add(Entity(type=EntityType.IP, value="1.2.3.4", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")]))
    g.link(Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.IP, "1.2.3.4"),
                relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    da = gather_signals(g)[_k(EntityType.DOMAIN, "a.com")]
    check("a_ip" in da and "nb24" in da, f"DNS/넷블록 축 {sorted(da)[:6]}")
    check("txt_google-site-verification" in da, "TXT 벤더 축")
    check("hdr_strict-transport-security" in da, "보안헤더 축")
    print(f"  100-신호 레지스트리: {len(SIGNAL_KINDS_100)}축, gather 추출(DNS/넷블록/TXT/헤더) OK")

def t_fast_same_operator():
    from artes.core.infra_recon import fast_same_operator
    g = _graph_14()
    idx = fast_same_operator(g, gate=VerificationGate(tau=0.1, floor=0.01, alpha=0.05), max_bucket=64)
    pr = idx.pairs()
    check(len(pr) >= 1, f"fast 후보쌍 {len(pr)}")
    check(pr[0]["k"] >= 10, f"공유 축수 {pr[0]['k']} (다수 축 공유 기대)")
    print(f"  fast_same_operator: 100축 역인덱스, a-b 공유 {pr[0]['k']}축 검출")

def t_max_bucket_suppression():
    from artes.core.infra_recon import OperatorIndex
    import itertools
    # df=5 > max_bucket=3 → 값 'g' 는 제네릭 → 쌍 기여 0 (삽입순서 무관, 결정적 — 리뷰 P1).
    def pairvals(order, mb=3):
        idx = OperatorIndex(n_signals=1, signal_kinds=("ns",), max_bucket=mb, judge_cp=False)
        for d in order:
            idx.add(d, {"ns": {"g"}})
        return frozenset(frozenset(p) for p in idx.pair_vals)
    check(len(pairvals(["d0", "d1", "d2", "d3", "d4"])) == 0, "df>max_bucket → 제네릭(쌍 0)")
    # 순열 불변: 모든 삽입순서가 동일 결과(예전엔 순서에 따라 달랐음 = 버그)
    results = {pairvals(list(p)) for p in itertools.permutations(["a", "b", "c", "d", "e"])}
    check(len(results) == 1, f"모든 삽입순서 동일 결과(순열불변) — {len(results)}가지")
    # df=3 <= max_bucket → C(3,2)=3 쌍(정상 기여)
    check(len(pairvals(["a", "b", "c"])) == 3, "df<=max_bucket → 전부 쌍 생성")
    print(f"  max_bucket 결정성(P1): df>cap → 제네릭 0쌍, 순열불변, df<=cap → 정상")

def t_100_faster_than_12():
    import time as _t
    from artes.core.infra_recon import fast_same_operator, correlate_same_operator
    N, C = 900, 6
    g = Graph()
    def add(t, v, **at):
        g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")], attrs=at))
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED,
                    evidence=[Evidence("t", "")]))
    for i in range(N):
        dom = f"d{i}.com"; add(EntityType.DOMAIN, dom)
        cl = i // C
        nsv = f"ns{cl}.prov.net"; ipv = f"10.{cl}.0.5"   # 클러스터별 고유(교차 공유 없음)
        add(EntityType.DOMAIN, nsv); add(EntityType.IP, ipv)
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.DOMAIN, nsv), "네임서버")
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.IP, ipv), "해석됨(A)")
    gate = VerificationGate(tau=0.05, floor=0.001, alpha=0.05)
    t0 = _t.perf_counter()
    idx = fast_same_operator(g, gate=gate, max_bucket=64)
    tf = _t.perf_counter() - t0
    kinds12 = ("ns", "ip", "asn", "registrar", "mx", "co_cert",
               "spf", "spki", "favicon", "httpfp", "netblock", "tlsfp")
    t1 = _t.perf_counter()
    correlate_same_operator(g, gate=gate, n_signals=12, signal_kinds=kinds12, link=False)
    to = _t.perf_counter() - t1
    cl = idx.clusters()
    check(len(cl) == N // C, f"fast 클러스터 {len(cl)} (기대 {N//C})")
    check(all(len(c) == C for c in cl), "모든 클러스터 크기 6")
    check(tf < to, f"fast(100축) {tf:.3f}s < old(12축 all-pairs) {to:.3f}s 이어야")
    print(f"  100축 vs 12축 속도: fast(100축) {tf:.3f}s < old(12축 all-pairs) {to:.3f}s "
          f"→ {to/max(tf,1e-6):.1f}× 빠름 (클러스터 {len(cl)}개 정확)")

def t_extended_registry():
    from artes.core.signals import EXTENDED_KINDS, gather_signals, EXTENDED_SPECS
    check(len(EXTENDED_KINDS) >= 150, f"확장 축수 {len(EXTENDED_KINDS)}")
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")],
                 attrs={"caa": ["letsencrypt.org"], "cdn": "cloudflare",
                        "http_headers": {"content-type": "text/html"}}))
    da = gather_signals(g, EXTENDED_SPECS).get(_k(EntityType.DOMAIN, "a.com"), {})
    check("caa" in da and "cdn" in da, f"확장 축 추출 {sorted(da)[:5]}")
    print(f"  확장 레지스트리: {len(EXTENDED_KINDS)}축, 확장 패밀리(CAA/CDN/헤더) 추출 OK")

def t_coincidence_idf():
    from artes.core.infra_recon import OperatorIndex
    from artes.core.verify_cp import coincidence_prob
    check(coincidence_prob([2, 2, 2], 1000) < 1e-7, "희소 3값 공유 → 극소 우연확률")
    check(coincidence_prob([1000], 1000) >= 0.99, "제네릭값 → 우연확률≈1")
    check(coincidence_prob([2, 2, 2], 1000) < coincidence_prob([2, 2], 1000), "더 많은 희소공유=더 강한 증거")
    idx = OperatorIndex(n_signals=100, signal_kinds=("ns", "ip", "mx"),
                        max_bucket=100000, track_values=True)
    idx.add("a", {"ns": {"rareNS"}, "ip": {"rareIP"}})
    idx.add("b", {"ns": {"rareNS"}, "ip": {"rareIP"}})       # a,b 희소 2값 공유(df=2)
    for i in range(50):
        idx.add(f"g{i}", {"mx": {"bigMX"}})                  # generic mx (df=50)
    cp = idx.coincidence_pairs(threshold=1e-3)
    check(any(p["a"] == "a" and p["b"] == "b" for p in cp), f"a-b 희소공유 검출 {cp[:1]}")
    check(all(not (p["a"].startswith("g") and p["b"].startswith("g")) for p in cp),
          "generic mx 쌍은 우연확률↑ → 제외")
    cl = idx.coincidence_clusters(threshold=1e-3)
    check(any(set(c) == {"a", "b"} for c in cl), f"희소 클러스터 {cl}")
    print(f"  IDF 우연일치: 희소 2값(df=2,N={len(idx.domains)}) 검출 / generic 제외 (정확 확률)")

def t_streaming_callback():
    from artes.core.infra_recon import OperatorIndex
    confirmed = []
    idx = OperatorIndex(gate=VerificationGate(tau=0.1, floor=0.01, alpha=0.05),
                        n_signals=2, signal_kinds=("ns", "ip"), max_bucket=100,
                        on_confirm=lambda a, b: confirmed.append((a, b)))
    r1 = idx.add("a", {"ns": {"x"}, "ip": {"y"}})
    check(r1 == [], "첫 도메인 확정 없음")
    r2 = idx.add("b", {"ns": {"x"}, "ip": {"y"}})
    check(("a", "b") in r2 and ("a", "b") in confirmed, f"b 도착 즉시 확정 통지 {r2}")
    r3 = idx.add("c", {"ns": {"x"}, "ip": {"y"}})
    check(len(r3) == 2, f"c 도착 시 2쌍 확정 {r3}")
    check(any(set(cl) == {"a", "b", "c"} for cl in idx.clusters()), "실시간 클러스터 갱신")
    print("  스트리밍 콜백: 도메인 도착마다 확정 즉시 통지 + 실시간 클러스터")

def t_scale_flat():
    import time as _t
    from artes.core.infra_recon import fast_same_operator
    from artes.core.signals import SIGNAL_SPECS, EXTENDED_SPECS, pad_specs
    N, C = 600, 6
    g = Graph()
    def add(t, v):
        g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for i in range(N):
        cl = i // C
        # 같은 운영자 클러스터 = 독립 지문 다수 공유(NS+IP+favicon+SPKI). IP파생 넷블록에 기대지 않음
        # (의존성 붕괴 후에도 정당하게 뭉치도록 — 리뷰 반영: 중첩 넷블록은 독립 증거 아님).
        dom = f"d{i}.com"
        g.add(Entity(type=EntityType.DOMAIN, value=dom, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")], attrs={"favicon": f"fav{cl}", "spki": f"spki{cl}"}))
        nsv = f"ns{cl}.p.net"; ipv = f"10.{cl}.0.5"
        add(EntityType.DOMAIN, nsv); add(EntityType.IP, ipv)
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.DOMAIN, nsv), "네임서버")
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.IP, ipv), "해석됨(A)")
    gate = VerificationGate(tau=0.05, floor=0.001, alpha=0.05)
    t0 = _t.perf_counter(); i1 = fast_same_operator(g, gate=gate, specs=SIGNAL_SPECS, max_bucket=64); a = _t.perf_counter() - t0
    specs300 = pad_specs(EXTENDED_SPECS, 300)
    t1 = _t.perf_counter(); i2 = fast_same_operator(g, gate=gate, specs=specs300, max_bucket=64); b = _t.perf_counter() - t1
    # 클러스터 동일성은 축수(n)에 안 흔들리는 coincidence 로 확인(k/n CP 는 n 에 민감 — 정상).
    c1 = i1.coincidence_clusters(threshold=1e-6)
    c2 = i2.coincidence_clusters(threshold=1e-6)
    check(len(c1) == N // C and len(c2) == N // C, f"100·300축 동일 클러스터 {len(c1)}/{len(c2)}")
    check(b < a * 2.0 + 0.25, f"300축 {b:.3f}s ~ 100축 {a:.3f}s (near-flat)")
    print(f"  스케일 near-flat: 100축 {a:.3f}s → 300축 {b:.3f}s (축 3배, 시간 ~유지 — 역인덱스)")

def t_gather_parallel_equiv():
    from artes.core.signals import gather_signals, gather_signals_parallel, EXTENDED_SPECS
    g = Graph()
    def add(t, v, **at):
        g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")], attrs=at))
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for i in range(400):
        dom = f"d{i}.com"; add(EntityType.DOMAIN, dom, spki=f"k{i%20}")
        ipv = f"10.0.{i % 50}.5"; add(EntityType.IP, ipv)
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.IP, ipv), "해석됨(A)")
    s1 = gather_signals(g, EXTENDED_SPECS)
    s2 = gather_signals_parallel(g, EXTENDED_SPECS, workers=4)
    check(s1.keys() == s2.keys(), "병렬 gather 키 동일")
    check(all(s1[k] == s2[k] for k in s1), "병렬 gather 값 동일")
    print(f"  gather 병렬: {len(s1)}도메인 serial==parallel(4 workers) 동치")

def t_coincidence_default_bench():
    import time as _t
    from artes.core.infra_recon import fast_clusters
    from artes.core.signals import EXTENDED_SPECS
    N, C = 3000, 6
    g = Graph()
    def add(t, v):
        g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    def link(s, d, rel):
        g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for i in range(N):
        cl = i // C
        # 클러스터마다 고유 /16 + 독립 지문(NS·favicon·SPKI). 의존성 붕괴 후에도 정당히 뭉침.
        dom = f"d{i}.com"
        g.add(Entity(type=EntityType.DOMAIN, value=dom, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")], attrs={"favicon": f"fav{cl}", "spki": f"spki{cl}"}))
        nsv = f"ns{cl}.p.net"; ipv = f"{10 + cl // 250}.{cl % 250}.0.5"
        add(EntityType.DOMAIN, nsv); add(EntityType.IP, ipv)
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.DOMAIN, nsv), "네임서버")
        link(_k(EntityType.DOMAIN, dom), _k(EntityType.IP, ipv), "해석됨(A)")
    t0 = _t.perf_counter()
    cl = fast_clusters(g, threshold=1e-6, specs=EXTENDED_SPECS, use_cp_upper=False, max_bucket=64)
    dt = _t.perf_counter() - t0
    check(len(cl) == N // C, f"coincidence 클러스터 {len(cl)} (기대 {N//C})")
    check(all(len(c) == C for c in cl), "모든 클러스터 크기 6")
    print(f"  coincidence 대량: {N}도메인 × {len(EXTENDED_SPECS)}축 → {len(cl)}클러스터 {dt:.2f}s (축수-무관 판정)")

def t_freshness_prune():
    from artes.core.infra_recon import OperatorIndex
    idx = OperatorIndex(gate=VerificationGate(tau=0.1, floor=0.01, alpha=0.05),
                        n_signals=2, signal_kinds=("ns", "ip"), max_bucket=100)
    idx.add("a", {"ns": {"x"}, "ip": {"y"}}, ts=100)
    idx.add("b", {"ns": {"x"}, "ip": {"y"}}, ts=100)
    check(any(set(c) == {"a", "b"} for c in idx.clusters()), "초기 a-b 클러스터")
    removed = idx.prune(before_ts=200)            # ts=100 신호 전부 만료
    check(removed > 0, f"만료 제거 수 {removed}")
    check(idx.clusters() == [], f"만료 후 stale 클러스터 소멸 {idx.clusters()}")
    idx.add("c", {"ns": {"z"}, "ip": {"w"}}, ts=300)
    idx.add("d", {"ns": {"z"}, "ip": {"w"}}, ts=300)
    idx.prune(before_ts=200)                       # 신선(ts=300) 유지
    check(any(set(cc) == {"c", "d"} for cc in idx.clusters()), "신선 c-d 유지")
    print("  freshness prune: TTL 지난 신호 하드컷 → stale 클러스터 소멸 / 신선 유지")

def t_generic_permanent_after_prune():
    """리뷰 P1: 제네릭은 영구 승격. prune 으로 버킷이 max_bucket 이하로 줄어도 되살아나면 안 된다.

    df>max_bucket 로 제네릭이 된 값이, freshness prune 후 버킷이 작아졌다고 _rebuild_pairs 에서
    다시 쌍을 만들면 '과거 제네릭 → 지금 소형버킷 → 증거 재생성'이라는 정책 충돌이 생긴다."""
    from artes.core.infra_recon import OperatorIndex
    idx = OperatorIndex(gate=VerificationGate(tau=0.1, floor=0.01, alpha=0.05),
                        n_signals=1, signal_kinds=("ns",), max_bucket=2)
    idx.add("d1", {"ns": {"g"}}, ts=100)
    idx.add("d2", {"ns": {"g"}}, ts=100)          # 버킷 {d1,d2} 크기2 → 쌍 생성/확정 가능
    idx.add("d3", {"ns": {"g"}}, ts=50)           # 크기3 > max_bucket=2 → ('ns','g') 영구 제네릭
    check(("ns", "g") in idx._generic, "df>cap → ('ns','g') 제네릭 승격")
    check(not any({"d1", "d2"} <= set(c) for c in idx.clusters()), "제네릭 → d1-d2 클러스터 없음")
    idx.prune(before_ts=75)                        # d3(ts=50) 만료 → 버킷 {d1,d2} 크기2 (<=cap)
    check(("ns", "g") in idx._generic, "prune 후에도 제네릭 유지(영구)")
    check(not any({"d1", "d2"} <= set(c) for c in idx.clusters()),
          f"prune 후에도 제네릭 값은 쌍 재생성 안 함 {idx.clusters()}")
    print("  제네릭 영구성(P1): df>cap 승격 후 prune 으로 버킷 줄어도 쌍 재생성 없음")

def t_snapshot_content_diff():
    """리뷰 P1: snapshot_diff 는 key 추가/삭제뿐 아니라 **내용 변경**(confidence/decision)도 잡는다."""
    from artes.core import graph_analytics as ga
    from artes.core.infra_recon import SAME_OPERATOR_SIGNAL_REL
    from artes.core.model import Graph, Edge, Entity, EntityType, Certainty, Evidence
    def mk(conf, dec):
        g = Graph()
        for v in ("a.com", "b.com"):
            g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                         evidence=[Evidence("t", "")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.DOMAIN, "b.com"),
                    relation=SAME_OPERATOR_SIGNAL_REL, certainty=Certainty.UNCONFIRMED,
                    confidence=conf, evidence_lower=conf, evidence_upper=0.9, decision=dec,
                    evidence=[Evidence("t", "")]))
        return g
    g1 = mk(0.4, "unconfirmed")
    g2 = mk(0.9, "confirmed")                      # 같은 (src,rel,dst), 내용만 변경
    d = ga.snapshot_diff(g1, g2)
    check(d["summary"]["edge_added"] == 0 and d["summary"]["edge_removed"] == 0,
          f"key 는 동일(add/del 0) {d['summary']}")
    check(d["summary"]["edge_changed"] == 1 and d["edges_changed"],
          f"내용 변경 1건 탐지 {d['summary']}")
    # 완전 동일하면 변화 없음
    d0 = ga.snapshot_diff(g1, mk(0.4, "unconfirmed"))
    check(not d0["summary"]["changed"], "동일 스냅샷 → 변화 없음")
    print(f"  snapshot 내용변경(P1): confidence 0.4→0.9·decision 변경을 edges_changed 로 탐지")

def t_graph_analytics():
    from artes.core import graph_analytics as ga
    # 손검증 그래프: 삼각형 a-b-c + 다리 c-d-e
    adj = {"a": {"b", "c"}, "b": {"a", "c"}, "c": {"a", "b", "d"},
           "d": {"c", "e"}, "e": {"d"}}
    comps = ga.connected_components(adj)
    check(len(comps) == 1 and len(comps[0]) == 5, f"연결요소 {comps}")
    ap = ga.articulation_points(adj)
    check(ap == {"c", "d"}, f"절단점 {ap} (기대 c,d)")
    br = ga.bridges(adj)
    check(set(br) == {("c", "d"), ("d", "e")}, f"절단간선 {br}")
    core = ga.core_number(adj)
    check(core["a"] == 2 and core["c"] == 2 and core["d"] == 1 and core["e"] == 1,
          f"coreness {core}")
    check(ga.k_core(adj, 2) == {"a", "b", "c"}, f"2-core {ga.k_core(adj,2)}")
    bet = ga.betweenness(adj)
    check(max(bet, key=lambda k: bet[k]) == "c", f"최고 매개중심성 {bet}")
    check(abs(bet["a"]) < 1e-12, f"a 매개중심성 0 {bet['a']}")
    check(bet["c"] > bet["d"] > 0, f"c>d>0 {bet['c']},{bet['d']}")
    print(f"  그래프 구조분석: 절단점{sorted(ap)}·다리{br}·2-core{sorted(ga.k_core(adj,2))}·중심성 hub=c (정확)")

def t_graph_analytics_on_graph():
    from artes.core import graph_analytics as ga
    g = Graph()
    def add(v): g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    def link(s, d): g.link(Edge(src=_k(EntityType.DOMAIN, s), dst=_k(EntityType.DOMAIN, d), relation="네임서버", certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for v in ("a.com", "b.com", "c.com", "d.com", "e.com"):
        add(v)
    for s, d in [("a.com", "b.com"), ("b.com", "c.com"), ("c.com", "a.com"),
                 ("c.com", "d.com"), ("d.com", "e.com")]:
        link(s, d)
    rep = ga.analyze(g)
    check(rep["nodes"] == 5 and rep["edges"] == 5 and rep["components"] == 1, f"요약 {rep}")
    check(_k(EntityType.DOMAIN, "c.com") in rep["articulation_points"], "c.com 절단점")
    check(rep["max_core"] == 2, f"max_core {rep['max_core']}")
    check(rep["top_betweenness"] and rep["top_betweenness"][0][0] == _k(EntityType.DOMAIN, "c.com"),
          f"최고 중심성 노드 {rep['top_betweenness'][:1]}")
    print(f"  analyze(그래프): 노드{rep['nodes']} 절단점{len(rep['articulation_points'])} max_core{rep['max_core']} hub={rep['top_betweenness'][0][0].split(':')[1]}")

def t_cluster_analytics_and_diff():
    from artes.core import graph_analytics as ga
    g = Graph()
    def add(t, v): g.add(Entity(type=t, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    def link(s, d, rel): g.link(Edge(src=s, dst=d, relation=rel, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for v in ("a.com", "b.com", "ns.shared.net"):
        add(EntityType.DOMAIN, v)
    add(EntityType.IP, "1.1.1.1"); add(EntityType.IP, "2.2.2.2")
    link(_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "ns.shared.net"), "네임서버")
    link(_k(EntityType.DOMAIN, "b.com"), _k(EntityType.DOMAIN, "ns.shared.net"), "네임서버")
    link(_k(EntityType.DOMAIN, "a.com"), _k(EntityType.IP, "1.1.1.1"), "해석됨(A)")
    link(_k(EntityType.DOMAIN, "b.com"), _k(EntityType.IP, "2.2.2.2"), "해석됨(A)")
    ca = ga.cluster_analytics(g, [[_k(EntityType.DOMAIN, "a.com"), _k(EntityType.DOMAIN, "b.com")]])
    check(len(ca) == 1 and ca[0]["size"] == 2, f"클러스터분석 {ca}")
    check(_k(EntityType.DOMAIN, "ns.shared.net") in ca[0]["critical_assets"],
          f"공유 NS 가 핵심(절단) 자산 {ca[0]['critical_assets']}")
    check(_k(EntityType.DOMAIN, "ns.shared.net") in ca[0]["hubs"], f"공유 NS 가 허브 {ca[0]['hubs']}")
    # 스냅샷 diff(시계열 변화)
    g2 = Graph.from_dict(g.to_dict())
    g2.add(Entity(type=EntityType.IP, value="9.9.9.9", certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    g2.link(Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.IP, "9.9.9.9"),
                 relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    d = ga.snapshot_diff(g, g2)
    check(d["summary"]["ent_added"] == 1 and d["summary"]["edge_added"] == 1 and d["summary"]["changed"],
          f"diff 요약 {d['summary']}")
    check(_k(EntityType.IP, "9.9.9.9") in d["entities_added"], "추가 엔티티 탐지")
    print(f"  클러스터분석+diff: 핵심자산={ca[0]['critical_assets'][:1]} 허브={ca[0]['hubs'][:1]} 변화={d['summary']}")

def t_cli_analytics_export():
    import io, contextlib, tempfile, os
    from artes import cli_infra
    with tempfile.TemporaryDirectory() as d:
        cyp = os.path.join(d, "g.cypher")
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cli_infra.main(["example.com", "8.8.8.8", "--dry", "--analytics",
                                 "--case", "A", "--cypher-out", cyp, "--no-graph"])
        check(rc == 0, f"cli rc {rc}")
        data = _json.loads(buf.getvalue())
        check("structure" in data and "cluster_analytics" in data, "분석 키 포함")
        check("coincidence_clusters" in data, "coincidence 클러스터 키")
        check("graph" not in data, "--no-graph 로 전체 graph 생략")
        check(os.path.exists(cyp) and data.get("cypher_written", 0) >= 1, "cypher export")
    print("  CLI 실배선: --analytics(구조+클러스터) + --cypher-out + --no-graph OK")

def t_same_operator_drop():
    """신호 공유 0 → 후보 자체가 안 생김. 그리고 약한 공유는 floor 로 drop 가능."""
    from artes.core.model import Entity, Edge, Evidence
    g = Graph()
    for v in ["x.com","y.com","nsx.net","nsy.net"]:
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t","")]))
    def link(s,d,rel): g.link(Edge(src=s,dst=d,relation=rel,certainty=Certainty.CONFIRMED,evidence=[Evidence("t","")]))
    link(_k(EntityType.DOMAIN,"x.com"), _k(EntityType.DOMAIN,"nsx.net"), "네임서버")
    link(_k(EntityType.DOMAIN,"y.com"), _k(EntityType.DOMAIN,"nsy.net"), "네임서버")  # 서로 다른 NS
    edges = correlate_same_operator(g, n_signals=4, link=False)
    check(len(edges) == 0, f"공유 0 → 후보 없어야 {len(edges)}")
    print("  same-operator: 공유신호 0 → 후보 미생성 OK")


# --------------------------------------------------------------- main ------ #
async def _asuite():
    await t_ct_parser(); await t_doh_parser(); await t_rdap_domain_no_person()
    await t_rdap_ip_and_asn(); await t_recon_end_to_end()
    await t_passive_dns_corroborate(); await t_favicon_httpfp_signals()
    await t_tls_behavior(); await t_dmarc_ptr_adapters()
    await t_recon_authz_infra_only()

def main():
    print("[verify_cp]")
    t_cp_math(); t_cp_scipy_crosscheck(); t_cp_gate()
    print("[classify]")
    t_classify()
    print("[throughput/scale]")
    asyncio.run(t_caching_http()); t_scope_generators()
    asyncio.run(t_doh_parallel()); asyncio.run(t_pooled_http_smoke())
    asyncio.run(t_politeness_http())
    asyncio.run(t_large_lazy_intake()); asyncio.run(t_bulk_sweep_scale())
    print("[adapters + recon]")
    asyncio.run(_asuite())
    print("[same-operator + CP]")
    t_same_operator_cp(); t_mx_and_cocert_signals(); t_more_signals_tightens_bound()
    t_corroborate_edges()
    asyncio.run(t_tls_spki()); t_spf_parse_and_eight_axis(); t_ten_axis_tighten()
    t_twelve_axis_tighten(); t_fourteen_axis_tighten()
    t_incremental_same_operator(); t_operator_clusters(); t_same_operator_drop()
    print("[signals-100]")
    t_signals_100_registry(); t_fast_same_operator()
    t_max_bucket_suppression(); t_100_faster_than_12()
    print("[signals-scale/idf/stream]")
    t_extended_registry(); t_coincidence_idf()
    t_streaming_callback(); t_scale_flat()
    print("[limit: parallel/coincidence-default/freshness]")
    t_gather_parallel_equiv(); t_coincidence_default_bench(); t_freshness_prune()
    t_generic_permanent_after_prune()
    print("[graph-analytics]")
    t_graph_analytics(); t_graph_analytics_on_graph()
    print("[cluster-analytics/diff + CLI wiring]")
    t_cluster_analytics_and_diff(); t_snapshot_content_diff(); t_cli_analytics_export()
    print("[cli]")
    t_cli_dry(); t_cli_register_subparser()
    print("[serialization]")
    t_graph_io(); t_cypher_batch(); t_gzip_shard()
    t_neo4j_push(); t_parallel_shard_load(); t_stream_load_shards()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0

if __name__ == "__main__":
    raise SystemExit(main())
