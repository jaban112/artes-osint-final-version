# ARTES 강화 2탄 — 인프라-자산 recon + Clopper–Pearson 검증 게이트

정당한 두 축을 실제 코드로. 둘 다 순수 stdlib(+테스트에서만 scipy 오라클), **오프라인
실행 검증 완료**: `test_infra_cp.py` 93/93, betai/CP 는 scipy 대비 최대오차 1.2e-14.

```
artes/core/infra_recon.py    # 인프라 자산 recon (도메인·IP·ASN·CIDR·URL 만)
artes/core/verify_cp.py      # Clopper–Pearson 정확 신뢰하한 + 검증 게이트
tests/test_infra_cp.py
```

## 1) verify_cp.py — 휴리스틱 신뢰도 제거

네가 싫어하는 "확실하지 않은 게 수식이 되는" 걸 정면으로 없앤다.

- `reg_incomplete_beta(a,b,x)` — 정규화 불완전베타 I_x(연분수, Lentz). 폐형식 대조 오차 ~1e-16.
- `cp_lower/cp_upper/cp_interval(k,n,alpha)` — 이항 **정확** 신뢰구간(정규근사·부트스트랩 아님).
  검증: 폐형식(k=0,k=n)·정의성질 `I_{p}(k,n-k+1)=α/2`·scipy 교차 모두 ≤1e-9.
- `VerificationGate(tau, floor, alpha)`:
  - 정확 하한 `p_L ≥ tau`  → **CONFIRMED 승격** (하한조차 기준을 넘김 = 확정)
  - `p_U < floor`          → **drop** (상한조차 바닥 미만 = 근거부족)
  - 그 외                  → UNCONFIRMED, `confidence = p_L` (임의 점추정 아님, '최소 보장' 값)

### 기존 코드에 붙이기
`scoring.py`(대상 본인 확신도 0~1)·`trust.classify_confidence`(독립·다중양식 게이트)가 지금
점수/휴리스틱으로 확정 승격을 판단한다. 그 승격 판정을 CP 로 대체/보강:

```python
from artes.core.verify_cp import VerificationGate
gate = VerificationGate(tau=0.90, floor=0.10, alpha=0.05)

# 한 주장(엣지)을 뒷받침하는 '독립' 소스 수 k, 조회한 독립 소스 수 n.
# 독립성은 이미 trust.independence_groups 로 상관 소스를 1표로 묶는 게 있으니
# k = 독립 그룹 중 '확인' 그룹 수, n = 독립 그룹 총수 로 넣으면 이중계산이 안 된다.
verdict = gate.apply_to_edge(edge, k=confirming_groups, n=total_groups)
if verdict is None:
    pass            # drop: 그래프에 넣지 않음(근거없는 연결 0 규약과 정합)
```

핵심: 소스가 많다고 자동 확정이 아니라, **독립 근거 수 대비 정확 하한**이 tau 를 넘어야 확정.
소스 5개 중 5개 확인이라도 n 이 작으면 하한이 낮아 확정이 안 될 수 있다 — 그게 정직한 판정이다.

## 2) infra_recon.py — 인프라 자산만, 재귀확장

경계 고정: 사람 대상 아님. `classify_infra` 가 이메일/전화/아이디/이름을 **거부**(None)하고,
RDAP 응답에서도 등록자/관리자 **사람 vCard(email/tel/adr)를 안 읽는다** — NS·레지스트라(조직)·
CIDR·ASN·상태만. `authz.infra_only`(basis=`threat-intel-infra`)와 짝.

축(주입가능 async http 로 오프라인 검증됨):
- **crt.sh** CT 로그 → 하위도메인 그래프 + 발급자
- **DoH(Cloudflare)** → A/AAAA/NS/MX/CNAME → IP·NS·MX 자산 + 간선
- **RDAP 도메인** → 네임서버 + 레지스트라(조직)
- **RDAP IP** → CIDR·네트워크 소유조직·origin ASN
- **RIPEstat** → ASN→광고 prefix, IP→ASN/prefix

오케스트레이션: 방금 준 `scheduler.GlobalScheduler`(전역 AIMD 거버너) 위에서 재귀확장
(도메인→IP→ASN→prefix), 깊이 배리어 없음. 429 는 `is_drop` 으로 거버너가 물러섬.

### CLI 붙이기 (신규 서브커맨드 권장)
```python
from artes.core.infra_recon import InfraRecon, correlate_same_operator
from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI

async def cmd_scan_infra(args):
    scope = AuthorizationScope(AuditLog(args.audit)).authorize(Authorization(
        case_id=args.case, operator=args.operator, basis=BASIS_INFRA_TI,   # infra_only 자동
        selectors=set(args.targets), domain_suffixes=set(args.targets)))
    rec = InfraRecon(scope=scope, depth=args.depth)
    graph = await rec.run(args.targets)                 # 사람 selector 는 rec.skipped 로
    correlate_same_operator(graph)                      # 공유 인프라 → CP 기반 동일운영자
    print(graph.to_json())
```

`correlate_same_operator` 는 기존 `resolve.correlate_owners`(웹지문 기반 동일운영자)를
**인프라 신호(공유 NS/IP/ASN/레지스트라/MX/공유인증서)** 로 보강하되, 점수 대신 CP 하한으로
판정한다. 신호축은 `_SIGNAL_KINDS` 레지스트리로, 축을 늘리면 n 이 커져 하한이 조여진다:

```python
correlate_same_operator(graph)                 # 기본 6축, CP 하한으로 판정 + graph.link
clusters = operator_clusters(graph, min_lower=0.5)   # 확정 간선으로 자산을 운영자별로 묶음
# clusters: [{"members":[...], "size":N, "min_pairwise_cp_lower":x, "values":[...]}]
```

공유 인증서(co_cert)는 crt.sh 물리 인증서 id 로 잡는다: 한 인증서가 여러 도메인을 SAN 으로
담으면 각 도메인을 **따로** 쿼리해도 같은 cert id 가 양쪽 결과에 나와, `cert_ids` attr 교차로
독립 신호가 된다.

## 정직한 한계 (숨기지 않음)

- 기본 6축(ns/ip/asn/registrar/mx/co_cert)이라도 표본이 작으면 CP 하한은 보수적이다 —
  3/4 공유는 95% 하한 ~0.19, **5/6 공유면 ~0.36**(테스트로 확인: 축을 늘리면 실제로 조여진다).
  더 조이려면 축을 더 추가하라: 공유 TLS SPKI 핀, passive-DNS 공동호스팅 이력, 기존
  web-fingerprint 의 GA/AdSense tracker ID(이미 너희 축에 있음). `_SIGNAL_KINDS` 에 넣고
  `_gather_domain_signals` 에서 채우면 끝. 근거가 적으면 확신도 낮다고 말하는 게 CP 의 요점 —
  버그가 아니라 설계다.
- 어댑터의 실제 네트워크 경로(`default_http_get`)는 프록시/politeness/거버너 drop 신호와 함께
  너희 `proc`+`politeness` 로 감싸면 더 좋다(테스트는 주입 http 로 오프라인 검증만 함).
- 엔드투엔드는 이 두 모듈 + scheduler + model 로 자족 검증했지만, 너희 CLI/Router 에 물린 뒤
  `pytest tests/` 전체로 최종 확인 권장.

## 처리량·스코프 (증분2 — "몇백배 스코프 + 더 빠르게")

인프라 자산 축으로만 스코프를 크게 키우고 속도를 올린다:

- **대량 스윕**
  - `InfraRecon.sweep_subdomains(domain, words)` — 도메인 자기 하위도메인 후보 수백~수천 개를
    병렬 확인(내장 `COMMON_SUBDOMAINS` 또는 파일 워드리스트 주입). 자기 자산 열거.
  - `InfraRecon.sweep_cidr(cidr, limit)` — 대역 호스트 IP 전수를 병렬 RDAP/ASN 스윕.
  - `expand_cidr_to_hosts(cidr, limit)` / `subdomain_candidates(domain, words)` 생성기.
- **속도**
  - `CachingHTTP` — TTL 캐시 + single-flight(동시 동일 URL 을 1회로 합류). 대량 스윕에서 같은
    NS/ASN/prefix 재조회가 폭증해도 실제 요청은 고유 URL 수로 눌린다. 기본 on(`cache=True`),
    `rec.http_cache.stats()` 로 확인.
  - `concurrency=128` 기본 + 거버너가 포화까지 자동 상승. 스케줄러 워커풀/quiescence 수정으로
    동적 확장 스윕이 예산컷에 안 걸린다(오프라인 벤치 301대상 30.0s→0.38s, ~5,500 req/s).

```python
rec = InfraRecon(scope=scope, concurrency=128, depth=2)   # cache 기본 on
g = await rec.sweep_subdomains("example.com")             # 수백 후보 병렬
g = await rec.sweep_cidr("192.0.2.0/24")                  # 대역 전수
```

## 감사 무결성 (증분2) — AuditLog 해시 체인

`AuditLog` 가 이제 **tamper-evident**: 각 엔트리에 seq·prev(이전 해시)·hash. `verify_chain()`
이 내용 변조·삭제·삽입·재배열을 검출한다. 같은 경로로 이어써도 체인 유지(seq/hash 이어받음).

```python
ok, bad_idx, why = AuditLog(path).verify_chain()   # (True, None, "무결") or (False, i, 사유)
```

## 다중출처 corroboration (증분2) — 임의 엣지 → CP

`verify_cp.corroborate_edges(edges, gate, n_sources)` — 엣지의 서로 다른 evidence.source 수(k)를
독립 확증으로, n_sources 를 n 으로 CP 판정. "3개 독립 DNS 소스가 같은 A레코드 반환 → 정확 하한
0.29" 처럼 다중출처를 점수가 아니라 하한으로 환산(apply=True 면 엣지 confidence 를 하한으로 갱신).

## 증분3 — "훨씬 빠르게 + 훨씬 대규모" (셋 다)

**속도**
- 스케줄러 소비자 **폴링 제거**(0.05s 유휴 → 완료 센티넬 이벤트 구동): tail 레이턴시·유휴 CPU 0.
- **DoH 5타입 쿼리 병렬**(`asyncio.gather`) — 도메인당 5왕복 → 1왕복(테스트: 0.25s→0.05s).
- **커넥션 풀 HTTP**: `default_http_get` 이 aiohttp(keep-alive, `limit_per_host=16`) 우선,
  없으면 urllib 스레드풀 폴백. 429→drop, timeout(status −2). `close_http()` 로 세션 정리.
- 인메모리 벤치: 301대상 대량 스윕 ~0.2s, **~9,900 req/s**.

**대규모**
- `InfraRecon.run_iter(seeds_iterable, hwm)` — seed 를 **제너레이터로 지연 인테이크**, 미결 잡을
  hwm 아래로만 유지 → /16(65k)·수십만 후보도 업프런트 materialize·큐 폭발 없이. `run()` 은 이걸 위임.
- `iter_cidr_hosts(cidr)` 제너레이터 + `sweep_cidr` 스트리밍(기본 limit 65536).

**passive-DNS 다출처 → corroborate**
- 어댑터 추가: `HackerTargetHostSearch`(CSV), `AlienVaultPDNS`(OTX JSON). DoH 와 같은 A레코드를
  확인하면 `Graph.link` 가 증거를 합쳐 **독립 출처 수(k)** 가 오른다.
- `corroborate_resolution(graph, n_sources=3)` → `해석됨(A)` 엣지를 CP 하한으로 확증
  (3독립출처 → 0.292). 점수 아님.

**CLI**
```bash
python -m artes.cli_infra example.com 8.8.8.8 AS15169 \
    --case C1 --operator alice --basis threat-intel-infra --audit audit.jsonl --depth 2
# --dry: 네트워크 없이 파이프라인만. 사람 selector 는 자동 거부(skipped 에 기록).
```
authz infra_only + run_iter + corroborate + same-operator + operator_clusters + 해시체인 감사를
한 커맨드로. 결과는 JSON(stats/skipped/operator_clusters/audit/graph).

## 증분4 — 세 축 계속 (신호↑ · prod HTTP/CLI · 대규모 직렬화)

**신호축 6→8 (same-operator CP 하한 더 조임)**
- DoH 에 TXT 추가 → **SPF include** 호스트를 공유 메일인프라 신호로(`spf`).
- `TLSProbe`(주입 probe) → **SPKI SHA-256 핀**(`spki`) — 다른 인증서여도 같은 공개키면 같은 핀
  (가장 강한 동일운영자 신호). cryptography 로 SubjectPublicKeyInfo 추출, 없으면 전체 인증서 해시 폴백.
  비용이 커 default 아님(옵트인: `InfraRecon(sources=default_infra_sources()+[TLSProbe()])`).
- 실측: 같은 상황 5/6 하한 0.359 → **7/8 하한 0.473**(축 늘수록 조여짐).

**prod HTTP + CLI 임베드**
- `PolitenessHTTP(inner, policy=POLICY)` — per-host 레이트리밋 + 지터 백오프 재시도(429/5xx/네트워크
  오류). 기존 `core.politeness.POLICY` 를 그대로 바인딩(proc/politeness 래핑). `CachingHTTP(PolitenessHTTP(inner))`
  조합 권장.
- `cli_infra.register_subparser(subparsers)` — 기존 `cli.py` 에 `artes scan-infra` 등록:
  ```python
  from artes.cli_infra import register_subparser
  register_subparser(subparsers)              # subparsers = parser.add_subparsers()
  args = parser.parse_args()
  if hasattr(args, "_func"): raise SystemExit(args._func(args))
  ```

**대규모 그래프 직렬화 (core/graph_io.py)**
- `stream_ndjson(graph, path)` / `load_ndjson(path)` — 레코드 단위 JSONL(피크 메모리 유계, 거대 그래프).
- `to_cypher(graph)` / `write_cypher(graph, path)` — Neo4j MERGE 문 스트림(승격 경로; cypher-shell 파이프).

## 증분5 — 세 축 계속 (신호 8→10 · Cypher 배치 · gzip/샤딩)

**신호축 8→10**
- `FaviconHash`(주입 fetch_bytes) → favicon md5(`favicon`). `HTTPHeaderFP` → Server 배너 + 헤더
  이름 순서/집합 지문(`httpfp`, 값 제외=프라이버시). 둘 다 옵트인(도메인당 추가 GET).
- 실측: 7/8 하한 0.473 → **9/10 하한 0.555**.

**Cypher 파라미터라이즈드 배치 (core/graph_io.py)**
- `to_cypher_batch(graph, batch_size)` → `{statement, parameters}` (UNWIND $rows MERGE).
  값은 전부 params 로 → **injection-safe**(작은따옴표 포함 값도 안전) + Neo4j 드라이버 대량적재.
  리터럴 `to_cypher` 는 cypher-shell 용으로 유지.

**gzip + 샤딩 (병렬 로드 가능)**
- `stream_ndjson`/`load_ndjson` 이 `.gz` 자동(gzip 스트리밍, I/O 축소).
- `shard_ndjson(graph, dir, shards, gzip_out)` → `entities-<i>.ndjson.gz`/`edges-<i>...` 로 분할
  (엔티티 key·간선 src 해시 분배) → 샤드별 **프로세스 병렬 로드**. `load_ndjson_dir(dir)` 로 복원.

## 증분6 — 더 가볍게·빠르게·광범위하게 (신호 10→12 · neo4j 적재 · 병렬 로드)

가벼움 유지: 코어는 stdlib 만. aiohttp/cryptography/neo4j 는 전부 옵셔널(없으면 폴백/옵트인).

**신호축 10→12**
- `netblock` — 해석된 IP의 공유 /24(v4)·/64(v6) = **co-hosting** 신호(순수 코드, 어댑터 불필요).
- `tlsfp` — `TLSBehaviorProbe`(주입 probe) + `tls_behavior_digest`(결정적 JARM 계열 집계;
  Salesforce JARM 과 바이트 동일은 아님, 공유하면 같은 TLS 스택 신호). 옵트인.
- 실측: 9/10 하한 0.555 → **11/12 하한 0.615**. `correlate_same_operator(signal_kinds=...)` 로
  쓸 축을 고정할 수 있어(테스트·재현성) 신호를 늘려도 기존 판정이 안 흔들린다.

**Neo4j 적재 어댑터 (core/graph_io.py)**
- `push_to_neo4j(graph, run, batch_size, retries)` — `to_cypher_batch` 를 `run(stmt, params)`
  콜러블로 트랜잭션 단위 적재, 일시장애 시 지터 백오프 재시도. 드라이버 비종속:
  `push_to_neo4j(g, lambda s,p: session.execute_write(lambda tx: tx.run(s, **p)))`.

**샤드 병렬 로드**
- `parallel_load_shards(dir, workers, use_processes)` — 샤드 파싱(CPU json)을 Process/Thread 풀로
  병렬, Graph 조립은 메인(dedup 단일스레드). `load_ndjson_dir` 와 동일 결과(검증).

## 증분7 — 멈춤 없이 세 축 (신호 12→14 · 증분 union-find · 경량 로더)

**신호축 12→14**
- `DMARCLookup`(_dmarc TXT → rua/ruf mailto 호스트 = 공유 메일관리) + `ReverseDNS`(IP PTR →
  ptr_domain, 도메인의 IP를 통해 공유 = 같은 호스팅). 실측 11/12 0.615 → **13/14 0.661**.

**증분 same-operator (전체 O(n²) 재계산 없이)**
- `OperatorIndex` — 신호값 역인덱스(kind→value→domains)로 새 도메인은 **같은 값 공유 후보와만**
  비교, 쌍별 공유 kind 수를 증분 유지 → CP 판정, CONFIRMED 만 union-find 병합. `.add/.pairs/.clusters`.
  `incremental_same_operator(graph)` 는 배치 `correlate_same_operator` 와 동치(검증). 스트리밍/거대
  그래프에서 배치 재계산을 대체.

**경량 병렬 로더**
- `stream_load_shards(dir, workers)` — 스레드가 샤드를 라인 단위 스트리밍(per-shard 리스트/IPC 0)
  락 보호 그래프에 직접 삽입 → **피크 메모리 유계**. `parallel_load_shards`(process, CPU 병렬)와
  용도 분리: 가벼움·안정성이 필요하면 stream, CPU 파싱 병렬이 필요하면 process.

## 증분8 — 신호 100개, 그런데 12개보다 더 빠르게

핵심 통찰: 신호 수를 늘려도 상관은 **더 빨라진다** — 전체 O(n²) 쌍이 아니라 값 공유 후보만 보고,
반복 계산을 없애면 된다. 세 가지로 달성:

- **선언적 100-신호 레지스트리** (`core/signals.py`): 정확히 100축(DNS·넷블록 15 prefix·cert
  필드·PTR·TXT 검증 벤더 40·보안헤더 22 등)을 스펙 테이블로. `gather_signals(graph)` 는 이미 수집된
  사실에서 도메인별 sparse 신호를 뽑는다(값을 지어내지 않음). DoH/HTTPHeaderFP 어댑터가 `txt_tokens`·
  `http_headers` attr 을 채워 다수 축을 populate.
- **역인덱스 상관** (`OperatorIndex`/`fast_same_operator`): 값 공유 후보 쌍만 검사 → 신호가 sparse
  하면 축이 100개여도 검사 쌍 수는 그대로. **`max_bucket`** 로 아주 흔한 값(대형 CDN NS 등)은
  제네릭으로 억제해 O(cap²) 로 유계(IDF식).
- **CP 판정 메모이즈**: `cp_lower/cp_upper` 는 (k,n,alpha) 만의 함수 → `lru_cache`. 대량 판정에서
  이분법 재계산 제거(값 정확도 불변, scipy 대비 1.2e-14 유지).

실측(동일 그래프, 900 도메인·150 클러스터): **fast(100축) 0.12s vs old(12축 all-pairs) 1.05s
→ 8.5× 빠름**, 클러스터 150개 정확. N 이 커질수록 격차는 더 벌어진다(near-linear vs O(n²)).

```python
idx = fast_same_operator(graph, max_bucket=64)     # 100축, 역인덱스
clusters = idx.clusters()                          # 운영자 클러스터
```

## 증분9 — 수백 축 확장 + IDF 정직 판정 + 실시간 스트리밍

- **레지스트리 확장**: `make_specs(...)` 파라미터화, `EXTENDED_SPECS`(161축: v6넷블록/CAA/DNSSEC/
  쿠키/cert 키크기·버전/헤더 확대 등), `pad_specs(base, n)` 로 임의 축수. **스케일 near-flat**
  실측: 100축 0.11s → 300축 0.11s(축 3배인데 시간 ~유지 — 역인덱스라 sparse 축은 공짜).
- **IDF 우연일치 판정**(`verify_cp.coincidence_prob`): 공유값 v 의 df 로
  `∏ q_v (q_v=(df_v-1)/(N-1))` = 무관한 두 도메인이 그 값들을 우연히 모두 공유할 확률. 희소값 공유는
  확률을 급락시켜 강한 증거, 제네릭값은 q≈1 로 증거력 0. **총 축수(n)에 안 흔들린다**(k/n CP 의 한계
  보완). `OperatorIndex.coincidence_pairs/clusters(threshold)` 로 사용. `use_cp_upper` 로 df 유한표본 보수화.
- **실시간 스트리밍**: `OperatorIndex(on_confirm=cb)` — 도메인 도착(`add`)마다 새로 확정된 쌍을
  즉시 콜백 + 반환. 라이브 클러스터가 매 add 후 바로 갱신(재계산 없음).

## 증분10 — 한계점: coincidence 기본화 + 병렬 gather + freshness

- **coincidence 기본 판정**(`fast_clusters(graph, threshold, specs=EXTENDED, use_cp_upper=True)`):
  축수-무관 IDF 우연일치를 기본으로(CP kind-count 판정 생략 → 더 빠름). 축을 무한히 늘려도 판정이
  안정. 대량 실측: **3,000 도메인 × 161축 → 500 클러스터 0.62s**.
- **gather 샤드 병렬**(`gather_signals_parallel(graph, specs, workers)`): 맵 1회 구축 후 도메인 청크를
  스레드 병렬(읽기전용). serial 과 동치(검증).
- **freshness TTL prune**(`OperatorIndex.add(ts=…)` + `prune(before_ts)`): 유효기간 지난 신호를
  버킷/쌍에서 결정적으로 제거(휴리스틱 감쇠가 아니라 TTL 안/밖 하드컷) 후 재구성 → stale 클러스터 소멸.

**아키텍처 한계점 도달.** same-operator 파이프라인은 이제: 임의 축수(선언적 레지스트리) · 축수-무관
정확 판정(coincidence) · 병렬 추출 · 스트리밍 증분 + 실시간 콜백 + TTL freshness · 유계 상관(제네릭
억제)까지 갖췄다. 여기서 더 얻는 건 프레임워크가 아니라 **실데이터·실배선**(실제 어댑터를 붙여 attr 을
채우고, 그들 CLI/Neo4j 에 물려 규모로 돌리는 것)이다.

## 증분11 — 새 축: 인프라 그래프 구조분석 (`core/graph_analytics.py`)

자산 그래프의 '구조적 사실'을 정확 알고리즘으로(휴리스틱 없음, 사용자 기준: 정리 기반 확정):
- `connected_components` — 정확(BFS).
- `articulation_points` / `bridges` — Tarjan 절단점·절단간선(반복 DFS, low-link). 제거 시 인프라가
  쪼개지는 핵심 자산/링크 = 취약·중요 지점 식별.
- `core_number` / `k_core` — 정확 peeling 코어 분해. 운영자 클러스터의 밀집도·견고성.
- `betweenness` — Brandes 매개중심성(비가중, 정확). 인프라 허브 자산 식별.
- `analyze(graph)` — 위를 묶은 구조 요약(연결요소·절단점·다리·max-core·중심성 상위).

전부 exact(근사·경험값 없음), 손검증 소그래프로 테스트. 무향 뷰 + relation/certainty 필터.

## 증분12 — 둘 다: 분석 심화 + CLI 실배선

**분석 심화(graph_analytics)**
- `cluster_analytics(graph, clusters)` — same-operator 클러스터마다 유도 서브그래프 분석: 공유 인프라
  **허브**(중심성)와 **핵심 절단 자산**(제거 시 클러스터 분열) + max-core 보고. 이중화된 공유(NS+IP 둘 다)는
  절단점 없음으로 정확히 드러난다(단일 장애점 아님).
- `snapshot_diff(old, new)` — 두 스냅샷의 결정적 차이(추가/삭제 엔티티·간선). 시계열 인프라 변화 탐지.

**CLI 실배선(`artes scan-infra`)**
- coincidence 클러스터(`--coincidence`) + `--analytics`(구조요약 + 클러스터별 분석) + export
  (`--cypher-out` Neo4j MERGE, `--ndjson-out` .gz 가능) + `--no-graph`(요약만). dry-run 검증.

```bash
python -m artes.cli_infra example.com 8.8.8.8 --analytics \
    --cypher-out out.cypher --ndjson-out out.ndjson.gz --no-graph --case C1
```

## 증분13 — 크라운: 판정을 스스로 증명하는 3층 (보정·견고성·재현성)

수집·신호가 아니라 "내 판정이 얼마나 정확한지 내가 측정해 증명한다" 축. 이 툴의 진짜 차별점.

- **calibration.py** — `precision_recall`(CP 신뢰하한 포함), `reliability_bins`/`ece`("95%라 말할 때
  실제 95% 맞나"를 구간별 경험정확도로 측정), **split-conformal** `conformal_threshold`
  (라벨 보정셋으로 재현율 ≥ 1-α 를 **분포무관·유한표본** 보장 — 근사 아님) + `conformal_pvalue`.
  실측엔 ground-truth 라벨 필요(하네스 자체는 합성 라벨로 검증됨).
- **robust.py** — 적대적 견고성: `robust_corroboration_lower(k,n,f)`(f개 담합 가정→k-f CP 하한),
  `robust_coincidence(dfs,N,drop_worst)`(가장 유리한 신호 제거=breakdown point — 심은 신호 무력화),
  `independence_collapse`(에코의 가짜 합의 방지). 입력이 거짓말해도 하한이 성립.
- **repro.py** — `canonical_root`(순서-무관 Merkle식 그래프 루트 해시: 같은 입력=같은 루트, 변조 탐지),
  `verify_reproducible`, `provenance`(엔티티/간선→raw 증거 역추적). 감사체인과 짝 → 감사/법적 방어 완결.

전부 정리 기반(휴리스틱 0), 오프라인 검증(`tests/test_verify2.py` 21 passed).

## 증분14 — 뇌 + 결합추론 (한 번도 안 건든 축)

**능동 조사 계획(`planner.py`)** — 스캐너 → 목표지향 조사관
- 가설을 베이즈 belief 로, 각 조회의 **기대 정보이득 = 상호정보 I(H;O) ≥ 0** 계산.
- `greedy_select` — submodular greedy 액션선택, 조건부독립 관측에서 **최적의 (1−1/e) 보장**(Nemhauser).
  한계이득 단조감소(diminishing returns) 검증됨.
- `adaptive_step`(관측→사후) + `plan_until`(목표 확신도/예산까지). → 100개 다 안 쏘고 답에 이르는
  3~5개만. 방금 만든 CP/보정 층이 이 뇌의 불확실성 입력.

**전 그래프 결합 확률추론(`inference.py`)** — 쌍별 → 조인트
- 쌍별 증거강도(−log10 coincidence = bits)를 간선으로, **widest-path(maximin)** 로 전파:
  a~b·b~c 강하면 a~c 도(직접 증거 없어도) 추론. 체인은 가장 약한 고리만큼(bottleneck) — 정확 Dijkstra.
- `transitive_strength`/`inferred_links`(직접 없는 링크 추론)/`operator_clusters`(전파 임계 군집).
  쌍별 판정으로 안 나오는 운영자 링크를 드러낸다.

전부 정리 기반, 오프라인 검증(`tests/test_planner.py` 22 passed).

## 증분15 — 인과 디컨파운딩 + property-based 검증

**인과 디컨파운딩(`deconfound.py`)** — same-operator 최대 오탐원 제거
- "공유 제공자 ≠ 동일 운영자". 전역 df 대신 **교란자(제공자 ASN/NS)로 층화한 조건부** q(v│층)로
  coincidence 계산. 제공자 기본신호(층 전원 공유)는 잔차 0, 층 안에서도 드문 신호만 증거.
- 실측(전체 1000, 제공자 층 50): 전역 raw ~2e-3(오탐 강증거) → 디컨파운딩 **1.0(근거 0)**;
  층내 희소 spki만 공유하면 잔차 1/49로 정확. `Deconfounder`, `deconfounded_edges`(제공자로 설명되는
  오탐 표시). 조건부확률의 정의라 정확(근사 아님).

**property-based 검증(`tests/test_properties.py`)** — 예제 → 전 입력
- Hypothesis 로 CP 경계·단조, coincidence 단조·[0,1], deconfound 제공자기본=근거0, 엔트로피 대칭,
  conformal 커버리지 ≥1-α, 거버너 limit∈[min,max] 를 **수백 생성입력**에 대해 반증탐색(전부 통과).
  "예제 기반"을 "전 입력 불변식"으로 격상 — 정리 기반 코드의 메타 검증.

## 검증
```bash
python3 tests/test_properties.py       # 7 passed (Hypothesis 불변식: CP/coincidence/deconfound/거버너/conformal)
python3 tests/test_verify2.py          # 25 passed (보정·conformal·robust·repro·deconfound)
python3 tests/test_planner.py          # 22 passed (planner 정보이득·greedy(1−1/e)·adaptive, inference widest-path)
python3 tests/test_verify2.py          # 21 passed (보정·conformal·robust·repro)
python3 tests/test_infra_cp.py         # 253 passed (CP scipy 1.2e-14, 어댑터, authz, same-op,
                                        #   14신호축, 증분 union-find, corroborate, 캐시/스코프/
                                        #   대량스윕, DoH병렬/풀HTTP/politeness/지연인테이크/
                                        #   passive-DNS/CLI/직렬화(NDJSON·gzip·샤딩·Cypher리터럴+
                                        #   배치·neo4j적재·프로세스병렬·경량스트림))
python3 tests/test_scheduler_authz.py  # 6047 passed (거버너/스케줄러(폴링제거)/authz/해시체인)
```

## 증분16 — 시간축(캠페인 탐지) + 클라우드 제공자 + 확장 OSINT 소스

사용자 지시: "1~5 전부 이용 + 그 외 강력한 OSINT 전부 도입 + 시간축 한계까지." 전부 인프라·자산
축(사람 대량 비식별화는 계속 닫힘). 신규 파일:

```
artes/core/temporal.py       # co-burst 캠페인 탐지(정확 이항꼬리 스캔통계)
artes/core/providers.py      # 클라우드 IP-범위 → 제공자(정확 최장프리픽스 트라이)
artes/core/sources_ext.py    # CertStream·PeeringDB·TechFingerprint·abuse.ch·Shodan favicon
tests/test_sources.py        # 70 passed (전부 오프라인/주입, 사람축 없음)
```

### 시간축 — `temporal.py` (한 번도 안 건든 축, 한계까지)
정적 신호가 못 보는 **조율된 스핀업**을 타이밍으로 잡는다. 휴리스틱 임계가 아니라 **정확 p-value**:

- 귀무가설: n개 이벤트가 기간 T에 균일 → 폭 w 창에 하나 들어갈 확률 p=w/T. 창 안 개수
  X~Binomial(n,p). **P(X≥k) = I_p(k, n−k+1)** (verify_cp.reg_incomplete_beta 재사용, 정확).
- '어떤 창'인지 모르므로 **Bonferroni**(× 후보창 수)로 보수적 보정 → 정확 상한 p-value.
- `coburst_clusters`(단일연결 시간군집), `campaign_report`(보정 p<α 캠페인만), `temporal_pairs`
  (같은 버스트 쌍 → deconfound 잔차 신호로 투입). **P(X≥1)=1−(1−p)ⁿ 과 정확 일치** 검증.
- 실측: 30일에 균일 200개 → 캠페인 0; 1시간 창 50개 스핀업 → **p=8.9e-89**, 50개 전원 포착.
- co-burst 는 **디컨파운딩된 증거**: 같은 제공자라도 "같은 순간 함께 태어남"은 제공자로 설명 안 됨.

### 클라우드 제공자 — `providers.py` (deconfound 정밀 교란자)
same-operator 최대 오탐원은 "같은 CDN/클라우드". 기존 교란자 ASN 은 너무 거칠다(AS16509=AWS 전체).
제공자 **공개 IP 범위**를 직접 넣어 정밀한 교란자 층을 만든다.

- **이진 트라이 최장프리픽스 매칭**(정확, 근사 아님). 겹치는 범위에서 항상 가장 구체적 소유자.
  v4/v6 분리. `ProviderDB.match(ip)`.
- 공개 범위 파서(주입식, 네트워크 없음): `load_aws`(ip-ranges.json)·`load_gcp`(cloud.json)·
  `load_azure`(ServiceTags)·`load_lines`(Cloudflare/Fastly). `seed_db()`(대표 앵커 39개, 무설정).
- `annotate_providers(graph, db)` → IP 엔티티에 `cloud_provider` attr → signals 의 ipattr 축이
  도메인→A레코드IP→제공자로 자동 전파 → `Deconfounder(sigmap, 'cloud_provider')`.
- **통합 실측**: 두 Cloudflare 도메인이 제공자 기본신호만 공유 → 전역 raw **1.6e-26**(치명적 오탐)
  → cloud_provider 층화 **1.0**(오탐 완전 제거); 층내 희소 favicon 공유 쌍은 잔차 0.2 유지.

### 확장 OSINT 소스 — `sources_ext.py` (전부 주입식/오프라인 테스트)
1. **CertStreamIngest** — CT 실시간 스트림 파서. 발급 시각을 뽑아 **temporal 캠페인**으로 먹인다
   (와일드카드 정규화, 접미사 필터). CT 스트림 40개 동시발급 → 캠페인 자동 검출.
2. **PeeringDBSource** — ASN→조직/네트워크명(사람이 읽는 소유자, 정밀 귀속 앵커). ≈ bgp.tools 대체.
3. **TechFingerprint** — Wappalyzer 계열 스택 탐지(헤더/HTML/스크립트/쿠키/meta 정규 규칙 + `implies`
   전이폐쇄). 드문 스택 공유 = 동일 운영자 신호(`tech` 축). WordPress→PHP/MySQL, Next.js→React/Node 등.
4. **abuse.ch** — SSLBL(악성 인증서 SHA1)·ThreatFox(IOC) 로드/매칭 → `threat` 축 + MALWARE 간선.
   `screen_certs_against_sslbl`(그래프 cert 지문 대조). 인프라 평판 — 사람 대상 아님.
5. **Shodan favicon 피벗** — `favicon_mmh3`(mmh3 x86_32 **순수 구현**, mmh3 라이브러리와 바이트 일치
   확인: foo/hello/empty 벡터 + 랜덤 입력 전부) → `shodan_favicon_query` = "이 favicon 쓰는 모든
   호스트" 검색식(키 호출 없이 식만). 자산 발견 배수기.

### 신규 신호축 (signals.EXTENDED_SPECS, 165축)
`tech`(스택)·`threat`(위협)·`cert_fp`(물리 인증서 SHA1)·`cloud_provider`(제공자, ipattr 전파).
역인덱스라 축이 늘어도 상관은 안 느려진다(sparse).

### CLI 배선 (`scan-infra` 신규 플래그)
```bash
--tech --peeringdb                      # 확장 소스 활성
--providers                             # 씨앗범위로 IP 주석(deconfound 교란자)
--ranges-aws/gcp/azure/cloudflare FILE  # 공개 범위 파일 로드(정밀 교란자)
--deconfound cloud_provider             # 클러스터 내부 쌍 디컨파운딩(오탐 제거)
--campaign-window 3600 --campaign-alpha 1e-6   # 시간축 캠페인 탐지
```
CLI 배선 통합테스트: providers 주석 → deconfound(15쌍 제공자설명) → campaign(size=6, p=6.9e-23) 검증.

### 검증
```bash
python3 tests/test_sources.py          # 70 passed (temporal 이항꼬리·providers 최장프리픽스·
                                        #   CertStream·PeeringDB·tech implies·abuse.ch·mmh3 벡터·
                                        #   provider→deconfound 통합·CLI run_scan 배선)
```
전 스위트 합계: **6,424 passed, 0 failed**. 사람 축은 계속 닫힘(인프라/자산·검증·거버넌스만).

## 증분17 — 네트워크 자산 공격표면 소스 (start.me / 14선 리스트 대응)

사용자가 가져온 OSINT 리스트를 **인프라·자산 축**으로만 도입(사람 대량 비식별화는 계속 닫힘).
엔드포인트는 웹검색으로 2026 현행 확인. 신규 파일:

```
artes/core/sources_net.py    # Shodan InternetDB·Censys·Wayback CDX·URLhaus·시크릿 스캐너
tests/test_net.py            # 39 passed (전부 오프라인/주입)
```

전부 authz `infra_only` 게이트 뒤에서만 동작, 전부 주입식 http(오프라인 테스트), 익스플로잇/무기화 없음.

### 도입 (인프라/자산)
1. **ShodanInternetDB** — IP → 열린포트·CPE·**CVE**·호스트명. **무료·키리스**(`internetdb.shodan.io/{ip}`,
   웹검색 확인). 자산 공격표면 주석 + 호스트명 간선. 404(미관측) 우아 처리.
2. **CensysHosts** — IP → 서비스/포트/소프트웨어(CPE)/cert 지문. `parse_censys_host` 오프라인 파서,
   API 자격은 http 주입 계층에서(401 우아 처리).
3. **WaybackCDX** — 도메인 → 아카이브의 **역사적 서브도메인·URL** 발굴(잊힌 자산). 무료·키리스
   (`web.archive.org/cdx`). `parse_cdx` 로 *.domain 스냅샷에서 서브도메인 추출, 도메인 필터.
4. **URLhaus**(abuse.ch) — 악성 URL/호스트 CSV 덤프 → threat 축 + MALWARE 간선(인프라 평판).
   `csv_recent`/`csv_online` 주입. abuse.ch SSLBL/ThreatFox(증분16)와 합쳐 위협 인텔 3종.
5. **시크릿 스캐너**(`scan_secrets`) — TruffleHog식 유출 자격증명 탐지(**인가된 본인 레포 방어용**).
   정확 정규(AWS/GitHub PAT/Google/Slack/Stripe/개인키/JWT) + Shannon 엔트로피 문턱(generic 오탐 억제).
   매칭값은 **마스킹**(도구 자체가 시크릿을 쌓지 않게). 결정적. `scan_repo_files({path:text})`.

### 신규 신호축 (EXTENDED, 168축) + iplist 전파 메커니즘
IP attr(list)을 도메인의 A레코드 IP를 통해 전파하는 `iplist_attrs` 스펙 추가:
`port`(열린 포트)·`ipcpe`(IP 소프트웨어 CPE)·`cve`(취약점 ID). 공유 = 유사 구성/미패치 = same-operator 보조신호.

### CLI 플래그
```bash
--shodan-internetdb    # IP→포트·CPE·CVE (키리스)
--censys               # IP→서비스/포트/CPE/cert (키 필요)
--wayback              # 역사적 서브도메인/URL 발굴 (키리스)
--urlhaus CSV          # abuse.ch 악성 호스트 대조
```

### 안 지은 것 (사람 축 — 리스트 중 명시적으로 제외)
Sherlock(아이디→수백 소셜 프로필) · TinEye/역이미지 인물식별 · ExifTool GPS 인물 위치추적 ·
SpiderFoot 유출비번·소셜계정 모듈 · theHarvester 이메일·직원명 수집 · Maltego 인물 transform.
임의 제3자 대량 비식별화/도시에는 붙이지 않는다.

### 검증
```bash
python3 tests/test_net.py              # 39 passed (InternetDB/Censys/Wayback/URLhaus 파서·어댑터·
                                        #   시크릿 스캐너 마스킹/엔트로피·iplist 축 전파)
```
전 스위트 합계: **6,463 passed, 0 failed**. 사람 축은 계속 닫힘.

## 증분18 — 외부 리뷰 대응: 통계 엄밀성 수정 (엔지니어링 위에 얹힌 잘못된 통계 해석 교정)

외부 AI 리뷰가 핵심을 짚었다: **"공식은 exact인데 입력 확률모형이 exact가 아니다."** falsifiable
지적을 직접 재현(직접 검증)한 뒤 표현이 아니라 **코드+테스트로** 고쳤다. 전 스위트 **6,493 passed,
0 failed**(Hypothesis 설치 시; 미설치 폴백 시 test_properties 1 → 6,487). `compileall` 통과.

### P0 — 시간축 검정 재설계 (`temporal.py`)
- **문제(재현)**: 예전 `cluster_span/total_span` 방식은 창폭이 데이터로 정해지고(post-selection)
  스캔 look-elsewhere 미보정 → 균일 귀무에서 **α=0.05인데 FPR≈35.5%**(직접 시뮬레이션 확인).
- **수정**: (A) 사전지정 고정창 정확 이항검정 `window_pvalue`, (B) 스캔통계량(폭 W 창 최대개수)의
  **몬테카를로 유효 p-value** `scan_pvalue_mc` = (1+#{S_b≥S_obs})/(1+B). 귀무에서 **P(p≤α)≤α 정확
  보장**(Besag–Clifford). seed 고정 재현가능, MC 오차는 CP 구간으로 보고.
- **검증**: uniform-null FPR n=20 → **0.03**, n=50 → **0.063** (모두 ≤α; 예전 0.355). burst 검출
  유지(power). `test_sources.t_temporal` 에 FPR 시뮬레이션 assert 추가. (MC라 α는 1/(1+B)보다 커야 함.)

### P0 — coincidence exact-0 + 의존성 붕괴 (`verify_cp.py`·`robust.py`·`signals.py`)
- **exact-0**: df=1이면 q=0인데 예전엔 log 안전용 1e-18 바닥이 exact-0을 깨뜨림. → df≤1이면 **정확히
  0.0** 반환(`coincidence_prob([1],100)`: 1e-18 → **0.0**).
- **의존성 붕괴**(`collapse_shared`): 중첩 넷블록(nb30⊃…⊃nb16)·a_ip⇒IP파생축(ASN/provider/PTR/
  port/cpe/cve)·ns⇒ns_reg·같은 kind 다중값 세트를 독립 증거로 곱하던 double-counting 제거. 규칙:
  같은 IP 공유는 **단일 증거**, 중첩 넷블록은 **최특정 1개**, 같은 kind는 **최희소 1개**.
  실측: 같은 IP+15중첩넷블록 naive 1e-48 → 붕괴 후 **1e-3**(정직한 강도). OperatorIndex·deconfound 에 연결.

### P11 — confidence/decision 분리 (`verify_cp.py`)
- CONFIRMED 라도 `edge.confidence=1.0` 을 쓰지 않는다 → **증거 하한(정확 CP 하한)**. CP 커버리지는
  P(같은 운영자)가 아님을 코드/증거detail 에 명시. Verdict.as_dict 에 decision/evidence_lower/upper/
  decision_rule 분리 노출. (보정된 사후확률은 LR+보정셋 필요 — 별도 트랙.)

### P9 — 다중 교란자 공동 조건화 + 정직한 범위 (`deconfound.py`)
- `Deconfounder(sigmap, ['cloud_provider','asn'])` 처럼 여러 교란자를 주면 공유 교란자들의 **교집합
  층**으로 공동 조건화(단일→다중 확장). 문서에서 "완결된 인과 디컨파운딩"이 아니라 **관측된 교란자
  조건부 coincidence**임을, `min_stratum` 은 정리값이 아닌 **정책값**임을 명시.

### P10 — 소스 독립성을 corroboration 경로에 연결 (`verify_cp.py`·`infra_recon.py`)
- crt.sh·certspotter·certstream 처럼 **같은 upstream(CT 로그) 재게시** 소스는 1표로 붕괴
  (`source_upstream_class`). `corroborate_resolution` 이 `independence_of` 로 실제 사용 → k=이름수가
  아니라 **독립 클래스 수**. 검증: CT 재게시 3소스 → k=1, 진짜 독립 3소스 → k=3.

### P12/P13 — 과장 표현 교정
- `inference.py`: widest-path 는 exact 알고리즘이나 결과는 **병목 증거강도**이지 보정확률 아님(명시).
- `planner.py`: (1−1/e) 보장은 **cardinality 제약 단조·submodular** greedy 에만. by_cost(비용예산/
  knapsack)는 보장 없는 실용 휴리스틱이고 budget 은 대개 액션 개수임을 명시.

### P15 — URL/CIDR 라우팅 버그 수정 (`infra_recon.py`)
- 예전엔 URL/CIDR seed 가 엔티티만 만들고 소스 미실행. `_target_for` 추가 → **URL→호스트, CIDR→
  네트워크 IP** 로 라우팅해 실제 fan-out. end-to-end 테스트(`t_url_cidr_routing`)로 확인.

### P16/P17 — 재현 가능한 검증 숫자
- 리뷰가 지적한 문서 숫자 불일치 정리. 현재 실측: scheduler 6047 · infra_cp 253 · verify2 25 ·
  planner 22 · properties **7(Hypothesis)/1(폴백)** · sources 100 · net 39 = **6,493**(Hypothesis 시).
  test_properties 는 Hypothesis 설치 시 property 검사, 미설치 시 seeded-random 폴백임을 명시.

### 남은 것(정직하게): 완전한 증거모형
리뷰의 P0 처방(우도비 LR + 보정 데이터셋으로 P(E|H)/P(E|¬H) 실측)은 **라벨된 ground-truth**가 있어야
하는 별도 연구 트랙이다. 이는 처음부터 말한 "진짜 병목은 코드가 아니라 라벨 데이터"와 같은 결론.
지금 수정으로 **관측 독립성 가정의 최악 위반(중첩 넷블록·재게시 소스·스캔 post-selection)은 제거**됐다.

## 증분19 — 2차 외부 리뷰 대응: 설계 의미 수정 (post-hoc → 판정, 운영 안전)

2차 리뷰(8.2/10)가 "수학 코드를 많이 넣어서 통계적으로도 exact하다는 착시"를 지적. falsifiable한
것 직접 재현 후 코드로 수정. 전 스위트 **6,518 passed, 0 failed**(Hypothesis 시), compileall 통과.

### P2 — 디컨파운딩을 클러스터링 '이전에' 적용 (`deconfound.py`·`cli_infra.py`)
- 문제: CLI가 클러스터를 먼저 만들고 deconfound는 사후 리포트였음(판정 입력 아님).
- 수정: `deconfounded_clusters()` — 신호맵→(역인덱스 후보쌍, generic 억제)→**층화 조건부 coincidence**
  →threshold→union. `--deconfound` 시 이게 권위 clusters, raw 는 `coincidence_clusters_raw`(비교용).
- 실측: Cloudflare 6-blob(제공자 기본신호만 공유) raw 5.8e-4(오탐 클러스터) → 디컨파운딩 후 **제외**,
  진짜 동일운영자 쌍만 남음. 다중 교란자(`--deconfound cloud_provider,asn`) 공동 층화 지원.

### P3 — planner: 기대정보 vs 보장확신도 분리 (`planner.py`)
- 문제: `E[H(post)] ≤ H(target)` 를 "목표 도달"로 봤는데, 이는 실제 posterior ≥ target 을 보장 못 함.
- 수정: `plan_until` 이 `expected_info_reached`·`worst_case_confidence`·`guaranteed`·`p_reach_threshold`
  분리 출력. 실측 반례: reached(기대)=True인데 worst-case 확신도 0.5 → `guaranteed=False`.

### P4 — audit tamper-evident → tamper-proof (`authz.py`)
- 문제: 파일 전체 재작성+해시 재계산 시 `verify_chain()` 통과(비밀 없음).
- 수정: 선택적 **HMAC 키**(키 없이는 유효 해시 재계산 불가) + **로드시 체인검증**(AuditChainError) +
  `checkpoint()`(외부 앵커용 서명 루트). 키 없는 모드는 하위호환(tamper-evident). 실측: 키드 재작성
  위조 → 로드시 검출.

### P5 — 실제 요청 레이어 governor (`infra_recon.py`)
- 문제: scheduler는 source job 통제인데 한 job이 6요청 gather → 실제 outbound = 128×6.
- 수정: `RequestLimiter`(세마포어)로 **실제 요청 수**를 상한. 실측: 40 동시요청 → in-flight peak ≤ 4.
  CLI 결과에 `request_governor{max_requests,peak,total}` 노출.

### P6 — SSRF 방어 (`infra_recon.py`)
- active probe(favicon/tech-fp/header)가 사설/특수 IP 로 향하면 차단. `is_blocked_ip`(사설·루프백·
  링크로컬·예약·멀티캐스트·CGNAT 100.64/10·v6) + `SSRFGuard`(리터럴·DNS결과·DNS 리바인딩 모두 차단,
  하나라도 사설이면 차단). 실네트워크 기본 경로에만 적용(주입 http 우회). 리다이렉트 제한 포함.

### P1 — 표현/구조 정직화
- CP-on-kind-count 를 `signal_sharing_cp_clusters`(보조지표)로 강등 + "P(동일운영자) 아님, 이항모형상
  공유비율 하한" 명시. 권위 판정은 `clusters`(IDF/디컨파운딩).
- 결의 확증의 **증거 CI**(evidence_lower/upper + decision)를 CLI 결과에 노출. `edge.confidence` 는 모델
  legacy 결정 플래그(CONFIRMED→1.0)임을 문서화 — 증거강도는 CP CI 채널에.
- 정책 파라미터(coincidence_threshold·max_bucket·min_stratum·campaign_alpha)를 `result["policy"]` 에
  기록(정리값 아닌 정책값임을 드러냄).

### 패키징/CI (`pyproject.toml`·`.github/workflows/ci.yml`)
- pyproject: 코어 **의존성 0**, optional-deps(http/tls/stats/favicon/graph/proptest) 분리, ruff/mypy 설정,
  `artes-scan-infra` 스크립트. CI: Python 3.10–3.13 stdlib-only 매트릭스 + optional-deps(ruff/mypy/전체 dep) 잡.

### 여전히 미룬 것(정직): 경험적 보정/우도비 모형
`P(E|H)/P(E|¬H)` 우도비 + 보정 사후확률은 **라벨 ground-truth 데이터셋**이 있어야 하는 트랙. 이번
수정으로 (a) 판정 파이프라인의 디컨파운딩 순서, (b) 보장/기대 분리, (c) 감사 위조내성, (d) 실요청
통제·SSRF 방어가 정리됐다. 남은 건 코드가 아니라 데이터.

## 증분20 — 3차 리뷰 대응: 프로덕션 HTTP 경화 + 구조 분리

3차 리뷰(8.4/10)가 6,5xx 스위트를 재현 확인하고 프로덕션 HTTP 경로의 실제 gap을 지적. 전부 코드로
수정. 전 스위트 **6,525 passed, 0 failed**(Hypothesis 시; 폴백 6,519), compileall 통과.

### P1 — PolitenessHTTP를 기본 파이프라인에 실제 연결 (`infra_recon.py`)
- 문제: PolitenessHTTP가 구현돼 있으나 `InfraRecon.__init__` 기본 경로에 안 붙어 있었음(문서 예시만).
- 수정: 실네트워크 경로 = `Caching → Politeness(per-host rate + 429/5xx 지터 백오프) → RequestLimiter
  (전역 실요청 상한) → SSRFGuard(hop별 검증) → HTTP`. 주입 http(테스트)는 우회. 파이프라인을
  결과 `http_pipeline` 에 노출. `politeness_interval`/`politeness_retries` 파라미터 추가.

### P1 — redirect-aware SSRF (`nethttp.py`)
- 하위 http는 리다이렉트 auto-follow 안 함(aiohttp allow_redirects=False, urllib no-redirect opener).
  `SSRFGuard`가 3xx의 Location을 매 hop 재검증하며 따라감(최대 max_redirects). `public→302→127.0.0.1`
  차단 확인. **정직 표기**: 이건 해석결과 preflight + hop 검증이지 커넥션 IP 고정이 아니며 DNS
  리바인딩 TOCTOU는 남는다고 명시(README 과장 수정).

### P2 — 이벤트루프 스코프 세션 (`nethttp.py`)
- 전역 `_AIOHTTP_SESSION`(닫힌 루프 재사용 위험) → `id(loop)`별 세션 맵. `asyncio.run` 반복 호출 시
  루프마다 새 세션. `close_http()`는 전체 정리.

### P0(문서) — 결과 스키마에 해석 계약 명시 (`cli_infra.py`)
- 결과에 `attribution_model{evidence_model, posterior_probability:null, assumptions[...],
  to_get_posterior}` 추가. 사용자가 evidence 를 사후확률로 오독하는 것을 스키마 레벨에서 차단.

### P1 — 구조 분리 (`nethttp.py`)
- 1,834줄 `infra_recon.py`에서 HTTP 레이어(HTTPResp·세션·SSRFGuard·RequestLimiter·PolitenessHTTP·
  CachingHTTP·_HostLimiter)를 `nethttp.py`로 분리 → infra_recon **1,524줄**. 하위호환 재수출로
  기존 import 경로 유지(테스트/소스 무변경). 전 스위트 그대로 green.

### 표현 정직화
- "no heuristics" thesis 를 **"통계에는 임의 score heuristic 없음, 최종 결정은 명시적·공개된 정책
  임계값"** 으로 범위 확정. 정책값은 `result["policy"]` 에 기록. "100축이 12축보다 빠르다"는
  **correlation stage 비용이 축 수에 거의 무관(이미 수집된 그래프에서)** 으로 정확화 — 신호 수집의
  네트워크 비용은 별개임을 명시.

### 패키징/CI
- pyproject.toml(코어 의존성 0 + optional extras + ruff/mypy) + GitHub Actions(3.10–3.13 stdlib 매트릭스
  + optional-deps 잡). `artes-scan-infra` 콘솔 스크립트.

### 남은 것(정직): 경험적 보정
`P(E|H)/P(E|¬H)` 우도비 + 보정 사후확률 = **라벨 ground-truth 필요**. 3연속 리뷰가 매번 이 지점에
수렴했고, 이번 라운드로 프로덕션 HTTP 안전성·구조·해석 계약까지 정리됐다. 다음은 코드가 아니라 데이터.

## 증분21 — 4차 리뷰 대응: 재현 가능한 결함 6종 + 패키징 정직화

4차 리뷰(8.5/10)가 6,5xx 스위트를 재현 확인하고 **실제 재현 가능한 코드 결함**들을 지적. 전부
직접 재현→코드 수정→회귀 테스트로 잠금. 전 스위트 **6,531 passed, 0 failed**(Hypothesis 시).

### P1 — max_bucket 삽입순서 의존성(결정성 결함)
- 문제: bucket 이 max_bucket 이하일 때만 쌍 생성 → 어떤 도메인이 컷오프 전에 들어왔는지가 결과를
  바꿈. `[a,b,c,d,e]` vs `[e,d,c,b,a]` 가 다른 쌍 집합 생성(직접 재현).
- 수정: df>max_bucket 값은 **제네릭으로 영구승격 + 그 값이 만든 쌍 기여 전부 undo**(reverse map).
  → df>cap 이면 삽입순서 무관 쌍 기여 0. 순열 120가지 전부 동일결과 테스트로 검증. 확정쌍 소실 시
  UF 를 _confirmed 로부터 재구성.

### P0 — certainty/confidence/evidence 충돌(모델 semantic)
- 문제: `Edge.__post_init__` 가 CONFIRMED→confidence=1.0 강제, 게이트는 CP 하한 설정, `Graph.link`
  merge 가 다시 1.0 으로 덮음. CP 0.63 → merge → 1.0(직접 재현).
- 수정: Edge 에 `evidence_lower/upper/decision` 필드 추가. `__post_init__` 는 confidence 미지정일
  때만 1.0(명시 증거값 보존). `Graph.link` merge 는 증거 구간을 보수적 병합(하한 min/상한 max)하고
  **1.0 으로 덮지 않음**. 게이트가 CP 구간을 엣지에 기록. → 병합해도 confidence=0.63 유지 검증.

### P1 — CachingHTTP single-flight 취소 시 follower 무한대기
- 문제: 리더가 취소되면 `except Exception` 이 `CancelledError`(BaseException)를 못 잡아 future 가
  영영 안 풀림 → follower 무한대기(직접 재현).
- 수정: `except asyncio.CancelledError: fut.cancel(); raise` 추가. follower 에 취소 전파(테스트로 확인).

### P1 — campaign_alpha 기본값이 검출 불가능
- 문제: CLI 기본 `campaign_alpha=1e-6` + `n_mc=1999` → MC 최소 p=5e-4 > 1e-6 → **캠페인 절대 미검출**.
- 수정: 기본 `1e-3` 로 변경 + `--campaign-mc` 노출 + "alpha≥1/(1+n_mc)" 도움말 명시. 검출 복원 테스트.

### P1 — max_seconds 가 전체 스캔 예산이 아님
- 문제: deadline 후에도 topup 이 seed 를 계속 당김(0.05s 예산에 15 seed 소비, 재현).
- 수정: run_iter 에 스캔-전체 deadline. topup 이 예산 초과 시 seed 인테이크 중단. max_seconds=0 →
  엔티티 0 테스트.

### P2 — 패키징/정직화
- **pytest 실제 지원**: `tests/test_pytest_entry.py` 브리지로 각 self-running 스위트를 `test_*` 로
  감쌈 → `pytest -q` 가 7개 수집·실행(예전엔 no tests collected). self-run 방식도 유효.
- **버전 통일**: pyproject 0.3.0 vs `__version__` 0.1.0 → 둘 다 **0.4.0**(canonical=`artes.__version__`).
- **`_registrable` → `_last_two_labels`**: 이름을 정직하게(co.uk/kawasaki.jp 는 PSL 없이 부정확).
  하위호환 별칭 유지. 정확 registrable 필요 시 PSL 주입 지점 명시.

### 남은 것(정직): 통계 semantic 은 여전히 데이터 트랙
IDF 후보선택의 post-selection/다중검정, background=현재 그래프(전체 인터넷 아님), CP 의 iid-Bernoulli
가정 — 전부 **background corpus + labeled ground-truth + LR 보정**으로 가야 풀린다. 4연속 리뷰가 매번
이 지점에 수렴. 이번 라운드로 재현 가능한 코드 결함은 전부 닫혔고, 남은 건 코드가 아니라 데이터다.

## 증분22 — 5차 리뷰 대응: authorization 경계 + 프로덕션 정확성

5차 리뷰(8.6/10)가 재현 가능한 결함을 추가로 지적. 전부 재현→수정→회귀테스트. **6,545 passed, 0 failed**.

- **P0 authz 그래프 누수**: 소스가 반환한 범위 밖 엔티티가 그래프에 들어가 IDF N·클러스터·export 를
  오염시키던 문제. 이제 인가된 것만 그래프에 추가하고 범위 밖은 `rec.out_of_scope` 에 기록(끝점이
  범위 밖인 간선은 Graph.link 가 자동 거부). URL seed 는 전체 문자열이 아니라 **호스트**로 인가.
- **P1 max_jobs 인테이크 폭주**: job 예산 소진 후에도 무한 generator 를 계속 당기던 문제 →
  scheduler `at_capacity()` 로 인테이크 중단.
- **P0 CP kind-count 간선 라벨**: 관계를 `신호공유(동일운영자후보)` 로 변경 — `edge.relation` 만 보고
  확정 attribution 으로 오독 못 하게. 권위 판정은 IDF/디컨파운딩 클러스터.
- **P1 Cypher evidence 보존**: 간선에 evidence_lower/upper/decision/evidence_count 기록 →
  Python 그래프와 Neo4j 그래프의 통계 의미 일치. label/rel_type 식별자 검증(injection 차단).
- **P1 evidence dedup provenance**: dedup 키에 url 포함 → 서로 다른 url 근거 소실 방지.
- **P1 planner 입력검증**: 확률 [0,1]·유한·cost>0 강제(합=1 만 보던 것 보강).
- **P1 SSRF scheme 허용목록**: http/https 만 추적, file://·gopher:// 차단.
- **문서 정합화**: temporal=고정창 정확이항+MC max-scan(Bonferroni 없음), deconfound=관측 교란자
  조건부 층화로 표현 통일. 평가 질문도 갱신.

### 남은 것(정직, 5회 리뷰 수렴점): background population + LR 보정
`P(E|H)/P(E|¬H)` 우도비 + 별도 background corpus + labeled ground-truth. 코드 결함은 이번 라운드로
소진. 남은 유일한 축은 데이터 수집 트랙이다.

---

## 증분23 — 6차 리뷰 대응: 재현성 루트 완결성 + 모델 불변식 + export/관측성 parity

6차 외부 리뷰(8.7/10)의 falsifiable 코드 주장만 실제 코드로 검증 → 진짜인 것만 수정.
아키텍처/통계 대개조(evidence-family ontology, LR calibration, SafeOutbound 통합)는
데이터 트랙 본작업이라 이번 라운드에 끼워넣지 않음(코드에 억지로 붙이면 오히려 의미 훼손).

### CONFIRMED → 수정
- **[P0] repro.edge_digest 통계의미 누락**: certainty/confidence 만 해싱 → evidence_lower/upper/decision
  이 달라도 canonical_root 불변(감사 맹점). edge_digest·provenance 에 증거구간/decision 포함.
  회귀: test_verify2.t_edge_digest_semantics (같은 conf·다른 구간/decision → 다른 루트, 동일의미 결정적).
- **[P1] Edge 불변식 부재**: confidence=1.7/NaN, lower>upper, decision="nonsense" 통과.
  Edge.__post_init__ 에서 [0,1]·유한·lower≤upper·decision∈{confirmed,unconfirmed,drop,None} 강제.
  회귀: test_verify2.t_edge_invariants (불량 5종 거부, 정상 통과).
- **[P1] corroborate_edges 비멱등**: cp-corroborate 증거가 ignore 목록에 없고 매 호출 append →
  재실행마다 k+1. ignore 기본값에 "cp-corroborate" 추가 + 이전 cp-corroborate 증거 교체(누적 안 함).
  회귀: test_sources.t_corroborate_idempotent (두 번 적용 → k=3·conf·증거 불변).
- **[P1] 제네릭 비영구성**: prune 으로 버킷이 max_bucket 이하로 줄면 _rebuild_pairs 가 과거 제네릭 값의
  쌍을 재생성(정책 충돌). _rebuild_pairs 가 self._generic 을 존중(영구 승격 계약 준수).
  회귀: test_infra_cp.t_generic_permanent_after_prune.
- **[naming] operator_clusters min_pairwise_cp_lower**: 실제는 '연결 간선'의 최소 하한(모든 쌍 아님).
  connected component 는 A–B,B–C 로도 생기므로 A–C 강도 미보장 → min_edge_lower 로 개명 + docstring 정정.
- **[semantics] max_seconds=0 계층 불일치**: scheduler=무제한 vs InfraRecon.run_iter=즉시중단.
  <=0/None = 무제한으로 통일(deadline=None). 회귀: test_net.t_max_seconds_budget(0=무제한/양수=중단).
- **[P1] snapshot_diff 내용변경 미탐지**: key 추가/삭제만 봄 → confidence/decision 만 바뀐 간선 못 잡음.
  entity/edge content digest 로 entities_changed/edges_changed 추가(P0 edge_digest 수정과 연동).
  회귀: test_infra_cp.t_snapshot_content_diff.
- **[P1] Cypher literal/batch parity**: to_cypher_batch 는 evidence_lower/upper/decision/count 보존하는데
  리터럴 to_cypher 는 certainty/confidence 만 → 세 export 경로 의미 불일치. 리터럴에도 증거필드 추가.
  회귀: test_sources.t_cypher_evidence_and_ident (batch+리터럴 둘 다 + injection 거부).
- **[P1] deconfound 관측성**: '적용됨' 표기지만 교란자가 데이터에 없거나 층이 작아 전역 폴백인 경우 안 보임.
  Deconfounder.coincidence_meta(p, used_stratified) 추가 → deconfounded_clusters 가
  requested/available_confounders·effective·stratified_pairs·global_fallback_pairs 보고. CLI 노출.
  회귀: test_sources.t_deconfounded_clustering (effective/available/없는교란자 fallback).

### FALSE / 이미 처리됨 (검증만, 코드 변경 없음)
- **IP→netblock double-count**: 리뷰는 _IP_DERIVED 에 netblock 이 없어 a_ip 와 same-/24 가 둘 다 남는다고
  주장 → 실제로는 collapse_shared 규칙2a 가 a_ip 공유 시 nb* 를 **전부** 제거함(별도 규칙). 오지적.

### 데이터 트랙(코드 아님, 이번에 안 함)
evidence-family ontology(168축→20~40 family), background reference population, likelihood-ratio
calibration, FDR/multiple-testing, SafeOutbound 공통 계층, 객체타입 분리(candidate vs attribution).
6개 리뷰가 모두 같은 천장(labeled ground-truth 필요)에 수렴 → 코드가 아니라 데이터 작업.

### 검증
전체 스위트 6,569 passed / 0 failed (6차 회귀 +24). compileall OK. pytest 브릿지 7 OK. CLI dry-run OK.

---

## 증분24 — 7차 리뷰 대응: 실제 코드 버그 4종(P0) + 운영 정합성 P1

7차 리뷰(8.8/10)는 처음으로 **재현 가능한 실제 코드 버그**(이론 아님)를 4개 짚었다. 전부 코드로
재현·수정·회귀테스트했다. 통계 대개조(evidence family, background population, LR)는 데이터 트랙 유지.

### P0 — 실제 버그 (재현 → 수정 → 회귀)
- **[P0-1] Conformal new-point 커버리지 붕괴**: `rank=min(n, ⌈(1-α)(n+1)⌉)` 가 ⌈⌉>n 일 때 n 으로
  clamp → τ=최댓값 → 새 교환가능 점이 이를 넘을 확률 ~1/(n+1) 라 실제 커버리지가 n/(n+1)<1-α 로
  떨어짐(n=5,α=.1 → 0.833, MC로 재현). 수정: k>n 이면 유한 임계값으로 1-α 보장 불가 → τ=±∞(전수
  채택). 회귀: test_verify2.t_conformal_newpoint_coverage(새점 MC 커버리지 ≥1-α), t_conformal.
- **[P0-2] Authorization 실행시점 TOCTOU**: 인가를 enqueue 시점(is_authorized)에만 검사 → 잡이 큐에서
  대기하는 동안 scope 만료 시 실제 조회가 만료 후 실행됨. 수정: 실제 fetch 직전 scope.check() 로
  **재검증**(_fetch_authed). 회귀: test_net.t_authz_execution_time_toctou(대기 중 만료 → 차단).
- **[P0-3] 실제 쿼리가 감사에 안 남음**: InfraRecon 이 is_authorized(감사 없음)만 써서 '무엇을 언제
  조회했나'가 기록 안 됨. 수정: 실행시점 scope.check() 가 통과/차단을 'query'/'blocked' 로 감사.
  회귀: test_net.t_query_audit_wiring(실제 조회 query 기록 + collector).
- **[P0-4] Edge merge 후 의미 모순**: certainty 는 CONFIRMED 흡수(OR), decision 은 마지막 기록 덮어쓰기
  → certainty=CONFIRMED + decision=drop 모순 가능. 수정: decision 보수적 병합(drop>unconfirmed>
  confirmed) + certainty 를 그와 일관되게 + 생성/merge 불변식(_check_consistency). 회귀:
  test_verify2.t_edge_merge_no_contradiction.

### P1 — 운영 정합성
- **[P1] SSRF/정책 거부(-3) 재시도 금지**: PolitenessHTTP._transient 가 status<0 전부 일시적 취급 →
  차단(-3)을 무의미하게 재시도. 수정: -1(연결)·-2(타임아웃)만 일시적, -3/-4 는 non-retryable.
  회귀: test_net.t_ssrf_no_retry.
- **[P1] Entity.merge dedup 에 raw_ref 포함**: Edge 는 고쳤는데 Entity 는 (source,detail,url)만 봐서
  같은 url·다른 raw_ref(인증서 id 등) 근거가 소실. (source,detail,url,raw_ref)로 통일(Edge link 도).
  회귀: test_sources.t_entity_dedup_rawref.
- **[P1] RequestLimiter 이름/예산 분리**: max_requests 는 사실 '동시성' 상한인데 '총' 상한처럼 읽힘 →
  max_concurrency 로 개명(max_requests 는 하위호환 별칭), 별도 max_total(총 요청 하드캡, 초과 시 -4)
  추가. CLI request_governor 키도 정정. 회귀: test_net.t_request_limiter_naming_and_budget.
- **[P1] 신호 개수 drift(100/161/168)**: fast_clusters docstring '161축' → 168 로 정정. signals.py 에
  SIGNAL_VERSION / BASE_SIGNAL_COUNT / EXTENDED_SIGNAL_COUNT 를 스펙에서 자동 계산해 단일 출처화.

### 데이터 트랙(코드 아님, 이번에도 안 함)
evidence-family ontology(168→20~40 family), background reference population + df 분리, P(E|H1)/P(E|H0)
likelihood ratio, calibration, FDR/multiple-testing, SafeOutbound 공통 probe 계층, graph_root/run_root
분리 + signal registry hash, Neo4j evidence 1급 객체화. 7개 리뷰가 같은 천장(labeled ground-truth)에 수렴.

### 검증
전체 스위트 6,594 passed / 0 failed (hypothesis 포함; 미포함 6,588). 7차 회귀 +25. compileall OK.
pytest 브릿지 7 OK. CLI dry-run OK(request_governor.max_concurrency 노출).

---

## 증분25 — v0.5.0 대규모 강화: 15개 축 + 2~4차 배선/계약 (자체 평가 후 보강)

사용자 지시로 스스로 약점을 15개 축으로 파악하고 전부 보강 → 이후 2·3·4차로 배선·계약까지 보강.
전 과정 사람 대상 재식별 축은 계속 닫음. 테스트 6,691 통과(hypothesis 포함; 미포함 6,685).

### 1차 — 15개 축(신규 모듈 6 + 기존 9 강화)
- 축1 **배경 모집단**(background.py): df 를 타겟 그래프와 분리(BackgroundCorpus, source='corpus'|'target-self'
  정직표기, 미관측값=CP상한 rule-of-three, corpus_hash).
- 축2 **증거 패밀리**(signals.family_of/collapse_families): 한 HTTP응답·한 인증서에서 파생된 축을
  패밀리당 1개로 붕괴 → co-derived double-count 제거(리뷰가 지목한 최대 통계 약점).
- 축3 **우도비**(likelihood.py): LR=P(E|동일)/P(E|무관), posterior_odds=prior×LR. 비보정=상한(posterior
  None, 정직), 보정 모델 주입 시 posterior 채움. 사후확률 날조 금지.
- 축4 **FDR**(fdr.py): BH(독립/PRDS) + BY(임의종속) q-value, 후보쌍 다중검정 통제.
- 축5 **run manifest**(manifest.py): run_root = H(graph_root, sw버전, signal_set_hash, policy,
  background_hash, time_window, sources) — graph_root(내용)과 분리.
- 축6 **신호 레지스트리 버전**: SIGNAL_VERSION/BASE/EXTENDED_COUNT 자동계산 + signal_set_hash + 패밀리 맵.
- 축7 **SafeOutbound**(safeoutbound.py): HTTP/TLS/favicon 등 모든 probe 를 authz+SSRF+limiter+politeness+
  audit 단일 관문으로. register_probe 로 새 probe 가 보증 자동 상속.
- 축8 **응답 크기 상한**(nethttp): max_body_bytes(기본 2MB) + truncated 플래그 — 응답크기 DoS 방어.
- 축9 **감사 내구성**(authz): durability sync|batch|buffer + entries_iter/verify_chain_stream(O(1) 메모리).
- 축10 **temporal 관측창**: observation_start/end 명시 API(사전지정 균일 null) + mc_pvalue/mc_exceedances/
  pvalue_ci 명명 분리.
- 축11 **deconfound 민감도**: sensitivity_analysis(min_stratum 3/10/30/100 스윕 + stable 판정).
- 축12 **conformal 확장**: Mondrian(그룹조건부) 임계값 + Conformal Risk Control(기대손실 E[L]≤α 유한표본).
- 축13 **객체 모델 분리**(attribution.py): AttributionEvidence/CandidateRelation/Decision — 증거≠결정,
  decision 은 정책값 기록, posterior 는 보정 시에만.
- 축14 **order-statistic 보정**(verify_cp): 'kind 내 최소 df 선택' post-selection 을 1-(1-q)^m 로 보정
  (coincidence_prob_selected).
- 축15 **robust 오염모델**(robust): CONTAMINATION_MODEL 명세(추가-only f-deletion, breakdown=f) +
  robust_guarantee machine-readable.

### 2차 — 엔진/CLI 배선(신규 능력을 실제로 사용)
- fast_clusters/coincidence_pairs/coincidence_clusters 에 by_family·order_correct 배선.
- CLI 플래그: --family-collapse, --order-correct, --fdr {bh,by}, --fdr-alpha.
- CLI 출력: run_manifest(graph_root≠run_root), 강화된 attribution_model(background_source·signal_set_hash·
  family_collapse·effective_deconfounding 요청≠효과 구분), fdr 블록, policy 확장.

### 3차 — lifecycle/provenance
- nethttp 세션을 WeakKeyDictionary(루프)로 → 종료 루프 세션 누수 제거.
- Evidence 에 observed_at/collector_version/content_hash(포렌식 재현성, 하위호환 기본 빈값).
- use_cp_upper 표본 모형(Binomial(N,p_v)) 엄밀 정의 + target-self 폴백 한계 명시.

### 4차 — 계약(contract) 성질 테스트
- batch==incremental(삽입순서 무관 클러스터), snapshot_diff 반대칭, NDJSON roundtrip==canonical_root,
  Edge merge 멱등, conformal 새점 커버리지(6차에서 추가) — 코드 커버리지에서 계약 검증으로.

### 검증
전체 6,691 passed / 0 failed(hypothesis 포함). compileall OK. pytest 브릿지 8스위트. CLI dry-run 신규 블록 확인.

---

## 증분26 — 사람 축 활성화(거버넌스 게이팅) + 8차 리뷰 P1–P5 반영

### 정책 재정의: 타입 차단 → 거버넌스 게이팅
합법 OSINT 는 공개정보를 인가·합법근거·공개출처·목적 안에서 활용하는 것이며 불법이 아니다. 이메일·전화·
아이디·성명을 **데이터 타입 자체로 전면 차단하면 정당한 OSINT(위협인텔·인가 pentest·WHOIS·컨센트 조사)가
죽는다**. 그래서 차단을 거버넌스로 바꿨다:
- authz: BASIS_OSINT("osint-public") 추가. Authorization.person_allowed() = not infra_only. `_in_scope` 가
  사람 타입을 **정확 인가 selector** 로만 허용(consent/legal/self-audit/osint-public). 이메일은 인가 도메인
  접미사로도 매칭(조직 대규모 조사). phone/username/name 은 정확 인가만(사인 집단 무단 수집 방지).
  infra_only(threat-intel-infra)에선 사람 selector 여전히 전면 거부.
- infra_recon: classify_person 추가, seed_one 이 인가된 사람 selector 를 1급 엔티티로 수용(무범위/미인가/
  infra_only 는 명확한 사유로 skip). 실행시점 scope.check 재검증 + 전 조회 감사(기존 P0 틀 재사용).

### 사람 축 발전: 공개출처 유출 노출(person_osint.py)
사용자 요구 — "유출 여부만 알면 소용없다. 그 아이디/이메일이 진짜 당사자 것인지 확인할 수 있어야 한다.
단 비밀번호 같은 민감정보는 제외." → HIBP 모델:
- BreachPresenceSource: 운영자 공급 corpus 에 대해 presence/count/breach 메타 + **함께 노출된 식별자**
  (당사자 확인용) 반환. corpus 로드 시 authz.redact_credentials 로 password/hash/secret 전량 제거.
- PersonRecon(scope, source): 인가된 사람 selector 만, 매 조회 감사. 식별자·breach 노출 그래프 생성
  (당사자가 '이 아이디가 내 것'인지 그래프에서 확인). 비밀번호는 어디에도 안 나온다(하드 리밋).
- CLI --breach JSON: 인가된 사람 selector 의 유출 노출을 result.person_breach 로. E2E 검증: 코퍼스에
  password 가 있어도 출력에 절대 안 나옴, 식별자·linked_identifiers 는 표시.

### 8차 리뷰(8.9/10) 반영
- **[P1] max_total 동시부하 no-op(실버그)**: 예산 체크가 세마포어 밖, 증가가 안이라 gather 400개가
  전부 통과. → 진입 즉시 **예약 카운터(reserved)** 를 await 전에 증가(단일스레드 원자적). 검증: 400 병렬
  → inner 정확히 100, 300건 -4. test_upgrade.t_review8_max_total_concurrency.
- **[P2] correlate_same_operator 절대 confirm 안 함(tau=0.8 > n=14 달성상한 0.768)**: 스크리닝 전용임을
  docstring 에 명시(권위 판정은 IDF-coincidence/deconfounded). max_confirmable_lower(n,α) 헬퍼로 상한 투명화.
- **[P3] deconfound 폴백이 가장 필요한 희소점에서 조용히**: fallback_ratio + fallback_note 를 1급 출력으로
  (deconfounded_clusters·sensitivity_analysis·CLI). "결과의 X% 는 실제 디컨파운딩 안 됨" 명시.
- **[P4] temporal MC null endpoint-conditioning(검정력 손해)**: 데이터유도 창에서 null 이 양 끝점 고정 +
  내부 n-2 점만 재표본 → range 편향 제거(level 보존, 검정력 회복).
- **[P5] 감사 해시가 재직렬화 JSON 해싱**: 기록시점 **canonical bytes** 를 디스크에 쓰고 그 바이트를 해싱
  → '디스크의 그 바이트'를 봉인. _canon_bytes 통일(record/buffer flush 모두).
- **coincidence 문구**: "우연일치의 정확 확률" → "**축 독립 가정 하** 정확 확률"(헤드라인 수치 ≠ 현실 확률 명시).
- **conformal property 교체**: 약한 in-sample 커버리지 property(P0 버그를 놓쳤던 그것) → **new-point** MC
  커버리지 property 로 교체(test_properties).

### 검증
전체 6,734 passed / 0 failed(hypothesis 포함; 미포함 6,725). compileall OK. pytest 브릿지 8스위트.
CLI: 사람 selector 가 consent 근거에선 그래프 진입, infra_only 에선 거부. --breach 는 식별자 표시·비밀번호 제외.

---

## 증분27 — 9차 리뷰 P6–P8 반영(사람 축 안전 조임)

9차 리뷰(9.0/10)가 P1–P5 실측 통과를 확인하고, 새로 연 사람 축에서 구멍 3개를 재현했다. 전부 수정·검증.

- **[P6] domain_suffixes 이중용도 → 대형 메일제공자 대량 스캔 인가(사람 축 최대 리스크)**: 인프라
  서브도메인 와일드카드(domain_suffixes)가 사람 이메일 매칭에 재사용돼, gmail.com 을 인프라 접미사로
  넣으면 모든 @gmail.com 개인 유출점검이 자동 인가됐다. 수정: 사람 이메일 와일드카드를 **person_email_domains**
  로 분리(인프라와 별개), 공용 메일 제공자(gmail/naver/outlook 등 30+)는 person_email_domains 등록 자체를
  ValueError 로 거부. CLI --person-email-domain 신설. 회귀: t_review_p6_domain_suffix_split.
- **[P7] redact_credentials 신뢰불가(부분문자열 denylist, pw/pass/plain/cleartext 통과, list 미재귀)**:
  (1) 토큰 매칭으로 전환(pw/pass 잡되 pwn_count/passport 오탐 안 함) + 리스트/중첩 재귀. (2) breach corpus 는
  BreachPresenceSource 가 **allowlist**(breach/date/data_classes/identifiers/count/... 만)로 로드 → 자격증명은
  어떤 필드명으로 와도 저장 안 됨(문서화된 보장, denylist 는 2차 방어). 회귀: t_review_p7_redact_robust,
  t_review_p7_breach_allowlist.
- **[P8] linked_identifiers 제3자 spill(corpus 품질 의존)**: 같은 유출 레코드의 다른 식별자를 무조건
  '본인 확인용'으로 노출하면 느슨한 레코드(메일스레드 등)에서 제3자가 딸려나온다. 수정: same_subject=True 로
  '이 레코드 식별자는 모두 동일 주체'를 명시한 경우에만 노출, 미명시는 withheld 카운트 + third_party_warning.
  corpus 스키마 계약(레코드=단일 주체) 문서화. 회귀: t_review_p8_third_party_spill.

검증: 전체 6,750 passed / 0 failed. CLI: --person-email-domain acme-corp.com → @acme-corp.com 인가,
gmail.com → 거부(fail closed). 사람 축은 방향(거버넌스 게이팅) 유지하면서 가장 위험한 지점을 조였다.

---

## 증분28 — 사람 축 도구 추가(공개출처·인가·자격증명 없음)

사용자 요청: 사람 축에 추가할 도구. Maltego/SpiderFoot/Maigret 계열의 **합법·공개** 부분만, 기존 거버넌스
(인가 selector 정확 매칭 + 감사 + 자격증명/생체/제3자 spill 없음) 안에서 도입.

- **아이디 공개 프로필 존재 조회(UsernamePresenceSource, Maigret/Sherlock 모델)**: 인가된 아이디의 공개
  프로필이 어느 사이트에 있는지 + URL. username_candidate_urls 는 네트워크 없이 후보 URL 결정적 구성,
  probe(url)->bool 주입식(오프라인 테스트/‑‑dry 는 후보만; 실네트워크는 HTTP presence 200/404 만, 페이지
  내용·자격증명 스크레이핑 없음). 아이디는 와일드카드 불가(정확 인가만) 유지.
- **이메일 공개 enrichment(email_enrichment)**: Gravatar 공개 아바타/프로필(이메일→md5, Gravatar 는 공개
  설계), 형식 유효성, 도메인, disposable(일회용) 판별(공개 목록), MX 존재(resolver 주입 시). "이 이메일이
  진짜·활성인가" 확인용 — 비밀번호·계정내용 없음.
- **동일인 후보 상관(same_person_candidates)**: 인프라 same-operator 의 IDF-coincidence 엔진을 사람 식별자에
  재사용. 희소 **공개** 신호(아바타 해시·표시명·연결 이메일 등) 공유 → 동일인 **후보**(relation 동일인후보,
  확정 아님) 링크 + coincidence 증거. "이 아이디가 이 이메일과 동일인?"을 통계로. 결정은 사람이 인가·맥락과.
- **PersonRecon 통합**: breach + username presence + email enrich 를 한 번에(인가·감사 안). CLI
  --username-check / --email-enrich 플래그(‑‑breach 와 함께/독립). 결과는 result.person_osint.

전부 공개출처·인가 게이팅·감사. 생체 대량식별·자격증명 노출·제3자 spill 없음(P6–P8 가드 유지).
검증: 전체 6,767 passed. CLI dry-run 에서 username 후보/email gravatar·disposable·MX 정상.

---

## 증분29 — 사람 축 도구 배치2(공개출처 6종 추가)

전부 공개·비민감·인가·감사. 개인키/자격증명/생체/제3자 spill 없음.
- **전화 메타데이터(phone_intel)**: E.164 파싱 → 국가(calling code)·국번·형식 유효성. 결정적·네트워크 없음.
  통신사(HLR)/소유자 조회는 유료·민감이라 **안 함**(정직). '이 번호가 유효/어느 국가인가' 확인.
- **role 계정 분류(classify_identifier_role)**: info@/noreply@/admin 등 = 개인 아님 플래그 → 개인 대상
  조사에서 구분/제외(오남용 방지).
- **PGP 공개키서버(KeyserverSource)**: 이메일→**공개키** 지문/UID(개인키 절대 없음). 같은 키의 다른 UID =
  동일 주체 별칭으로 노출(공개키 소유자가 등록한 자기 신원).
- **CT 이메일 SAN(CTEmailSANSource)**: 이메일→S/MIME 인증서 공개 메타(발급자·유효기간·시리얼, allowlist).
- **공개 git 커밋 이메일(GitCommitIdentitySource)**: 아이디→공개 커밋 author 이메일(아이디↔이메일 공개 연결).
- **Gravatar 공개 프로필 확장(gravatar_profile)**: 이메일→공개 연결 계정/표시명(Gravatar 공개 설계).
- PersonRecon 통합: phone/role 은 자동(결정적), keyserver 는 주입식. CT/git/gravatar 는 라이브러리 API
  (운영자 lookup 주입). 인가·감사 게이팅 유지.

검증: 전체 6,783 passed. 전화 KR 파싱, role 탐지, 공개키 동일주체 UID 링크, CT allowlist(개인키 제거) 확인.

---

## 증분30 — 사람 축 성능·정확도 강화

- **동일인 상관 = OperatorIndex 재사용(성능+정확도)**: same_person_candidates 를 인프라 same-operator
  엔진 위에 재작성. (1) 역인덱스 → 값 공유 **후보쌍만** 비교(전체 O(n²) 회피 — 400명 흔한신호 0.009s).
  (2) **generic 억제(max_bucket)** → 흔한 표시명·플랫폼 기본신호가 전원을 연결하지 않음(정확도+폭발 방지).
  (3) order-statistic 보정 + CP-upper + **배경 모집단(background)** 지원 → 인프라 축과 동일한 통계 엄밀성.
  검증: 배경에서 희소 값 공유가 흔한 값 공유보다 강한 근거(rare_p < common_p).
- **전화 정확도**: phone_intel 에 국가별 국번 자릿수 범위(_NATIONAL_LEN, 주요 20+국) → **plausible** 정밀
  판정(KR 국번 10자리 그럴듯, 5자리는 아님). 여전히 통신사/소유자 조회 없음(정직).
- **성능(네트워크)**: UsernamePresenceSource.lookup_async — 15+ 사이트를 세마포어로 **동시 probe**(gather).
  느린 probe 0.02s×15 를 순차 0.3s → 동시 ~0.02s. presence 만.

검증: 전체 6,793 passed. generic 억제·동시 probe·전화 plausible·배경 상관 실측 확인.


## 증분31 — 사람 축 정확도·검정력 강화 3종 + 테스트 강건화

동일인 상관과 신원 통합을 인프라 통계 엔진 위에서 더 엄밀하게. 3가지 모두 **기존 엔진 재사용**(성능 유지).

- **(1) 사람 신호 deconfounding**: same_person_candidates(deconfound=<confounder kind>) → deconfound.
  deconfounded_clusters 재사용. 플랫폼 등 교란자 층에서 **조건부** coincidence 계산 → 같은 플랫폼
  기본신호로 엮이는 오탐 제거. fallback_ratio 를 1급 지표로 함께 반환(층 부족 시 전역 폴백 비율 정직 표기).
  검증: github 을 공유하는 40명이 동일인으로 오병합되지 않고, 희소신호(RAREHASH+aliceX) 공유한 진짜
  쌍만 남음.
- **(2) 동일인 후보 FDR 통제**: same_person_candidates(fdr='bh'|'by') → fdr.fdr_edges 재사용. 다중
  후보쌍의 오탐률(FDR)을 BH(독립)/BY(임의종속)로 통제, 각 쌍에 q_value 부여. 검증: BY q_value ≥ raw p
  (보수적 조정), 강한 진짜 쌍은 통과.
- **(3) 인프라+사람 통합 신원 해소(resolve_identities)**: 여러 공개출처 링크(같은 유출레코드·같은 PGP
  키 UID·공개 커밋 author·Gravatar 연결계정) + 동일인 상관을 **한 그래프**로 합쳐 connected-component =
  신원 클러스터(피벗). graph_analytics.connected_components 재사용.
  - **오병합 방지**: identity-bearing 관계만 union — 식별자↔사이트(REL_PROFILE_ON)·식별자↔breach
    (REL_EXPOSED_IN)·이메일↔아바타(REL_GRAVATAR) 같은 **비신원 엣지는 무시**(사이트 사용자 전원이 한
    사람으로 붕괴하는 것 방지). min_coincidence(약한 상관 배제)·min_bridge_types(단일신호 오병합 저항) 게이트.
  - **정직 표기**: near-bijective 공개사실 브리지로 묶이면 deterministic=True("확인"), 통계 상관만이면
    False("후보"). 검증: alice 이메일+업무이메일+아이디가 통합되고, github.com·breach·avatar 노드는 신원
    클러스터에 유입되지 않음.
- **정리(정직성)**: same_person_candidates 의 `n_population` 파라미터 **제거**. 소표본 in-sample df 를
  임의 대형 N 으로 나눠 rarity 를 부풀리는 것은 anti-conservative(오탐↑)라 지원 불가 — 참조 모집단 유병률은
  `background=BackgroundCorpus`(모집단 규모 df)로만 공급. 죽은/오도 파라미터를 남기지 않음.
- **테스트 강건화(flaky 제거)**: 병렬성 검증 타이밍 임계값 2곳(t_doh_parallel, t_person_perf_accuracy)을
  0.15→0.20 으로 완화. 순차(0.30s)와 뚜렷이 분리되면서 pytest 출력캡처·이벤트루프 스케줄링 지터에 강건
  (0.15 는 캡처 부하에서 간헐 실패했음 — 회귀).

검증: 전체 6,809 passed(증분30 대비 +16 신규 체크: deconfound+FDR, 신원해소), 0 failed. 4연속 green
(캡처 on) — flaky 제거 확인.


## 증분32 — 클린 머신 크래시 수정: 옵션 의존성(cryptography) 우아한 강등

실제 배포 검증(사용자 크롬북, Debian 13 / Python 3.13, cryptography 미설치)에서 드러난 **진짜 버그**.

- **증상**: `tests/test_infra_cp.py::t_tls_spki` 가 매 실행마다 `_make_cert_der` 로 X.509 인증서를 생성하며
  `from cryptography import x509` 를 **하드 임포트** → cryptography 없는 클린 머신에서 `ModuleNotFoundError`
  가 잡히지 않고 전파되어 **스위트 전체가 크래시**(summary 없이 중단). scipy·hypothesis 는 "미설치→스킵/폴백"
  인데 이 테스트만 일관성이 깨져 있었음. runtime 은 무해(`spki_pin` 은 이미 cryptography 없으면 `cert:` 전체
  해시로 폴백) — **테스트 위생 결함**이었음.
- **수정**: 매 실행 인증서 생성을 **정적 DER 테스트벡터 3종**(결정적 EC 키 사전생성)으로 교체 — cryptography
  없이도 테스트가 돈다. A/B 는 다른 키, A2 는 **A와 같은 키·다른 인증서**. cryptography 유무를 감지해:
  - 있으면 SPKI 파싱 경로(`spki:` 접두사) + **같은 키·다른 인증서 → 같은 SPKI 핀**(SPKI 핀의 핵심 성질을
    이제 실제로 검증 — 과거 테스트엔 없던 체크, +1).
  - 없으면 `cert:` 전체해시 폴백 경로(사용자 크롬북에서 실제로 도는 경로)를 검증 — 다른 인증서 → 다른 핀.
  두 경로 모두 크래시 없이 통과. cryptography 차단 시뮬레이션(meta_path 블록)으로 클린 머신 동작 확인.
- **원칙 확인**: 모든 옵션 의존성(hypothesis/scipy/cryptography/aiohttp)은 부재 시 **우아하게 강등**하며
  어떤 스위트도 크래시하지 않는다(zero required deps 약속의 테스트 계층 이행).

검증: 전체 6,810 passed(+1: 같은키→같은SPKI핀 성질), 0 failed. cryptography 유/무 양쪽 모두 크래시 없음.
