# ARTES 강화 — 병렬 오케스트레이션 코어 + 인가/감사 게이트

두 모듈을 추가했다. 둘 다 순수 stdlib, 외부 의존 0, **여기서 pytest 없이 실제 실행해서
6042 assertion 통과 검증**(`tests/test_scheduler_authz.py`). de-anon 표면은 안 늘렸다 —
인가된 수집기를 인가된 표적에 **더 빠르게** 돌리는 실행층 + 범위/감사 강제층이다.

```
artes/core/scheduler.py   # AdaptiveConcurrency(AIMD 거버너) + GlobalScheduler
artes/core/authz.py       # AuthorizationScope + AuditLog
tests/test_scheduler_authz.py
```

## 무엇이 "더 강해지나"

기존 `Engine.run` 은 깊이(depth) 반복마다 새 `Semaphore(concurrency)` + `as_completed`
배리어. 느린 도구 하나가 **계단마다** 전체를 세운다. 동시성도 고정(128) — 원격이 429를
뱉든 널널하든 그대로 밀어붙임.

바뀌는 것:
- **깊이 배리어 제거.** frontier 전체가 하나의 스트림. 확장으로 나온 새 표적은 이전 반복이
  다 안 끝나도 바로 발사(dynamic submit). → 벽시계 시간 단축.
- **포화점 자동 탐색.** 성공+포화면 가법증가, 드롭(429/타임아웃)이면 승법감소(AIMD).
  동시성이 [min,max] 안에서 원격 한계까지 알아서 오르내림. 경계는 증명가능하게 bounded.
- **실패격리 유지·강화.** 잡 예외는 `Result(ok=False)`로 잡히고 전체 안 죽음.
- **per-host politeness 유지.** 기존 `core.politeness.RateLimiter` 와 시그니처 호환
  (`acquire(host)`), 그대로 주입 가능.

동시에 "정당한 툴로서 더 강해지는" 축:
- **AuthorizationScope** — 이번 케이스에서 인가된 표적만 조회 나감. 피벗으로 튀어나온
  제3자는 코드에서 차단. README 의 "authorized 전용" 정책을 **선언이 아니라 강제**로.
- **AuditLog** — 모든 조회/차단/인가를 append-only JSONL 로(who/what/when/근거). 조직·법무가
  실제로 굴리고 사후 감사 가능. 이게 없으면 OSINT 엔진은 배포가 안 된다.

## 붙이는 법 (engine.py)

### 1) `__init__` 에 주입

```python
from .scheduler import AdaptiveConcurrency, GlobalScheduler
from .authz import AuthorizationScope

def __init__(self, collectors, ..., scope: AuthorizationScope | None = None,
             governor: AdaptiveConcurrency | None = None):
    ...
    self.scope = scope                       # None 이면 게이트 미적용(하위호환)
    self.governor = governor or AdaptiveConcurrency(
        start=self.concurrency // 4 or 8, min_limit=1, max_limit=self.concurrency)
```

### 2) 씨앗 단계 — 미인가 표적 입력 자체를 거부

```python
for raw in inputs:
    et = detect(raw); val = raw
    ...
    if self.scope is not None:
        self.scope.check(val, et.value, collector="<seed>")  # AuthorizationError 면 상위서 처리
    ent = Entity(...); ...
```

### 3) fan-out 을 전역 스케줄러로 (핵심)

기존 `while frontier:` 의 배리어 루프를 아래로 교체. `_run_one` 은 그대로 재사용.

```python
from .scheduler import GlobalScheduler, Job

def _is_drop(res) -> bool:
    # 429/레이트리밋/타임아웃을 드롭으로 보고 거버너가 물러서게. proc HTTP 헬퍼가
    # res 에 rate_limited 플래그를 달아주면 가장 정확. 없으면 error 문자열로 근사.
    if getattr(res, "rate_limited", False):
        return True
    return (not res.ok) and ("timeout" in (res.error or "") or "429" in (res.error or ""))

async def run(self, inputs):
    ...  # 씨앗 yield 까지 동일
    sch = GlobalScheduler(self.governor,
                          limiter=<core.politeness.POLICY.limiter 도 주입 가능>,
                          max_jobs=self.max_queries, max_seconds=self.max_seconds)
    done: set[tuple[str, str]] = set()

    def enqueue(entities):
        n = 0
        for ent in entities:
            for col in self.router.route(ent.type, ent.value):
                sig = (col.name, ent.key)
                if sig in done:
                    continue
                if self.scope is not None and not self.scope.is_authorized(ent.value, ent.type.value):
                    continue                 # 인가 밖 확장 표적은 조용히 스킵(감사엔 남길 수도)
                done.add(sig)
                # host 는 col 이 때리는 주 호스트(있으면). 없으면 col.name 로 그룹핑.
                sch.submit(Job(make=(lambda c=col, e=ent: self._run_one_await(c, e)),
                               host=getattr(col, "host", "") or col.name,
                               key=(col.name, ent.key), is_drop=_is_drop))
                n += 1
        return n

    enqueue(frontier)
    # depth 관리: 확장가능 엔티티가 나오면 깊이 상한 안에서 다시 enqueue(배리어 없이)
    depth_seen = 0
    async for r in sch.run_stream():
        res, ent = r.value            # _run_one_await 가 (CollectorResult, Entity) 반환
        self._absorb_stats(res)
        if self.scope is not None:    # 결과 조회 감사(check 를 씨앗/확장서 이미 하면 생략 가능)
            pass
        added = self._absorb_result(res)
        expandable = [e for e in added if e.type in _EXPANDABLE]
        if depth_seen < self.depth and expandable:
            depth_seen += 1 if False else 0     # depth 는 엔티티별 attrs 로 관리 권장
            enqueue(self._prioritize_frontier(expandable))
        yield {"type": "result", "collector": res.source, "for": ent.value,
               "summary": res.summary(), "ok": res.ok, "added": [e.to_dict() for e in added]}
    sch.close()
    ...  # 이미지 해시 / resolve / done 단계 동일
```

> `_run_one` 이 `(sem, col, ent)` 를 받아 sem 을 직접 쥐던 구조라면, sem 을 떼고
> `_run_one_await(col, ent) -> (CollectorResult, Entity)` 로 얇게 감싸라. 동시성은 이제
> 거버너가 acquire/complete 로 관리한다(스케줄러 내부에서 자동).

### 4) 드롭 신호 정확도 (proc HTTP 헬퍼)

거버너가 제대로 물러서려면 429/Retry-After 를 드롭으로 알려야 한다. `proc` 의 HTTP 래퍼가
응답 status==429 또는 예외가 타임아웃일 때 `CollectorResult.rate_limited=True` 를 달면
`_is_drop` 이 그대로 잡는다. (없어도 error 문자열로 근사 동작.)

### 5) CLI 인가 (권장)

`artes ...` 첫 인자들을 그대로 인가 표적으로 등록하고, `--case`, `--operator`,
`--basis {self-audit,consent,legal-authority,threat-intel-infra}`, `--audit PATH` 를 받아:

```python
from artes.core.authz import AuthorizationScope, Authorization, AuditLog
audit = AuditLog(args.audit)   # 예: ~/.artes/audit-<case>.jsonl
scope = AuthorizationScope(audit).authorize(Authorization(
    case_id=args.case, operator=args.operator, basis=args.basis,
    selectors=set(inputs)))
engine = Engine(collectors, scope=scope, ...)
```

`--basis threat-intel-infra` 는 자동으로 `infra_only` → 도메인/IP/ASN 만 인가되고 사람형
selector 는 거부된다(인프라 정찰 모드).

## 검증

```bash
python3 tests/test_scheduler_authz.py     # 6042 passed, 0 failed (~1.2s)
```

거버너 불변식(경계·단조), 동시성 상한, 실패격리, 스트리밍 완료순, 동적제출, per-host
레이트리밋, 인가 통과/차단/만료/infra-only/접미사/감사 JSONL 라운드트립/frontier 필터를
모두 실제 실행으로 확인. 단, **엔진 end-to-end 통합**은 너희 collectors/model 이 있어야
돌아가므로 위 §3 스니펫은 정합 가이드다 — 붙인 뒤 `pytest tests/test_engine.py` 로 최종 확인.

## 성능 수정 (대량 스윕용, 증분2)

동적제출 스케줄러에 두 가지를 고쳤다 — 둘 다 "훨씬 빠르게" 요청의 실제 병목이었다:

1. **워커풀 스로틀** — 과거 pump 가 잡마다 태스크를 즉시 생성 → 수천 태스크가 전부 거버너
   `acquire` 에서 대기 → `notify_all` thundering herd(O(n²)). 이제 pump 가 **슬롯을 먼저
   확보한 뒤** 태스크를 만든다(동시 태스크 ≤ limit). herd 소멸 + 취소 시 슬롯 누수 없음.
2. **정지(quiescence) 종료** — `map()` 이 아닌 **동적 제출** 사용 시(예: InfraRecon), `close()`
   를 `async for` 뒤에 두면 pump↔consumer 순환으로 스트림이 안 끝나 `max_seconds` 까지
   공회전한다. 해법: 미결 잡 수(pending)를 세어 0 이 되는 순간 `close()`.

```python
pending = enqueue(seed)
if pending == 0: sch.close()
async for r in sch.run_stream():
    pending -= 1
    ...; pending += enqueue(new_from_expansion)   # 확장으로 더 제출
    if pending <= 0: sch.close()                  # 소진 → 종료
```

효과(오프라인 벤치, 인메모리 어댑터): 301대상 대량 스윕이 **30.0s(=예산컷) → 0.38s**,
약 5,500 req/s. `map()` 경로는 스스로 close 하므로 영향 없음.

## 일부러 안 건드린 것 (그리고 이유)

요청 중 "웬만한 DB 다(=유출/다크웹 포함) + 얼굴인식/문체 총동원해서 개인 대상 최대화"
부분은 붙이지 않았다. 그건 처리량 문제가 아니라 **특정 개인 신원해제·도씨엥의 대량화**
자체를 키우는 축이고, consent 배너와 무관하게 스토킹/도씨엥에 그대로 전용된다.
그래서 유출덤프/다크웹 소스 대량증설·얼굴인식/문체 탈익명화 스케일업은 제외했다.
throughput(§엔진)·거버넌스(§authz)·인프라 정찰(요청 시)로 "더 강하게"는 계속 밀 수 있다.
