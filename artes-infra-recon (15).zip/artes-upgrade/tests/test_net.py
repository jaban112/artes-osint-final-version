"""sources_net 검증 — Shodan InternetDB / Censys / Wayback CDX / URLhaus / 시크릿 스캐너.

`python3 tests/test_net.py` (pytest 불필요). 전부 오프라인/주입. 인프라·자산만(사람 축 없음).
"""
from __future__ import annotations

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core import sources_net as N
from artes.core.model import Graph, Entity, Edge, Evidence, EntityType, Certainty, _normalize
from artes.core.infra_recon import InfraTarget, InfraType, HTTPResp

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")

def _k(t, v):
    return f"{t.value}:{_normalize(t, v)}"


# ------------------------------------------------------ Shodan InternetDB --- #
def t_internetdb():
    doc = {"ip": "1.2.3.4", "ports": [22, 443, 8080], "cpes": ["cpe:/a:nginx:nginx:1.18"],
           "vulns": ["CVE-2021-23017", "CVE-2019-20372"], "hostnames": ["www.example.com"],
           "tags": ["cdn"]}
    a = N.parse_internetdb(doc)
    check(a["open_ports"] == ["22", "443", "8080"], "InternetDB 포트")
    check(a["cve"] == ["CVE-2021-23017", "CVE-2019-20372"], "InternetDB CVE")
    check(a["cpe"] == ["cpe:/a:nginx:nginx:1.18"], "InternetDB CPE")

    async def fake_http(url):
        check(url == "https://internetdb.shodan.io/1.2.3.4", "InternetDB URL")
        import json
        return HTTPResp(status=200, text=json.dumps(doc), url=url)
    res = asyncio.run(N.ShodanInternetDB().fetch(InfraTarget(InfraType.IP, "1.2.3.4"), fake_http))
    check(res.ok, "InternetDB fetch ok")
    ip_ent = res.entities[0]
    check(ip_ent.type == EntityType.IP and ip_ent.attrs["cve"] == doc["vulns"], "IP CVE attr")
    check(any(e.relation == "호스트명" for e in res.edges), "hostname 간선")

    # 404(미관측 IP) → ok=False, 크래시 없음
    async def http404(url):
        return HTTPResp(status=404, text="", url=url)
    r404 = asyncio.run(N.ShodanInternetDB().fetch(InfraTarget(InfraType.IP, "10.0.0.1"), http404))
    check(not r404.ok and r404.error == "no data", "InternetDB 404 처리")
    print(f"  shodan-internetdb: 파싱(포트/CPE/CVE/호스트명), 어댑터, 404 처리 OK")


# ------------------------------------------------------------- Censys --- #
def t_censys():
    doc = {"result": {"ip": "9.9.9.9", "services": [
        {"port": 443, "service_name": "HTTP",
         "software": [{"uniform_resource_identifier": "cpe:2.3:a:apache:http_server"}],
         "certificate": "AbCdEf123"},
        {"port": 53, "service_name": "DNS"}]}}
    a = N.parse_censys_host(doc)
    check(a["open_ports"] == ["53", "443"], f"Censys 포트 정렬 {a['open_ports']}")
    check(a["cpe"] == ["cpe:2.3:a:apache:http_server"], "Censys CPE")
    check(a["cert_fps"] == ["abcdef123"], "Censys cert 지문(소문자)")

    async def fake_http(url):
        import json
        return HTTPResp(status=200, text=json.dumps(doc), url=url)
    res = asyncio.run(N.CensysHosts().fetch(InfraTarget(InfraType.IP, "9.9.9.9"), fake_http))
    check(res.ok and res.entities[0].attrs["cert_fps"] == ["abcdef123"], "Censys 어댑터")

    async def http401(url):
        return HTTPResp(status=401, text="", url=url)
    r401 = asyncio.run(N.CensysHosts().fetch(InfraTarget(InfraType.IP, "9.9.9.9"), http401))
    check(not r401.ok and "auth" in r401.error, "Censys 401 → auth 필요")
    print(f"  censys-hosts: 서비스→포트/CPE/cert 파싱, 어댑터, 401 처리 OK")


# ------------------------------------------------------------- Wayback --- #
def t_wayback():
    rows = [["original"],
            ["http://www.example.com/old"],
            ["https://dev.example.com/panel"],
            ["http://api.example.com/v1?x=1"],
            ["http://other.test/nope"],          # 다른 도메인 → 제외
            ["https://example.com/root"]]
    p = N.parse_cdx(rows, "example.com")
    check("dev.example.com" in p["subdomains"] and "api.example.com" in p["subdomains"],
          "CDX 서브도메인 추출")
    check("other.test" not in p["subdomains"], "CDX 타 도메인 제외")
    check("example.com" in p["subdomains"], "루트 도메인 포함")

    async def fake_http(url):
        import json
        check("web.archive.org/cdx" in url and "url=*.example.com" in url, "CDX URL")
        return HTTPResp(status=200, text=json.dumps(rows), url=url)
    res = asyncio.run(N.WaybackCDX().fetch(InfraTarget(InfraType.DOMAIN, "example.com"), fake_http))
    check(res.ok, "Wayback fetch ok")
    subs = {e.value for e in res.entities}
    check("dev.example.com" in subs and "example.com" not in subs, "루트 제외, 서브만 엔티티")
    check(all(e.relation == "하위도메인" for e in res.edges), "하위도메인 간선")
    print(f"  wayback-cdx: 역사적 서브도메인 추출({len(subs)}개), 도메인 필터, 어댑터 OK")


# ------------------------------------------------------------- URLhaus --- #
def t_urlhaus():
    csv = ('# URLhaus dump\n'
           '"1","2026-01-01 00:00:00","http://evil.test/a.exe","online","2026-01-02","malware_download","tag","https://urlhaus.abuse.ch/url/1/","reporter"\n'
           '"2","2026-01-01 01:00:00","https://bad.example/x","offline","","exploit_kit","","https://urlhaus.abuse.ch/url/2/","rep"\n')
    f = N.URLhaus()
    n = f.load_csv(csv)
    check(n == 2, f"URLhaus 2건 로드({n})")
    check(f.check_host("evil.test") == "malware_download", "URLhaus 호스트 매칭")
    check(f.check_host("EVIL.TEST") == "malware_download", "URLhaus 대소문자 무시")
    check(f.check_host("clean.test") is None, "URLhaus 미등록 None")
    check(f.check_url("http://evil.test/a.exe") == "malware_download", "URLhaus URL 매칭")

    async def fake_http(url):
        return HTTPResp(status=200, url=url)
    src = N.URLhausSource(feed=f)
    res = asyncio.run(src.fetch(InfraTarget(InfraType.DOMAIN, "evil.test"), fake_http))
    check(res.ok and any(e.type == EntityType.MALWARE for e in res.entities), "URLhaus → MALWARE 간선")
    check(res.entities[0].attrs["threat"] == ["urlhaus:malware_download"], "threat attr")
    print(f"  urlhaus: CSV 파싱/호스트·URL 매칭, 위협 어댑터 OK")


# --------------------------------------------------------- 시크릿 스캐너 --- #
def t_secrets():
    text = ('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n'
            'ghp_abcdefghijklmnopqrstuvwxyz0123456789\n'                 # ghp_ + 36
            'google = "AIzaB1234567890abcdefghijklmnopqrstuvwx"\n'       # AIza + 35
            'password = "correcthorsebattery"\n'
            'x = "lowlowlowlowlow"\n'                      # 낮은 엔트로피 → 억제
            '-----BEGIN RSA PRIVATE KEY-----\n')
    f = N.scan_secrets(text)
    types = {x["type"] for x in f}
    check("aws_access_key" in types, "AWS 키 탐지")
    check("github_pat" in types, "GitHub PAT 탐지")
    check("google_api_key" in types, "Google API 키 탐지")
    check("private_key" in types, "개인키 헤더 탐지")
    # 마스킹: 원문 시크릿이 결과에 그대로 남지 않음(방어 도구가 시크릿을 쌓지 않게)
    check(all("AKIAIOSFODNN7EXAMPLE" not in x["masked"] for x in f), "AWS 키 마스킹됨")
    check(all("len=" in x["masked"] for x in f), "마스크에 길이표기")
    # 낮은 엔트로피 generic 은 억제
    check(not any(x["masked"].startswith("lowlow") for x in f), "저엔트로피 억제")
    # 결정적
    check(N.scan_secrets(text) == f, "스캔 결정적")
    # repo 스캔
    rf = N.scan_repo_files({"config.py": 'token = "AKIAIOSFODNN7EXAMPLE"', "ok.py": "x=1"})
    check(len(rf) >= 1 and rf[0]["path"] == "config.py", "repo 파일 스캔")
    print(f"  secret-scan: AWS/GitHub/Google/개인키 탐지({len(types)}종), 마스킹·엔트로피 억제·결정적 OK")


# ------------------------------------------- IP→도메인 축 전파(iplist) 통합 --- #
def t_iplist_propagation():
    from artes.core import signals as sig
    g = Graph()
    ip = "203.0.113.5"
    g.add(Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("shodan-internetdb", "obs")],
                 attrs={"open_ports": ["443", "22"], "cpe": ["cpe:/a:nginx"], "cve": ["CVE-2021-1"]}))
    g.add(Entity(type=EntityType.DOMAIN, value="svc.example", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    g.link(Edge(src=_k(EntityType.DOMAIN, "svc.example"), dst=_k(EntityType.IP, ip),
                relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "A")]))
    sm = sig.gather_signals(g, sig.EXTENDED_SPECS)
    s = sm["domain:svc.example"]
    check(s.get("port") == {"443", "22"}, f"port 축 전파 {s.get('port')}")
    check(s.get("cve") == {"CVE-2021-1"}, f"cve 축 전파 {s.get('cve')}")
    check(s.get("ipcpe") == {"cpe:/a:nginx"}, f"ipcpe 축 전파 {s.get('ipcpe')}")
    print(f"  iplist 전파: Shodan/Censys IP attr(port/cpe/cve) → 도메인 신호축 자동 전파 OK")


def t_request_governor():
    """리뷰 P5: 실제 outbound 요청 수를 concurrency 로 통제(job 수가 아니라). RequestLimiter 세마포어."""
    from artes.core.infra_recon import RequestLimiter, HTTPResp

    async def drive():
        cur = {"n": 0, "peak": 0}

        async def slow(url, **kw):
            cur["n"] += 1
            cur["peak"] = max(cur["peak"], cur["n"])
            await asyncio.sleep(0.005)
            cur["n"] -= 1
            return HTTPResp(status=200, url=url)
        lim = RequestLimiter(slow, max_requests=4)
        await asyncio.gather(*[lim(f"https://x/{i}") for i in range(40)])
        return cur["peak"], lim.peak, lim.total
    observed_peak, lim_peak, total = asyncio.run(drive())
    check(observed_peak <= 4, f"동시 실제요청 ≤ 4 (관측 peak {observed_peak})")
    check(lim_peak <= 4 and total == 40, f"limiter peak {lim_peak}, total {total}")
    print(f"  request governor(P5): 40개 동시요청, 실제 in-flight peak {observed_peak} ≤ 4")


def t_ssrf_guard():
    """리뷰 P6: active probe 가 사설/특수 IP 로 향하면 차단(리터럴·DNS결과 모두)."""
    from artes.core.infra_recon import SSRFGuard, is_blocked_ip, HTTPResp
    check(is_blocked_ip("127.0.0.1") and is_blocked_ip("10.1.2.3") and is_blocked_ip("192.168.0.1"),
          "사설/루프백 차단")
    check(is_blocked_ip("169.254.1.1") and is_blocked_ip("100.64.0.1") and is_blocked_ip("::1"),
          "링크로컬·CGNAT·v6 루프백 차단")
    check(not is_blocked_ip("8.8.8.8") and not is_blocked_ip("1.1.1.1"), "공인 IP 허용")

    called = {"n": 0}

    async def inner(url, **kw):
        called["n"] += 1
        return HTTPResp(status=200, url=url)

    fake_dns = {"public.example": {"8.8.8.8"}, "evil.example": {"10.0.0.5"},
                "rebind.example": {"1.1.1.1", "127.0.0.1"}}
    guard = SSRFGuard(inner, resolver=lambda h: fake_dns.get(h, set()))

    async def go():
        r_pub = await guard("https://public.example/")       # 공인 → 통과
        r_evil = await guard("https://evil.example/")          # 사설 → 차단
        r_lit = await guard("https://10.0.0.9/")               # 리터럴 사설 → 차단
        r_rebind = await guard("https://rebind.example/")      # 하나라도 사설이면 차단
        return r_pub, r_evil, r_lit, r_rebind
    r_pub, r_evil, r_lit, r_rebind = asyncio.run(go())
    check(r_pub.status == 200, "공인 호스트 통과")
    check(r_evil.status == -3 and r_lit.status == -3 and r_rebind.status == -3, "사설/리바인딩 차단")
    check(called["n"] == 1, f"차단된 요청은 inner 미호출(호출 {called['n']}회=공인만)")
    print(f"  SSRF 가드(P6): 사설/링크로컬/CGNAT/리바인딩 차단, 공인만 통과")


def t_redirect_ssrf():
    """리뷰 P1: SSRFGuard 가 리다이렉트 hop 을 따라가며 각 hop 의 호스트를 재검증(302→사설 차단)."""
    from artes.core.infra_recon import SSRFGuard, HTTPResp
    dns = {"public.example": {"8.8.8.8"}, "public2.example": {"1.1.1.1"},
           "evil.example": {"10.0.0.5"}}

    async def inner(url, **kw):
        if url == "https://public.example/":         # 사설로 302
            return HTTPResp(status=302, url=url, headers={"Location": "https://evil.example/admin"})
        if url == "https://hop.example/":            # 공인으로 302 → 최종 200
            return HTTPResp(status=302, url=url, headers={"Location": "https://public2.example/"})
        return HTTPResp(status=200, url=url)
    dns["hop.example"] = {"8.8.8.8"}
    guard = SSRFGuard(inner, resolver=lambda h: dns.get(h, set()), max_redirects=5)

    async def go():
        return (await guard("https://public.example/"),   # → 302 → evil(사설) → 차단
                await guard("https://hop.example/"))        # → 302 → public2(공인) → 200
    r_evil, r_ok = asyncio.run(go())
    check(r_evil.status == -3, f"리다이렉트 사설 hop 차단 (status {r_evil.status})")
    check(r_ok.status == 200, f"공인 리다이렉트는 따라가 최종 200 (status {r_ok.status})")
    print(f"  redirect SSRF(P1): 302→사설 차단, 302→공인 정상 추적")


def t_politeness_pipeline():
    """리뷰 P1: PolitenessHTTP 가 기본(실네트워크) 파이프라인에 실제로 연결됨."""
    from artes.core.infra_recon import (InfraRecon, PolitenessHTTP, RequestLimiter,
                                        CachingHTTP, HTTPResp)
    rec = InfraRecon(http=None, cache=True)              # 실네트워크 기본 경로
    check(rec.politeness is not None and isinstance(rec.politeness, PolitenessHTTP),
          "politeness 가 기본 경로에 연결됨")
    check(rec.request_limiter is not None and isinstance(rec.request_limiter, RequestLimiter),
          "request limiter 연결됨")
    check(isinstance(rec.http, CachingHTTP), "최외곽은 캐시")

    async def stub(url, **kw):
        return HTTPResp(status=404, url=url)
    rec2 = InfraRecon(http=stub)                          # 주입 http → politeness 우회(테스트가 통제)
    check(rec2.politeness is None, "주입 http 는 politeness 미적용(테스트 통제)")
    # close_http 는 루프-스코프 세션 dict 를 비운다(리뷰 P2)
    from artes.core import infra_recon as _ir
    asyncio.run(_ir.close_http())
    check(_ir._AIOHTTP_SESSIONS == {}, "close_http → 세션 dict 비움(루프 스코프)")
    print(f"  politeness 파이프라인(P1): 기본=Caching→Politeness→Limiter→SSRF→HTTP, 주입=우회")


def t_cache_cancel_no_hang():
    """리뷰 P1: single-flight 리더가 취소돼도 follower 가 무한대기하지 않는다(CancelledError 전파)."""
    from artes.core.infra_recon import CachingHTTP, HTTPResp

    async def go():
        started = asyncio.Event()

        async def slow(url, **kw):
            started.set()
            await asyncio.sleep(10)
            return HTTPResp(status=200, url=url)
        c = CachingHTTP(slow)
        leader = asyncio.create_task(c("u"))
        await started.wait()
        follower = asyncio.create_task(c("u"))   # 리더의 future 에 합류
        await asyncio.sleep(0)
        leader.cancel()
        try:
            await asyncio.wait_for(follower, timeout=1.0)
            return "completed"
        except asyncio.CancelledError:
            return "cancelled"                    # 정상: 취소 전파(무한대기 아님)
        except asyncio.TimeoutError:
            return "HANG"
    outcome = asyncio.run(go())
    check(outcome != "HANG", f"follower 무한대기 없음 (outcome={outcome})")
    print(f"  cache cancel(P1): 리더 취소 → follower {outcome}(hang 아님)")


def t_campaign_alpha_reachable():
    """리뷰 P1: MC 캠페인 검정은 alpha > 1/(1+n_mc) 여야 검출 가능(예전 CLI 기본 1e-6 은 불가능)."""
    from artes.core import temporal as T
    DAY = 86400.0
    import random
    rng = random.Random(3)
    ev = {f"u{i}": rng.uniform(0, 30 * DAY) for i in range(150)}
    ev.update({f"b{i}": 10 * DAY + rng.uniform(0, 1800) for i in range(40)})
    # alpha=1e-6 with n_mc=1999 → 최소 p=5e-4 > alpha → 원리적으로 검출 불가(예전 CLI 기본 버그)
    check(T.campaign_report(ev, window=1800, alpha=1e-6, n_mc=1999) == [],
          "alpha<1/(1+n_mc) → 검출 불가(예전 기본값 재현)")
    # 새 기본 alpha=1e-3 → 검출됨
    rep = T.campaign_report(ev, window=1800, alpha=1e-3, n_mc=1999)
    check(len(rep) >= 1 and rep[0]["size"] >= 40, f"alpha=1e-3 → 캠페인 검출 {rep[0]['size'] if rep else None}")
    print(f"  campaign alpha(P1): 1e-6/n_mc=1999 불가 → 새 기본 1e-3 검출 OK")


def t_max_seconds_budget():
    """리뷰: max_seconds<=0 = 무제한(스케줄러와 동일 semantics). 양수 예산은 deadline 후 seed 중단.

    예전엔 InfraRecon 에서 0 이 'deadline=now → 즉시 중단'이라 계층마다 0 의 뜻이 달랐다(P1).
    이제 0/None = 무제한으로 통일 → 0 이면 씨앗 전부 처리, 양수 예산이 소진되면 인테이크가 멈춘다."""
    from artes.core.infra_recon import InfraRecon, HTTPResp

    async def stub(url, **kw):
        return HTTPResp(status=404, url=url)

    # (1) max_seconds=0 → 무제한: 씨앗 50개 전부 처리(예전엔 0 이라 0개였음)
    async def go_unlimited():
        rec = InfraRecon(http=stub, max_seconds=0.0, depth=1)
        g = await rec.run([f"d{i}.com" for i in range(50)])
        return g.stats()
    s0 = asyncio.run(go_unlimited())
    check(s0["entities"] == 50, f"max_seconds=0 → 무제한(엔티티 {s0['entities']}=50)")

    # (2) 양수 예산: 느린 요청이면 deadline 후 topup 이 새 seed 인테이크 중단 → 일부만(<50)
    async def slow(url, **kw):
        await asyncio.sleep(0.02)
        return HTTPResp(status=404, url=url)

    async def go_budget():
        rec = InfraRecon(http=slow, max_seconds=0.05, depth=1, concurrency=1)
        g = await rec.run([f"e{i}.com" for i in range(50)])
        return g.stats()
    sb = asyncio.run(go_budget())
    check(sb["entities"] < 50, f"양수 예산 소진 → 인테이크 중단(엔티티 {sb['entities']}<50)")
    print(f"  max_seconds semantics: 0=무제한(={s0['entities']}), 양수예산 소진 중단(={sb['entities']}<50)")


def t_authz_no_graph_leak():
    """리뷰 P0: 범위 밖 발견물이 그래프에 들어가지 않는다(IDF/클러스터/export 오염 차단)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp, FetchResult, InfraSource, InfraType
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI

    class Leaky(InfraSource):
        name = "leaky"; accepts = {InfraType.DOMAIN}; host = "x"
        async def fetch(self, target, http):
            e = Entity(type=EntityType.DOMAIN, value="outside.net", certainty=Certainty.CONFIRMED,
                       evidence=[Evidence("leaky", "o")])
            edge = Edge(src=_k(EntityType.DOMAIN, target.normalized), dst=_k(EntityType.DOMAIN, "outside.net"),
                        relation="하위도메인", certainty=Certainty.CONFIRMED, evidence=[Evidence("leaky", "o")])
            return FetchResult(self.name, entities=[e], edges=[edge])

    async def stub(u, **kw):
        return HTTPResp(status=404, url=u)

    async def go():
        scope = AuthorizationScope(AuditLog()).authorize(Authorization(
            case_id="C", operator="o", basis=BASIS_INFRA_TI,
            selectors={"example.com"}, domain_suffixes={"example.com"}))
        rec = InfraRecon(sources=[Leaky()], http=stub, scope=scope, depth=1)
        g = await rec.run(["example.com"])
        return {e.value for e in g.entities}, rec.out_of_scope
    vals, oos = asyncio.run(go())
    check("outside.net" not in vals, "범위 밖 엔티티가 그래프에 없음")
    check(("outside.net", "domain") in oos, "범위 밖 발견물은 out_of_scope 에 기록")
    check(not any("outside.net" in v for v in vals), "범위 밖 끝점 간선도 없음(link 거부)")
    print(f"  authz 그래프 누수(P0): 범위 밖 outside.net 그래프 제외, out_of_scope 기록")


def t_max_jobs_bounded_intake():
    """리뷰 P1: max_jobs 소진 시 seed 인테이크 중단(무한 generator 소모 방지)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp
    consumed = {"n": 0}

    def gen():
        for i in range(1000):
            consumed["n"] += 1
            yield f"d{i}.com"

    async def stub(u, **kw):
        return HTTPResp(status=404, url=u)

    async def go():
        rec = InfraRecon(http=stub, max_jobs=1, depth=1)
        await rec.run_iter(gen())
    asyncio.run(go())
    check(consumed["n"] <= 5, f"max_jobs=1 → seed 소모 유계 ({consumed['n']}, 예전 무제한)")
    print(f"  max_jobs 인테이크(P1): cap=1 → seed {consumed['n']}개만 소모(무한 소모 방지)")


def t_url_authz_host():
    """리뷰 P1: URL seed 는 호스트로 인가 검사(전체 URL 문자열 아님)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI

    async def stub(u, **kw):
        return HTTPResp(status=404, url=u)

    async def go():
        scope = AuthorizationScope(AuditLog()).authorize(Authorization(
            case_id="C", operator="o", basis=BASIS_INFRA_TI,
            selectors={"example.com"}, domain_suffixes={"example.com"}))
        rec = InfraRecon(http=stub, scope=scope, depth=1)
        g = await rec.run(["https://example.com/path?x=1"])
        return g.stats()["entities"], rec.skipped
    ents, skipped = asyncio.run(go())
    check(ents >= 1 and not skipped, f"URL seed 호스트 인가 통과(엔티티 {ents}, skipped {skipped})")
    print(f"  URL 인가(P1): https://example.com/path → 호스트 example.com 으로 인가 통과")


def t_ssrf_scheme_allowlist():
    """리뷰 P1: SSRFGuard 는 http/https 만 허용(file:// 등 차단)."""
    from artes.core.infra_recon import SSRFGuard, HTTPResp

    async def inner(url, **kw):
        return HTTPResp(status=200, url=url)
    guard = SSRFGuard(inner, resolver=lambda h: {"8.8.8.8"})

    async def go():
        return (await guard("http://public/"), await guard("file:///etc/passwd"),
                await guard("gopher://x/"))
    ok, f1, f2 = asyncio.run(go())
    check(ok.status == 200, "http 통과")
    check(f1.status == -3 and f2.status == -3, "file://·gopher:// 차단")
    print(f"  SSRF scheme(P1): http/https 만 허용, file/gopher 차단")


def t_query_audit_wiring():
    """리뷰 P0: 실제 source 조회가 감사에 'query' 로 기록된다(예전엔 is_authorized 만 써서 누락)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp, FetchResult, InfraSource, InfraType
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI

    class Src(InfraSource):
        name = "probe"; accepts = {InfraType.DOMAIN}; host = "x"
        async def fetch(self, target, http):
            return FetchResult(self.name, entities=[], edges=[])

    async def stub(u, **kw):
        return HTTPResp(status=404, url=u)

    async def go():
        audit = AuditLog()
        scope = AuthorizationScope(audit).authorize(Authorization(
            case_id="C", operator="o", basis=BASIS_INFRA_TI,
            selectors={"example.com"}, domain_suffixes={"example.com"}))
        rec = InfraRecon(sources=[Src()], http=stub, scope=scope, depth=1)
        await rec.run(["example.com"])
        return audit.entries()
    entries = asyncio.run(go())
    queries = [e for e in entries if e["action"] == "query"]
    check(any(e["action"] == "authorize" for e in entries), "인가 사실 기록")
    check(queries and any(e["collector"] == "probe" for e in queries),
          f"실제 조회가 query 로 감사됨(collector=probe) {[ (e['action'],e['collector']) for e in entries]}")
    print(f"  query 감사 배선(P0): 실제 source 조회 {len(queries)}건이 'query' 로 기록(collector 포함)")

def t_authz_execution_time_toctou():
    """리뷰 P0: 큐 대기 중 scope 가 만료되면 실제 조회 시점에 재검증해 차단한다(enqueue-시점만 X)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp, FetchResult, InfraSource, InfraType
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI
    import time
    fetched = []

    class Slow(InfraSource):
        name = "slow"; accepts = {InfraType.DOMAIN}; host = "x"
        async def fetch(self, target, http):
            fetched.append(target.normalized)
            await asyncio.sleep(0.15)                 # 조회가 느린 동안 인가 만료
            return FetchResult(self.name, entities=[], edges=[])

    async def stub(u, **kw):
        return HTTPResp(status=404, url=u)

    async def go():
        audit = AuditLog()
        scope = AuthorizationScope(audit).authorize(Authorization(
            case_id="C", operator="o", basis=BASIS_INFRA_TI,
            selectors={"a.example.com", "b.example.com"}, domain_suffixes={"example.com"},
            expires_at=time.time() + 0.05))          # enqueue 시엔 유효, 실행 중 만료
        rec = InfraRecon(sources=[Slow()], http=stub, scope=scope, depth=1, concurrency=1)
        await rec.run(["a.example.com", "b.example.com"])
        return list(fetched), [e["action"] for e in audit.entries()]
    fetched_list, acts = asyncio.run(go())
    check(len(fetched_list) == 1, f"만료 후 두번째 조회 차단 → 실제 fetch 1건만 {fetched_list}")
    check("query" in acts and "blocked" in acts, f"통과=query, 만료=blocked 감사 {set(acts)}")
    print(f"  실행시점 authz TOCTOU(P0): 큐 대기 중 만료 → 실제 조회 전 차단 + blocked 감사")

def t_ssrf_no_retry():
    """리뷰 P1: SSRF/정책 거부(-3)는 재시도 대상이 아니다(-1 연결오류·-2 타임아웃만 일시적)."""
    from artes.core.infra_recon import PolitenessHTTP, HTTPResp
    check(PolitenessHTTP._transient(HTTPResp(status=-3, url="x")) is False, "-3(정책거부) 재시도 안 함")
    check(PolitenessHTTP._transient(HTTPResp(status=-1, url="x")) is True, "-1(연결오류) 재시도")
    check(PolitenessHTTP._transient(HTTPResp(status=-2, url="x")) is True, "-2(타임아웃) 재시도")
    check(PolitenessHTTP._transient(HTTPResp(status=503, url="x")) is True, "503 재시도")
    check(PolitenessHTTP._transient(HTTPResp(status=200, url="x")) is False, "200 재시도 안 함")
    # 실제 파이프라인: SSRF 차단 대상은 재시도 없이 즉시 -3 (retry 카운트 0)
    print("  SSRF -3 재시도 금지(P1): -3 정책거부 non-retryable, -1/-2 만 일시적")

def t_request_limiter_naming_and_budget():
    """리뷰 P1: RequestLimiter 는 '동시성' 상한(max_concurrency) — 옛 이름 max_requests 는 별칭.
    별도의 '총 요청' 하드캡(max_total)도 지원."""
    from artes.core.infra_recon import RequestLimiter, HTTPResp, PolitenessHTTP

    async def inner(u, **kw):
        return HTTPResp(status=200, url=u)

    # 이름: max_concurrency 가 정식, max_requests 는 하위호환 별칭(둘 다 '동시' 상한)
    lim = RequestLimiter(inner, max_concurrency=3)
    check(lim.max_concurrency == 3 and lim.max_requests == 3, "max_concurrency=정식, max_requests=별칭")
    lim2 = RequestLimiter(inner, max_requests=5)               # 옛 키워드
    check(lim2.max_concurrency == 5, "옛 max_requests 키워드 → max_concurrency")

    # 총 요청 예산: max_total 초과분은 실제 요청 없이 status=-4(재시도 아님)
    async def go():
        lb = RequestLimiter(inner, max_concurrency=8, max_total=2)
        rs = [await lb(f"http://h/{i}") for i in range(5)]
        return [r.status for r in rs], lb.total, lb.rejected_over_budget
    statuses, total, rejected = asyncio.run(go())
    check(statuses.count(200) == 2 and statuses.count(-4) == 3, f"총 2건만 통과, 3건 예산초과(-4) {statuses}")
    check(total == 2 and rejected == 3, f"total=2, rejected=3 {total}/{rejected}")
    check(PolitenessHTTP._transient(HTTPResp(status=-4, url="x")) is False, "-4(예산소진)도 재시도 안 함")
    print("  RequestLimiter(P1): max_concurrency 정식/별칭 + max_total 하드캡(-4, non-retryable)")

def main():
    print("[authz 그래프 누수(P0)]"); t_authz_no_graph_leak()
    print("[query 감사 배선(P0)]"); t_query_audit_wiring()
    print("[실행시점 authz TOCTOU(P0)]"); t_authz_execution_time_toctou()
    print("[SSRF -3 재시도 금지(P1)]"); t_ssrf_no_retry()
    print("[RequestLimiter 이름/예산(P1)]"); t_request_limiter_naming_and_budget()
    print("[max_jobs 인테이크(P1)]"); t_max_jobs_bounded_intake()
    print("[URL 인가(P1)]"); t_url_authz_host()
    print("[SSRF scheme(P1)]"); t_ssrf_scheme_allowlist()
    print("[cache cancel(P1)]"); t_cache_cancel_no_hang()
    print("[campaign alpha(P1)]"); t_campaign_alpha_reachable()
    print("[max_seconds 예산(P1)]"); t_max_seconds_budget()
    print("[redirect SSRF(P1)]"); t_redirect_ssrf()
    print("[politeness 파이프라인(P1)]"); t_politeness_pipeline()
    print("[request governor(P5)]"); t_request_governor()
    print("[SSRF 가드(P6)]"); t_ssrf_guard()
    print("[shodan-internetdb]"); t_internetdb()
    print("[censys]"); t_censys()
    print("[wayback]"); t_wayback()
    print("[urlhaus]"); t_urlhaus()
    print("[secret-scan]"); t_secrets()
    print("[iplist 전파]"); t_iplist_propagation()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
