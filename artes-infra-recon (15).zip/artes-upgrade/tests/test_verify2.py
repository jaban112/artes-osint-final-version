"""calibration / robust / repro 검증. `python3 tests/test_verify2.py` (pytest 불필요)."""
from __future__ import annotations

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core.verify_cp import cp_lower, coincidence_prob
from artes.core import calibration as cal
from artes.core import robust as rob
from artes.core import repro
from artes.core.model import Graph, Entity, Edge, Evidence, EntityType, Certainty

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")


def _k(t, v):
    from artes.core.model import _normalize
    return f"{t.value}:{_normalize(t, v)}"


# ---------------------------------------------------------- calibration --- #
def t_confusion_pr():
    pred = [("a", "b"), ("a", "c")]
    true = [("a", "b"), ("b", "c")]
    tp, fp, fn = cal.confusion(pred, true)
    check((tp, fp, fn) == (1, 1, 1), f"confusion {(tp,fp,fn)}")
    pr = cal.precision_recall(tp, fp, fn)
    check(abs(pr["precision"] - 0.5) < 1e-9 and abs(pr["recall"] - 0.5) < 1e-9, "P/R=0.5")
    check(abs(pr["precision_lower"] - cp_lower(1, 2)) < 1e-12, "정밀도 CP 하한")
    print(f"  confusion+PR: tp/fp/fn={tp}/{fp}/{fn}, P/R=0.5, CP하한 {pr['precision_lower']:.3f}")

def t_ece_reliability():
    # 확신도 0.9 인데 실제 0.5 맞음 → ECE = 0.4
    pairs = [(0.9, 1)] * 50 + [(0.9, 0)] * 50
    e = cal.ece(pairs, n_bins=10)
    check(abs(e - 0.4) < 1e-9, f"ECE {e} (0.4 기대)")
    b = cal.reliability_bins(pairs)
    check(len(b) == 1 and abs(b[0]["empirical"] - 0.5) < 1e-9, "reliability 경험정확도 0.5")
    # 완벽 보정(확신도=경험) → ECE 0
    perfect = [(1.0, 1)] * 30 + [(0.0, 0)] * 30
    check(cal.ece(perfect) < 1e-9, f"완벽보정 ECE≈0 {cal.ece(perfect)}")
    print(f"  ECE/reliability: 오보정 0.4 / 완벽 0.0 측정 OK")

def t_conformal():
    import math as _m
    # 경계(리뷰 P0): n=5, alpha=0.1 → k=ceil(0.9*6)=6 > n=5 → 유한 임계값으로 1-α 보장 불가 → τ=+∞.
    # (예전엔 rank 를 5 로 clamp 해 τ=0.05(최댓값) → 새 점 커버리지 5/6=0.833<0.9 인 버그였음)
    tau = cal.conformal_threshold([0.01, 0.02, 0.03, 0.04, 0.05], alpha=0.1)
    check(tau == _m.inf, f"n=5·α=0.1 → 유한 임계값 불가 → +∞ (전수 채택) {tau}")
    # 유한 임계값이 존재하는 경우(k<=n)만 실제 점수를 돌려준다: n=5, α=0.3 → k=ceil(0.7*6)=5<=5 → s[4]
    tau_fin = cal.conformal_threshold([0.01, 0.02, 0.03, 0.04, 0.05], alpha=0.3)
    check(abs(tau_fin - 0.05) < 1e-12, f"n=5·α=0.3 → k=5 → τ=0.05 {tau_fin}")
    # 유한표본 커버리지: 보정셋 자체에서 score≤τ 비율 ≥ 1-α (분포무관 보장)
    scores = [i / 1000 for i in range(1000)]
    tau2 = cal.conformal_threshold(scores, alpha=0.1)
    cov = sum(1 for s in scores if s <= tau2) / len(scores)
    check(cov >= 0.90, f"conformal 커버리지 {cov} ≥ 0.90")
    # 더 큰 alpha → 더 작은 τ → 커버리지 감소(단조)
    tau3 = cal.conformal_threshold(scores, alpha=0.3)
    check(tau3 < tau2, f"alpha↑ → τ↓ {tau3} < {tau2}")
    # p-value: 진짜 분포 극단(아주 큰 점수=비동일운영자스러움) → p 작음
    p_out = cal.conformal_pvalue(999.0, scores)
    p_in = cal.conformal_pvalue(-1.0, scores)
    check(p_out < 0.01 and abs(p_in - 1.0) < 1e-9, f"conformal p out={p_out} in={p_in}")
    print(f"  conformal: τ 분위수 정확, 커버리지 {cov:.3f}≥0.9, p-value 이질 검출")


def t_conformal_newpoint_coverage():
    """리뷰 P0: 진짜 보장은 '보정셋 내부'가 아니라 **새 교환가능 점**의 커버리지 ≥ 1-α.

    보정셋 n개 + 독립 테스트 1개를 같은 분포에서 뽑아(교환가능) τ 결정 후 test≤τ 비율을 MC 추정.
    예전 clamp 버그면 n=5,α=0.1 에서 이 값이 ~0.833 으로 떨어진다(리뷰가 재현). 수정 후 ≥1-α.
    이전 property test 는 '보정셋 내부' 커버리지만 봐서 이 버그를 못 잡았다 — 그래서 이 테스트가 필요."""
    import random
    rng = random.Random(20260929)
    trials = 30000
    for (n, alpha) in [(5, 0.1), (9, 0.1), (19, 0.05), (99, 0.05)]:
        covered = 0
        for _ in range(trials):
            pts = [rng.random() for _ in range(n + 1)]     # 교환가능: n 보정 + 1 테스트
            calib, test = pts[:n], pts[n]
            tau = cal.conformal_threshold(calib, alpha=alpha)
            if test <= tau:                                 # lower_is_positive: score≤τ → positive
                covered += 1
        cov = covered / trials
        check(cov >= 1 - alpha - 0.01, f"n={n},α={alpha}: 새점 커버리지 {cov:.3f} ≥ {1-alpha:.2f}")
    print(f"  conformal 새점 커버리지(P0): (5,.1)/(9,.1)/(19,.05)/(99,.05) 모두 ≥ 1-α (경계 τ=∞ 포함)")


# --------------------------------------------------------------- robust --- #
def t_robust():
    check(abs(rob.robust_corroboration_lower(5, 10, f=2) - cp_lower(3, 10)) < 1e-12,
          "f=2 담합 가정 → k-f=3 CP 하한")
    # 심어진 rarest 1개 제거해도 진짜 2개로 강한 근거 유지
    r = rob.robust_coincidence([2, 2, 2], 1000, drop_worst=1, use_cp_upper=False)
    base = coincidence_prob([2, 2, 2], 1000)
    check(base < r < 1e-3, f"robust {r} (base {base:.2e} < robust < 1e-3)")
    # 적대자가 단 1개 희귀 신호만 조작 → drop_worst=1 이면 근거 0(안 속음)
    r1 = rob.robust_coincidence([2], 1000, drop_worst=1)
    check(abs(r1 - 1.0) < 1e-12, f"단일 조작신호 무력화 {r1}")
    v = rob.robust_verdict(5, 6, f=1, tau=0.3, floor=0.05)
    check(abs(v["lower"] - cp_lower(4, 6)) < 1e-12, f"robust_verdict 하한 {v}")
    print(f"  robust: 담합 k-f 하한, breakdown drop_worst=1 (심은신호 무력화), verdict OK")


# ----------------------------------------------------------------- repro -- #
def _mk_graph(val="1.2.3.4"):
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("doh", "A", url="https://x")]))
    g.add(Entity(type=EntityType.IP, value=val, certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    g.link(Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.IP, val),
                relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "A")]))
    return g

def t_repro():
    g1 = _mk_graph(); g2 = _mk_graph()
    check(repro.canonical_root(g1) == repro.canonical_root(g2), "동일 입력 → 동일 루트")
    check(repro.verify_reproducible(g1, g2), "verify_reproducible True")
    g3 = _mk_graph(val="9.9.9.9")
    check(repro.canonical_root(g1) != repro.canonical_root(g3), "값 변경 → 루트 변경")
    # provenance 역추적
    prov = repro.provenance(g1, _k(EntityType.IP, "1.2.3.4"))
    check(prov.get("kind") == "entity" and prov["evidence"] and prov["evidence"][0]["hash"],
          f"엔티티 provenance {prov.get('kind')}")
    ekey = f"{_k(EntityType.DOMAIN,'a.com')}|해석됨(A)|{_k(EntityType.IP,'1.2.3.4')}"
    pe = repro.provenance(g1, ekey)
    check(pe.get("kind") == "edge" and pe["evidence"], "간선 provenance")
    check(repro.evidence_hash(Evidence("doh", "A")) == repro.evidence_hash(Evidence("doh", "A")),
          "evidence_hash 결정적")
    rep = repro.provenance_report(g1)
    check("root" in rep and len(rep["entities"]) == 3, f"provenance_report {len(rep['entities'])} 엔티티")
    print(f"  repro: 재현 루트 일치/변조탐지, provenance 역추적, 결정적 해시 OK")


def t_edge_digest_semantics():
    """리뷰 P0: 재현성 루트가 간선의 통계적 의미(증거구간·decision)까지 반영해야 한다.

    confidence 만 같고 evidence 구간/decision 이 다른 두 간선은 서로 다른 다이제스트여야 하고,
    그래야 canonical_root 가 '통계적 의미가 바뀌었는데 루트는 그대로'인 맹점을 막는다."""
    a = Edge(src="d:x", dst="d:y", relation="r", confidence=0.2,
             evidence_lower=0.2, evidence_upper=0.8, decision="unconfirmed")
    b = Edge(src="d:x", dst="d:y", relation="r", confidence=0.2,
             evidence_lower=0.7, evidence_upper=0.9, decision="confirmed")
    check(repro.edge_digest(a) != repro.edge_digest(b),
          "같은 confidence·다른 증거구간/decision → 다른 edge_digest")
    # canonical_root 도 달라야 한다(그래프 지문이 통계 의미 변화를 잡음)
    g1 = Graph(); g1._edges[a.key] = a
    g2 = Graph(); g2._edges[b.key] = b
    check(repro.canonical_root(g1) != repro.canonical_root(g2), "루트도 달라짐")
    # 동일 의미면 동일 다이제스트(결정성)
    c = Edge(src="d:x", dst="d:y", relation="r", confidence=0.2,
             evidence_lower=0.2, evidence_upper=0.8, decision="unconfirmed")
    check(repro.edge_digest(a) == repro.edge_digest(c), "동일 의미 → 동일 다이제스트")
    prov = repro.provenance(g2, b.key)
    check(prov.get("decision") == "confirmed" and prov.get("evidence_lower") == 0.7,
          "provenance 가 증거구간/decision 보고")
    print("  edge_digest(P0): 증거구간/decision 변화가 다이제스트·루트에 반영, 동일의미는 결정적")


def t_edge_invariants():
    """리뷰 P1: Edge 는 확률 [0,1]·유한, lower≤upper, decision 허용집합을 생성 시점에 강제."""
    bad = 0
    cases = [
        dict(confidence=1.7),
        dict(confidence=float("nan")),
        dict(evidence_lower=0.9, evidence_upper=0.2),      # 역전
        dict(evidence_lower=-0.1),
        dict(decision="nonsense"),
    ]
    for kw in cases:
        try:
            Edge(src="d:x", dst="d:y", relation="r", **kw)
        except ValueError:
            bad += 1
    check(bad == len(cases), f"불량 Edge {len(cases)}종 모두 거부 ({bad}/{len(cases)})")
    ok = Edge(src="d:x", dst="d:y", relation="r", confidence=0.5,
              evidence_lower=0.3, evidence_upper=0.7, decision="confirmed")
    check(ok is not None, "정상 Edge 는 통과")
    print(f"  Edge 불변식(P1): [0,1]·유한·lower≤upper·decision 허용집합 강제")


def t_edge_merge_no_contradiction():
    """리뷰 P0: Graph.link merge 후 certainty=CONFIRMED 인데 decision=drop 같은 모순이 생기면 안 된다.

    예전엔 certainty 는 CONFIRMED 로 흡수(OR)하고 decision 은 마지막 기록으로 덮어써서, 확정 간선에
    drop 결정이 붙는 모순이 가능했다. 이제 decision 은 보수적으로 병합(drop>unconfirmed>confirmed)하고
    certainty 를 그와 일관되게 맞춘다(+ merge 후 불변식 재확인)."""
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")]))
    kw = dict(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.DOMAIN, "b.com"),
              relation="해석됨(A)")
    g.link(Edge(certainty=Certainty.CONFIRMED, confidence=0.8, evidence_lower=0.8,
                evidence_upper=0.9, decision="confirmed", evidence=[Evidence("cp", "1")], **kw))
    g.link(Edge(certainty=Certainty.UNCONFIRMED, confidence=0.1, evidence_lower=0.1,
                evidence_upper=0.2, decision="drop", evidence=[Evidence("cp", "2")], **kw))
    e = [x for x in g.edges if x.relation == "해석됨(A)"][0]
    check(e.decision == "drop", f"보수적 병합 → decision=drop {e.decision}")
    check(e.certainty is Certainty.UNCONFIRMED, f"certainty 가 decision 과 일관(UNCONFIRMED) {e.certainty}")
    check(not (e.certainty is Certainty.CONFIRMED and e.decision in ("drop", "unconfirmed")),
          "모순(CONFIRMED+drop) 없음")
    # 생성 시점에도 모순은 거부된다
    bad = 0
    try:
        Edge(src="d:x", dst="d:y", relation="r", certainty=Certainty.CONFIRMED,
             decision="drop", evidence=[Evidence("t", "")])
    except ValueError:
        bad += 1
    check(bad == 1, "생성 시점 CONFIRMED+drop 거부")
    print("  Edge merge 모순 차단(P0): decision 보수적 병합 + certainty 일관 + 생성/merge 불변식")


def t_deconfound():
    from artes.core.deconfound import Deconfounder, deconfounded_edges
    sig = {}
    for i in range(950):                       # 서로 안 겹치는 배경 950개
        sig[f"o{i}"] = {"asn": {f"AS-{i}"}, "ns": {f"ns{i}"}}
    for i in range(50):                        # 제공자 P 층 50개 — 기본신호 ns/tls 공유
        sig[f"p{i}"] = {"asn": {"AS-P"}, "ns": {"nsP"}, "tlsfp": {"tlsP"}}
    sig["p0"]["spki"] = {"rareK"}; sig["p1"]["spki"] = {"rareK"}   # p0,p1 만 층내 희소 공유
    dc = Deconfounder(sig, "asn")              # N=1000, 층 P size=50
    raw = dc.coincidence("p2", "p3", stratified=False)   # 전역: ns,tls 공유 → 오탐 강증거
    adj = dc.coincidence("p2", "p3", stratified=True)     # 조건부: 제공자 기본 → 근거 0
    check(raw < 5e-3, f"전역 raw 오탐 강증거 {raw:.2e}")
    check(abs(adj - 1.0) < 1e-9, f"디컨파운딩 → 근거 0(제공자 탓) {adj}")
    adj_ab = dc.coincidence("p0", "p1", stratified=True)  # 잔차 = 층내 희소 spki 만
    check(abs(adj_ab - (1 / 49)) < 1e-9, f"p0-p1 잔차=희소 spki {adj_ab:.4f}")
    rep = deconfounded_edges(sig, [("p2", "p3")], "asn")
    check(rep[0]["provider_explained"], "p2-p3 는 제공자로 설명됨(오탐)")
    print(f"  디컨파운딩: 제공자기본 raw {raw:.1e} → adj 1.0(오탐 제거), 층내 희소 잔차 {adj_ab:.3f}")


def main():
    print("[calibration]"); t_confusion_pr(); t_ece_reliability(); t_conformal(); t_conformal_newpoint_coverage()
    print("[robust]"); t_robust()
    print("[repro]"); t_repro(); t_edge_digest_semantics(); t_edge_invariants(); t_edge_merge_no_contradiction()
    print("[deconfound]"); t_deconfound()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
