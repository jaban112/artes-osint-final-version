"""pytest 진입 브리지(리뷰 P2). 각 self-running 스위트를 pytest 가 수집·실행할 수 있게 한다.

기존 스위트는 `t_*` 함수 + `main()` 구조라 pytest 가 `test_*` 를 못 찾아 'no tests collected' 였다.
이 파일이 각 스위트의 main() 을 `test_*` 로 감싸 진짜 pytest 지원을 만든다(=`pytest -q` 동작).
self-running 방식(`python3 tests/test_x.py`)도 그대로 유효하다.
"""
import importlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _run(modname: str) -> None:
    mod = importlib.import_module(modname)
    assert mod.main() == 0, f"{modname}.main() reported failures"


def test_verify_cp_infra():
    _run("test_infra_cp")


def test_verify2():
    _run("test_verify2")


def test_planner():
    _run("test_planner")


def test_properties():
    _run("test_properties")


def test_sources():
    _run("test_sources")


def test_net():
    _run("test_net")


def test_scheduler_authz():
    _run("test_scheduler_authz")


def test_upgrade():
    _run("test_upgrade")
