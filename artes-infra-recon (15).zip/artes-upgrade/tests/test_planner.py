"""planner / inference 검증. `python3 tests/test_planner.py` (pytest 불필요)."""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core import planner as P
from artes.core import inference as I

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")


# --------------------------------------------------------------- planner --- #
def t_entropy_ig():
    check(abs(P.binary_entropy(0.5) - 1.0) < 1e-12, "H(0.5)=1")
    check(P.binary_entropy(0.0) == 0.0 and P.binary_entropy(1.0) == 0.0, "H(0)=H(1)=0")
    good = P.Action("good", {"y": (1.0, 0.0), "n": (0.0, 1.0)})   # 완전 판별
    bad = P.Action("bad", {"y": (0.6, 0.6), "n": (0.4, 0.4)})     # 무정보
    check(abs(P.info_gain(0.5, good) - 1.0) < 1e-9, f"완전판별 IG=1 {P.info_gain(0.5,good)}")
    check(abs(P.info_gain(0.5, bad)) < 1e-12, f"무정보 IG=0 {P.info_gain(0.5,bad)}")
    # 부분 정보 액션 IG 는 (0,1) 사이
    part = P.Action("part", {"y": (0.9, 0.1), "n": (0.1, 0.9)})
    ig = P.info_gain(0.5, part)
    check(0 < ig < 1, f"부분정보 IG∈(0,1) {ig}")
    print(f"  엔트로피/정보이득: 완전=1, 무정보=0, 부분={ig:.3f} OK")

def t_greedy_submodular():
    part = lambda nm: P.Action(nm, {"y": (0.85, 0.15), "n": (0.15, 0.85)})
    bad = P.Action("bad", {"y": (0.5, 0.5), "n": (0.5, 0.5)})
    acts = [part("a1"), part("a2"), bad]
    order = P.greedy_select(0.5, acts, k=3)
    names = [a.name for a, _ in order]
    check(names[0] in ("a1", "a2") and names[-1] == "bad", f"greedy 정보순 {names}")
    # 한계이득 단조감소(submodular): 두번째 part 의 한계이득 < 첫번째
    mg1 = order[0][1]; mg2 = order[1][1]
    check(mg2 < mg1 + 1e-12 and mg2 >= -1e-12, f"한계이득 단조감소 {mg1:.3f}→{mg2:.3f}")
    print(f"  greedy+submodular: 순서 {names}, 한계이득 {mg1:.3f}→{mg2:.3f} (감소)")

def t_adaptive_plan():
    good = P.Action("g", {"y": (1.0, 0.0), "n": (0.0, 1.0)})
    check(abs(P.adaptive_step(0.5, good, "y") - 1.0) < 1e-12, "관측 y → belief 1")
    check(abs(P.adaptive_step(0.5, good, "n") - 0.0) < 1e-12, "관측 n → belief 0")
    part = P.Action("p", {"y": (0.9, 0.1), "n": (0.1, 0.9)})
    b1 = P.adaptive_step(0.5, part, "y")
    check(b1 > 0.5, f"부분관측 y → belief↑ {b1:.3f}")
    # plan_until: 부분정보 액션 여러 개면 목표 확신도에 기대 도달
    acts = [P.Action(f"p{i}", {"y": (0.9, 0.1), "n": (0.1, 0.9)}) for i in range(6)]
    res = P.plan_until(0.5, acts, target_confidence=0.95, budget=6)
    check(res["reached"], f"plan 목표도달 {res['expected_entropy']:.3f}")
    check(len(res["plan"]) <= 6, "예산 내")
    print(f"  적응/계획: 관측 갱신 OK, plan {len(res['plan'])}스텝에 목표도달({res['reached']})")


# ------------------------------------------------------------- inference -- #
def t_transitive_widest():
    edges = [("a", "b", 5.0), ("b", "c", 4.0)]
    ts = I.transitive_strength(edges)
    check(abs(ts[("a", "c")] - 4.0) < 1e-12, f"a~c widest=min(5,4)=4 {ts.get(('a','c'))}")
    check(abs(ts[("a", "b")] - 5.0) < 1e-12, "a~b=5")
    inf = I.inferred_links(edges, threshold=3.0)
    ac_list = [l for l in inf if (l["a"], l["b"]) == ("a", "c")]
    check(len(ac_list) == 1, f"a-c 간접추론 존재 {inf}")
    ac = ac_list[0]
    check(ac["direct"] is None and abs(ac["transitive"] - 4.0) < 1e-12, f"a-c 직접없음/전파4 {ac}")
    # 직접 약한 간선 있어도 전파가 더 강하면 전파 채택
    edges2 = edges + [("a", "c", 2.0)]
    ts2 = I.transitive_strength(edges2)
    check(abs(ts2[("a", "c")] - 4.0) < 1e-12, f"직접2 vs 전파4 → 4 {ts2[('a','c')]}")
    # 병목: 약한 고리가 있으면 체인 약함
    weak = [("a", "b", 5.0), ("b", "c", 1.0)]
    tw = I.transitive_strength(weak)
    check(abs(tw[("a", "c")] - 1.0) < 1e-12, f"병목 min(5,1)=1 {tw[('a','c')]}")
    clw = I.operator_clusters(weak, threshold=3.0)
    check(not any(set(c) >= {"a", "c"} for c in clw), "약한 체인은 클러스터 안 됨")
    print("  transitive widest-path: 간접추론/직접우회/병목/임계 클러스터 정확")

def t_inference_clusters():
    edges = [("a", "b", 5.0), ("b", "c", 4.0), ("x", "y", 6.0), ("a", "d", 1.0)]
    cl = I.operator_clusters(edges, threshold=3.0)
    check(any(set(c) == {"a", "b", "c"} for c in cl), f"운영자 군집 {{a,b,c}} {cl}")
    check(any(set(c) == {"x", "y"} for c in cl), "군집 {x,y}")
    check(not any("d" in c for c in cl), "약한 d 는 제외")
    print(f"  결합 클러스터: {[len(c) for c in cl]} (전파 임계 3.0, 약링크 제외)")


def t_plan_expected_vs_guaranteed():
    """리뷰 P3: 기대정보 도달(reached) ≠ 사후확신도 보장(guaranteed). 최악 관측을 별도 보고."""
    from artes.core.planner import Action, plan_until, binary_entropy
    # 정보성 높은 고확률 결과 + 무정보 저확률 결과 → 기대엔트로피는 낮지만 최악 확신도는 0.5
    a = Action("probe", {"strong": (0.98, 0.02), "ambiguous": (0.01, 0.01), "weak": (0.01, 0.97)})
    r = plan_until(0.5, [a], target_confidence=0.95, budget=2)
    check(r["expected_entropy"] <= binary_entropy(0.95), "기대 엔트로피 ≤ H(target)")
    check(r["reached"] is True and r["expected_info_reached"] is True, "expected-info reached=True")
    check(r["guaranteed"] is False, "그러나 보장 아님(guaranteed=False)")
    check(abs(r["worst_case_confidence"] - 0.5) < 1e-9, f"최악 관측 확신도 0.5 {r['worst_case_confidence']}")
    check(0.0 <= r["p_reach_threshold"] <= 1.0, "p_reach_threshold ∈ [0,1]")
    # 진짜 보장되는 계획: 모든 결과가 확신적 → guaranteed=True
    b = Action("clean", {"y": (0.999, 0.001), "n": (0.001, 0.999)})
    r2 = plan_until(0.5, [b], target_confidence=0.95, budget=2)
    check(r2["guaranteed"] is True and r2["worst_case_confidence"] >= 0.95, "확신적 계획 → guaranteed")
    print(f"  planner 보장분리(P3): reached(기대)=True인데 worst-case={r['worst_case_confidence']:.2f}<target "
          f"→ guaranteed=False. 보장되는 계획은 별도")


def t_action_input_validation():
    """리뷰 P1: Action 은 확률 [0,1]·유한·비용>0 을 검증(합=1 만으로 통과시키지 않음)."""
    from artes.core.planner import Action
    ok = Action("v", {"y": (0.8, 0.2), "n": (0.2, 0.8)})    # 정상
    check(ok is not None, "정상 Action 생성")
    bad = 0
    for outcomes, cost in [({"y": (1.1, -0.1), "n": (-0.1, 1.1)}, 1.0),   # p 범위 밖
                           ({"y": (0.5, 0.5), "n": (0.5, 0.5)}, 0.0),      # cost=0
                           ({"y": (float("nan"), 0.0), "n": (0.0, 1.0)}, 1.0)]:  # nan
        try:
            Action("x", outcomes, cost)
        except ValueError:
            bad += 1
    check(bad == 3, f"불량 입력 3종 모두 거부 ({bad}/3)")
    print(f"  Action 검증(P1): 확률 [0,1]·유한·cost>0 강제")


def main():
    print("[planner]"); t_entropy_ig(); t_greedy_submodular(); t_adaptive_plan(); t_plan_expected_vs_guaranteed(); t_action_input_validation()
    print("[inference]"); t_transitive_widest(); t_inference_clusters()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
