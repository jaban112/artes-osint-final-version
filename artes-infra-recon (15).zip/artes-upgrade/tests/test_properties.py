"""property-based 불변식 검증 — 예제가 아니라 '모든 생성입력'에 대해 정리를 반증탐색.

Hypothesis 로 CP/coincidence/deconfound/planner/거버너의 불변식을 무작위 생성입력에 대해 검사한다.
사용자 기준(정리 기반)에 맞는 메타 검증: "이 성질이 예제뿐 아니라 전 입력에서 성립하나".

`python3 tests/test_properties.py`. Hypothesis 없으면 시드 랜덤 폴백.
"""
from __future__ import annotations

import asyncio
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core.verify_cp import cp_lower, cp_upper, coincidence_prob
from artes.core.calibration import conformal_threshold
from artes.core.planner import binary_entropy
from artes.core.scheduler import AdaptiveConcurrency
from artes.core.deconfound import Deconfounder

PASS = FAIL = 0
def report(name, ok, detail=""):
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        print(f"  ✗ FAIL {name}: {detail}")

try:
    from hypothesis import given, settings, strategies as st, assume, HealthCheck
    HAVE_H = True
except Exception:
    HAVE_H = False

_ALPHA = [0.01, 0.05, 0.1]


def _run_props():
    S = settings(max_examples=200, deadline=None,
                 suppress_health_check=list(HealthCheck))

    @S
    @given(st.integers(1, 400), st.integers(0, 400), st.sampled_from(_ALPHA))
    def cp_bounds(n, k, a):
        assume(0 <= k <= n)
        lo, hi = cp_lower(k, n, a), cp_upper(k, n, a)
        assert 0.0 <= lo <= hi <= 1.0

    @S
    @given(st.integers(1, 400), st.integers(0, 399), st.sampled_from(_ALPHA))
    def cp_monotone(n, k, a):
        assume(k + 1 <= n)
        assert cp_lower(k, n, a) <= cp_lower(k + 1, n, a) + 1e-12
        assert cp_upper(k, n, a) <= cp_upper(k + 1, n, a) + 1e-12

    @S
    @given(st.integers(2, 500), st.lists(st.integers(1, 500), max_size=8),
           st.integers(1, 500))
    def coincidence_props(N, dfs, extra):
        dfs = [min(d, N) for d in dfs]
        extra = min(extra, N)
        base = coincidence_prob(dfs, N)
        more = coincidence_prob(dfs + [extra], N)
        assert 0.0 <= more <= 1.0 and 0.0 <= base <= 1.0
        assert more <= base + 1e-12          # 공유값 추가는 확률을 못 올린다(증거만 늘어남)

    @S
    @given(st.integers(3, 60), st.integers(1, 6))
    def deconfound_provider_default(m, n_default):
        # 층 크기 m, 전원이 공유하는 제공자 기본신호 n_default 개 → 잔차 증거 0(coincidence=1)
        sig = {}
        defaults = {f"k{j}": {f"pd{j}"} for j in range(n_default)}
        for i in range(m):
            s = {"asn": {"AS-P"}}
            for j in range(n_default):
                s[f"k{j}"] = {f"pd{j}"}
            sig[f"d{i}"] = s
        dc = Deconfounder(sig, "asn")
        val = dc.coincidence("d0", "d1", stratified=True, min_stratum=3)
        assert abs(val - 1.0) < 1e-9        # 제공자 기본신호만 공유 → same-operator 근거 0

    @S
    @given(st.floats(0.0, 1.0))
    def entropy_props(p):
        h = binary_entropy(p)
        assert 0.0 <= h <= 1.0 + 1e-12
        assert abs(binary_entropy(p) - binary_entropy(1 - p)) < 1e-9   # 대칭

    @S
    @given(st.integers(2, 60), st.sampled_from(_ALPHA), st.integers(0, 10**6))
    def conformal_newpoint_coverage(n, a, seed):
        # 리뷰 반영: 예전 in-sample 커버리지 property 는 P0(τ=max 버그)를 놓쳤다. 진짜 보장은
        # **새 교환가능 점**의 커버리지. n+1 점을 같은 분포에서 뽑아(교환가능) τ 결정 후 검정.
        import random as _r
        rng = _r.Random(seed)
        trials = 400
        covered = 0
        for _ in range(trials):
            pts = [rng.random() for _ in range(n + 1)]
            tau = conformal_threshold(pts[:n], alpha=a)
            if pts[n] <= tau:
                covered += 1
        # 유한 trials 의 통계오차 허용(one-sided 보장이라 하한만 검사, 넉넉한 tol)
        assert covered / trials >= 1 - a - 0.06

    # ---- 강화 모듈 property (v0.5.0) ----
    from artes.core.fdr import bh_adjusted, by_adjusted
    from artes.core.verify_cp import order_statistic_correction
    from artes.core.background import BackgroundCorpus

    @S
    @given(st.lists(st.floats(0.0, 1.0), min_size=1, max_size=50))
    def fdr_props(ps):
        bh = bh_adjusted(ps); by = by_adjusted(ps)
        assert all(0.0 <= q <= 1.0 for q in bh + by)          # 조정 p ∈ [0,1]
        assert all(by[i] >= bh[i] - 1e-12 for i in range(len(ps)))  # BY ≥ BH(더 보수적)
        assert all(bh[i] >= ps[i] - 1e-9 for i in range(len(ps)))   # 조정 p ≥ 원 p

    @S
    @given(st.floats(0.0, 1.0), st.integers(1, 50))
    def order_stat_props(q, m):
        c = order_statistic_correction(q, m)
        assert q - 1e-12 <= c <= 1.0 + 1e-12                  # 보정은 q 를 키우거나 유지(증거 약화)
        assert order_statistic_correction(q, 1) == q          # m=1 항등

    @S
    @given(st.integers(1, 200), st.integers(0, 200), st.sampled_from(_ALPHA))
    def background_q_props(n, d, a):
        assume(d <= n)
        bc = BackgroundCorpus({("k", "v"): d}, n=n)
        q = bc.q("k", "v", alpha=a); qu = bc.q_upper("k", "v", alpha=a)
        assert 0.0 <= q <= 1.0 and 0.0 <= qu <= 1.0
        assert qu >= q - 1e-9                                  # 상한 ≥ 점추정
        assert bc.q("k", "unseen", alpha=a) > 0.0             # 미관측도 0 아님(rule of three)

    props = [cp_bounds, cp_monotone, coincidence_props, deconfound_provider_default,
             entropy_props, conformal_newpoint_coverage, fdr_props, order_stat_props, background_q_props]
    for f in props:
        try:
            f()
            report(f.__name__, True)
        except Exception as e:
            report(f.__name__, False, f"{type(e).__name__}: {str(e)[:200]}")

    # 거버너 경계: 무작위 op 시퀀스에서 limit∈[min,max] 유지(async → 소량 실행)
    @settings(max_examples=40, deadline=None, suppress_health_check=list(HealthCheck))
    @given(st.lists(st.booleans(), min_size=1, max_size=200))
    def governor_bounds(ops):
        async def drive():
            g = AdaptiveConcurrency(start=8, min_limit=1, max_limit=64, beta=0.7)
            out = 0
            for drop in ops:
                if out == 0 or g.in_flight < g.limit:
                    await g.acquire(); out += 1
                    assert g._min <= g.limit <= g._max
                else:
                    await g.complete(dropped=bool(drop)); out -= 1
                    assert g._min <= g.limit <= g._max
            while out:
                await g.complete(dropped=False); out -= 1
        asyncio.run(drive())
    try:
        governor_bounds()
        report("governor_bounds", True)
    except Exception as e:
        report("governor_bounds", False, f"{type(e).__name__}: {str(e)[:200]}")


def _run_fallback():
    """Hypothesis 없을 때: 시드 랜덤으로 같은 성질 다수 검사."""
    import random
    rng = random.Random(20260928)
    ok = True
    for _ in range(5000):
        n = rng.randint(1, 400); k = rng.randint(0, n); a = rng.choice(_ALPHA)
        lo, hi = cp_lower(k, n, a), cp_upper(k, n, a)
        if not (0 <= lo <= hi <= 1):
            ok = False; break
        if k + 1 <= n and cp_lower(k, n, a) > cp_lower(k + 1, n, a) + 1e-12:
            ok = False; break
    report("cp_bounds+monotone(random 5000)", ok)


def main():
    print("[property-based]" + ("" if HAVE_H else " (Hypothesis 없음 → 랜덤 폴백)"))
    if HAVE_H:
        _run_props()
    else:
        _run_fallback()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
