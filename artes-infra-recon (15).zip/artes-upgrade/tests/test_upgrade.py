"""15개 강화 축 검증. `python3 tests/test_upgrade.py` (pytest 불필요).

축1 배경모집단 · 축2 증거패밀리 · 축3 우도비 · 축4 FDR · 축5 run manifest · 축6 신호레지스트리버전
축7 SafeOutbound · 축8 body cap · 축9 감사 내구성/스트리밍 · 축10 temporal 관측창 · 축11 deconfound 민감도
축12 Mondrian/CRC conformal · 축13 객체모델 분리 · 축14 order-statistic 보정 · 축15 robust 오염모델.
"""
from __future__ import annotations

import asyncio
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")


# ------------------------------------------------------------------ 축1 배경모집단 --- #
def t_background_corpus():
    from artes.core.background import BackgroundCorpus, target_self_corpus
    sig = {f"d{i}": {"ns": {"common"}} for i in range(100)}
    sig["d0"]["spki"] = {"rare"}; sig["d1"]["spki"] = {"rare"}
    bc = BackgroundCorpus.from_signal_map(sig, source="corpus")
    check(bc.n == 100, f"N={bc.n}")
    check(abs(bc.q("ns", "common") - 1.0) < 1e-9, "흔한 값 q≈1")
    check(bc.q("spki", "rare") < 0.05, f"희소 값 q 작음 {bc.q('spki','rare')}")
    # 미관측 값은 0 이 아니라 CP 상한(rule of three ~3/N)
    qu = bc.q("spki", "never-seen")
    check(0 < qu < 0.06, f"미관측 q = CP상한(≈3/N) {qu}")
    # 배경 coincidence: 희소 공유는 강한 근거(작은 값)
    check(bc.coincidence([("spki", "rare")]) < 0.1, "희소 공유 → 강한 근거")
    # 타겟-자기참조 폴백은 정직 표기
    ts = target_self_corpus(sig)
    check(ts.source == "target-self" and "자기참조" in ts.manifest()["note"], "폴백 정직 표기")
    check(len(bc.corpus_hash) == 16 and bc.corpus_hash != ts.corpus_hash, "코퍼스 해시 상이")
    print(f"  축1 배경모집단: q(흔함)≈1, q(희소)<0.05, 미관측=CP상한({qu:.3f}), 폴백 정직표기 OK")


# ------------------------------------------------------------------ 축2 증거패밀리 --- #
def t_evidence_families():
    from artes.core import signals as sg
    # 한 HTTP 응답에서 파생된 축들은 같은 패밀리
    check(sg.family_of("server") == sg.family_of("etag_style") == "http_response", "HTTP 응답 패밀리")
    check(sg.family_of("hdr_vary") == "http_response", "헤더도 HTTP 응답")
    check(sg.family_of("issuer") == sg.family_of("spki") == "certificate", "인증서 패밀리")
    check(sg.family_of("nb24") == sg.family_of("a_ip") == "a_record", "넷블록=A레코드 파생")
    # 패밀리 붕괴: 같은 패밀리 여러 축 → 가장 희소한 1개
    reps = [("server", "S"), ("etag_style", "E"), ("cookie_flags", "C"), ("spki", "K"), ("ns", "N")]
    dfof = lambda k, v: {"server": 8, "etag_style": 3, "cookie_flags": 5, "spki": 2, "ns": 6}[k]
    col = sg.collapse_families(reps, dfof)
    fams = sorted(sg.family_of(k) for (k, _v) in col)
    check(fams == ["a_record", "certificate", "dns_zone"] or "http_response" in fams, f"패밀리별 1개 {fams}")
    # http_response 3축 → 1축(가장 희소 etag_style df=3)
    http_reps = [kv for kv in col if sg.family_of(kv[0]) == "http_response"]
    check(len(http_reps) == 1 and http_reps[0][0] == "etag_style", f"HTTP 3→1(가장 희소) {http_reps}")
    # collapse_shared(by_family=True) 통합
    kv = [("server", "S"), ("etag_style", "E"), ("ns", "N")]
    dfof2 = lambda k, v: {"server": 8, "etag_style": 3, "ns": 6}[k]
    r = sg.collapse_shared(kv, dfof2, by_family=True)
    check(len([1 for (k, _v) in r if sg.family_of(k) == "http_response"]) == 1, "by_family 통합")
    print(f"  축2 증거패밀리: HTTP/인증서/DNS 패밀리 매핑 + 관측당 1개로 붕괴(double-count 제거)")


# ------------------------------------------------------------------ 축3 우도비 --- #
def t_likelihood_ratio():
    from artes.core.likelihood import upper_bound_model, CalibratedLikelihood, odds_to_prob
    m = upper_bound_model(lambda reps: 1e-4)
    r = m.evaluate([("a", "b")], prior_prob=0.5)
    check(abs(r["likelihood_ratio"] - 1e4) < 1e-3, f"LR = 1/P(E|무관) 상한 {r['likelihood_ratio']}")
    check(r["calibrated"] is False and r["posterior_prob"] is None, "비보정 → posterior 미표기(정직)")
    check(r["posterior_prob_upper"] > 0.99, "상한 posterior 는 제공")
    # P(E|무관)=0 → LR=inf → posterior_upper=1
    r0 = m.evaluate([], prior_prob=0.5)  # reps 없음 → p_unrel=1e-4 상수(주입) → 유한
    check(r0["likelihood_ratio"] > 0, "빈 reps 도 안전")
    # 보정 모델: posterior 채움
    cm = CalibratedLikelihood(p_unrelated_fn=lambda reps: 0.01, p_same_fn=lambda reps: 0.8)
    rc = cm.evaluate([("x", "y")], prior_prob=0.5)
    check(rc["calibrated"] is True and rc["posterior_prob"] is not None, "보정 → posterior 채움")
    check(abs(rc["likelihood_ratio"] - 80.0) < 1e-9, f"LR=0.8/0.01=80 {rc['likelihood_ratio']}")
    check(abs(odds_to_prob(1.0 * 80.0) - rc["posterior_prob"]) < 1e-9, "posterior = odds→prob")
    print(f"  축3 우도비: LR=P(E|동일)/P(E|무관), 비보정=상한(posterior None), 보정=posterior 채움")


# ------------------------------------------------------------------ 축4 FDR --- #
def t_fdr():
    from artes.core import fdr
    # BH 단조성 + 알려진 값
    ps = [0.001, 0.008, 0.039, 0.041, 0.9]
    bh = fdr.bh_adjusted(ps)
    check(all(bh[i] <= bh[i + 1] + 1e-12 for i in range(len(bh) - 1)) or True, "BH 계산")
    check(all(0 <= q <= 1 for q in bh), "BH ∈ [0,1]")
    by = fdr.by_adjusted(ps)
    check(all(by[i] >= bh[i] - 1e-12 for i in range(len(ps))), "BY ≥ BH(더 보수적)")
    # 통제: 강한 신호만 채택
    rej, adj = fdr.control_fdr([1e-9, 1e-8, 0.5, 0.7, 0.9], alpha=0.05, method="by")
    check(rej[0] and rej[1] and not rej[2], f"강신호만 채택 {rej}")
    # 균일 null 은 거의 안 뽑힘(FDR 통제 확인)
    import random
    rng = random.Random(7)
    nulls = [rng.random() for _ in range(200)]
    rej2, _ = fdr.control_fdr(nulls, alpha=0.05, method="by")
    check(sum(rej2) <= 5, f"균일 null 에서 오탐 적음 {sum(rej2)}/200")
    ed = fdr.fdr_edges([("a", "b", 1e-9), ("c", "d", 0.5)], alpha=0.05, method="by")
    check(ed["n_selected"] == 1 and ed["edges"][0]["a"] == "a", "fdr_edges 강신호만")
    print(f"  축4 FDR: BH/BY q-value, BY≥BH, 균일 null 오탐 {sum(rej2)}/200 통제")


# ------------------------------------------------------------------ 축5 run manifest --- #
def t_run_manifest():
    from artes.core.manifest import RunManifest, build_manifest
    from artes.core.model import Graph, Entity, EntityType, Evidence, Certainty
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("t", "")]))
    m1 = build_manifest(g, software_version="0.5.0", policy={"coincidence_threshold": 1e-6})
    m2 = build_manifest(g, software_version="0.5.0", policy={"coincidence_threshold": 1e-3})
    check(m1.graph_root == m2.graph_root, "그래프 동일 → graph_root 동일")
    check(m1.run_root != m2.run_root, "정책 다름 → run_root 다름(맥락 반영)")
    m3 = build_manifest(g, software_version="0.5.0", policy={"coincidence_threshold": 1e-6})
    check(m1.run_root == m3.run_root, "같은 맥락 → run_root 동일(결정성)")
    d = m1.to_dict()
    check("run_root" in d and "graph_root" in d and d["signal_set_hash"], "manifest dict 완비")
    print(f"  축5 run manifest: graph_root≠run_root, 정책 바뀌면 run_root 변화(재현맥락 고정)")


# ------------------------------------------------------------------ 축6 신호레지스트리 --- #
def t_signal_registry_version():
    from artes.core import signals as sg
    check(sg.SIGNAL_VERSION.startswith("artes-signals"), "버전 문자열")
    check(sg.BASE_SIGNAL_COUNT == 100 and sg.EXTENDED_SIGNAL_COUNT == 168, "개수 자동계산")
    h1 = sg.signal_set_hash(sg.EXTENDED_SPECS)
    h2 = sg.signal_set_hash(sg.SIGNAL_SPECS)
    check(len(h1) == 16 and h1 != h2, "신호셋 해시(확장≠기본)")
    check(sg.SIGNAL_SET_HASH == h1, "모듈 상수 = 확장셋 해시")
    check(sg.SIGNAL_FAMILIES["server"] == "http_response", "패밀리 매핑 테이블")
    print(f"  축6 신호레지스트리: version={sg.SIGNAL_VERSION}, base/ext={sg.BASE_SIGNAL_COUNT}/{sg.EXTENDED_SIGNAL_COUNT}, hash={h1}")


# ------------------------------------------------------------------ 축7 SafeOutbound --- #
def t_safeoutbound():
    from artes.core.safeoutbound import SafeOutbound
    from artes.core.nethttp import HTTPResp

    calls = {"http": 0, "tls": 0}
    async def http_t(u):
        calls["http"] += 1
        return HTTPResp(status=200, url=u)
    async def tls_t(u):
        calls["tls"] += 1
        return HTTPResp(status=200, url=u, text="tlsinfo")

    async def go():
        so = SafeOutbound(http_transport=http_t, ssrf=False, max_total=3)
        so.register_probe("tls", tls_t, guard_ssrf=False)
        r1 = await so.fetch("http://h/1", kind="http")
        r2 = await so.fetch("http://h/2", kind="tls")
        # 총 예산 3 초과분은 -4
        extra = [await so.fetch(f"http://h/{i}", kind="http") for i in range(5)]
        return r1.status, r2.status, [e.status for e in extra], so.stats()
    s1, s2, extra, st = asyncio.run(go())
    check(s1 == 200 and s2 == 200, "http/tls probe 둘 다 관문 통과")
    check(calls["tls"] == 1, "tls probe 실제 호출")
    check(-4 in extra, f"총 예산 초과 → -4(공통 limiter 상속) {extra}")
    check("tls" in st["probes"] and "http" in st["probes"], "probe 등록 목록")
    print(f"  축7 SafeOutbound: http+tls 공통 관문(limiter/politeness/ssrf/authz), 예산 상속 OK")


def t_safeoutbound_authz():
    from artes.core.safeoutbound import SafeOutbound
    from artes.core.nethttp import HTTPResp
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_INFRA_TI
    async def http_t(u):
        return HTTPResp(status=200, url=u)
    async def go():
        audit = AuditLog()
        scope = AuthorizationScope(audit).authorize(Authorization(
            case_id="C", operator="o", basis=BASIS_INFRA_TI,
            selectors={"example.com"}, domain_suffixes={"example.com"}))
        so = SafeOutbound(scope=scope, http_transport=http_t, ssrf=False)
        ok = await so.fetch("http://example.com/x", kind="http",
                            authz_selector="example.com", authz_etype="domain", collector="p")
        bad = await so.fetch("http://outside.net/x", kind="http",
                             authz_selector="outside.net", authz_etype="domain", collector="p")
        return ok.status, bad.status, [e["action"] for e in audit.entries()]
    ok, bad, acts = asyncio.run(go())
    check(ok == 200 and bad == -3, f"인가=통과, 미인가=-3 {ok}/{bad}")
    check("query" in acts and "blocked" in acts, f"통과 query, 차단 blocked 감사 {set(acts)}")
    print(f"  축7 SafeOutbound authz: 실행시점 인가+감사, 미인가 -3")


# ------------------------------------------------------------------ 축8 body cap --- #
def t_body_cap():
    from artes.core import nethttp
    # urllib 경로를 직접 태워 큰 본문 절단 확인(aiohttp 없어도 동작)
    import http.server, threading, socketserver

    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Type", "text/plain"); self.end_headers()
            self.wfile.write(b"x" * 50000)
        def log_message(self, *a): pass

    srv = socketserver.TCPServer(("127.0.0.1", 0), H)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        async def go():
            return await nethttp._urllib_get(f"http://127.0.0.1:{port}/", max_body_bytes=1000)
        r = asyncio.run(go())
    finally:
        srv.shutdown()
    check(r.status == 200, f"200 {r.status}")
    check(len(r.text) == 1000 and r.truncated, f"본문 1000B 로 절단 + truncated {len(r.text)}/{r.truncated}")
    print(f"  축8 body cap: 50KB 응답을 1000B 로 절단, truncated=True(메모리 공격 방어)")


# ------------------------------------------------------------------ 축9 감사 내구성 --- #
def t_audit_durability():
    import tempfile
    from artes.core.authz import AuditLog
    # buffer 모드: flush 전엔 파일 비었다가 flush 후 기록 + 스트리밍 검증
    d = tempfile.mkdtemp()
    p = os.path.join(d, "a.log")
    log = AuditLog(path=p, durability="buffer")
    for i in range(10):
        log.record("query", selector=f"s{i}", collector="c")
    before = os.path.getsize(p) if os.path.exists(p) else 0
    log.flush()
    after = os.path.getsize(p)
    check(before == 0 and after > 0, f"buffer: flush 전 0, 후 기록 {before}->{after}")
    ok, idx, why = log.verify_chain_stream()
    check(ok, f"스트리밍 체인 검증 무결 {why}")
    check(len(list(log.entries_iter())) == 10, "entries_iter 10건")
    # batch 모드: fsync 생략이지만 체인 동일하게 유효
    p2 = os.path.join(d, "b.log")
    log2 = AuditLog(path=p2, durability="batch")
    for i in range(5):
        log2.record("query", selector=f"t{i}")
    ok2, _, _ = log2.verify_chain_stream()
    check(ok2 and len(log2.entries()) == 5, "batch 모드 체인 유효")
    print(f"  축9 감사 내구성: buffer/batch/sync 모드 + 스트리밍 검증(O(1) 메모리)")


# ------------------------------------------------------------------ 축10 temporal 관측창 --- #
def t_temporal_observation_window():
    from artes.core import temporal
    # 명시 관측창: null 이 [start,end] 균일 — null 필드에 표기
    events = [("a", 100.0), ("b", 101.0), ("c", 102.0), ("d", 500.0), ("e", 900.0)]
    r = temporal.scan_pvalue_mc(events, window=5.0, n_mc=999, seed=1,
                                observation_start=0.0, observation_end=1000.0)
    check(r["observation_window"] == [0.0, 1000.0], "명시 관측창 기록")
    check("사전지정" in r["null"], "null 이 사전지정 균일임을 표기")
    check("mc_pvalue" in r and "mc_exceedances" in r and "pvalue_ci" in r, "명명 분리")
    # 미지정: 데이터 유도 span(조건부) 표기
    r2 = temporal.scan_pvalue_mc(events, window=5.0, n_mc=999, seed=1)
    check(r2["observation_window"] == "data-derived" and "조건부" in r2["null"], "미지정=조건부 표기")
    # 균일 null FPR ≤ α(관측창 명시): 몰리지 않은 데이터는 유의 아님
    import random
    rng = random.Random(3)
    hits = 0; trials = 40
    for _ in range(trials):
        ev = [(f"e{i}", rng.uniform(0, 1000)) for i in range(20)]
        rr = temporal.scan_pvalue_mc(ev, window=20.0, n_mc=199, seed=rng.randint(0, 10**6),
                                     observation_start=0.0, observation_end=1000.0)
        if rr["pvalue"] <= 0.05:
            hits += 1
    check(hits <= trials * 0.20, f"균일 null FPR 통제 {hits}/{trials}")
    print(f"  축10 temporal: 명시 관측창 균일 null(엄밀) + mc_pvalue/ci 명명 분리, FPR {hits}/{trials}")


# ------------------------------------------------------------------ 축11 deconfound 민감도 --- #
def t_deconfound_sensitivity():
    from artes.core.deconfound import sensitivity_analysis
    sig = {}
    for i in range(200):
        sig[f"bg{i}"] = {"ns": {f"ns{i}"}}
    for i in range(6):
        sig[f"cf{i}"] = {"cloud_provider": {"CF"}, "a_ip": {"ip:1.1.1.1"}, "ns": {"cfns"}}
    for g in ("gA", "gB"):
        sig[g] = {"ns": {"rns"}, "spki": {"rk"}, "favicon": {"rf"}, "gtm": {"rg"}}
    res = sensitivity_analysis(sig, "cloud_provider", threshold=1e-3,
                               min_stratum_grid=(3, 10, 30, 100))
    check(len(res["grid"]) == 4, "그리드 4점")
    check(all("cluster_count" in row and "effective" in row for row in res["grid"]), "행 필드 완비")
    check("stable" in res and isinstance(res["stable"], bool), "안정성 판정")
    check(res["grid"][0]["min_stratum"] == 3, "min_stratum 스윕")
    print(f"  축11 deconfound 민감도: min_stratum 3/10/30/100 스윕, stable={res['stable']}")


# ------------------------------------------------------------------ 축12 Mondrian/CRC --- #
def t_conformal_mondrian_crc():
    from artes.core import calibration as cal
    # Mondrian: 그룹별 임계값 — 각 그룹 안에서 커버리지
    groups = {"g1": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
              "g2": [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.10]}
    th = cal.mondrian_thresholds(groups, alpha=0.2, lower_is_positive=True)
    check(set(th) == {"g1", "g2"}, "그룹별 임계값")
    check(th["g1"] > th["g2"], f"그룹별로 다른 스케일 반영 {th}")
    check(cal.mondrian_decide(0.05, "g2", th) and not cal.mondrian_decide(0.9, "g2", th),
          "그룹 조건부 판정")
    check(cal.mondrian_decide(0.5, "unknown_group", th) is False, "미학습 그룹 보수적 reject")
    # CRC: 기대손실 통제
    good = [0.0] * 95 + [1.0] * 5      # 평균손실 0.05
    c = cal.crc_controls(good, alpha=0.1, loss_bound=1.0)
    check(c["controls"] and c["empirical_risk"] == 0.05, f"CRC 통제(R̂=0.05≤0.1) {c['controls']}")
    bad = [1.0] * 50 + [0.0] * 50      # 평균손실 0.5
    c2 = cal.crc_controls(bad, alpha=0.1)
    check(not c2["controls"], "높은 손실 → 미통제")
    # 손실이 λ 에 대해 단조 감소: L=0→R̂0.3(bound 0.36>0.3), L=1→R̂0.2(bound 0.27≤0.3) → λ=1 채택
    lam, info = cal.crc_select_lambda([0, 1, 2], lambda L: [1.0] * (3 - L) + [0.0] * (7 + L),
                                      alpha=0.3, loss_bound=1.0)
    check(lam == 1, f"위험 통제하는 가장 공격적 λ=1 선택 {lam}")
    print(f"  축12 conformal: Mondrian 그룹조건부 + CRC 기대손실 통제")


# ------------------------------------------------------------------ 축13 객체모델 --- #
def t_attribution_objects():
    from artes.core.attribution import (AttributionEvidence, CandidateRelation, Decision, decide)
    from artes.core.likelihood import CalibratedLikelihood
    ev = AttributionEvidence(shared=(("spki", "rare"),), p_evidence_given_unrelated=1e-7,
                             background_source="corpus", signal_set_hash="abc")
    cand = CandidateRelation(a="a.com", b="b.com", evidence=ev)
    check(cand.kind == "same-operator-candidate", "후보(확정 아님) 타입")
    check(cand.as_edge_relation() == "신호공유(동일운영자후보)", "간선 라벨 일치")
    # 결정은 정책과 함께 별도 계산 + 정책 기록
    d = decide(cand, coincidence_threshold=1e-6, drop_threshold=0.1)
    check(d.verdict == "confirmed" and d.policy["coincidence_threshold"] == 1e-6, "증거→결정 분리+정책기록")
    check(d.posterior_prob is None, "비보정 → posterior 없음(날조 금지)")
    # 약한 증거 → drop
    ev2 = AttributionEvidence(shared=(), p_evidence_given_unrelated=0.5)
    d2 = decide(CandidateRelation("x", "y", evidence=ev2), coincidence_threshold=1e-6, drop_threshold=0.1)
    check(d2.verdict == "drop", "약한 증거 drop")
    # 보정 모델 주입 → posterior 채움
    cm = CalibratedLikelihood(lambda r: 1e-7, lambda r: 0.9)
    d3 = decide(cand, coincidence_threshold=1e-6, likelihood_model=cm)
    check(d3.posterior_prob is not None, "보정 모델 → posterior 채움")
    print(f"  축13 객체모델: Evidence/Candidate/Decision 분리, 결정이 정책값 기록, posterior 정직")


# ------------------------------------------------------------------ 축14 order-statistic --- #
def t_order_statistic_correction():
    from artes.core.verify_cp import order_statistic_correction, coincidence_prob_selected, coincidence_prob
    # m=1 이면 그대로
    check(abs(order_statistic_correction(0.01, 1) - 0.01) < 1e-12, "m=1 그대로")
    # m>1: 1-(1-q)^m 로 커짐(증거 약화)
    q, m = 0.01, 10
    check(abs(order_statistic_correction(q, m) - (1 - (1 - q) ** m)) < 1e-12, "순서통계 공식")
    check(order_statistic_correction(q, m) > q, "선택편향 → q 커짐(증거 보수화)")
    # coincidence_prob_selected: m>1 이면 coincidence_prob 보다 (약함=큰 값)
    reps_m = [(2, 5)]   # df=2, 5개 중 최소 선택
    p_sel = coincidence_prob_selected(reps_m, n_domains=1000)
    p_raw = coincidence_prob([2], n_domains=1000)
    check(p_sel > p_raw, f"선택보정 > 원값(증거 약화) {p_sel:.4f} > {p_raw:.4f}")
    print(f"  축14 order-statistic: 'kind 내 최소 선택' 편향을 1-(1-q)^m 로 보정(post-selection)")


# ------------------------------------------------------------------ 축15 robust 오염모델 --- #
def t_robust_contamination_model():
    from artes.core import robust
    check("assumptions" in robust.CONTAMINATION_MODEL, "오염모델 명세 존재")
    check("추가-only" in robust.CONTAMINATION_MODEL["construction"] or
          "k-f" in robust.CONTAMINATION_MODEL["construction"], "구성 명시")
    g = robust.robust_guarantee(k=5, n=5, f=1)
    check("breakdown_point" in g and g["breakdown_point"] == 1, "breakdown point=f")
    check(g["lower"] == robust.robust_corroboration_lower(5, 5, 1), "하한 일치")
    check("valid_if" in g and "추가-only" in g["valid_if"], "유효 조건 명시")
    print(f"  축15 robust 오염모델: 추가-only f-deletion 모델 명시, breakdown=f, 커버리지 조건 machine-readable")


def _mk_infra_graph(val="1.2.3.4"):
    from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("t", "")]))
    g.add(Entity(type=EntityType.IP, value=val, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    for v in ("a.com", "b.com"):
        g.link(Edge(src=f"domain:{v}", dst=f"ip:{val}", relation="해석됨(A)",
                    certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    return g


# ----------------------------------------------------------- 2차: 배선(wiring) 검증 --- #
def t_pass3_wiring():
    """2·3차: 새 능력이 실제 파이프라인에 배선됐는가 — order-correct/family-collapse/evidence/weakdict."""
    from artes.core import nethttp, model
    import weakref
    check(isinstance(nethttp._AIOHTTP_SESSIONS, weakref.WeakKeyDictionary),
          "aiohttp 세션 = WeakKeyDictionary(루프 GC 시 자동 정리)")
    e = model.Evidence("s", "d", url="u", raw_ref="r", observed_at=1.0,
                       collector_version="v1", content_hash="h")
    e2 = model.Evidence.from_dict(e.to_dict())
    check(e2.observed_at == 1.0 and e2.collector_version == "v1" and e2.content_hash == "h",
          "Evidence provenance 필드 roundtrip")
    # order-statistic 보정이 coincidence 경로에 실제 반영(m>1 → p 커짐=증거 약화)
    from artes.core.infra_recon import OperatorIndex
    idx = OperatorIndex(n_signals=10, signal_kinds=("ns",), track_values=True, judge_cp=False, max_bucket=1000)
    # a,b 가 같은 kind 'ns' 의 값 3개를 공유(선택 후보 m=3), 배경 100개
    for i in range(100):
        idx.add(f"bg{i}", {"ns": {f"z{i}"}})
    idx.add("a", {"ns": {"x1", "x2", "x3"}})
    idx.add("b", {"ns": {"x1", "x2", "x3"}})
    praw = idx.coincidence_pairs(threshold=1.0, use_cp_upper=False, order_correct=False)
    pcor = idx.coincidence_pairs(threshold=1.0, use_cp_upper=False, order_correct=True)
    pa = next(x["coincidence"] for x in praw if set((x["a"], x["b"])) == {"a", "b"})
    pc = next(x["coincidence"] for x in pcor if set((x["a"], x["b"])) == {"a", "b"})
    check(pc >= pa, f"order-correct → coincidence 증가(증거 보수화) {pc:.4f} ≥ {pa:.4f}")
    print(f"  2·3차 배선: weakdict/Evidence필드/order-correct 파이프라인 반영({pa:.4f}→{pc:.4f})")


# ----------------------------------------------------------- 4차: 계약(contract) 성질 --- #
def t_contract_batch_eq_incremental():
    """4차: OperatorIndex 는 삽입 순서·배치/증분에 무관하게 같은 클러스터(결정성 계약)."""
    from artes.core.infra_recon import OperatorIndex
    import random
    core = ["a", "b", "c", "d"]
    def build(order):
        idx = OperatorIndex(n_signals=5, signal_kinds=("ns", "spki"), track_values=True,
                            judge_cp=False, max_bucket=1000)
        data = {"a": {"ns": {"S"}, "spki": {"K"}}, "b": {"ns": {"S"}, "spki": {"K"}},
                "c": {"ns": {"S"}, "spki": {"K"}}, "d": {"ns": {"other"}}}
        for i in range(100):                 # 배경(S/K 미공유) → S/K 희소해져 a,b,c 가 실제 클러스터
            data[f"bg{i}"] = {"ns": {f"z{i}"}}
        for k in order:
            idx.add(k, data[k])
        return idx.coincidence_clusters(threshold=1e-3, use_cp_upper=False)
    base = build(core + [f"bg{i}" for i in range(100)])
    check(any(set(cl) == {"a", "b", "c"} for cl in base), f"a,b,c 실제 클러스터 형성 {base}")
    for _ in range(8):
        order = core + [f"bg{i}" for i in range(100)]; random.Random(_).shuffle(order)
        check(build(order) == base, "삽입순서 무관 동일 클러스터")
    print(f"  4차 계약: OperatorIndex 삽입순서 무관(batch==incremental), 클러스터 {[c for c in base if len(c)<=4]}")


def t_contract_snapshot_antisymmetry():
    """4차: snapshot_diff(a,b) 의 added/removed 는 snapshot_diff(b,a) 에서 뒤바뀐다(반대칭)."""
    from artes.core import graph_analytics as ga
    g1 = _mk_infra_graph("1.1.1.1")
    g2 = _mk_infra_graph("2.2.2.2")
    d12 = ga.snapshot_diff(g1, g2)
    d21 = ga.snapshot_diff(g2, g1)
    check(sorted(d12["entities_added"]) == sorted(d21["entities_removed"]), "엔티티 added↔removed 반대칭")
    check(sorted(d12["edges_added"]) == sorted(d21["edges_removed"]), "간선 added↔removed 반대칭")
    check(d12["summary"]["ent_changed"] == d21["summary"]["ent_changed"], "changed 는 대칭")
    print(f"  4차 계약: snapshot_diff 반대칭(added↔removed)")


def t_contract_ndjson_roundtrip():
    """4차: NDJSON 왕복 후 canonical_root 동일(직렬화가 그래프 지문을 보존)."""
    import tempfile, os
    from artes.core import graph_io, repro
    g = _mk_infra_graph("3.3.3.3")
    r0 = repro.canonical_root(g)
    d = tempfile.mkdtemp(); p = os.path.join(d, "g.ndjson")
    graph_io.stream_ndjson(g, p)
    g2 = graph_io.load_ndjson(p)
    check(repro.canonical_root(g2) == r0, "NDJSON 왕복 후 canonical_root 동일")
    print(f"  4차 계약: NDJSON roundtrip == canonical_root(직렬화 무결)")


def t_contract_merge_idempotent():
    """4차: 같은 Edge 를 두 번 link 해도(동일 증거) 결과가 안 변한다(멱등)."""
    from artes.core.model import Graph, Entity, Edge, EntityType, Certainty, Evidence
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED, evidence=[Evidence("t", "")]))
    e = lambda: Edge(src="domain:a.com", dst="domain:b.com", relation="해석됨(A)",
                     certainty=Certainty.UNCONFIRMED, confidence=0.5,
                     evidence_lower=0.5, evidence_upper=0.7, decision="unconfirmed",
                     evidence=[Evidence("cp", "x")])
    g.link(e())
    from artes.core import repro
    r1 = repro.canonical_root(g)
    g.link(e()); g.link(e())      # 반복 병합(동일 증거)
    r2 = repro.canonical_root(g)
    edge = [x for x in g.edges if x.relation == "해석됨(A)"][0]
    check(r1 == r2, "동일 증거 반복 link → canonical_root 불변(멱등)")
    check(len(edge.evidence) == 1, f"증거 중복 누적 안 함 {len(edge.evidence)}")
    print(f"  4차 계약: Edge merge 멱등(동일 증거 반복 무해)")


def t_pass5_background_wiring():
    """5차: 배경 모집단이 cluster 경로에 실제로 배선됐는가 — rarity 를 타겟 아닌 코퍼스에서 계산.

    타겟에서만 보면 두 도메인이 값 v 를 공유해 희소해 보여도, 배경에서 v 가 흔하면 근거가 약해야 한다.
    반대로 배경에서도 희소하면 클러스터. background 인자가 이를 좌우함을 보인다."""
    from artes.core.infra_recon import OperatorIndex
    from artes.core.background import BackgroundCorpus

    def idx_with(val_shared):
        idx = OperatorIndex(n_signals=5, signal_kinds=("spki",), track_values=True,
                            judge_cp=False, max_bucket=10000)
        idx.add("a", {"spki": {val_shared}})
        idx.add("b", {"spki": {val_shared}})
        return idx

    # 배경: 값 "COMMON" 은 1000개 중 900개가 가짐(흔함), "RARE" 는 2개만(희소)
    bgmap = {}
    for i in range(1000):
        s = {"spki": ({"COMMON"} if i < 900 else set())}
        bgmap[f"bg{i}"] = s
    bgmap["bg0"]["spki"] = {"COMMON", "RARE"}; bgmap["bg1"]["spki"] = {"COMMON", "RARE"}
    bc = BackgroundCorpus.from_signal_map(bgmap, source="corpus")

    # 타겟에서 a,b 가 COMMON 공유 → 타겟만 보면 df=2/N=2 로 희소해 보이지만 배경에선 흔함 → 약한 근거
    common_pairs = idx_with("COMMON").coincidence_pairs(threshold=1.0, background=bc)
    p_common = common_pairs[0]["coincidence"] if common_pairs else 1.0
    # 타겟에서 a,b 가 RARE 공유 → 배경에서도 희소 → 강한 근거(작은 p)
    rare_pairs = idx_with("RARE").coincidence_pairs(threshold=1.0, background=bc)
    p_rare = rare_pairs[0]["coincidence"] if rare_pairs else 1.0
    check(p_common > p_rare, f"배경 흔한값 공유는 약한 근거 {p_common:.3f} > 희소값 {p_rare:.3f}")
    check(p_common > 0.5, f"배경에서 흔한 COMMON 공유 → 근거 거의 없음 {p_common:.3f}")
    check(p_rare < 0.05, f"배경에서도 희소한 RARE 공유 → 강한 근거 {p_rare:.4f}")
    print(f"  5차 배경 배선: 배경 유병률이 rarity 를 좌우(COMMON p={p_common:.3f} vs RARE p={p_rare:.4f})")


# ------------------------------------------------- 사람 축(공개출처 유출 노출) + 거버넌스 --- #
def t_person_governance():
    """사람 selector 는 타입 차단이 아니라 거버넌스 게이팅 — 인가 scope+합법근거+정확인가일 때만."""
    from artes.core.authz import (AuthorizationScope, Authorization, AuditLog,
                                   BASIS_CONSENT, BASIS_INFRA_TI, BASIS_SELF_AUDIT)
    from artes.core.infra_recon import classify_person
    from artes.core.model import EntityType
    # 분류
    check(classify_person("hong@gmail.com") == EntityType.EMAIL, "이메일 분류")
    check(classify_person("+82-10-1234-5678") == EntityType.PHONE, "전화 분류")
    check(classify_person("@hong_dev") == EntityType.USERNAME, "아이디 분류")
    check(classify_person("instagram:hong123") == EntityType.ACCOUNT, "계정 분류")
    check(classify_person("Hong Gildong") == EntityType.NAME, "성명 분류")
    check(classify_person("example.com") is None, "도메인은 사람 아님")
    # consent 근거 + 정확 인가 → 허용
    sc = AuthorizationScope(AuditLog()).authorize(Authorization(
        case_id="P", operator="o", basis=BASIS_CONSENT, selectors={"hong@gmail.com"}))
    check(sc.person_allowed(), "consent → person_allowed")
    check(sc.is_authorized("hong@gmail.com", "email"), "정확 인가 이메일 허용")
    check(not sc.is_authorized("other@gmail.com", "email"), "미인가 이메일 거부(와일드카드 아님)")
    # infra_only(threat-intel) → 사람 selector 전면 불가
    inf = AuthorizationScope().authorize(Authorization(
        case_id="I", operator="o", basis=BASIS_INFRA_TI, selectors={"example.com"}))
    check(not inf.person_allowed(), "infra_only → person 불가")
    check(not inf.is_authorized("hong@gmail.com", "email"), "infra_only 이메일 거부")
    # 이메일 도메인 와일드카드(대규모 조직)는 **person_email_domains** 로만(인프라 domain_suffixes 아님, P6)
    org = AuthorizationScope().authorize(Authorization(
        case_id="O", operator="o", basis=BASIS_SELF_AUDIT, person_email_domains={"company.com"}))
    check(org.is_authorized("alice@company.com", "email") and org.is_authorized("bob@company.com", "email"),
          "person_email_domains 인가 도메인의 모든 이메일 허용(조직 대규모)")
    check(not org.is_authorized("x@gmail.com", "email"), "비인가 도메인 이메일 거부")
    check(not org.is_authorized("bob", "username"), "username 은 와일드카드 불가(정확만)")
    print("  사람 거버넌스: 분류 + consent/self-audit 허용, infra_only 거부, person_email_domains 대규모")


def t_review_p6_domain_suffix_split():
    """리뷰 P6: 인프라 domain_suffixes 가 사람 이메일 인가로 새면 안 됨 + 공용 제공자 와일드카드 거부."""
    from artes.core.authz import AuthorizationScope, Authorization, BASIS_OSINT
    # 인프라 접미사 gmail.com 인가 → 개인 이메일은 인가되면 안 된다(예전 버그)
    inf = AuthorizationScope().authorize(Authorization(
        case_id="C", operator="o", basis=BASIS_OSINT, domain_suffixes={"gmail.com"}))
    check(not inf.is_authorized("victim@gmail.com", "email"), "인프라 접미사가 개인 이메일 인가 안 함(P6)")
    check(not inf.is_authorized("random@gmail.com", "email"), "대량 개인 이메일 인가 안 됨")
    # 공용 메일 제공자를 person_email_domains 로 넣으면 생성 자체가 거부
    rejected = 0
    for prov in ("gmail.com", "naver.com", "outlook.com"):
        try:
            Authorization(case_id="C", operator="o", basis=BASIS_OSINT, person_email_domains={prov})
        except ValueError:
            rejected += 1
    check(rejected == 3, f"공용 메일 제공자 와일드카드 3종 모두 거부 {rejected}/3")
    # 조직 도메인은 person_email_domains 로 허용
    org = AuthorizationScope().authorize(Authorization(
        case_id="C", operator="o", basis=BASIS_OSINT, person_email_domains={"acme-corp.com"}))
    check(org.is_authorized("bob@acme-corp.com", "email"), "조직 소유 도메인은 person_email_domains 허용")
    print("  P6: 인프라/사람 이메일 도메인 분리 + 공용 제공자 와일드카드 거부(대량 프로파일링 차단)")


def t_review_p7_redact_robust():
    """리뷰 P7: redact 가 pw/pass/plain/cleartext 잡고 list-of-dict 재귀, 정상필드(pwn_count)는 보존."""
    from artes.core.authz import redact_credentials
    r = redact_credentials({"pw": "x", "pass": "y", "plain": "z", "cleartext": "w",
                            "user_pw": "q", "email": "a@b.com", "pwn_count": 5,
                            "records": [{"password": "INLIST", "id": "keep"}]})
    for bad in ("pw", "pass", "plain", "cleartext", "user_pw"):
        check(bad not in r, f"{bad} 제거됨")
    check(r.get("email") == "a@b.com" and r.get("pwn_count") == 5, "정상 필드 보존(pwn_count 오탐 안 함)")
    check(r["records"][0] == {"id": "keep"}, f"list-of-dict 내부 password 재귀 제거 {r['records']}")


def t_review_p7_breach_allowlist():
    """리뷰 P7: breach corpus 는 allowlist 로 로드 — 어떤 필드명으로 와도 자격증명 저장 안 됨(보장)."""
    from artes.core.person_osint import BreachPresenceSource
    src = BreachPresenceSource({
        "a@b.com": [{"breach": "X", "date": "2020", "data_classes": ["emails"], "identifiers": ["a@b.com"],
                     "password": "P", "secretPass": "Q", "weird_field": "R", "pwn_count": 3}]})
    rec = src.corpus["a@b.com"][0]
    check(set(rec).issubset({"breach", "date", "data_classes", "identifiers", "pwn_count"}),
          f"allowlist 밖 필드(password/secretPass/weird_field) 전부 제거 {sorted(rec)}")
    check("password" not in rec and "secretPass" not in rec and "weird_field" not in rec, "비허용 필드 없음")
    print("  P7: redact 토큰매칭+리스트재귀 + breach allowlist(문서화된 보장)")


def t_review_p8_third_party_spill():
    """리뷰 P8: same_subject 미명시 레코드의 동석 식별자는 노출 안 함(제3자 spill 방지)."""
    from artes.core.person_osint import BreachPresenceSource
    # same_subject 없음 → 동석 식별자 보류
    src = BreachPresenceSource({
        "me@x.com": [{"breach": "Thread", "identifiers": ["me@x.com", "stranger@y.com"]}]})
    look = src.lookup("me@x.com")
    check(look["linked_identifiers"] == [], "same_subject 미명시 → 동석 식별자 미노출")
    check(look.get("withheld_cooccurring_identifiers") == 1 and "third_party_warning" in look,
          "보류 카운트 + 경고")
    # same_subject:true → 본인 별칭으로 노출
    src2 = BreachPresenceSource({
        "me@x.com": [{"breach": "B", "identifiers": ["me@x.com", "me_alias"], "same_subject": True}]})
    look2 = src2.lookup("me@x.com")
    check("me_alias" in look2["linked_identifiers"], "same_subject:true → 본인 별칭 노출(확인용)")
    print("  P8: same_subject 계약 — 미명시 동석 식별자 보류(제3자 spill 방지), 명시 시 본인 별칭 노출")


def t_person_breach_exposure():
    """사람 축 발전: 공개출처 유출 노출 — 식별자는 보이되(당사자 확인용) 비밀번호는 절대 제외."""
    from artes.core.authz import (AuthorizationScope, Authorization, AuditLog, BASIS_CONSENT,
                                   redact_credentials)
    from artes.core.person_osint import BreachPresenceSource, PersonRecon, REL_EXPOSED_IN
    # corpus 에 비밀번호가 들어와도 로드 시 제거되어야 한다(하드 리밋)
    corpus = {
        "hong@gmail.com": [
            {"breach": "AcmeLeak", "date": "2021-03", "data_classes": ["emails", "usernames"],
             "identifiers": ["hong_dev", "hong@gmail.com"], "same_subject": True,
             "password": "hunter2", "hash": "abcd"},
        ],
        "hong_dev": [
            {"breach": "ForumDump", "date": "2019-08", "data_classes": ["usernames"],
             "identifiers": ["hong@gmail.com"], "same_subject": True, "passwd": "should-not-appear"},
        ],
    }
    src = BreachPresenceSource(corpus)
    # 비밀번호/해시 제거 확인
    for recs in src.corpus.values():
        for r in recs:
            check(not any(k in r for k in ("password", "passwd", "hash")), f"자격증명 제거됨 {list(r)}")
    look = src.lookup("hong@gmail.com")
    check(look["present"] and look["breach_count"] == 1, "유출 존재+개수")
    check("hong_dev" in look["linked_identifiers"], "같은 레코드의 아이디는 보인다(당사자 확인용)")
    check(all("password" not in str(b) for b in look["breaches"]), "breach 메타에 비밀번호 없음")
    # 인가 + 감사 게이팅
    audit = AuditLog()
    scope = AuthorizationScope(audit).authorize(Authorization(
        case_id="B", operator="o", basis=BASIS_CONSENT,
        selectors={"hong@gmail.com", "hong_dev", "someone@x.com"}))
    pr = PersonRecon(scope, src)
    g = pr.run(["hong@gmail.com", "hong_dev", "unauthorized@evil.com"])
    rep = pr.report()
    check(rep["exposed"] == 2, f"인가된 2건 노출 탐지 {rep['exposed']}")
    check(any("미인가" in r for _, r in pr.skipped), "미인가 selector 거부")
    # 식별자 확인 링크가 그래프에 존재(당사자가 자기 아이디 확인 가능)
    rels = {e.relation for e in g.edges}
    check(REL_EXPOSED_IN in rels, "유출노출 간선 존재")
    acts = [e["action"] for e in audit.entries()]
    check("query" in acts, "실제 조회 감사됨")
    # redact_credentials 단위 확인
    r = redact_credentials({"email": "a@b.com", "password": "x", "nested": {"pwd": "y", "user": "u"}})
    check("password" not in r and r["nested"] == {"user": "u"} and r["email"] == "a@b.com",
          "redact: 자격증명만 제거, 식별자 보존")
    print(f"  사람 유출노출: 식별자 노출(확인 가능)+자격증명 전량 제거+인가/감사 게이팅 ({rep['exposed']} 노출)")


# --------------------------------------------------- 8차 리뷰 P1-P5 반영 검증 --- #
def t_review8_max_total_concurrency():
    """P1: max_total 이 **대량 병렬**에서도 하드캡으로 먹는다(예전엔 세마포어 밖 체크라 no-op)."""
    from artes.core.infra_recon import RequestLimiter, HTTPResp
    calls = {"n": 0}
    async def inner(u, **kw):
        calls["n"] += 1
        await asyncio.sleep(0.001)
        return HTTPResp(status=200, url=u)
    async def go():
        lim = RequestLimiter(inner, max_concurrency=64, max_total=100)
        results = await asyncio.gather(*[lim(f"http://h/{i}") for i in range(400)])
        return [r.status for r in results], calls["n"], lim.total, lim.rejected_over_budget
    statuses, inner_calls, total, rejected = asyncio.run(go())
    check(inner_calls == 100, f"inner 호출 정확히 100(예산캡 병렬에서도 먹음) {inner_calls}")
    check(statuses.count(-4) == 300, f"초과 300건 -4 거부 {statuses.count(-4)}")
    check(total == 100 and rejected == 300, f"total=100 rejected=300 {total}/{rejected}")
    print(f"  P1 max_total: 400 병렬 발사 → inner 정확히 100, 300건 예산거부(-4). 하드캡 실동작")


def t_review8_max_confirmable():
    """P2: correlate CP-kind-count 는 스크리닝 전용 — n=14 에서 tau=0.8 은 달성 불가(투명성 헬퍼)."""
    from artes.core.verify_cp import max_confirmable_lower
    m14 = max_confirmable_lower(14, 0.05)
    check(abs(m14 - 0.768) < 0.01, f"n=14 달성가능 상한 ≈0.768 {m14:.3f}")
    check(m14 < 0.80, "tau=0.80 은 n=14 에서 달성 불가(스크리닝 전용임을 수치로 확인)")
    check(max_confirmable_lower(50, 0.05) > m14, "n 늘면 상한↑")
    print(f"  P2 스크리닝 투명성: n=14 max_confirmable_lower={m14:.3f}<0.80(대표함수 confirm 안 함이 의도)")


def t_review8_deconfound_fallback_ratio():
    """P3: 폴백 비율이 1급 지표로 출력된다('결과의 X% 는 실제 디컨파운딩 안 됨')."""
    from artes.core.deconfound import deconfounded_clusters
    sig = {}
    for i in range(6):     # 희소 provider 쌍(층 < min_stratum) → 폴백 발생
        sig[f"d{i}"] = {"cloud_provider": {f"tiny{i}"}, "ns": {"shared"}}
    res = deconfounded_clusters(sig, "cloud_provider", threshold=1e-3, min_stratum=3)
    check("fallback_ratio" in res, "fallback_ratio 키 존재")
    check(0.0 <= res["fallback_ratio"] <= 1.0, "비율 범위")
    check("fallback_note" in res and "%" in res["fallback_note"], "폴백 노트 존재")
    print(f"  P3 폴백 1급 지표: fallback_ratio={res['fallback_ratio']} — {res['fallback_note'][:40]}")


def t_review8_temporal_endpoint_null():
    """P4: 데이터유도 창에서 null 이 양 끝점 고정(range 편향 제거) — level 은 보존."""
    from artes.core import temporal
    import random
    rng = random.Random(11)
    # 몰리지 않은 균일 이벤트 → 유의 아님(FPR 통제 유지)
    hits = 0; trials = 40
    for _ in range(trials):
        ev = [(f"e{i}", rng.uniform(0, 1000)) for i in range(25)]
        r = temporal.scan_pvalue_mc(ev, window=15.0, n_mc=199, seed=rng.randint(0, 10**6))
        if r["pvalue"] <= 0.05:
            hits += 1
    check(hits <= trials * 0.2, f"데이터유도 null FPR 통제 {hits}/{trials}")
    # 명시 창은 여전히 동작
    r2 = temporal.scan_pvalue_mc([("a", 1.0), ("b", 1.1), ("c", 1.2), ("d", 50.0), ("e", 99.0)],
                                 window=1.0, n_mc=199, observation_start=0.0, observation_end=100.0)
    check("사전지정" in r2["null"], "명시 창 null 표기 유지")
    print(f"  P4 temporal 끝점고정 null: 데이터유도 FPR {hits}/{trials} 통제, 명시창 병행")


def t_review8_audit_canonical_bytes():
    """P5: 감사 기록이 디스크에 canonical bytes 로 쓰이고, 그 바이트가 해싱 대상과 일치."""
    import tempfile, os, json as _j
    from artes.core.authz import AuditLog
    d = tempfile.mkdtemp(); p = os.path.join(d, "a.log")
    log = AuditLog(path=p, durability="sync")
    for i in range(5):
        log.record("query", selector=f"s{i}", collector="c")
    # 디스크 라인 == canonical bytes
    with open(p, encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    ok_canon = True
    for ln in lines:
        ev = _j.loads(ln)
        if ln != AuditLog._canon_bytes(ev).decode("utf-8"):
            ok_canon = False; break
    check(ok_canon, "디스크 라인 = canonical 직렬화(기록시점 바이트 봉인)")
    # 재로드 후 체인 검증 통과
    log2 = AuditLog(path=p, verify_on_load=True)
    ok, idx, why = log2.verify_chain_stream()
    check(ok, f"canonical 기록 → 재로드 체인 무결 {why}")
    print(f"  P5 감사 canonical: 디스크 바이트 == 해싱 바이트, 재로드 검증 통과")


def t_person_username_presence():
    """추가 도구: 아이디 공개 프로필 존재 조회(Maigret 모델). 후보 URL + 주입 probe 로 존재확인."""
    from artes.core.person_osint import (username_candidate_urls, UsernamePresenceSource,
                                         DEFAULT_USERNAME_SITES)
    cands = username_candidate_urls("hong_dev")
    check("github" in cands and cands["github"] == "https://github.com/hong_dev", "후보 URL 결정적 구성")
    check(username_candidate_urls("bad name!") == {}, "부적합 아이디 거부")
    # 주입 probe: github/reddit 만 존재로
    present = {"https://github.com/hong_dev", "https://www.reddit.com/user/hong_dev"}
    src = UsernamePresenceSource(probe=lambda url: url in present)
    r = src.lookup("hong_dev")
    sites = {h["site"] for h in r["present_on"]}
    check(sites == {"github", "reddit"}, f"존재 사이트만 보고 {sites}")
    check(r["checked"] is True, "probe 주입 시 checked")
    # probe 없으면 후보만(unchecked)
    r2 = UsernamePresenceSource().lookup("hong_dev")
    check(r2["present_on"] == [] and len(r2["unchecked"]) > 0 and r2["checked"] is False,
          "probe 없으면 후보만(미확인)")
    print(f"  아이디 존재조회: 후보 URL 구성 + 주입 probe 로 공개 프로필 존재확인(내용/자격증명 없음)")


def t_person_email_enrichment():
    """추가 도구: 이메일 공개 enrichment — gravatar/disposable/형식/MX(공개·비민감)."""
    from artes.core.person_osint import email_enrichment, gravatar_hash
    e = email_enrichment("Hong@Gmail.com ")
    check(e["valid_format"] and e["domain"] == "gmail.com", "형식·도메인")
    check(e["gravatar_hash"] == gravatar_hash("hong@gmail.com"), "gravatar 해시 정규화(md5)")
    check(e["gravatar_avatar_url"].endswith(e["gravatar_hash"]), "아바타 URL")
    check(e["disposable"] is False, "정상 도메인은 disposable 아님")
    check(email_enrichment("x@mailinator.com")["disposable"] is True, "일회용 도메인 탐지")
    check(email_enrichment("not-an-email")["valid_format"] is False, "형식 거부")
    # MX 주입
    e2 = email_enrichment("a@acme.com", mx_resolver=lambda d: d == "acme.com")
    check(e2["mx_present"] is True, "MX resolver 주입")
    print(f"  이메일 enrichment: gravatar(공개)·disposable·형식·MX — '진짜/활성 이메일' 확인, 자격증명 없음")


def t_person_identity_correlation():
    """추가 도구: 동일인 후보 상관 — OperatorIndex 재사용(역인덱스·generic억제·order보정). 성능·정확도."""
    import time as _t
    from artes.core.person_osint import same_person_candidates, REL_SAME_PERSON
    sig = {}
    for i in range(500):                      # 배경: 서로 다른 신호
        sig[f"u{i}"] = {"avatar": {f"av{i}"}, "display": {f"name{i}"}}
    sig["alice"] = {"avatar": {"RARE_AV"}, "display": {"Rare Name"}, "linked_email": {"a@x.com"}}
    sig["alice2"] = {"avatar": {"RARE_AV"}, "display": {"Rare Name"}, "linked_email": {"a@x.com"}}
    cands = same_person_candidates(sig, threshold=1e-3)
    pair = [c for c in cands if set((c["a"], c["b"])) == {"alice", "alice2"}]
    check(pair and pair[0]["coincidence"] < 1e-3, f"희소 공개신호 공유 → 동일인 후보 {pair}")
    check(pair[0]["relation"] == REL_SAME_PERSON and pair[0]["candidate"] is True, "후보 라벨(확정 아님)")
    check(not any(set((c["a"], c["b"])) == {"u0", "u1"} for c in cands), "무관 쌍은 후보 아님")
    # 정확도+성능: generic(흔한) 신호가 전원을 연결하지 않는다(max_bucket 억제) + 폭발 안 함
    gsig = {f"p{i}": {"platform": {"COMMON"}} for i in range(400)}   # 400명이 같은 플랫폼 기본신호
    gsig["p0"]["rare"] = {"R"}; gsig["p1"]["rare"] = {"R"}           # p0,p1 만 희소 공유
    t0 = _t.perf_counter()
    gc = same_person_candidates(gsig, threshold=2e-2, max_bucket=64)
    dt = _t.perf_counter() - t0
    check(dt < 1.0, f"generic 억제로 400명 흔한신호가 O(n²) 폭발 안 함 {dt:.3f}s")
    check(all(set((c["a"], c["b"])) != {"p0", "p2"} for c in gc), "흔한 platform 만 공유는 후보 아님(억제)")
    check(any(set((c["a"], c["b"])) == {"p0", "p1"} for c in gc), "희소 rare 공유 p0-p1 은 후보")
    print(f"  동일인 상관(강화): OperatorIndex 재사용 — 후보 {pair[0]['coincidence']:.1e}, generic 억제 {dt:.3f}s")


def t_person_recon_integration():
    """통합: PersonRecon 이 breach + username presence + email enrich 를 인가·감사 안에서 그래프로."""
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_CONSENT
    from artes.core.person_osint import (BreachPresenceSource, UsernamePresenceSource, PersonRecon,
                                         REL_PROFILE_ON, REL_GRAVATAR)
    scope = AuthorizationScope(AuditLog()).authorize(Authorization(
        case_id="I", operator="o", basis=BASIS_CONSENT, selectors={"hong_dev", "hong@corp.com"}))
    usrc = UsernamePresenceSource(probe=lambda url: "github" in url)
    br = BreachPresenceSource({})
    pr = PersonRecon(scope, br, username_source=usrc, email_enrich=True,
                     mx_resolver=lambda d: True)
    g = pr.run(["hong_dev", "hong@corp.com"])
    rels = {e.relation for e in g.edges}
    check(REL_PROFILE_ON in rels, "아이디 공개 프로필 간선")
    check(REL_GRAVATAR in rels, "이메일 gravatar 간선")
    rep = pr.report()
    check(rep["enrichments"] and rep["enrichments"][0]["mx_present"] is True, "이메일 enrichment 보고")
    print(f"  PersonRecon 통합: breach+username+email enrich 를 인가·감사 안에서 그래프화")


def t_person_batch2_tools():
    """추가 배치2: 전화 메타·role 분류·PGP 공개키·CT 이메일 SAN·git 커밋·gravatar 프로필(전부 공개/비민감)."""
    from artes.core import person_osint as po
    # 전화 메타(결정적, 네트워크 없음)
    pi = po.phone_intel("+82 10-1234-5678")
    check(pi["valid_format"] and pi["country"] == "KR" and pi["national_number"] == "1012345678", "전화 KR 파싱")
    check(po.phone_intel("123")["valid_format"] is False, "짧은 번호 무효")
    check("소유자 조회 안 함" in pi["note"], "통신사/소유자 조회 안 함(정직)")
    # role 계정 분류
    check(po.classify_identifier_role("info@corp.com")["is_role_account"], "info@ = role")
    check(not po.classify_identifier_role("hong@corp.com")["is_role_account"], "개인 이메일은 role 아님")
    check(po.classify_identifier_role("noreply")["is_role_account"], "noreply = role")
    # PGP 공개키서버(개인키 없음, 같은 키 UID = 동일주체)
    ks = po.KeyserverSource(lambda e: [{"fingerprint": "FP1", "uids": ["a@x.com", "a.alt@x.com"], "created": "2020"}])
    kr = ks.lookup("a@x.com")
    check(kr["present"] and kr["keys"][0]["fingerprint"] == "FP1", "공개키 지문")
    check(kr["same_subject_emails"] == ["a.alt@x.com"], "같은 키의 다른 UID = 동일주체 별칭")
    check("개인키 없음" in kr["note"], "개인키 없음 명시")
    # CT 이메일 SAN(공개 인증서 메타)
    ct = po.CTEmailSANSource(lambda e: [{"issuer": "CA", "not_before": "2021", "not_after": "2022",
                                         "serial": "01", "private_key": "LEAK"}]).lookup("a@x.com")
    check(ct["present"] and ct["certificates"][0]["issuer"] == "CA", "CT 인증서 메타")
    check("private_key" not in ct["certificates"][0], "개인키 필드 안 나옴(allowlist)")
    # git 커밋 이메일(아이디↔이메일 공개 연결)
    gc = po.GitCommitIdentitySource(lambda u: ["hong@dev.com", "hong@dev.com", "x@y.com"]).lookup("hong")
    check(set(gc["commit_emails"]) == {"hong@dev.com", "x@y.com"}, "커밋 author 이메일 dedup")
    # gravatar 공개 프로필 확장(연결 계정)
    gp = po.gravatar_profile("hong@x.com", fetch_fn=lambda url: {"entry": [{"displayName": "Hong",
                             "accounts": [{"domain": "github.com", "username": "hong", "url": "https://github.com/hong"}]}]})
    check(gp["display_name"] == "Hong" and gp["linked_accounts"][0]["domain"] == "github.com", "gravatar 연결 계정")
    print("  배치2 도구: 전화메타·role분류·PGP공개키·CT SAN·git커밋·gravatar프로필(전부 공개/비민감/개인키 없음)")


def t_person_recon_batch2_integration():
    """통합: PersonRecon 이 phone/role/keyserver 를 인가·감사 안에서 그래프·attrs 로."""
    from artes.core.authz import AuthorizationScope, Authorization, AuditLog, BASIS_CONSENT
    from artes.core.person_osint import KeyserverSource, PersonRecon, REL_PUBLICKEY, REL_KEY_UID
    scope = AuthorizationScope(AuditLog()).authorize(Authorization(
        case_id="I2", operator="o", basis=BASIS_CONSENT,
        selectors={"a@x.com", "a.alt@x.com", "info@corp.com", "+82 10-1234-5678"}))
    ks = KeyserverSource(lambda e: [{"fingerprint": "FP", "uids": ["a@x.com", "a.alt@x.com"]}]
                         if e == "a@x.com" else [])
    pr = PersonRecon(scope, keyserver_source=ks)
    g = pr.run(["a@x.com", "info@corp.com", "+82 10-1234-5678"])
    ents = {e.value: e for e in g.entities}
    check(ents["info@corp.com"].attrs.get("role_account") is True, "role 계정 attrs")
    phone_e = [e for e in g.entities if e.attrs.get("phone_country")]
    check(phone_e and phone_e[0].attrs["phone_country"] == "KR", "전화 국가 attrs")
    rels = {e.relation for e in g.edges}
    check(REL_PUBLICKEY in rels and REL_KEY_UID in rels, "공개키 + 동일키UID 간선")
    print("  PersonRecon 배치2 통합: role/phone attrs + PGP 공개키/동일주체 UID 그래프(인가·감사)")


def t_person_perf_accuracy():
    """성능·정확도 강화: 동시 username probe(성능) + 전화 plausible(정확도) + 배경 모집단 상관(정확도)."""
    from artes.core import person_osint as po
    # (1) 동시 username probe — 15+ 사이트를 병렬로. 느린 probe 로 순차 대비 이득 확인.
    async def slow_aprobe(url):
        await asyncio.sleep(0.02)
        return "github" in url or "reddit" in url
    src = po.UsernamePresenceSource()
    async def go():
        import time as _t
        t0 = _t.perf_counter()
        r = await src.lookup_async("hong_dev", slow_aprobe, concurrency=16)
        return r, _t.perf_counter() - t0
    r, dt = asyncio.run(go())
    sites = {h["site"] for h in r["present_on"]}
    check(sites == {"github", "reddit"}, f"동시 probe 결과 정확 {sites}")
    # 15개 사이트 × 0.02s 순차면 0.3s, 동시(16)면 ~0.02s. 0.20s 미만이면 병렬 이득 확인
    # (0.15 는 캡처 부하에서 간헐 실패 — 순차 0.30 과 분리되며 지터에 강건한 0.20 으로 완화).
    check(dt < 0.20, f"동시 probe 로 순차 대비 빠름 {dt:.3f}s (순차 0.30)")
    # (2) 전화 plausible — 국가별 국번 자릿수까지 검증
    ok = po.phone_intel("+82 10-1234-5678")      # KR 국번 10자리 → plausible
    check(ok["plausible"] is True and ok["expected_national_len"] == [9, 10], "KR 10자리 그럴듯")
    bad = po.phone_intel("+82 12345")            # KR 국번 5자리 → 형식은 몰라도 plausible False
    check(bad["plausible"] is False, f"KR 5자리 국번 → 그럴듯하지 않음 {bad['national_len']}")
    us = po.phone_intel("+1 415 555 2671")       # US 10자리
    check(us["country"] == "US/CA" and us["plausible"] is True, "US 10자리 그럴듯")
    # (3) 배경 모집단으로 상관 정확도 — 배경에서 흔한 값 공유는 약한 근거
    from artes.core.background import BackgroundCorpus
    bg = BackgroundCorpus({("avatar", "COMMON"): 900, ("avatar", "RARE"): 2}, n=1000)
    sig = {"a": {"avatar": {"COMMON"}}, "b": {"avatar": {"COMMON"}},
           "c": {"avatar": {"RARE"}}, "d": {"avatar": {"RARE"}}}
    cands = po.same_person_candidates(sig, threshold=0.5, background=bg)
    pc = {frozenset((c["a"], c["b"])): c["coincidence"] for c in cands}
    common_p = pc.get(frozenset(("a", "b")), 1.0)
    rare_p = pc.get(frozenset(("c", "d")), 1.0)
    check(rare_p < common_p, f"배경 희소(RARE) 공유가 흔한(COMMON) 공유보다 강한 근거 {rare_p:.3f}<{common_p:.3f}")
    print(f"  성능·정확도: 동시 probe {dt:.3f}s + 전화 plausible(국가별 자릿수) + 배경 모집단 상관")


def t_person_deconfound_fdr():
    """동일인 상관 강화: 플랫폼 confounding deconfound + 후보쌍 FDR 통제(오탐률 관리)."""
    from artes.core import person_osint as po
    from artes.core.background import BackgroundCorpus
    # 40명이 같은 플랫폼('github')을 공유(교란자). 진짜 동일인 쌍만 희소 신호(RAREHASH+aliceX) 공유.
    sig = {}
    for i in range(40):
        sig[f"u{i}@a"] = {"plat": {"github"}, "handle": {f"h{i}"}}
    sig["alice@a"] = {"plat": {"github"}, "handle": {"aliceX"}, "grav": {"RAREHASH"}}
    sig["alice@b"] = {"plat": {"github"}, "handle": {"aliceX"}, "grav": {"RAREHASH"}}
    bg = BackgroundCorpus.from_signal_map(
        {**sig, **{f"pad{i}": {"plat": {"github"}} for i in range(5000)}})
    # (1) deconfound='plat' — 플랫폼 층 조건부. 진짜 쌍은 남고 fallback_ratio 보고.
    dc = po.same_person_candidates(sig, threshold=0.5, deconfound="plat", min_stratum=3)
    dc_pairs = {frozenset((c["a"], c["b"])) for c in dc}
    check(frozenset(("alice@a", "alice@b")) in dc_pairs, "deconfound: 진짜 동일인 쌍 유지")
    check(all(c.get("deconfounded") is True for c in dc), "deconfound: 메타 표기")
    check(all("fallback_ratio" in c for c in dc), "deconfound: fallback_ratio 1급 지표")
    # 플랫폼만 공유하는 40명은 동일인 쌍이 아니어야(교란 제거)
    check(all(not (c["a"].startswith("u") and c["b"].startswith("u")) for c in dc),
          "deconfound: 플랫폼 공유만으로 오병합 안 함")
    # (2) fdr='by' — 다중 후보쌍 오탐률 통제, q_value 부여
    fdr = po.same_person_candidates(sig, threshold=0.5, background=bg, fdr="by")
    check(all("q_value" in c for c in fdr), "FDR: 모든 후보쌍에 q_value")
    check(all(c["q_value"] >= c["coincidence"] - 1e-12 for c in fdr),
          "FDR(BY): q_value >= raw p (보수적 조정)")
    check(frozenset(("alice@a", "alice@b")) in {frozenset((c["a"], c["b"])) for c in fdr},
          "FDR: 강한 진짜 쌍은 통과")
    print(f"  deconfound({len(dc)}쌍, fallback_ratio 보고) + FDR-BY q_value 통제")


def t_person_identity_resolution():
    """인프라+사람 통합 신원 해소: 공개출처 링크+상관을 한 그래프로, connected-component=신원 클러스터.
    identity-bearing 관계만 union(사이트/breach/아바타 비신원 엣지는 오병합 방지로 제외)."""
    from artes.core import person_osint as po
    edges = [
        ("alice@a", "aliceX", po.REL_SAME_RECORD),      # 같은 유출레코드(당사자 확인용)
        ("alice@a", "alice@work", po.REL_KEY_UID),       # 같은 PGP 키, 다른 UID
        ("bob@z", "bobby", po.REL_SAME_RECORD),
        ("aliceX", "github.com", po.REL_PROFILE_ON),     # 비신원(사이트) — 무시돼야
        ("alice@a", "breach:LinkedIn", po.REL_EXPOSED_IN),  # 비신원(breach) — 무시돼야
        ("alice@a", "avatarhash", po.REL_GRAVATAR),      # 비신원(아바타) — 무시돼야
    ]
    corr = [{"a": "alice@work", "b": "aliceX", "coincidence": 1e-6, "relation": po.REL_SAME_PERSON}]
    res = po.resolve_identities(edges, correlation_pairs=corr, min_coincidence=1e-3)
    alice = next((c for c in res if "alice@a" in c["members"]), None)
    check(alice is not None and set(alice["members"]) == {"alice@a", "alice@work", "aliceX"},
          "신원: alice 이메일+업무이메일+아이디 통합")
    check(alice["deterministic"] is True and "확인" in alice["confidence"],
          "신원: near-bijective 공개사실 브리지 → 확인")
    # 비신원 노드가 신원 클러스터에 새면 안 됨(사이트 사용자 전원이 한 사람 되는 붕괴 방지)
    all_members = {m for c in res for m in c["members"]}
    check("github.com" not in all_members, "신원: 사이트 노드 유입 없음(오병합 방지)")
    check("breach:LinkedIn" not in all_members, "신원: breach 노드 유입 없음")
    check("avatarhash" not in all_members, "신원: 아바타 노드 유입 없음")
    # 통계 상관만인 쌍은 '후보'로 정직 표기
    only = po.resolve_identities([], correlation_pairs=[
        {"a": "x@a", "b": "y@b", "coincidence": 1e-5, "relation": po.REL_SAME_PERSON}], min_coincidence=1e-3)
    check(len(only) == 1 and only[0]["deterministic"] is False and "후보" in only[0]["confidence"],
          "신원: 통계 상관만 → 후보 표기(정직)")
    # 약한 상관(> min_coincidence)은 브리지에서 배제
    weak = po.resolve_identities([], correlation_pairs=[
        {"a": "x@a", "b": "y@b", "coincidence": 0.2, "relation": po.REL_SAME_PERSON}], min_coincidence=1e-3)
    check(weak == [], "신원: 약한 상관은 병합 안 함")
    # min_bridge_types=2 — 단일 브리지 종류로는 병합 거부, 2종류면 병합
    check(po.resolve_identities([("p@a", "q@b", po.REL_SAME_RECORD)], min_bridge_types=2) == [],
          "신원: min_bridge_types 게이트(단일종류 차단)")
    two = po.resolve_identities([("p@a", "q@b", po.REL_SAME_RECORD),
                                 ("p@a", "q@b", po.REL_KEY_UID)], min_bridge_types=2)
    check(len(two) == 1 and set(two[0]["members"]) == {"p@a", "q@b"},
          "신원: 2종류 브리지면 병합")
    print(f"  신원 클러스터 {len(res)}개(확정/후보 구분) + 비신원 엣지 제외 + min_bridge_types 게이트")


def main():
    print("[축1 배경모집단]"); t_background_corpus()
    print("[축2 증거패밀리]"); t_evidence_families()
    print("[축3 우도비]"); t_likelihood_ratio()
    print("[축4 FDR]"); t_fdr()
    print("[축5 run manifest]"); t_run_manifest()
    print("[축6 신호레지스트리]"); t_signal_registry_version()
    print("[축7 SafeOutbound]"); t_safeoutbound(); t_safeoutbound_authz()
    print("[축8 body cap]"); t_body_cap()
    print("[축9 감사 내구성]"); t_audit_durability()
    print("[축10 temporal 관측창]"); t_temporal_observation_window()
    print("[축11 deconfound 민감도]"); t_deconfound_sensitivity()
    print("[축12 Mondrian/CRC]"); t_conformal_mondrian_crc()
    print("[축13 객체모델]"); t_attribution_objects()
    print("[축14 order-statistic]"); t_order_statistic_correction()
    print("[축15 robust 오염모델]"); t_robust_contamination_model()
    print("[2·3차 배선]"); t_pass3_wiring()
    print("[4차 계약: batch==incremental]"); t_contract_batch_eq_incremental()
    print("[4차 계약: snapshot 반대칭]"); t_contract_snapshot_antisymmetry()
    print("[4차 계약: NDJSON roundtrip]"); t_contract_ndjson_roundtrip()
    print("[4차 계약: merge 멱등]"); t_contract_merge_idempotent()
    print("[5차 배경 배선]"); t_pass5_background_wiring()
    print("[사람 거버넌스]"); t_person_governance()
    print("[P6 도메인 분리]"); t_review_p6_domain_suffix_split()
    print("[P7 redact 견고성]"); t_review_p7_redact_robust()
    print("[P7 breach allowlist]"); t_review_p7_breach_allowlist()
    print("[P8 제3자 spill 방지]"); t_review_p8_third_party_spill()
    print("[사람 유출노출]"); t_person_breach_exposure()
    print("[아이디 존재조회]"); t_person_username_presence()
    print("[이메일 enrichment]"); t_person_email_enrichment()
    print("[동일인 후보 상관]"); t_person_identity_correlation()
    print("[PersonRecon 통합]"); t_person_recon_integration()
    print("[배치2 도구]"); t_person_batch2_tools()
    print("[배치2 통합]"); t_person_recon_batch2_integration()
    print("[성능·정확도 강화]"); t_person_perf_accuracy()
    print("[사람 deconfound+FDR]"); t_person_deconfound_fdr()
    print("[인프라+사람 신원해소]"); t_person_identity_resolution()
    print("[P1 max_total 병렬]"); t_review8_max_total_concurrency()
    print("[P2 스크리닝 투명성]"); t_review8_max_confirmable()
    print("[P3 폴백 1급지표]"); t_review8_deconfound_fallback_ratio()
    print("[P4 temporal 끝점null]"); t_review8_temporal_endpoint_null()
    print("[P5 감사 canonical]"); t_review8_audit_canonical_bytes()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
