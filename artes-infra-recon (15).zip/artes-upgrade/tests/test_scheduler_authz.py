"""scheduler.py + authz.py 검증. pytest 없이도 `python3 tests/test_scheduler_authz.py` 로 실행.

'만든 건 실제로 돌려 검증' — 통과 확인 전엔 된다고 안 한다.
"""
from __future__ import annotations

import asyncio
import os
import random
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core.scheduler import (
    AdaptiveConcurrency, GlobalScheduler, HostRateLimiter, Job, Result,
)
from artes.core.authz import (
    AuthorizationScope, Authorization, AuditLog, AuthorizationError,
    normalize_selector, BASIS_CONSENT, BASIS_INFRA_TI, BASIS_SELF_AUDIT,
)

PASS = 0
FAIL = 0

def check(cond: bool, msg: str) -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")


# ---------------------------------------------------------------- governor --- #
async def t_governor_bounds_and_monotonic() -> None:
    g = AdaptiveConcurrency(start=16, min_limit=1, max_limit=64, beta=0.7)
    rng = random.Random(1234)
    outstanding = 0
    for _ in range(4000):
        if outstanding == 0 or (g.in_flight < g.limit and rng.random() < 0.5):
            await g.acquire()
            outstanding += 1
            check(g._min <= g.limit <= g._max, "acquire 후 경계 위반")
        else:
            before = g.limit
            drop = rng.random() < 0.3
            await g.complete(dropped=drop)
            outstanding -= 1
            after = g.limit
            check(g._min <= after <= g._max, "complete 후 경계 위반")
            if drop:
                check(after <= before, f"드롭이 limit 을 올림 {before}->{after}")
            else:
                check(after >= before, f"성공이 limit 을 내림 {before}->{after}")
    # 정리
    while outstanding:
        await g.complete(dropped=False)
        outstanding -= 1
    print(f"  governor invariants: drops={g.total_drops} acquired={g.total_acquired}")


async def t_governor_climbs_under_saturation() -> None:
    g = AdaptiveConcurrency(start=2, min_limit=1, max_limit=64)
    for _ in range(600):
        cap = g.limit
        for _ in range(cap):
            await g.acquire()          # cap 개까지는 블록 없이 승인됨
        for _ in range(cap):
            await g.complete(dropped=False)  # 첫 완료는 포화상태 → 가법증가
    check(g.limit > 2, f"포화 성공에도 상한 탐색 안 함 (limit={g.limit})")
    check(g.limit <= 64, f"max 초과 (limit={g.limit})")
    print(f"  climb: start=2 -> limit={g.limit} (<=64)")


async def t_governor_backs_off_on_drops() -> None:
    g = AdaptiveConcurrency(start=50, min_limit=1, max_limit=64, beta=0.5)
    seq = []
    for _ in range(12):
        before = g.limit
        await g.acquire()
        await g.complete(dropped=True)
        seq.append(g.limit)
        check(g.limit <= before, "드롭인데 안 줄어듦")
    check(g.limit < 50, f"드롭 반복인데 limit 그대로 ({g.limit})")
    check(g.limit >= 1, "min 아래로 내려감")
    print(f"  backoff: 50 -> {seq}")


# --------------------------------------------------------------- scheduler --- #
async def t_scheduler_isolation_and_completeness() -> None:
    N = 120
    def mk(i):
        async def job():
            await asyncio.sleep(0.001)
            if i % 5 == 0:
                raise ValueError(f"boom-{i}")
            return i * 2
        return job
    jobs = [Job(make=mk(i), key=i) for i in range(N)]
    sch = GlobalScheduler(AdaptiveConcurrency(start=8, max_limit=32))
    results = await sch.map(jobs)
    check(len(results) == N, f"결과 수 {len(results)} != {N} (실패격리 실패?)")
    failed = [r for r in results if not r.ok]
    oks = [r for r in results if r.ok]
    check(len(failed) == len(range(0, N, 5)), f"실패 수 {len(failed)}")
    check(all(r.value == r.key * 2 for r in oks), "정상 결과값 불일치")
    check(all("boom" in r.error for r in failed), "실패 error 메시지 누락")
    print(f"  isolation: {len(oks)} ok / {len(failed)} isolated failures, all {N} returned")


async def t_scheduler_caps_concurrency() -> None:
    gov = AdaptiveConcurrency(start=4, min_limit=1, max_limit=10)
    def mk(i):
        async def job():
            await asyncio.sleep(0.01)
            return i
        return job
    jobs = [Job(make=mk(i), key=i) for i in range(300)]
    sch = GlobalScheduler(gov)
    await sch.map(jobs)
    check(gov.max_in_flight <= 10, f"동시성 상한 위반 max_in_flight={gov.max_in_flight}")
    print(f"  cap: max_in_flight={gov.max_in_flight} <= 10")


async def t_scheduler_streaming_order() -> None:
    # 완료 순서대로 흘러야 함: 짧게 자는 잡이 먼저 나온다.
    sleeps = [0.20, 0.02, 0.12, 0.005, 0.08]
    def mk(s, i):
        async def job():
            await asyncio.sleep(s)
            return i
        return job
    sch = GlobalScheduler(AdaptiveConcurrency(start=16, max_limit=16))
    for i, s in enumerate(sleeps):
        sch.submit(Job(make=mk(s, i), key=i))
    sch.close()
    order = []
    async for r in sch.run_stream():
        order.append(r.key)
    # 기대: sleep 오름차순 = 인덱스 [3,1,4,2,0]
    expected = [i for i, _ in sorted(enumerate(sleeps), key=lambda kv: kv[1])]
    check(order == expected, f"스트리밍 완료순 불일치 got={order} exp={expected}")
    print(f"  streaming completion order = {order}")


async def t_scheduler_dynamic_submit() -> None:
    sch = GlobalScheduler(AdaptiveConcurrency(start=8, max_limit=16))
    def mk(i):
        async def job():
            await asyncio.sleep(0.005)
            return i
        return job
    for i in range(5):
        sch.submit(Job(make=mk(i), key=i))

    async def producer():
        await asyncio.sleep(0.02)
        for i in range(5, 10):
            sch.submit(Job(make=mk(i), key=i))
        sch.close()

    prod = asyncio.create_task(producer())
    got = []
    async for r in sch.run_stream():
        got.append(r.key)
    await prod
    check(sorted(got) == list(range(10)), f"동적 제출 누락 got={sorted(got)}")
    print(f"  dynamic submit: {len(got)} jobs (5 seed + 5 late)")


async def t_scheduler_host_ratelimit() -> None:
    lim = HostRateLimiter(min_interval=0.08)
    def mk(i):
        async def job():
            return i
        return job
    jobs = [Job(make=mk(i), key=i, host="api.example") for i in range(3)]
    sch = GlobalScheduler(AdaptiveConcurrency(start=8, max_limit=8), limiter=lim)
    t0 = time.perf_counter()
    await sch.map(jobs)
    dt = time.perf_counter() - t0
    check(dt >= 0.15, f"per-host 최소간격 미준수 dt={dt:.3f} (>=0.15 기대)")
    print(f"  host ratelimit: 3 req @0.08s => {dt:.3f}s")


# -------------------------------------------------------------------- authz - #
def t_authz_scope_basic() -> None:
    audit = AuditLog()
    scope = AuthorizationScope(audit).authorize(Authorization(
        case_id="C-1", operator="jiwan", basis=BASIS_CONSENT,
        selectors={"hong@gmail.com", "Hong123", "+82 10-1234-5678"}))
    # 인가된 표적 통과
    scope.check("hong@gmail.com", "email", "maigret")
    scope.check("hong123", "username", "sherlock")        # 대소문자 무시
    scope.check("+821012345678", "phone", "phoneinfoga")  # 전화 정규화
    # 미인가 제3자 차단
    raised = False
    try:
        scope.check("victim@x.com", "email", "holehe")
    except AuthorizationError:
        raised = True
    check(raised, "미인가 표적이 차단되지 않음")
    c = audit.counts()
    check(c.get("query", 0) == 3, f"query 감사 수 {c}")
    check(c.get("blocked", 0) == 1, f"blocked 감사 수 {c}")
    check(c.get("authorize", 0) == 1, f"authorize 감사 수 {c}")
    print(f"  scope basic: audit counts = {c}")


def t_authz_expiry() -> None:
    scope = AuthorizationScope().authorize(Authorization(
        case_id="C-2", operator="op", basis=BASIS_SELF_AUDIT,
        selectors={"me@self.io"}, expires_at=time.time() - 1))  # 이미 만료
    check(not scope.is_authorized("me@self.io", "email"), "만료됐는데 인가됨")
    raised = False
    try:
        scope.check("me@self.io", "email")
    except AuthorizationError as e:
        raised = "만료" in str(e)
    check(raised, "만료 사유로 차단되지 않음")
    print("  expiry: 만료된 인가 차단 OK")


def t_authz_infra_only_and_suffix() -> None:
    scope = AuthorizationScope().authorize(Authorization(
        case_id="C-3", operator="op", basis=BASIS_INFRA_TI,   # infra_only 강제됨
        selectors={"example.com"}, domain_suffixes={"example.com"}))
    check(scope.is_authorized("example.com", "domain"), "인가 도메인 거부")
    check(scope.is_authorized("mail.example.com", "domain"), "하위도메인 접미사 매칭 실패")
    check(scope.is_authorized("1.2.3.4", "ip") is False, "IP는 selectors에 없음(정상 거부)")
    # 사람형 selector 는 infra_only 에서 거부
    check(not scope.is_authorized("someone@example.com", "email"),
          "infra_only인데 사람형(email) 허용됨")
    print("  infra_only + suffix: 하위도메인 허용 / 사람형 거부 OK")


def t_authz_audit_jsonl_roundtrip() -> None:
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "audit.jsonl")
        audit = AuditLog(path)
        scope = AuthorizationScope(audit).authorize(Authorization(
            case_id="C-4", operator="op", basis=BASIS_CONSENT, selectors={"a@b.com"}))
        scope.check("a@b.com", "email", "maigret")
        try:
            scope.check("z@b.com", "email", "holehe")
        except AuthorizationError:
            pass
        # 파일에서 다시 읽기(append-only 무결성)
        entries = audit.entries()
        check(len(entries) == 3, f"JSONL 라운드트립 엔트리 수 {len(entries)}")
        check(entries[0]["action"] == "authorize", "첫 엔트리 authorize 아님")
        check(entries[-1]["action"] == "blocked", "마지막 엔트리 blocked 아님")
        check(os.path.exists(path), "감사 파일 미생성")
    print("  audit JSONL: 파일 append-only 라운드트립 OK")


def t_authz_filter_frontier() -> None:
    scope = AuthorizationScope().authorize(Authorization(
        case_id="C-5", operator="op", basis=BASIS_CONSENT,
        selectors={"target@x.com", "targetuser"}))
    # 확장으로 튀어나온 후보들(제3자 섞임)
    candidates = [("target@x.com", "email"), ("targetuser", "username"),
                  ("stranger@y.com", "email"), ("+8299", "phone")]
    kept = scope.filter_authorized(candidates)
    check(len(kept) == 2, f"frontier 필터 결과 {kept}")
    check(("stranger@y.com", "email") not in kept, "제3자가 확장에 남음")
    print(f"  frontier filter: {len(candidates)}개 중 인가 {len(kept)}개만 확장")


def t_audit_hash_chain() -> None:
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "chain.jsonl")
        a = AuditLog(path)
        for i in range(5):
            a.record("query", selector=f"s{i}", collector="c", ok=True)
        ok, idx, why = a.verify_chain()
        check(ok, f"정상 체인이 무결 아님: {why}@{idx}")
        # 이어쓰기: 같은 경로로 새 인스턴스 → seq/hash 이어받아 체인 유지
        b = AuditLog(path)
        b.record("blocked", selector="s5", collector="c", ok=False)
        ok2, idx2, why2 = b.verify_chain()
        check(ok2 and len(b.entries()) == 6, f"이어쓰기 체인 깨짐: {why2}@{idx2}")
        # 내용 변조 검출
        es = a.entries()
        es[2]["selector"] = "TAMPERED"
        okt, idxt, whyt = a.verify_chain(es)
        check((not okt) and idxt == 2 and "변조" in whyt, f"변조 미검출 {okt},{idxt},{whyt}")
        # 중간 삭제 검출
        es2 = a.entries(); del es2[2]
        okd, idxd, _ = a.verify_chain(es2)
        check(not okd and idxd == 2, f"삭제 미검출 {okd},{idxd}")
        # 재배열 검출
        es3 = a.entries(); es3[1], es3[2] = es3[2], es3[1]
        okr, idxr, _ = a.verify_chain(es3)
        check(not okr, "재배열 미검출")
    print("  audit hash-chain: 무결/이어쓰기 OK, 변조·삭제·재배열 검출 OK")


def t_normalize() -> None:
    check(normalize_selector("  Hong@Gmail.com ") == "hong@gmail.com", "이메일 정규화")
    check(normalize_selector("+82 10-1234-5678") == "+821012345678", "전화 정규화")
    check(normalize_selector("010-1234-5678") == "01012345678", "국내전화 정규화")
    print("  normalize: email/phone OK")


# --------------------------------------------------------------------- main - #
async def _async_suite() -> None:
    print("[governor]")
    await t_governor_bounds_and_monotonic()
    await t_governor_climbs_under_saturation()
    await t_governor_backs_off_on_drops()
    print("[scheduler]")
    await t_scheduler_isolation_and_completeness()
    await t_scheduler_caps_concurrency()
    await t_scheduler_streaming_order()
    await t_scheduler_dynamic_submit()
    await t_scheduler_host_ratelimit()


def main() -> int:
    asyncio.run(_async_suite())
    print("[authz]")
    t_authz_scope_basic()
    t_authz_expiry()
    t_authz_infra_only_and_suffix()
    t_authz_audit_jsonl_roundtrip()
    t_authz_filter_frontier()
    t_audit_hash_chain()
    t_normalize()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
