"""temporal / providers / sources_ext 검증. `python3 tests/test_sources.py` (pytest 불필요).

정리 기반·결정적. 네트워크·API키 없음(전부 주입/오프라인). 사람 축 없음(인프라/자산만).
"""
from __future__ import annotations

import asyncio
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from artes.core import temporal as T
from artes.core import providers as P
from artes.core import sources_ext as X
from artes.core.model import Graph, Entity, Edge, Evidence, EntityType, Certainty
from artes.core.model import _normalize
from artes.core.infra_recon import InfraTarget, InfraType, HTTPResp

PASS = FAIL = 0
def check(cond, msg):
    global PASS, FAIL
    if cond: PASS += 1
    else:
        FAIL += 1
        print(f"  ✗ FAIL: {msg}")

def _k(t, v):
    return f"{t.value}:{_normalize(t, v)}"

DAY = 86400.0


# ------------------------------------------------------------- temporal --- #
def t_temporal():
    import random
    # 이항 꼬리(사전지정 창용): P(X>=1) = 1-(1-p)^n 정확 일치
    for n, p in [(10, 0.1), (50, 0.02), (3, 0.5)]:
        check(abs(T.binomial_tail_ge(1, n, p) - (1 - (1 - p) ** n)) < 1e-12,
              f"tail_ge(1,{n},{p}) = 1-(1-p)^n")
    check(T.binomial_tail_ge(0, 10, 0.1) == 1.0, "k<=0 → 1")
    check(T.binomial_tail_ge(11, 10, 0.1) == 0.0, "k>n → 0")

    # 스캔통계량: 폭 W 창의 최대 개수(정확)
    check(T.max_window_count([0, 0.5, 0.9, 2.0], 1.0) == 3, "max_window_count 3")
    check(T.max_window_count([0, 1, 2, 3], 0.5) == 1, "간격>창 → 1")

    # ── 핵심: uniform-null 유의수준 통제 (예전 검출기는 여기서 α=0.05에 FPR≈35%였음) ──
    def fpr(n_events, window, alpha, trials=200, n_mc=149):
        hits = 0
        for s in range(trials):
            rng = random.Random(9000 + s)
            ev = {f"e{i}": rng.uniform(0, 1.0) for i in range(n_events)}
            if T.campaign_report(ev, window=window, alpha=alpha, n_mc=n_mc, seed=s):
                hits += 1
        return hits / trials
    f20 = fpr(20, 0.05, 0.10)
    f50 = fpr(50, 0.05, 0.10)
    check(f20 <= 0.18, f"uniform-null FPR n=20 α=0.10 = {f20:.3f} ≤ ~α (예전 0.355)")
    check(f50 <= 0.18, f"uniform-null FPR n=50 α=0.10 = {f50:.3f} ≤ ~α")

    # power: 1시간 창 50개 스핀업 + 30일 균일 배경 → 검출(멤버 전원 포착)
    rng = random.Random(7)
    uni = {f"u{i}": rng.uniform(0, 30 * DAY) for i in range(200)}
    burst = {f"b{i}": 10 * DAY + rng.uniform(0, 3600) for i in range(50)}
    mix = dict(uni); mix.update(burst)
    rep = T.campaign_report(mix, window=3600, alpha=1e-3)          # 기본 n_mc=1999
    check(len(rep) == 1 and rep[0]["size"] >= 50, f"버스트 검출 size={rep[0]['size'] if rep else None}")
    check(all(f"b{i}" in set(rep[0]["members"]) for i in range(50)), "버스트 멤버 전원 포착")
    # 순수 균일 → 캠페인 없음
    check(T.campaign_report(uni, window=3600, alpha=1e-3) == [], "균일 → 캠페인 없음")
    # 결정적(seed 고정)
    check(T.scan_pvalue_mc(mix, 3600, n_mc=499, seed=0) == T.scan_pvalue_mc(mix, 3600, n_mc=499, seed=0),
          "MC 결정적(seed 고정)")
    # MC 유효성: p = (1+#ge)/(1+B) → 최소 p = 1/(1+B)
    r = T.scan_pvalue_mc(mix, 3600, n_mc=999, seed=0)
    check(r["pvalue"] >= 1 / 1000 - 1e-12, "MC p 하한 = 1/(1+B)")

    # 사전지정 고정창(스캔 아님) 정확 이항검정
    check(abs(T.window_pvalue(3, 10, 0.1, 1.0) - T.binomial_tail_ge(3, 10, 0.1)) < 1e-12,
          "window_pvalue = 정확 이항꼬리")

    # temporal_pairs/coburst: 묶기용(유의성 아님)
    small = {"a": 100.0, "b": 130.0, "c": 160.0, "z": 999999.0}
    pairs = T.temporal_pairs(small, window=60)
    check(("a", "b") in pairs and ("b", "c") in pairs and all("z" not in pr for pr in pairs),
          "버스트 내 쌍(묶기용)")
    print(f"  temporal: uniform-null FPR n20={f20:.3f}/n50={f50:.3f}≤α(예전 0.355), "
          f"burst 검출 p={rep[0]['pvalue']:.1e} 멤버{rep[0]['size']}, MC 결정적/유효")


# ------------------------------------------------------------ providers --- #
def t_providers():
    db = P.ProviderDB()
    db.add_prefix("10.0.0.0/8", "ProvA")
    db.add_prefix("10.1.0.0/16", "ProvB")          # 겹침(더 구체적)
    db.add_prefix("10.1.2.0/24", "ProvC")          # 더더욱 구체적
    check(db.match("10.5.5.5") == "ProvA", "최장프리픽스: /8")
    check(db.match("10.1.9.9") == "ProvB", "최장프리픽스: /16 우선")
    check(db.match("10.1.2.7") == "ProvC", "최장프리픽스: /24 우선(가장 구체적)")
    check(db.match("11.0.0.1") is None, "미등록 → None")
    check(db.match("ip:10.1.2.7") == "ProvC", "ip:<addr> 키도 허용")

    # v6
    db.add_prefix("2606:4700::/32", "Cloudflare")
    check(db.match("2606:4700:4700::1111") == "Cloudflare", "v6 최장프리픽스")

    # 공개 범위 파서
    aws = {"prefixes": [{"ip_prefix": "52.94.0.0/22", "service": "AMAZON"},
                        {"ip_prefix": "52.94.4.0/24", "service": "S3"}],
           "ipv6_prefixes": [{"ipv6_prefix": "2600:1f00::/24"}]}
    d2 = P.ProviderDB()
    check(d2.load_aws(aws) == 3, "load_aws 3건")
    check(d2.match("52.94.4.5") == "AWS/S3", "AWS 서브서비스 태그(더 구체적 /24)")
    check(d2.match("52.94.1.1") == "AWS", "AWS 상위 /22")
    gcp = {"prefixes": [{"ipv4Prefix": "34.1.0.0/16", "service": "Google Cloud"}]}
    check(d2.load_gcp(gcp) == 1 and d2.match("34.1.2.3") == "GCP", "load_gcp")
    az = {"values": [{"name": "Storage.WestUS",
                      "properties": {"addressPrefixes": ["20.60.0.0/16", "2603:1030::/44"]}}]}
    check(d2.load_azure(az) == 2 and d2.match("20.60.1.1") == "Azure/Storage.WestUS", "load_azure")
    cf = "# comment\n104.16.0.0/13\n172.64.0.0/13\n"
    check(d2.load_lines(cf, "Cloudflare") == 2 and d2.match("104.20.1.1") == "Cloudflare", "load_lines")

    # 씨앗 DB
    seed = P.seed_db()
    check(len(seed) > 20, f"seed_db 크기 {len(seed)}")
    check(seed.match("104.16.5.5") == "Cloudflare", "seed: Cloudflare 앵커")
    check(seed.match("151.101.1.1") == "Fastly", "seed: Fastly 앵커")
    print(f"  providers: 최장프리픽스(겹침 정확) v4/v6, AWS/GCP/Azure/lines 파서, seed {len(seed)}개 OK")


def t_annotate_providers():
    g = Graph()
    # 도메인 → Cloudflare IP
    ip = "104.16.7.7"
    g.add(Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    g.add(Entity(type=EntityType.DOMAIN, value="x.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    g.link(Edge(src=_k(EntityType.DOMAIN, "x.com"), dst=_k(EntityType.IP, ip),
                relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "A")]))
    n = P.annotate_providers(g, P.seed_db())
    check(n == 1, f"annotate 1 IP ({n})")
    ipent = next(e for e in g.entities if e.type == EntityType.IP)
    check(ipent.attrs.get("cloud_provider") == "Cloudflare", "IP attr cloud_provider=Cloudflare")
    print(f"  annotate_providers: IP 엔티티에 cloud_provider 심음 → signals ipattr 전파 준비 OK")


# ---------------------------------------------------- deconfound 통합 --- #
def t_provider_deconfound_integration():
    """핵심: providers → signals(cloud_provider 축) → deconfound 교란자.

    Cloudflare 층 도메인들이 CF 기본 신호(같은 NS)만 공유 → 층화 coincidence ≈ 1(오탐 제거).
    층 안에서만 드문 신호를 공유한 두 도메인 → 잔차 증거 남음(진짜 동일운영자 후보).
    """
    from artes.core import signals as sig
    from artes.core.deconfound import Deconfounder

    g = Graph()
    # 전원이 같은 CF IP 로 A(=제공자 공유 앵커) + 같은 CF NS 공유(제공자 기본신호)
    cf_ip = "104.16.7.7"
    g.add(Entity(type=EntityType.IP, value=cf_ip, certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    # 배경(비-CF) 도메인 다수 → N 크게. 각자 고유 NS 로 신호를 가져야 sigmap 에 남는다.
    for i in range(200):
        d = f"bg{i}.com"
        g.add(Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("doh", "A")]))
        g.add(Entity(type=EntityType.DOMAIN, value=f"ns-bg{i}.net",
                     certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, f"ns-bg{i}.net"),
                    relation="네임서버", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
    # CF 층 6개 도메인: 전원 동일 CF IP + 동일 CF NS(제공자 기본신호만 공유)
    cf_doms = [f"cf{i}.com" for i in range(6)]
    nsent = "ns:cruz.ns.cloudflare.com"
    g.add(Entity(type=EntityType.DOMAIN, value="cruz.ns.cloudflare.com",
                 certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
    for i, d in enumerate(cf_doms):
        g.add(Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("doh", "A")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.IP, cf_ip),
                    relation="해석됨(A)", certainty=Certainty.CONFIRMED,
                    evidence=[Evidence("doh", "A")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=nsent, relation="네임서버",
                    certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
    # cf0, cf1 만 층내 드문 공유 신호(같은 favicon) → 진짜 동일운영자 잔차
    for d in ("cf0.com", "cf1.com"):
        e = next(x for x in g.entities if x.type == EntityType.DOMAIN and x.value == d)
        e.attrs = dict(e.attrs or {}); e.attrs["favicon"] = "rareFAV123"

    P.annotate_providers(g, P.seed_db())
    sigmap = sig.gather_signals(g, sig.EXTENDED_SPECS)
    # cloud_provider 축이 CF 도메인에 실렸는지
    check(sigmap["domain:cf0.com"].get("cloud_provider") == {"Cloudflare"},
          "cf0 신호에 cloud_provider=Cloudflare 전파됨")

    dc = Deconfounder(sigmap, "cloud_provider")       # ASN 대신 정밀 교란자
    check(dc.N >= 206, f"N {dc.N}")
    check(len(dc.strata.get(("cloud_provider", "Cloudflare"), set())) == 6, "Cloudflare 층 6개")

    # cf2,cf3: NS 만 공유(CF 기본) → 전역은 강한 오탐, 층화하면 근거 0
    raw = dc.coincidence("domain:cf2.com", "domain:cf3.com", stratified=False)
    adj = dc.coincidence("domain:cf2.com", "domain:cf3.com", stratified=True)
    check(raw < adj, f"층화가 오탐 약화 raw {raw:.2e} < adj {adj:.3f}")
    check(abs(adj - 1.0) < 1e-9, f"제공자 기본만 공유 → 근거 0 (adj={adj})")

    # cf0,cf1: 층내 드문 favicon 공유 → 잔차 증거 남음(1 미만)
    adj01 = dc.coincidence("domain:cf0.com", "domain:cf1.com", stratified=True)
    check(adj01 < 1.0, f"층내 희소 신호 잔차 남음 adj01={adj01:.4f} < 1")
    print(f"  통합: providers→cloud_provider축→deconfound. CF기본 raw {raw:.1e}→adj 1.0(오탐제거), "
          f"층내 희소 잔차 {adj01:.3f}")


# ----------------------------------------------------------- certstream --- #
def t_certstream():
    msgs = []
    base = 1_700_000_000.0
    # 40개 도메인이 같은 60초 창에 발급(피싱킷 스핀업), + 배경 5개 흩뿌림
    for i in range(40):
        msgs.append({"message_type": "certificate_update",
                     "data": {"seen": base + i * 1.0,
                              "leaf_cert": {"all_domains": [f"kit{i}.evil.test", f"*.kit{i}.evil.test"],
                                            "fingerprint": f"AA:BB:{i:02d}",
                                            "issuer": {"O": "Let's Encrypt"}}}})
    for i in range(5):
        msgs.append({"message_type": "certificate_update",
                     "data": {"seen": base + 100000 + i * 20000,
                              "leaf_cert": {"all_domains": [f"bg{i}.evil.test"],
                                            "fingerprint": f"CC:{i}", "issuer": {"O": "DigiCert"}}}})
    msgs.append({"message_type": "heartbeat", "data": {}})     # 무시돼야
    ing = X.CertStreamIngest(domain_suffixes=["evil.test"])
    kept = ing.ingest(msgs)
    check(kept >= 40, f"ingest 관측 수 {kept}")
    fs = ing.first_seen()
    check("kit0.evil.test" in fs and "*.kit0.evil.test" not in fs, "와일드카드 정규화")
    # first_seen → temporal 캠페인 (MC 스캔검정; alpha 는 1/(1+n_mc) 보다 커야 검출 가능)
    rep = T.campaign_report(fs, window=60, alpha=1e-3)
    check(len(rep) >= 1 and rep[0]["size"] >= 40, f"CT 스트림 캠페인 검출 size={rep[0]['size']}")
    # 접미사 필터
    ing2 = X.CertStreamIngest(domain_suffixes=["other.test"])
    check(ing2.ingest(msgs) == 0, "접미사 불일치 → 0")
    gu = ing.graph_updates()
    e0 = next(e for e in gu if e.value == "kit0.evil.test")
    check(e0.attrs["first_seen"] == base and e0.attrs["cert_fps"] == ["aabb00"], "graph_updates attr")
    print(f"  certstream: 파싱/필터/와일드카드, first_seen→캠페인 size={rep[0]['size']}, graph_updates OK")


# ------------------------------------------------------------ peeringdb --- #
def t_peeringdb():
    doc = {"data": [{"asn": 13335, "name": "Cloudflare, Inc.", "aka": "CF", "org_id": 10},
                    {"asn": 15169, "name": "Google LLC", "aka": "", "org_id": 20}]}
    m = X.parse_peeringdb_net(doc)
    check(m[13335]["name"] == "Cloudflare, Inc." and m[15169]["name"] == "Google LLC", "parse net")

    async def fake_http(url):
        return HTTPResp(status=200, text='{"data":[{"asn":13335,"name":"Cloudflare, Inc.","aka":"CF"}]}',
                        url=url)
    src = X.PeeringDBSource()
    res = asyncio.run(src.fetch(InfraTarget(InfraType.ASN, "AS13335"), fake_http))
    check(res.ok and res.entities[0].attrs["net_org"] == "Cloudflare, Inc.", "PeeringDBSource fetch")
    print(f"  peeringdb: parse_net, ASN→조직명 어댑터 OK")


# ------------------------------------------------------------ tech-fp --- #
def t_tech():
    # WordPress: meta generator + wp-content → PHP/MySQL 전이
    html = ('<html><head><meta name="generator" content="WordPress 6.4"></head>'
            '<body><link href="/wp-content/themes/x/style.css">'
            '<script src="/wp-includes/js/jquery/jquery.min.js"></script></body></html>')
    tech = X.detect_tech({"server": "nginx"}, html)
    check("WordPress" in tech, "WordPress 탐지")
    check("PHP" in tech and "MySQL" in tech, "implies 전이확장(PHP/MySQL)")
    check("jQuery" in tech, "jQuery 스크립트 탐지")
    check("Nginx" in tech, "헤더 Nginx 탐지")

    # Next.js → React + Node.js 전이
    t2 = X.detect_tech({}, '<div id="__next"></div><script src="/_next/static/x.js"></script>')
    check({"Next.js", "React", "Node.js"} <= t2, f"Next.js 전이폐쇄 {sorted(t2)}")

    # Cloudflare 헤더
    t3 = X.detect_tech({"cf-ray": "abc", "server": "cloudflare"}, "")
    check("Cloudflare" in t3, "Cloudflare 헤더")

    # 빈 입력 → 공집합
    check(X.detect_tech({}, "") == set(), "무단서 → 공집합")

    async def fake_http(url):
        return HTTPResp(status=200, text=html, url=url, headers={"server": "nginx"})
    res = asyncio.run(X.TechFingerprint().fetch(InfraTarget(InfraType.DOMAIN, "wp.example"), fake_http))
    check(res.ok and "WordPress" in res.entities[0].attrs["tech_stack"], "TechFingerprint 어댑터")
    print(f"  tech-fp: 규칙매칭 + implies 전이폐쇄, 어댑터 OK ({sorted(tech)[:4]}…)")


# ------------------------------------------------------------ abuse.ch --- #
def t_abusech():
    sslbl = X.AbuseChSSLBL()
    csv = ("# SSLBL\n"
           "2023-01-01 00:00:00," + "a" * 40 + ",MalwareX C2\n"
           "2023-01-02 00:00:00," + "b" * 40 + ",Dridex C2\n"
           "bad,notasha1,x\n")
    n = sslbl.load_csv(csv)
    check(n == 2, f"SSLBL 2건 로드({n})")
    check(sslbl.check("A" * 40) == "MalwareX C2", "SSLBL 대소문자 무시 매칭")
    check(sslbl.check(":".join(["aa"] * 20)) == "MalwareX C2", "SSLBL 콜론 제거 매칭")
    check(sslbl.check("f" * 40) is None, "SSLBL 미등록 None")

    tf = X.ThreatFox()
    doc = {"1": [{"ioc_value": "evil.test", "ioc_type": "domain",
                  "malware_printable": "Emotet", "confidence_level": 100}],
           "2": [{"ioc_value": "1.2.3.4:443", "ioc_type": "ip:port", "malware_printable": "Cobalt Strike"}]}
    check(tf.load(doc) == 2, "ThreatFox 2건")
    check(tf.check("EVIL.TEST")["malware"] == "Emotet", "ThreatFox 매칭")

    async def fake_http(url):
        return HTTPResp(status=200, url=url)
    src = X.AbuseChSource(sslbl=sslbl, threatfox=tf)
    res = asyncio.run(src.fetch(InfraTarget(InfraType.DOMAIN, "evil.test"), fake_http))
    check(res.ok and any(e.type == EntityType.MALWARE for e in res.entities), "AbuseChSource → MALWARE 간선")
    check(res.entities[0].attrs["threat"][0].startswith("threatfox:Emotet"), "threat attr")

    # SSLBL 화면검사(그래프 cert_fps 대조)
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="c2.test", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("certstream", "obs")], attrs={"cert_fps": ["a" * 40, "dead"]}))
    hits = X.screen_certs_against_sslbl(g, sslbl)
    check(hits == [("c2.test", "a" * 40, "MalwareX C2")], f"cert SSLBL 스크리닝 {hits}")
    print(f"  abuse.ch: SSLBL(SHA1)·ThreatFox(IOC) 로드/매칭, 어댑터, cert 스크리닝 OK")


# ------------------------------------------------------- shodan favicon --- #
def t_favicon():
    check(X.murmur3_x86_32(b"") == 0, "mmh3 empty=0")
    check(X._to_signed32(X.murmur3_x86_32(b"foo")) == -156908512, "mmh3 foo 벡터")
    check(X._to_signed32(X.murmur3_x86_32(b"hello")) == 613153351, "mmh3 hello 벡터")
    raw = bytes(range(256)) * 4 + b"favicon"
    q = X.shodan_favicon_query(raw)
    check(q.startswith("http.favicon.hash:"), "shodan 쿼리식 형식")
    # 결정적: 같은 바이트 → 같은 해시
    check(X.favicon_mmh3(raw) == X.favicon_mmh3(raw), "favicon 해시 결정적")
    # 부호 있는 32비트 범위
    h = X.favicon_mmh3(raw)
    check(-(2**31) <= h < 2**31, f"부호 32비트 범위 {h}")
    print(f"  favicon: mmh3 정확(벡터 검증), shodan 피벗식 '{q}'")


# ------------------------------------------------- CLI run_scan 배선 통합 --- #
def t_cli_wiring():
    """run_scan 전체 배선: providers 주석 → deconfound → campaign 결과 조립(prebuilt 그래프)."""
    from types import SimpleNamespace
    from artes import cli_infra
    from artes.core.authz import BASIS_INFRA_TI

    # CF 층 그래프(전원 동일 CF IP+NS; cf0/cf1 은 rare favicon; 일부 first_seen 버스트)
    g = Graph()
    cf_ip = "104.16.7.7"
    g.add(Entity(type=EntityType.IP, value=cf_ip, certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("doh", "A")]))
    g.add(Entity(type=EntityType.DOMAIN, value="cruz.ns.cloudflare.com",
                 certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
    base = 1_700_000_000.0
    for i in range(6):
        d = f"cf{i}.com"
        fs = base + i * 5 if i < 6 else None       # 30초 안에 6개 → 캠페인
        # 6개가 IP·NS 외에 공유 SPKI 도 가짐 → 의존성 붕괴 후에도 독립 지문 3종(a_ip·ns·spki)으로 뭉침.
        g.add(Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("certstream", "obs")],
                     attrs={"first_seen": fs, "spki": "cfSPKI"}))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.IP, cf_ip),
                    relation="해석됨(A)", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "A")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, "cruz.ns.cloudflare.com"),
                    relation="네임서버", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))
    for d in ("cf0.com", "cf1.com"):
        e = next(x for x in g.entities if x.type == EntityType.DOMAIN and x.value == d)
        e.attrs["favicon"] = "rareFAV"
    # 흩어진 배경 도메인 다수 → 25초 버스트가 전체 대비 몰림(campaign) + N 을 키워 CF 공유신호를 희소화.
    for i in range(200):
        d = f"bgt{i}.com"
        g.add(Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("certstream", "obs")],
                     attrs={"first_seen": base + 3600 + i * 86400.0}))
        g.add(Entity(type=EntityType.DOMAIN, value=f"ns-bgt{i}.net", certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("doh", "NS")]))
        g.link(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, f"ns-bgt{i}.net"),
                    relation="네임서버", certainty=Certainty.CONFIRMED, evidence=[Evidence("doh", "NS")]))

    async def fake_run_iter(self, it):
        for _ in it:
            pass
        self.graph = g
        return g

    orig = cli_infra.InfraRecon.run_iter
    cli_infra.InfraRecon.run_iter = fake_run_iter
    try:
        args = SimpleNamespace(
            targets=["cf0.com"], case="C", operator="op", basis=BASIS_INFRA_TI,
            depth=1, concurrency=8, sources=1, min_lower=0.5, coincidence=1e-3,
            analytics=False, cypher_out="", ndjson_out="", no_graph=True, audit="", out="",
            dry=True, tech=False, peeringdb=False, providers=True,
            ranges_aws="", ranges_gcp="", ranges_azure="", ranges_cloudflare="",
            deconfound="cloud_provider", campaign_window=60.0, campaign_alpha=1e-3,
            min_stratum=3)
        res = asyncio.run(cli_infra.run_scan(args))
    finally:
        cli_infra.InfraRecon.run_iter = orig

    check(res.get("providers_annotated") == 1, f"CLI providers_annotated {res.get('providers_annotated')}")
    dc = res.get("deconfound", {})
    check(dc.get("confounder") == "cloud_provider", "CLI deconfound confounder")
    check(dc.get("applied_before_clustering") is True, "디컨파운딩이 클러스터링 이전에 적용됨")
    check("clusters" in res and "coincidence_clusters_raw" in res, "권위 clusters + raw 비교 동시 제공")
    # CF 6개는 제공자 기본신호만 공유(+cf0/cf1 favicon) → 디컨파운딩 후 6-blob 클러스터 안 생김
    check(all(len(c) < 6 for c in res["clusters"]), f"제공자 blob 제거됨 {res['clusters']}")
    camps = res.get("campaigns", [])
    check(len(camps) >= 1 and camps[0]["size"] >= 6, f"CLI 캠페인 {[c['size'] for c in camps]}")
    check(res["audit"]["chain_ok"], "CLI 감사체인 무결")
    check(res["policy"]["min_stratum"] == 3 and res["policy"]["max_bucket"] == 64, "정책 파라미터 메타 기록")
    print(f"  CLI 배선: providers {res['providers_annotated']}, deconfound 클러스터링 전 적용 "
          f"(raw {dc.get('raw_cluster_count')}→{dc.get('deconfounded_cluster_count')}), 캠페인 size={camps[0]['size']}")


def t_cypher_evidence_and_ident():
    """리뷰 P1: Cypher export 가 evidence/decision 보존 + label/rel_type 식별자 검증."""
    from artes.core.graph_io import to_cypher_batch
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("x", "y")]))
    e = Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.DOMAIN, "b.com"),
             relation="신호공유(동일운영자후보)", certainty=Certainty.UNCONFIRMED, confidence=0.63,
             evidence=[Evidence("cp", "l")], evidence_lower=0.63, evidence_upper=0.9, decision="unconfirmed")
    g.link(e)
    batches = list(to_cypher_batch(g))
    edge_rows = [row for b in batches for row in b["parameters"]["rows"] if "relation" in row]
    check(edge_rows and edge_rows[0]["evidence_lower"] == 0.63 and edge_rows[0]["decision"] == "unconfirmed",
          "Cypher 간선이 evidence_lower/decision 보존")
    # 안전하지 않은 라벨/rel_type 거부
    bad = 0
    for kw in ({"entity_label": "Asset; DROP"}, {"rel_type": "LINK`"}):
        try:
            list(to_cypher_batch(g, **kw))
        except ValueError:
            bad += 1
    check(bad == 2, f"injection 라벨/rel_type 거부 ({bad}/2)")
    # 리뷰 P1: 리터럴 to_cypher 도 batch 와 동일 의미 그래프 — 증거구간/decision 보존
    from artes.core.graph_io import to_cypher
    lit = "\n".join(to_cypher(g))
    check("r.evidence_lower=0.63" in lit and "r.decision='unconfirmed'" in lit
          and "r.evidence_upper=0.9" in lit,
          "리터럴 to_cypher 도 evidence_lower/upper/decision 보존(batch 와 parity)")
    # injection 은 리터럴 경로에서도 거부
    litbad = 0
    for kw in ({"entity_label": "Asset; DROP"}, {"rel_type": "LINK`"}):
        try:
            list(to_cypher(g, **kw))
        except ValueError:
            litbad += 1
    check(litbad == 2, f"리터럴 경로도 injection 거부 ({litbad}/2)")
    print(f"  Cypher(P1): batch+리터럴 둘 다 evidence/decision 보존 + 식별자 검증")


def t_evidence_dedup_provenance():
    """리뷰 P1: evidence dedup 이 url 까지 봐서 서로 다른 url 근거를 잃지 않는다."""
    g = Graph()
    for v in ("a.com", "b.com"):
        g.add(Entity(type=EntityType.DOMAIN, value=v, certainty=Certainty.CONFIRMED,
                     evidence=[Evidence("x", "y")]))
    kw = dict(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.DOMAIN, "b.com"),
              relation="해석됨(A)", certainty=Certainty.UNCONFIRMED)
    g.link(Edge(evidence=[Evidence("crt.sh", "SAN", url="https://crt.sh/?q=1")], **kw))
    g.link(Edge(evidence=[Evidence("crt.sh", "SAN", url="https://crt.sh/?q=2")], **kw))  # 같은 source/detail, 다른 url
    merged = [x for x in g.edges if x.relation == "해석됨(A)"][0]
    urls = {ev.url for ev in merged.evidence}
    check(urls == {"https://crt.sh/?q=1", "https://crt.sh/?q=2"}, f"서로 다른 url 근거 둘 다 보존 {urls}")
    print(f"  evidence dedup(P1): (source,detail,url) 키 → provenance 보존")


def t_corroborate_idempotent():
    """리뷰 P1: corroborate_edges(apply=True) 를 두 번 돌려도 k·결정·증거가 안 변한다(멱등).

    예전엔 cp-corroborate 증거를 매번 append + ignore 목록에 없어서 재실행마다 k 가 +1 됐다."""
    from artes.core.verify_cp import corroborate_edges, VerificationGate
    gate = VerificationGate(tau=0.5, floor=0.01, alpha=0.05)
    e = Edge(src=_k(EntityType.DOMAIN, "a.com"), dst=_k(EntityType.DOMAIN, "b.com"),
             relation="해석됨(A)", certainty=Certainty.UNCONFIRMED,
             evidence=[Evidence("dohA", "A"), Evidence("dohB", "A"), Evidence("dohC", "A")])
    r1 = corroborate_edges([e], gate, n_sources=3, apply=True)
    k1, conf1 = r1[0]["k"], e.confidence
    n_cpc_1 = sum(1 for ev in e.evidence if ev.source == "cp-corroborate")
    r2 = corroborate_edges([e], gate, n_sources=3, apply=True)   # 재실행
    k2, conf2 = r2[0]["k"], e.confidence
    n_cpc_2 = sum(1 for ev in e.evidence if ev.source == "cp-corroborate")
    check(k1 == 3 and k2 == 3, f"재실행에도 k 불변(3) k1={k1} k2={k2}")
    check(abs(conf1 - conf2) < 1e-12, f"재실행에도 confidence 불변 {conf1}={conf2}")
    check(n_cpc_1 == 1 and n_cpc_2 == 1, f"cp-corroborate 증거 누적 안 함 {n_cpc_1}/{n_cpc_2}")
    print(f"  corroborate 멱등(P1): 두 번 적용해도 k=3·conf·증거 불변(누적/자기집계 없음)")


def t_entity_dedup_rawref():
    """리뷰 P1: Entity.merge dedup 도 raw_ref 까지 봐서 서로 다른 근거를 잃지 않는다(Edge 와 parity).

    같은 source/detail/url 이라도 raw_ref(예: 인증서 id-1 vs id-2)가 다르면 서로 다른 관측이다."""
    g = Graph()
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("crt.sh", "SAN", url="https://crt.sh/?q=x", raw_ref="cert-1")]))
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("crt.sh", "SAN", url="https://crt.sh/?q=x", raw_ref="cert-2")]))
    ent = g.get(_k(EntityType.DOMAIN, "a.com"))
    refs = {ev.raw_ref for ev in ent.evidence}
    check(refs == {"cert-1", "cert-2"}, f"raw_ref 다른 근거 둘 다 보존 {refs}")
    # 완전 동일(raw_ref 포함)하면 하나로 dedup
    g.add(Entity(type=EntityType.DOMAIN, value="a.com", certainty=Certainty.CONFIRMED,
                 evidence=[Evidence("crt.sh", "SAN", url="https://crt.sh/?q=x", raw_ref="cert-1")]))
    ent2 = g.get(_k(EntityType.DOMAIN, "a.com"))
    check(len(ent2.evidence) == 2, f"동일 근거는 dedup(2 유지) {len(ent2.evidence)}")
    print(f"  Entity dedup(P1): (source,detail,url,raw_ref) → provenance 보존")


def t_same_operator_relation_label():
    """리뷰 P0: CP kind-count 간선은 '신호공유(동일운영자후보)' 로 라벨 — 확정 attribution 아님."""
    from artes.core.infra_recon import SAME_OPERATOR_SIGNAL_REL, correlate_same_operator
    check(SAME_OPERATOR_SIGNAL_REL == "신호공유(동일운영자후보)", "관계 라벨이 신호공유임을 명시")
    check("동일 운영자?" != SAME_OPERATOR_SIGNAL_REL, "예전의 단정적 라벨 아님")
    print(f"  관계 라벨(P0): '{SAME_OPERATOR_SIGNAL_REL}' (확정 attribution 아님)")


def t_coincidence_model():
    """리뷰 P0: exact-0 + 의존성 붕괴(중첩 넷블록·IP파생·같은-kind 세트 double-counting 제거)."""
    from artes.core.verify_cp import coincidence_prob
    from artes.core.signals import collapse_shared
    # exact-0: df=1 → 그 값 가진 도메인 하나뿐 → 우연 공유확률 정확히 0 (예전엔 1e-18)
    check(coincidence_prob([1], 100) == 0.0, "df=1 → 정확히 0")
    check(coincidence_prob([1, 3], 100) == 0.0, "df=1 포함 → 0")
    check(0.0 < coincidence_prob([3, 4], 100) < 1.0, "정상 df → (0,1)")
    df5 = lambda k, v: 5
    # a_ip 공유 → 넷블록·ASN·provider·ns_reg 전부 붕괴, a_ip+ns 만 남음
    kv = [("a_ip", "ip"), ("nb24", "x"), ("nb16", "y"), ("asn", "a"),
          ("cloud_provider", "cf"), ("ns", "n"), ("ns_reg", "r")]
    check(set(dict(collapse_shared(kv, df5))) == {"a_ip", "ns"}, "a_ip 공유 → IP파생+ns_reg 붕괴")
    # a_ip 없이 중첩 넷블록 → 가장 특정한 것만
    check(set(dict(collapse_shared([("nb30", "a"), ("nb24", "b"), ("nb16", "c")], df5))) == {"nb30"},
          "중첩 넷블록 → 최특정(nb30)만")
    # 같은 kind 다중값 → 가장 희소한 1개(곱 제거)
    dfm = {("ns", "a"): 9, ("ns", "b"): 2, ("ns", "c"): 50}
    check(collapse_shared([("ns", "a"), ("ns", "b"), ("ns", "c")], lambda k, v: dfm[(k, v)]) == [("ns", "b")],
          "같은 kind 다중값 → 최희소 1개")
    # double-counting 제거: 같은 IP(+15 중첩 넷블록)는 a_ip 단일 증거여야
    naive = coincidence_prob([2] * 16, 1000)          # 예전: 16개 종속축 곱(부풀림)
    collapsed = coincidence_prob([2], 1000)           # 붕괴: a_ip 하나
    check(collapsed > naive, f"붕괴가 과대평가 제거 {collapsed:.1e} > naive {naive:.1e}")
    print(f"  coincidence 모델: exact-0, 의존성 붕괴, double-count 제거 naive {naive:.1e}→붕괴 {collapsed:.1e}")


def t_confidence_decision():
    """리뷰 P11: CONFIRMED 라도 confidence=1.0 을 쓰지 않는다(증거 하한). 결정≠사후확률."""
    from artes.core.verify_cp import VerificationGate, cp_lower
    from artes.core.model import Edge, Evidence as Ev, Certainty
    gate = VerificationGate(tau=0.30, floor=0.05, alpha=0.05)
    v = gate.judge(6, 6)                       # k=n=6 → 강한 근거
    check(v.verdict == "confirmed", "6/6 → confirmed 결정")
    check(abs(v.lower - cp_lower(6, 6, 0.05)) < 1e-12, "lower = 정확 CP 하한")
    check(v.lower < 1.0, f"CONFIRMED 라도 하한 < 1.0 ({v.lower:.3f}) — 사후확률 아님")
    d = v.as_dict()
    check(d["decision"] == "confirmed" and d["evidence_lower"] == round(v.lower, 6),
          "as_dict 에 decision/evidence 분리")
    # apply_to_edge: CONFIRMED 여도 edge.confidence = 하한(1.0 아님)
    e = Edge(src="domain:a.com", dst="domain:b.com", relation="동일운영자?",
             certainty=Certainty.UNCONFIRMED, evidence=[Ev("x", "y")])
    gate.apply_to_edge(e, k=6, n=6)
    check(e.certainty == Certainty.CONFIRMED, "결정=CONFIRMED")
    check(abs(e.confidence - v.lower) < 1e-12 and e.confidence < 1.0,
          f"edge.confidence = 증거 하한 {e.confidence:.3f}(≠1.0)")
    check(any("사후확률 아님" in ev.detail for ev in e.evidence), "증거에 사후확률 아님 명시")
    print(f"  confidence/decision 분리: CONFIRMED 하한 {v.lower:.3f}(≠1.0), CI/결정 분리 OK")


def t_audit_tamperproof():
    """리뷰 P4: HMAC 키 있으면 파일 전체 재작성 위조도 검출(tamper-evident → tamper-proof)."""
    import tempfile, shutil, os as _os
    from artes.core.authz import AuditLog, AuditChainError
    _d = tempfile.mkdtemp()
    p = _os.path.join(_d, "audit.jsonl")       # 신규 디렉토리 → 이전 실행 잔여물과 충돌 없음
    KEY = "secret-anchor-key"
    a = AuditLog(p, key=KEY)
    for i in range(3):
        a.record("query", selector=f"s{i}")
    check(a.verify_chain()[0], "키드 체인 검증 통과")
    cp = a.checkpoint()
    check(cp["keyed"] and cp["sig"] and cp["root"], "checkpoint 서명 루트 방출")
    # 공격자가 키 없이 파일 전체를 그럴듯하게 재작성
    forge = AuditLog(p + ".forge")
    forge.record("query", selector="FORGED")
    shutil.copy(p + ".forge", p)
    caught = False
    try:
        AuditLog(p, key=KEY)                 # 로드 시 키드 검증 → 위조 검출
    except AuditChainError:
        caught = True
    check(caught, "키드 전체재작성 위조 → 로드시 검출")
    # 키 없는(기존) 모드는 재작성을 통과(tamper-evident 한계) — 정직하게 확인
    plain = AuditLog(_os.path.join(_d, "plain.jsonl"))
    plain.record("query", selector="x")
    check(plain.verify_chain()[0], "키 없는 모드는 하위호환(tamper-evident)")
    shutil.rmtree(_d, ignore_errors=True)
    print(f"  audit tamper-proof(P4): HMAC 키드 재작성 위조 로드시 검출 + checkpoint 외부앵커")


def t_url_cidr_routing():
    """리뷰 P15: URL/CIDR seed 가 소스 fan-out 되는지 end-to-end (예전엔 엔티티만 만들고 미실행)."""
    from artes.core.infra_recon import InfraRecon, HTTPResp
    fetched = []

    async def rec_http(url, *, timeout=15.0):
        fetched.append(url)
        return HTTPResp(status=404, text="", url=url)

    async def go():
        rec = InfraRecon(http=rec_http, depth=1)
        await rec.run(["https://seedurl.example/path", "198.51.100.0/30", "seeddom.example"])
        return rec
    rec = asyncio.run(go())
    check(any("seedurl.example" in u for u in fetched), "URL seed → 호스트로 소스 실행")
    check(any("198.51.100.0" in u for u in fetched), "CIDR seed → 네트워크IP로 소스 실행")
    check(any("seeddom.example" in u for u in fetched), "도메인 seed 소스 실행")
    check(rec.skipped == [], "정상 자산 seed 는 skip 없음")
    print(f"  URL/CIDR 라우팅: URL→호스트·CIDR→네트워크IP fan-out 확인({len(fetched)} fetch)")


def t_deconfounded_clustering():
    """리뷰 P2: 디컨파운딩을 클러스터링 '이전에' 적용 — 제공자 기본신호 쌍은 아예 클러스터 안 됨."""
    from artes.core.deconfound import deconfounded_clusters, Deconfounder
    sig = {}
    for i in range(200):
        sig[f"bg{i}"] = {"ns": {f"ns{i}"}}
    for i in range(6):                     # CF 층: 제공자 기본신호(ip+ns)만 공유(오탐 후보)
        sig[f"cf{i}"] = {"cloud_provider": {"CF"}, "a_ip": {"ip:1.1.1.1"}, "ns": {"cfns"}}
    for g in ("gA", "gB"):                 # 진짜 동일운영자: 제공자 없이 희소 신호 4종 공유
        sig[g] = {"ns": {"rns"}, "spki": {"rk"}, "favicon": {"rf"}, "gtm": {"rg"}}
    res = deconfounded_clusters(sig, "cloud_provider", threshold=1e-3, min_stratum=3)
    check(res["clusters"] == [["gA", "gB"]], f"디컨파운딩 클러스터 = 진짜 쌍만 {res['clusters']}")
    dc = Deconfounder(sig, "cloud_provider")
    raw = dc.coincidence("cf2", "cf3", stratified=False)
    adj = dc.coincidence("cf2", "cf3", stratified=True)
    check(raw < 1e-3, f"CF 쌍 raw={raw:.1e} <1e-3 → raw면 오탐 클러스터됨")
    check(abs(adj - 1.0) < 1e-9, "CF 쌍 디컨파운딩 → 1.0(클러스터 안 됨)")
    check(dc.coincidence("gA", "gB", stratified=True) < 1e-6, "진짜 쌍은 디컨파운딩 후에도 강함")
    # 리뷰 P1: 관측성 — 요청 vs 실제 사용 교란자, 층화가 실제로 작동했는지
    check(res["requested_confounders"] == ["cloud_provider"], f"요청 교란자 보고 {res['requested_confounders']}")
    check(res["available_confounders"] == ["cloud_provider"], f"데이터에 존재하는 교란자 보고 {res['available_confounders']}")
    check(res["effective"] is True, "교란자 데이터 존재+층화 작동 → effective")
    check(res["stratified_pairs"] >= 1, f"층화로 계산된 쌍 수 {res['stratified_pairs']}")
    # 데이터에 없는 교란자를 요청하면 effective=False(사실상 전역) — '적용됨' 오해 방지
    res_missing = deconfounded_clusters(sig, "nonexistent_kind", threshold=1e-3, min_stratum=3)
    check(res_missing["available_confounders"] == [] and res_missing["effective"] is False,
          "없는 교란자 요청 → available 비고 effective=False")
    print(f"  디컨파운딩 클러스터링(P2): 오탐 제외 + 관측성(effective/available/fallback) 보고")


def t_multi_confounder():
    """리뷰 P9: 여러 교란자 공동(joint) 층화 — 단일 교란자로 못 잡는 결합 교란 제거."""
    from artes.core.deconfound import Deconfounder
    sig = {}
    for i in range(960):
        sig[f"o{i}"] = {"cloud_provider": {f"P{i%5}"}, "asn": {f"A{i%7}"}, "ns": {f"ns{i}"}}
    for i in range(40):                        # CF∩AS1 공동 층 40개, 전원 nsX 공유
        sig[f"c{i}"] = {"cloud_provider": {"CF"}, "asn": {"AS1"}, "ns": {"nsX"}}
    sig["c0"]["spki"] = {"rareK"}; sig["c1"]["spki"] = {"rareK"}
    dj = Deconfounder(sig, ["cloud_provider", "asn"])       # 공동 교란자
    check(len(dj._joint_stratum([("cloud_provider", "CF"), ("asn", "AS1")])) == 40, "공동 층 40")
    check(abs(dj.coincidence("c2", "c3", stratified=True) - 1.0) < 1e-9,
          "공동층 기본신호(nsX)만 공유 → 근거 0")
    check(abs(dj.coincidence("c0", "c1", stratified=True) - 1 / 39) < 1e-9,
          "층내 희소 spki 잔차 = 1/39")
    check(dj.confounder_of("c2", "c3") == ["asn:AS1", "cloud_provider:CF"], "공유 교란자 2개 보고")
    print(f"  다중 교란자: cloud_provider∩asn 공동 층화, 기본신호 근거 0 / 희소 잔차 1/39")


def t_source_independence():
    """리뷰 P10: 같은 upstream 재게시 소스는 corroboration 에서 1표(가짜 합의 방지)."""
    from artes.core.verify_cp import VerificationGate, corroborate_edges, cp_lower
    from artes.core.infra_recon import source_upstream_class
    from artes.core.model import Edge, Evidence as Ev, Certainty
    check(source_upstream_class("crt.sh") == source_upstream_class("certspotter") == "ct-logs",
          "crt.sh·certspotter 같은 upstream(ct-logs)")

    def mk(sources):
        return Edge(src="domain:a.com", dst="ip:1.2.3.4", relation="해석됨(A)",
                    certainty=Certainty.UNCONFIRMED, evidence=[Ev(s, "obs") for s in sources])
    gate = VerificationGate(tau=0.5, floor=0.01, alpha=0.05)
    # 3개 CT 재게시 소스 → 독립 클래스 1개 → k=1 (이름수 3 아님)
    e_ct = mk(["crt.sh", "certspotter", "certstream"])
    r_ct = corroborate_edges([e_ct], gate, n_sources=3, apply=False,
                             independence_of=source_upstream_class)[0]
    check(r_ct["k"] == 1, f"CT 재게시 3소스 → k=1 (붕괴), got {r_ct['k']}")
    # 이름 그대로 세면(붕괴 없음) k=3 — 예전 방식(가짜 합의)
    r_naive = corroborate_edges([mk(["crt.sh", "certspotter", "certstream"])], gate,
                                n_sources=3, apply=False)[0]
    check(r_naive["k"] == 3, "붕괴 없으면 k=3(예전 가짜 합의)")
    # 진짜 독립 3소스(CT + 라이브DNS + 패시브DNS) → k=3 유지
    e_indep = mk(["crt.sh", "doh-dns", "hackertarget"])
    r_indep = corroborate_edges([e_indep], gate, n_sources=3, apply=False,
                                independence_of=source_upstream_class)[0]
    check(r_indep["k"] == 3, f"진짜 독립 3소스 → k=3, got {r_indep['k']}")
    print(f"  소스 독립성: CT 재게시 3→k=1(붕괴), 진짜 독립 3→k=3. corroborate 경로에 연결됨")


def main():
    print("[Cypher evidence/ident(P1)]"); t_cypher_evidence_and_ident()
    print("[evidence dedup(P1)]"); t_evidence_dedup_provenance()
    print("[corroborate 멱등(P1)]"); t_corroborate_idempotent()
    print("[Entity dedup raw_ref(P1)]"); t_entity_dedup_rawref()
    print("[관계 라벨(P0)]"); t_same_operator_relation_label()
    print("[디컨파운딩 클러스터링(리뷰 P2)]"); t_deconfounded_clustering()
    print("[다중 교란자(리뷰 P9)]"); t_multi_confounder()
    print("[소스 독립성(리뷰 P10)]"); t_source_independence()
    print("[audit tamper-proof(리뷰 P4)]"); t_audit_tamperproof()
    print("[URL/CIDR 라우팅(리뷰 P15)]"); t_url_cidr_routing()
    print("[confidence/decision 분리(리뷰 P11)]"); t_confidence_decision()
    print("[coincidence 모델(리뷰 P0)]"); t_coincidence_model()
    print("[temporal]"); t_temporal()
    print("[providers]"); t_providers(); t_annotate_providers()
    print("[provider→deconfound 통합]"); t_provider_deconfound_integration()
    print("[certstream]"); t_certstream()
    print("[peeringdb]"); t_peeringdb()
    print("[tech-fp]"); t_tech()
    print("[abuse.ch]"); t_abusech()
    print("[shodan favicon]"); t_favicon()
    print("[CLI run_scan 배선]"); t_cli_wiring()
    print(f"\n=== {PASS} passed, {FAIL} failed ===")
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
