"""artes scan-infra — OSINT recon CLI 배선(자산 + 인가된 사람 selector, 거버넌스 게이팅).

authz 게이트 + InfraRecon(병렬/캐시/지연 인테이크) + A레코드 corroboration(CP) + same-operator 상관 +
운영자 클러스터 + 해시체인 감사로그를 하나의 서브커맨드로 묶는다. 사람 selector 는 데이터 타입으로 막지
않고(합법 OSINT), --basis(consent/legal-authority/self-audit/osint-public)에서 정확 인가·감사로 활용한다.

  python -m artes.cli_infra example.com 8.8.8.8 AS15169 \
      --case CASE-1 --operator alice --basis threat-intel-infra --audit audit.jsonl
  python -m artes.cli_infra hong@gmail.com --basis consent --breach corpus.json   # 유출 노출(식별자 표시)

--dry: 네트워크를 치지 않고(스텁 http) 파이프라인 구조만 실행(스모크/CI 용).
사람 selector 는 인가 근거+정확 인가에서 허용(infra_only=threat-intel-infra 근거에선 자산만). 비밀번호 등
자격증명은 어느 경로에서도 노출하지 않는다(authz.redact_credentials).
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from types import SimpleNamespace
from typing import Optional

from .core.infra_recon import (
    InfraRecon, HTTPResp, classify_infra, InfraType,
    correlate_same_operator, operator_clusters, corroborate_resolution,
)
from .core.authz import (
    AuthorizationScope, Authorization, AuditLog,
    BASIS_INFRA_TI, BASIS_CONSENT, BASIS_SELF_AUDIT, BASIS_LEGAL, BASIS_OSINT,
)

_BASES = [BASIS_INFRA_TI, BASIS_CONSENT, BASIS_SELF_AUDIT, BASIS_LEGAL, BASIS_OSINT]


async def _noop_http(url: str, *, timeout: float = 15.0) -> HTTPResp:
    return HTTPResp(status=404, text="", url=url)


def _build_extra_sources(args) -> list:
    """옵트인 확장 어댑터(인프라/자산). tech·peeringdb·shodan·censys·wayback·urlhaus."""
    extra = []
    if getattr(args, "tech", False):
        from artes.core.sources_ext import TechFingerprint
        extra.append(TechFingerprint())
    if getattr(args, "peeringdb", False):
        from artes.core.sources_ext import PeeringDBSource
        extra.append(PeeringDBSource())
    if getattr(args, "shodan_internetdb", False):
        from artes.core.sources_net import ShodanInternetDB
        extra.append(ShodanInternetDB())            # 키리스
    if getattr(args, "censys", False):
        from artes.core.sources_net import CensysHosts
        extra.append(CensysHosts())                 # 인증은 http 주입 계층에서
    if getattr(args, "wayback", False):
        from artes.core.sources_net import WaybackCDX
        extra.append(WaybackCDX())                  # 키리스
    if getattr(args, "urlhaus", ""):
        from artes.core.sources_net import URLhaus, URLhausSource
        feed = URLhaus()
        with open(args.urlhaus, encoding="utf-8") as f:
            feed.load_csv(f.read())
        extra.append(URLhausSource(feed=feed))
    return extra


def _build_provider_db(args):
    """클라우드 제공자 IP-범위 DB. seed(무설정) + 공개 범위 파일(load_*)."""
    if not (getattr(args, "providers", False) or args.ranges_aws or args.ranges_gcp
            or args.ranges_azure or args.ranges_cloudflare):
        return None
    from artes.core.providers import ProviderDB, seed_db
    db = seed_db() if args.providers else ProviderDB()
    import json as _j
    if args.ranges_aws:
        with open(args.ranges_aws, encoding="utf-8") as f:
            db.load_aws(_j.load(f))
    if args.ranges_gcp:
        with open(args.ranges_gcp, encoding="utf-8") as f:
            db.load_gcp(_j.load(f))
    if args.ranges_azure:
        with open(args.ranges_azure, encoding="utf-8") as f:
            db.load_azure(_j.load(f))
    if args.ranges_cloudflare:
        with open(args.ranges_cloudflare, encoding="utf-8") as f:
            db.load_lines(f.read(), "Cloudflare")
    return db


async def run_scan(args: SimpleNamespace) -> dict:
    audit = AuditLog(args.audit or None)
    # 도메인 타깃은 하위도메인 추적을 위해 접미사로도 인가(인프라 전용).
    suffixes = {t for t in args.targets if classify_infra(t) == InfraType.DOMAIN}
    # 사람 이메일 도메인 와일드카드(조직 대규모)는 인프라 접미사와 분리해 명시 지정(P6). 공용 제공자는 거부됨.
    pedoms = {d.strip() for d in (getattr(args, "person_email_domains", "") or "").split(",") if d.strip()}
    scope = AuthorizationScope(audit).authorize(Authorization(
        case_id=args.case, operator=args.operator, basis=args.basis,
        selectors=set(args.targets), domain_suffixes=suffixes, person_email_domains=pedoms))

    http = _noop_http if args.dry else None
    from artes.core.infra_recon import default_infra_sources
    sources = default_infra_sources() + _build_extra_sources(args)
    rec = InfraRecon(sources=sources, http=http, scope=scope, depth=args.depth,
                     concurrency=args.concurrency)
    graph = await rec.run_iter(iter(args.targets))

    # 검증·상관 패스(전부 CP/coincidence 기반, 휴리스틱 점수 없음)
    corr = corroborate_resolution(graph, n_sources=args.sources)
    correlate_same_operator(graph)
    clusters = operator_clusters(graph, min_lower=args.min_lower)

    # 클라우드 제공자 주석(IP → 제공자). deconfound 교란자 층으로 쓴다(오탐 최대원 제거).
    provider_db = _build_provider_db(args)
    annotated = 0
    if provider_db is not None:
        from artes.core.providers import annotate_providers
        annotated = annotate_providers(graph, provider_db)

    # 축수-무관 IDF 우연일치 클러스터(권장) + 클러스터별 구조분석
    from artes.core.infra_recon import fast_clusters
    from artes.core import graph_analytics as ga
    from artes.core import signals as _sig_mod
    _family_collapse = bool(getattr(args, "family_collapse", False))
    _order_correct = bool(getattr(args, "order_correct", False))
    # 배경 모집단(강화 축1): --background JSON 이 있으면 독립 코퍼스에서 rarity 계산, 아니면 target-self.
    _bg = None
    _bg_source = "target-self"
    _bg_path = getattr(args, "background", "")
    if _bg_path:
        try:
            import json as _bj
            from artes.core.background import BackgroundCorpus
            with open(_bg_path, encoding="utf-8") as _bf:
                _bgmap = _bj.load(_bf)
            _bg = BackgroundCorpus.from_signal_map(_bgmap, source="corpus",
                                                   label=f"file:{_bg_path}")
            _bg_source = "corpus"
        except Exception as _be:
            _bg = None
            _bg_source = f"target-self (background load failed: {_be})"
    coincidence_clusters = fast_clusters(graph, threshold=args.coincidence,
                                         use_cp_upper=True, max_bucket=64,
                                         by_family=_family_collapse, order_correct=_order_correct,
                                         background=_bg)
    # 결의(A레코드) 확증의 증거 CI 요약 — 결정과 증거강도를 분리해 노출(리뷰 P1/P11/P7).
    # edge.confidence 는 모델의 legacy 결정 플래그(CONFIRMED→1.0)라 여기서 CP 증거 CI 를 따로 낸다.
    corr_summary = {
        "edges": len(corr),
        "confirmed": sum(1 for r in corr if r["verdict"] == "confirmed"),
        "dropped": sum(1 for r in corr if r["dropped"]),
        "evidence_ci_sample": [{"relation": "해석됨(A)", "k": r["k"], "n": r["n"],
                                "evidence_lower": round(r["lower"], 4),
                                "evidence_upper": round(r["upper"], 4),
                                "decision": r["verdict"]} for r in corr[:20]],
        "note": "evidence_lower/upper 는 CP 증거 CI(결정과 분리). CP 커버리지지 P(동일운영자) 아님.",
    }
    result: dict = {
        "case": args.case, "operator": args.operator, "basis": args.basis,
        "dry": bool(args.dry),
        # 결과 해석 계약을 스키마에 명시(리뷰 P0): 이 엔진은 evidence-ranking/screening 이며
        # 보정된 사후확률 P(동일운영자|증거)을 산출하지 않는다. posterior 는 명시적으로 null.
        "attribution_model": {
            # evidence_model 은 실제 적용된 것만 기술한다(강화). deconfound 는 effective 일 때만 표기.
            "evidence_model": "idf_coincidence",
            "family_collapse": _family_collapse,   # 축2: 관측-패밀리 double-count 제거 적용 여부
            "background_source": _bg_source,       # 축1: corpus(독립) | target-self(자기참조 폴백)
            "signal_set_hash": _sig_mod.SIGNAL_SET_HASH,   # 축6: 신호 레지스트리 지문
            "signal_version": _sig_mod.SIGNAL_VERSION,
            "posterior_probability": None,
            "outputs": "evidence strength / policy decision (NOT calibrated probability)",
            "assumptions": [
                "retained-signal conditional independence (dependency-collapse"
                + (" + family-collapse" if _family_collapse else "")
                + " mitigates, residual correlation remains)",
                ("independent background population (target-self fallback: NOT independent)"),
                "observed confounders only (unobserved confounding not addressed)",
            ],
            "to_get_posterior": "requires labeled ground-truth + likelihood-ratio calibration (separate track)",
        },
        "stats": graph.stats(),
        "skipped": [{"value": v, "reason": r} for v, r in rec.skipped],
        # 권위 있는 same-operator 판정 = IDF 우연일치(축수-무관). --deconfound 시 아래서 교체됨.
        "clusters": coincidence_clusters,
        "coincidence_clusters": coincidence_clusters,
        # 아래는 보조지표: CP on 신호공유-kind 비율. **P(동일운영자) 아님**(리뷰 P1) — 이항모형상
        # 공유비율 하한일 뿐. 판정은 clusters(IDF/디컨파운딩)를 쓴다.
        "signal_sharing_cp_clusters": clusters,
        "resolution_corroboration": corr_summary,
        "http": rec.http_cache.stats() if rec.http_cache else None,
        "request_governor": ({"max_concurrency": rec.request_limiter.max_concurrency,
                              "peak_in_flight": rec.request_limiter.peak,
                              "total_requests": rec.request_limiter.total,
                              "max_total_requests": rec.request_limiter.max_total}
                             if rec.request_limiter else None),
        "http_pipeline": ["caching", "politeness", "request_limiter", "ssrf_guard", "http"]
        if rec.politeness else ["injected"],
    }
    if annotated:
        result["providers_annotated"] = annotated

    # 디컨파운딩을 **클러스터링 판정 자체**에 적용(사후 리포트 아님, 리뷰 P2):
    # provider 주석 → 신호맵 → 층화 조건부 coincidence → threshold → cluster.
    # --deconfound 를 주면 이것이 권위 있는 클러스터(coincidence_clusters 는 raw 비교용).
    if args.deconfound:
        from artes.core import signals as _sig
        from artes.core.deconfound import deconfounded_clusters, deconfounded_edges
        sigmap = _sig.gather_signals(graph, _sig.EXTENDED_SPECS)
        conf = [c.strip() for c in args.deconfound.split(",") if c.strip()]  # 다중 교란자 허용
        conf = conf[0] if len(conf) == 1 else conf
        dcres = deconfounded_clusters(sigmap, conf, threshold=args.coincidence,
                                      min_stratum=args.min_stratum, max_bucket=64)
        result["coincidence_clusters_raw"] = coincidence_clusters   # 교란 미보정(비교용)
        result["clusters"] = dcres["clusters"]                       # 권위: 디컨파운딩된 판정
        result["deconfound"] = {
            "confounder": conf, "applied_before_clustering": True,
            "min_stratum": args.min_stratum, "edges": len(dcres["edges"]),
            "raw_cluster_count": len(coincidence_clusters),
            "deconfounded_cluster_count": len(dcres["clusters"]),
            "removed_by_deconfound": len(coincidence_clusters) - len(dcres["clusters"]),
            # 관측성(리뷰 P1): 요청 교란자가 데이터에 실제로 있었는지, 층화가 작동했는지 명시.
            # effective=False 면 '디컨파운딩 표기'와 달리 사실상 전역이었다는 뜻.
            "requested_confounders": dcres["requested_confounders"],
            "available_confounders": dcres["available_confounders"],
            "effective": dcres["effective"],
            "stratified_pairs": dcres["stratified_pairs"],
            "global_fallback_pairs": dcres["global_fallback_pairs"],
            "fallback_ratio": dcres["fallback_ratio"],       # 리뷰 P3: 실제 미디컨파운딩 비중(1급 지표)
            "fallback_note": dcres["fallback_note"],
        }
        # evidence_model 은 **실제 효과가 있었을 때만** deconfounded 로 표기(강화: 요청≠효과 구분).
        result["attribution_model"]["evidence_model"] = (
            "idf_coincidence + conditional_stratification (deconfounded)"
            if dcres["effective"] else "idf_coincidence (deconfound requested but ineffective)")
        result["attribution_model"]["requested_deconfounding"] = dcres["requested_confounders"]
        result["attribution_model"]["effective_deconfounding"] = dcres["effective"]
        clusters_for_analytics = dcres["clusters"]
    else:
        clusters_for_analytics = coincidence_clusters

    # 다중검정 FDR 통제(강화 축4): 후보쌍의 coincidence(=H0 p-value)에 BH/BY 적용해 오탐률 통제.
    if getattr(args, "fdr", ""):
        from artes.core.infra_recon import OperatorIndex
        from artes.core.fdr import fdr_edges
        kinds = tuple(s.name for s in _sig_mod.EXTENDED_SPECS)
        _idx = OperatorIndex(n_signals=len(kinds), signal_kinds=kinds, max_bucket=64,
                             track_values=True, judge_cp=False)
        for _d, _sig in _sig_mod.gather_signals(graph, _sig_mod.EXTENDED_SPECS).items():
            _idx.add(_d, _sig)
        _pairs = _idx.coincidence_pairs(threshold=1.0, use_cp_upper=True,
                                        by_family=_family_collapse,
                                        order_correct=_order_correct)  # 전부 받아 FDR 로 거른다
        fe = fdr_edges([(p["a"], p["b"], p["coincidence"]) for p in _pairs],
                       alpha=getattr(args, "fdr_alpha", 0.05), method=args.fdr)
        result["fdr"] = {"method": fe["method"], "alpha": fe["alpha"],
                         "n_candidates": fe["n_candidates"], "n_selected": fe["n_selected"],
                         "edges": fe["edges"][:100], "note": fe["note"]}

    # 시간축: co-burst 캠페인 탐지. first_seen attr(CertStream/cert not_before)에서 수집.
    if args.campaign_window > 0:
        from artes.core import temporal as _tmp
        from artes.core.model import EntityType as _ET
        first = {e.value: (e.attrs or {}).get("first_seen") for e in graph.entities
                 if e.type == _ET.DOMAIN and (e.attrs or {}).get("first_seen")}
        if len(first) >= 2:
            camps = _tmp.campaign_report(first, window=args.campaign_window,
                                         alpha=args.campaign_alpha,
                                         n_mc=getattr(args, "campaign_mc", 1999))
            result["campaigns"] = camps[:100]

    if args.analytics:
        result["structure"] = ga.analyze(graph)
        result["cluster_analytics"] = ga.cluster_analytics(graph, clusters_for_analytics)
    # 정책 파라미터를 결과 메타에 명시(리뷰 P1: 재현·해석용 — 이 값들이 판정에 개입함을 드러냄)
    result["policy"] = {
        "coincidence_threshold": args.coincidence, "max_bucket": 64,
        "min_stratum": args.min_stratum, "corroboration_n_sources": args.sources,
        "operator_cluster_min_lower": args.min_lower,
        "family_collapse": _family_collapse,
        "order_correct": _order_correct,
        "fdr": getattr(args, "fdr", "") or None,
        "campaign_alpha": args.campaign_alpha if args.campaign_window > 0 else None,
        "note": "max_bucket/min_stratum 등은 정리값이 아닌 정책값(generic 억제·층 안정성)",
    }
    # Run manifest(강화 축5): graph_root(내용) 와 run_root(정책·신호셋·버전 포함 맥락) 분리 지문.
    try:
        from artes.core.manifest import build_manifest
        from artes import __version__ as _ver
        _mani = build_manifest(graph, software_version=_ver, policy=result["policy"],
                               background=_bg,
                               source_config=sorted({s.name for s in rec.sources}))
        result["run_manifest"] = _mani.to_dict()
    except Exception as _e:      # manifest 는 부가정보 — 실패해도 스캔 결과엔 영향 없음
        result["run_manifest"] = {"error": str(_e)}
    # 대규모 적재/이관용 export
    if getattr(args, "cypher_out", ""):
        from artes.core.graph_io import write_cypher
        result["cypher_written"] = write_cypher(graph, args.cypher_out)
    if getattr(args, "ndjson_out", ""):
        from artes.core.graph_io import stream_ndjson
        result["ndjson_records"] = stream_ndjson(graph, args.ndjson_out)

    # 사람 축: 공개출처 유출 노출 + 아이디 공개 프로필 + 이메일 enrichment(인가 selector 한정,
    # 식별자 표시·자격증명 제외). --breach/--username-check/--email-enrich 중 하나라도 있으면 실행.
    _want_person = bool(getattr(args, "breach", "") or getattr(args, "username_check", False)
                        or getattr(args, "email_enrich", False))
    if _want_person:
        try:
            import json as _brj
            from artes.core.person_osint import (BreachPresenceSource, UsernamePresenceSource,
                                                 PersonRecon)
            from artes.core.model import EntityType as _ET2
            _corpus = {}
            if getattr(args, "breach", ""):
                with open(args.breach, encoding="utf-8") as _brf:
                    _corpus = _brj.load(_brf)
            _person_types = {_ET2.EMAIL, _ET2.USERNAME, _ET2.ACCOUNT, _ET2.PHONE, _ET2.NAME}
            _sels = [e.value for e in graph.entities if e.type in _person_types]
            _usrc = None
            if getattr(args, "username_check", False):
                # --dry 면 probe 없음(후보 URL 만). 실네트워크면 HTTP presence(200=존재)로 확인.
                if args.dry:
                    _usrc = UsernamePresenceSource()
                else:
                    async def _probe(url):
                        r = await default_http_get(url)
                        return True if 200 <= r.status < 300 else (False if r.status == 404 else None)
                    # 동기 래핑(간단): 이벤트루프에서 개별 조회. 대량이면 별도 배치 권장.
                    def _sync_probe(url):
                        return asyncio.get_event_loop().run_until_complete(_probe(url))
                    _usrc = UsernamePresenceSource(probe=_sync_probe)
            pr = PersonRecon(scope, BreachPresenceSource(_corpus) if _corpus else BreachPresenceSource({}),
                             username_source=_usrc, email_enrich=bool(getattr(args, "email_enrich", False)))
            pg = pr.run(_sels)
            for _e in pg.entities:      # 사람 그래프를 메인 그래프에 병합
                graph.add(_e)
            for _ed in pg.edges:
                graph.link(_ed)
            result["person_osint"] = pr.report()
        except Exception as _pe:
            result["person_osint"] = {"error": str(_pe)}

    ok, bad, why = audit.verify_chain()
    result["audit"] = {"chain_ok": ok, "bad_index": bad, "reason": why,
                       "entries": len(audit.entries())}
    if not getattr(args, "no_graph", False):
        result["graph"] = graph.to_dict()
    return result


def _add_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("targets", nargs="+",
                   help="도메인/IP/ASN/CIDR/URL. 사람 selector(이메일·전화·아이디·이름)는 인가 근거"
                        "(--basis consent/legal-authority/self-audit/osint-public)에서 정확 인가 시 허용")
    p.add_argument("--case", default="adhoc", help="케이스 ID(감사)")
    p.add_argument("--operator", default="cli", help="수행자(책임 소재)")
    p.add_argument("--basis", default=BASIS_INFRA_TI, choices=_BASES,
                   help="인가 근거(기본 threat-intel-infra → infra_only)")
    p.add_argument("--depth", type=int, default=2, help="재귀확장 깊이")
    p.add_argument("--concurrency", type=int, default=128, help="최대 동시성(거버너 상한)")
    p.add_argument("--sources", type=int, default=3, help="A레코드 corroboration 독립출처 n")
    p.add_argument("--min-lower", type=float, default=0.5, dest="min_lower",
                   help="운영자 클러스터에 쓸 최소 CP 하한")
    p.add_argument("--coincidence", type=float, default=1e-6,
                   help="IDF 우연일치 클러스터 문턱(이하면 same-operator)")
    p.add_argument("--family-collapse", action="store_true", dest="family_collapse",
                   help="관측-패밀리 붕괴(강화 축2): co-derived 신호 double-count 제거(더 보수적·정확)")
    p.add_argument("--order-correct", action="store_true", dest="order_correct",
                   help="order-statistic 보정(강화 축14): 'kind 내 최소 df 선택' post-selection 을 1-(1-q)^m 로 보정")
    p.add_argument("--fdr", default="", metavar="METHOD", choices=["", "bh", "by"],
                   help="후보쌍에 다중검정 FDR 통제(bh=독립/PRDS, by=임의종속). 빈값=미적용(강화 축4)")
    p.add_argument("--fdr-alpha", type=float, default=0.05, dest="fdr_alpha",
                   help="FDR 목표 수준 α(기본 0.05)")
    p.add_argument("--background", default="", metavar="JSON",
                   help="독립 배경 모집단 신호맵 JSON({domain:{kind:[values]}}) 경로(강화 축1). "
                        "주면 rarity 를 타겟 그래프 대신 이 코퍼스에서 계산")
    p.add_argument("--breach", default="", metavar="JSON",
                   help="공개출처 유출 corpus JSON({ident:[{breach,date,data_classes,identifiers,same_subject}]}) "
                        "경로. 인가된 사람 selector 의 유출 노출 파악(식별자 표시, 비밀번호 등 자격증명 제외).")
    p.add_argument("--person-email-domain", default="", dest="person_email_domains", metavar="CSV",
                   help="조직 소유 이메일 도메인(쉼표) — 그 도메인의 모든 이메일 유출점검 인가(P6: 인프라 "
                        "접미사와 분리, 공용 제공자 gmail/naver 등은 거부).")
    p.add_argument("--username-check", action="store_true", dest="username_check",
                   help="인가된 아이디의 공개 프로필 존재 조회(Maigret 모델; 공개 존재여부만, 내용/자격증명 없음).")
    p.add_argument("--email-enrich", action="store_true", dest="email_enrich",
                   help="인가된 이메일의 공개 enrichment(Gravatar·disposable·형식·MX; 자격증명 없음).")
    p.add_argument("--analytics", action="store_true",
                   help="그래프 구조분석(절단점·허브·k-core) + 클러스터별 분석 포함")
    # 확장 소스/축
    p.add_argument("--tech", action="store_true", help="기술 스택 지문 소스(Wappalyzer 계열) 활성")
    p.add_argument("--peeringdb", action="store_true", help="PeeringDB ASN→조직명 소스 활성")
    p.add_argument("--shodan-internetdb", action="store_true", dest="shodan_internetdb",
                   help="Shodan InternetDB(키리스) IP→포트·CPE·CVE 활성")
    p.add_argument("--censys", action="store_true", help="Censys hosts IP→서비스/포트/CPE/cert(키 필요)")
    p.add_argument("--wayback", action="store_true", help="Wayback CDX 역사적 서브도메인/URL 발굴(키리스)")
    p.add_argument("--urlhaus", default="", metavar="CSV", help="abuse.ch URLhaus CSV 덤프 경로(위협 대조)")
    p.add_argument("--providers", action="store_true",
                   help="클라우드 제공자 씨앗범위로 IP 주석(deconfound 교란자 층)")
    p.add_argument("--ranges-aws", default="", dest="ranges_aws", help="AWS ip-ranges.json 경로")
    p.add_argument("--ranges-gcp", default="", dest="ranges_gcp", help="GCP cloud.json 경로")
    p.add_argument("--ranges-azure", default="", dest="ranges_azure", help="Azure ServiceTags JSON 경로")
    p.add_argument("--ranges-cloudflare", default="", dest="ranges_cloudflare",
                   help="Cloudflare ips-v4/v6(줄바꿈 CIDR) 경로")
    p.add_argument("--deconfound", default="", metavar="KIND",
                   help="교란자 축(예: cloud_provider, asn)으로 클러스터링 전에 디컨파운딩(쉼표로 다중)")
    p.add_argument("--min-stratum", type=int, default=3, dest="min_stratum",
                   help="디컨파운딩 층 최소 크기(정책값; 미만이면 전역 폴백)")
    p.add_argument("--campaign-window", type=float, default=0.0, dest="campaign_window",
                   help="시간축 co-burst 캠페인 창(초). >0 이면 first_seen 로 캠페인 탐지")
    p.add_argument("--campaign-alpha", type=float, default=1e-3, dest="campaign_alpha",
                   help="캠페인 유의수준. MC 검정이라 alpha 는 1/(1+n_mc) 보다 커야 검출 가능(기본 n_mc=1999 → 최소 5e-4)")
    p.add_argument("--campaign-mc", type=int, default=1999, dest="campaign_mc",
                   help="캠페인 몬테카를로 표본수. 더 작은 alpha 를 원하면 늘려라(alpha≥1/(1+n_mc))")
    p.add_argument("--cypher-out", default="", dest="cypher_out",
                   help="Neo4j Cypher(MERGE) 파일 경로로 export")
    p.add_argument("--ndjson-out", default="", dest="ndjson_out",
                   help="그래프 NDJSON(.gz 가능) export 경로")
    p.add_argument("--no-graph", action="store_true", dest="no_graph",
                   help="결과 JSON 에서 전체 graph 덤프 생략(요약만)")
    p.add_argument("--audit", default="", help="감사로그 JSONL 경로(비우면 메모리)")
    p.add_argument("--out", default="", help="결과 JSON 출력 경로(비우면 stdout)")
    p.add_argument("--dry", action="store_true", help="네트워크 없이 파이프라인만 실행")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="artes scan-infra",
        description="OSINT recon(도메인·IP·ASN·CIDR·URL + 인가된 사람 selector; 거버넌스 게이팅·감사)")
    _add_args(p)
    return p


def register_subparser(subparsers) -> argparse.ArgumentParser:
    """기존 artes cli.py 에 `scan-infra` 서브커맨드를 등록.

    사용(그들 cli.py 안에서):
        from artes.cli_infra import register_subparser
        register_subparser(subparsers)          # subparsers = parser.add_subparsers()
        ...
        args = parser.parse_args()
        if hasattr(args, "_func"): return args._func(args)
    """
    sp = subparsers.add_parser("scan-infra",
                               help="OSINT recon(자산 + 인가된 사람 selector; 합법근거·감사)")
    _add_args(sp)
    sp.set_defaults(_func=main_from_args)
    return sp


def main_from_args(args) -> int:
    result = asyncio.run(run_scan(args))
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if getattr(args, "out", ""):
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"결과 {result['stats']} → {args.out} (skipped {len(result['skipped'])})",
              file=sys.stderr)
    else:
        print(text)
    return 0


def main(argv: Optional[list] = None) -> int:
    return main_from_args(build_parser().parse_args(argv))


if __name__ == "__main__":
    raise SystemExit(main())
