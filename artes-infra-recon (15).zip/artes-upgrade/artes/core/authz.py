"""인가 범위 게이트 + 감사 로그 — authorized-investigation 을 실제로 강제·감사 가능하게.

README 는 "본인 발자국 점검 / 대상의 동의·권한이 있는 조사 / 위협인텔 연구 전용" 을
명시하고 첫 실행 consent 고지를 둔다. 그건 **정책 선언**이다. 이 모듈은 그 정책을
**실행층에서 강제**한다:

  * AuthorizationScope — 이번 케이스에서 조회가 허용된 selector(표적) 화이트리스트.
    인가되지 않은 표적으로 나가려는 조회는 코드 레벨에서 거부(AuthorizationError).
    범위 밖으로 확장된 새 엔티티(예: 피벗으로 튀어나온 제3자)도 자동 차단된다.
  * AuditLog — 모든 조회/차단을 append-only JSONL 로 기록(who/what/when/근거).
    책임 소재와 사후 감사(누가·언제·무슨 근거로·무엇을 조회했나)를 남긴다.

이건 툴을 "더 강하게" 만드는 축이기도 하다: 범위·감사 없는 OSINT 엔진은 조직/법무가
못 굴린다. 범위+감사가 있어야 실제 배포·의뢰수행이 방어가능해진다.

순수 stdlib. 수집 능력을 확장하지 않는다 — 오히려 표적 범위를 좁히고 기록을 남긴다.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional


class AuditChainError(Exception):
    """로드 시 기존 감사 체인이 깨졌거나(변조/절단) 위조된 경우."""


class AuthorizationError(PermissionError):
    """인가되지 않은 표적으로의 조회 시도."""


# --- 근거(basis) 분류 — 합법 OSINT 는 데이터 타입이 아니라 '근거+인가+공개출처+목적'에서 나온다.
BASIS_SELF_AUDIT = "self-audit"          # 본인/본인 자산
BASIS_CONSENT = "consent"                # 대상의 명시적 동의
BASIS_LEGAL = "legal-authority"          # 영장·법적 권한(수사·규제)
BASIS_INFRA_TI = "threat-intel-infra"    # 인프라(도메인·IP·ASN) 위협인텔(infra_only)
BASIS_OSINT = "osint-public"             # 인가된 공개출처 OSINT(사람 selector 포함 가능)
VALID_BASES = {BASIS_SELF_AUDIT, BASIS_CONSENT, BASIS_LEGAL, BASIS_INFRA_TI, BASIS_OSINT}

# 인프라형 selector(자산) — infra_only 근거에서 허용되는 타입.
_INFRA_TYPES = {"domain", "ip", "asn", "cidr", "url", "cert", "netblock"}
# 사람 selector 타입 — 데이터 타입 자체를 막지 않는다(합법 OSINT). 대신 아래 조건 전부를 만족해야 조회:
#   (1) infra_only 가 아닌 합법근거(consent/legal/self-audit/osint-public), (2) 그 selector 가 인가목록에
#   **명시적으로** 등록됨(접미사 와일드카드 불허 — 사인 대상은 정확 인가만), (3) 전 조회 감사 기록.
# 이것이 '타입 차단' 대신 '거버넌스 게이팅'이다. 공개출처+인가+감사 안에서 이메일·전화·아이디·이름을 활용.
_PERSON_TYPES = {"email", "phone", "username", "name", "account", "person"}
# 절대 저장·노출 금지(공개출처 OSINT라도): 유출된 자격증명 평문/해시. presence(존재여부) boolean 만 허용.
# 넓은 denylist(리뷰 P7): pw/pass/plain/cleartext/salt/token/otp/apikey/private key 계열까지.
_CREDENTIAL_FIELDS = {"password", "passwd", "pwd", "pw", "pass", "plain", "cleartext", "secret",
                      "credential", "hash", "ntlm", "pwdump", "salt", "token", "otp", "apikey",
                      "api_key", "privkey", "private_key", "seed_phrase", "mnemonic", "cvv"}
# 공용/무료 메일 제공자 — 사람 이메일 **도메인 와일드카드로 인가 불가**(리뷰 P6): 이걸 접미사로 넣으면
# 수억 개인 대량 프로파일링이 인가돼 버린다. 조직 소유 도메인만 person_email_domains 로 와일드카드 허용.
_PUBLIC_MAIL_PROVIDERS = {
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.co.jp", "ymail.com", "hotmail.com",
    "outlook.com", "live.com", "msn.com", "icloud.com", "me.com", "mac.com", "aol.com",
    "proton.me", "protonmail.com", "gmx.com", "gmx.net", "mail.com", "zoho.com", "yandex.com",
    "naver.com", "daum.net", "hanmail.net", "nate.com", "kakao.com", "qq.com", "163.com",
    "126.com", "sina.com", "foxmail.com", "hotmail.co.uk", "outlook.co.kr",
}


def _is_credential_key(key: str) -> bool:
    """key 가 자격증명 필드인가(리뷰 P7): 부분문자열이 아니라 **토큰** 매칭.

    'password'·'user_pw'·'plain' 은 잡되 'pwn_count'·'passport' 같은 정상 필드는 오탐하지 않는다
    (부분문자열 매칭이면 'pw' 가 'pwncount' 를 잘못 지웠다). 전체 key 또는 그 토큰 중 하나가
    credential 용어와 정확히 일치할 때만 자격증명으로 본다."""
    kl = str(key).strip().lower()
    if kl in _CREDENTIAL_FIELDS:
        return True
    toks = [t for t in re.split(r"[^a-z0-9]+", kl) if t]
    return any(t in _CREDENTIAL_FIELDS for t in toks)


def redact_credentials(obj):
    """공개출처 OSINT라도 유출 자격증명 평문/해시는 저장·노출하지 않는다(하드 리밋, 리뷰 P7 보강).

    dict 의 credential 키를 제거하고 **리스트/중첩까지 재귀**한다(예: records:[{password:...}] 내부도).
    presence/count/breach 메타는 이름이 credential 토큰이 아니라 통과. 새 객체 반환(원본 불변).
    ※ breach corpus 의 1차 방어는 BreachPresenceSource 의 allowlist(문서화된 보장), 이건 2차 방어."""
    if isinstance(obj, dict):
        return {k: redact_credentials(v) for k, v in obj.items() if not _is_credential_key(k)}
    if isinstance(obj, list):
        return [redact_credentials(x) for x in obj]
    return obj


def normalize_selector(sel: str) -> str:
    """표적 정규화 — 대소문자/공백/전화표기 차이를 흡수해 일관 매칭."""
    s = (sel or "").strip().lower()
    if not s:
        return s
    # 전화: 숫자와 선행 + 만 남김
    if re.fullmatch(r"[+()\-\s0-9]{6,}", s) and any(c.isdigit() for c in s):
        digits = re.sub(r"[^\d]", "", s)
        return ("+" if s.lstrip().startswith("+") else "") + digits
    # 이메일/도메인/아이디: 앞뒤 점·슬래시 정리
    return s.strip("/. ")


@dataclass
class Authorization:
    """한 케이스의 인가 사실. 실제 서명/보관은 상위 시스템 몫 — 여기선 범위·만료·근거만."""
    case_id: str
    operator: str                        # 조회 수행자(책임 소재)
    basis: str                           # VALID_BASES 중 하나
    selectors: set[str] = field(default_factory=set)   # 정규화된 인가 표적
    domain_suffixes: set[str] = field(default_factory=set)  # **인프라 전용** 접미사: *.example.com 자산
    # 사람 이메일 도메인 와일드카드(리뷰 P6) — 인프라 접미사와 **분리**. 조직이 소유/권한 주장하는
    # 도메인만(예: company.com → 모든 @company.com 유출점검). 공용 메일 제공자는 __post_init__ 에서 거부.
    person_email_domains: set[str] = field(default_factory=set)
    infra_only: bool = False             # True 면 인프라형 selector 만 허용
    allow_person: bool = True            # 사람 selector 허용(단, infra_only 면 무시). 기본 허용(합법 OSINT)
    expires_at: Optional[float] = None   # epoch 초; None = 무기한
    note: str = ""

    def __post_init__(self) -> None:
        if self.basis not in VALID_BASES:
            raise ValueError(f"basis must be one of {sorted(VALID_BASES)}")
        self.selectors = {normalize_selector(s) for s in self.selectors if s}
        self.domain_suffixes = {normalize_selector(s).lstrip("*.") for s in self.domain_suffixes if s}
        self.person_email_domains = {normalize_selector(s).lstrip("*.")
                                     for s in self.person_email_domains if s}
        # 공용 메일 제공자를 사람 이메일 와일드카드로 인가하는 것은 **거부**(대량 프로파일링 방지, P6).
        bad = self.person_email_domains & _PUBLIC_MAIL_PROVIDERS
        if bad:
            raise ValueError(f"공용 메일 제공자는 person_email_domains 와일드카드로 인가 불가(대량 "
                             f"개인 프로파일링 위험): {sorted(bad)} — 개별 이메일을 selectors 로 정확 인가하라")
        if self.basis == BASIS_INFRA_TI:
            self.infra_only = True        # 인프라 위협인텔은 자산만

    def person_allowed(self) -> bool:
        """사람 selector 조회가 이 인가에서 허용되는가 — infra_only 가 아니고 allow_person 일 때만.
        (근거는 어차피 consent/legal/self-audit/osint-public 중 하나여야 하며 전부 감사됨.)"""
        return (not self.infra_only) and self.allow_person

    def active(self, now: Optional[float] = None) -> bool:
        now = time.time() if now is None else now
        return self.expires_at is None or now < self.expires_at


class AuthorizationScope:
    """이번 실행의 인가 범위. Engine 이 seed·확장·수집 직전에 check() 를 통과시킨다."""

    def __init__(self, audit: "Optional[AuditLog]" = None) -> None:
        self._auth: Optional[Authorization] = None
        self.audit = audit

    def authorize(self, auth: Authorization) -> "AuthorizationScope":
        self._auth = auth
        if self.audit:
            self.audit.record("authorize", selector="", collector="",
                              ok=True, meta={"case": auth.case_id, "operator": auth.operator,
                                             "basis": auth.basis, "n_selectors": len(auth.selectors),
                                             "infra_only": auth.infra_only})
        return self

    # --- 범위 판정 ---------------------------------------------------------- #
    def _in_scope(self, selector: str, etype: Optional[str]) -> bool:
        a = self._auth
        if a is None:
            return False
        if not a.active():
            return False
        et = (etype or "").strip().lower()
        if a.infra_only and et and et not in _INFRA_TYPES:
            return False
        # 사람 selector 게이팅(타입 차단 아님): 사람 타입은 (1) person_allowed 이고 (2) 정확 인가된
        # selector 일 때만. 접미사 와일드카드로 사인 집단을 쓸어담는 것은 불허(정확 인가만) → 합법
        # OSINT 는 되고, 대량 사인 프로파일링은 막힌다.
        if et in _PERSON_TYPES:
            if not a.person_allowed():
                return False
            nsel = normalize_selector(selector)
            if nsel in a.selectors:
                return True
            # 대규모 조직 조사: 이메일은 **person_email_domains** 로만 도메인 와일드카드 매칭(리뷰 P6).
            # 인프라 domain_suffixes 와 분리 — 인프라 도메인 인가가 개인 이메일 대량 인가로 새지 않는다.
            # 공용 메일 제공자는 person_email_domains 로 등록 자체가 거부됨(__post_init__). phone/username/
            # name/account 는 와일드카드 전무(정확 인가만) — 사인 집단 무단 수집 방지.
            if et == "email" and "@" in nsel:
                dom = nsel.rsplit("@", 1)[-1]
                for suf in a.person_email_domains:
                    if dom == suf or dom.endswith("." + suf):
                        return True
            return False
        sel = normalize_selector(selector)
        if not sel:
            return False
        if sel in a.selectors:
            return True
        # 인프라 도메인 접미사 매칭(하위도메인까지 인가) — 인프라형에만.
        if et in _INFRA_TYPES or et == "":
            for suf in a.domain_suffixes:
                if sel == suf or sel.endswith("." + suf):
                    return True
        return False

    def is_authorized(self, selector: str, etype: Optional[str] = None) -> bool:
        return self._in_scope(selector, etype)

    def person_allowed(self) -> bool:
        """이 scope 에서 사람 selector 조회가 허용되는가(인가·감사 전제)."""
        return self._auth is not None and self._auth.active() and self._auth.person_allowed()

    def check(self, selector: str, etype: Optional[str] = None,
              collector: str = "") -> None:
        """인가 밖이면 AuthorizationError. 통과/차단 모두 감사에 남긴다."""
        ok = self._in_scope(selector, etype)
        if self.audit:
            self.audit.record("query" if ok else "blocked",
                              selector=selector, collector=collector, ok=ok,
                              meta={"etype": etype or "",
                                    "case": self._auth.case_id if self._auth else None})
        if not ok:
            reason = ("범위 미설정" if self._auth is None
                      else "만료" if not self._auth.active()
                      else "표적 미인가/범위 밖")
            raise AuthorizationError(
                f"미인가 조회 차단: selector={selector!r} type={etype!r} ({reason})")

    def filter_authorized(self, items: Iterable[tuple[str, Optional[str]]]
                          ) -> list[tuple[str, Optional[str]]]:
        """(selector, etype) 목록에서 인가된 것만. 확장 frontier 필터링에 사용."""
        return [(s, t) for (s, t) in items if self._in_scope(s, t)]


class AuditLog:
    """해시 체인(tamper-evident) append-only 감사 로그. 스레드 안전(단순 락).

    각 엔트리는 seq·prev(이전 해시)·hash 를 갖는다.
    - key 없음: hash = sha256(정규화(엔트리 - hash)) — **tamper-evident**. 삽입·삭제·재배열·
      제자리 변조는 검출하지만, 공격자가 파일 전체를 다시 계산해 갈아끼우면 검증을 통과한다.
    - key 있음: hash = HMAC-SHA256(key, 정규화) — **tamper-proof**. 비밀키 없이는 유효 해시를
      재계산할 수 없어 파일 전체 재작성 위조도 검출된다(리뷰 P4). key 는 별도 보관해야 의미가 있다.
    추가 방어: 로드 시 기존 체인을 검증(verify_on_load)하고, checkpoint() 로 외부 앵커용 서명 루트를
    내보낸다. 기존 record/entries/counts API 는 그대로(하위호환).
    """

    def __init__(self, path: Optional[str] = None, key: "Optional[bytes|str]" = None,
                 verify_on_load: bool = True, durability: str = "sync") -> None:
        # durability(축9): 대규모 스캔에서 record 마다 fsync 는 병목이다. 모드로 선택:
        #   "sync"   — write+flush+fsync 매 레코드(기본, 크래시 즉시 내구성; tamper-proof 그대로).
        #   "batch"  — write+flush, fsync 는 flush()/close() 에서만(OS 가 결국 내림; 체인은 동일).
        #   "buffer" — 메모리에 모아 flush()/close() 에서 한꺼번에 기록(최고 처리량, 명시 flush 필요).
        if durability not in ("sync", "batch", "buffer"):
            raise ValueError("durability must be sync|batch|buffer")
        self.durability = durability
        self.path = path
        self._key = key.encode("utf-8") if isinstance(key, str) else key
        self._lock = threading.Lock()
        self._mem: list[dict[str, Any]] = []
        self._pending: list[dict[str, Any]] = []   # buffer 모드: 아직 파일에 안 쓴 레코드
        self._seq = 0
        self._last_hash = ""
        # 기존 파일이 있으면: 먼저 체인 검증(변조/위조 조기 검출) 후 상태 이어받기.
        if path and os.path.exists(path):
            existing = self.entries()
            if existing:
                if verify_on_load:
                    ok, idx, why = self.verify_chain(existing)
                    if not ok:
                        raise AuditChainError(f"기존 감사 체인 무결성 실패(idx={idx}): {why}")
                self._seq = int(existing[-1].get("seq", len(existing) - 1)) + 1
                self._last_hash = existing[-1].get("hash", "")

    @staticmethod
    def _canon_bytes(entry: dict[str, Any]) -> bytes:
        """레코드의 canonical 직렬화(정렬키·조밀 구분자). 디스크 기록과 해싱이 같은 바이트를 쓰게(P5)."""
        return json.dumps(entry, sort_keys=True, ensure_ascii=False,
                          separators=(",", ":")).encode("utf-8")

    def _hash(self, entry: dict[str, Any]) -> str:
        body = {k: entry[k] for k in entry if k != "hash"}
        canon = self._canon_bytes(body)
        if self._key is not None:
            return hmac.new(self._key, canon, hashlib.sha256).hexdigest()
        return hashlib.sha256(canon).hexdigest()

    def checkpoint(self) -> dict[str, Any]:
        """외부 앵커용 서명 체크포인트. 이 값을 별도 저장소(WORM/원격/서명)로 보내면, 나중에
        파일이 통째로 위조돼도 root/서명 불일치로 검출된다. key 있으면 HMAC 서명 포함."""
        last = self._last_hash
        cp = {"seq": self._seq, "root": last, "count": len(self.entries()),
              "ts": round(time.time(), 3), "keyed": self._key is not None}
        if self._key is not None:
            cp["sig"] = hmac.new(self._key,
                                 f"{cp['seq']}|{last}|{cp['count']}".encode("utf-8"),
                                 hashlib.sha256).hexdigest()
        return cp

    def record(self, action: str, *, selector: str = "", collector: str = "",
               ok: bool = True, meta: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        with self._lock:
            ev = {
                "seq": self._seq,
                "ts": round(time.time(), 3),
                "action": action,          # authorize | query | blocked | note
                "selector": selector,
                "collector": collector,
                "ok": bool(ok),
                "meta": meta or {},
                "prev": self._last_hash,
            }
            ev["hash"] = self._hash(ev)
            self._seq += 1
            self._last_hash = ev["hash"]
            self._mem.append(ev)
            if self.path:
                # 기록시점 **canonical bytes** 를 그대로 디스크에 쓴다(리뷰 P5): 해싱 대상(_canon_bytes)과
                # 디스크 바이트가 동일 → '디스크의 그 바이트'를 봉인. 예전엔 non-canonical 로 쓰고 검증 때
                # 재직렬화를 해싱해 float/유니코드 round-trip 에서 오탐 여지가 있었다.
                line = self._canon_bytes(ev).decode("utf-8") + "\n"
                if self.durability == "buffer":
                    self._pending.append(ev)               # 나중에 flush()/close() 에서 기록
                else:
                    with open(self.path, "a", encoding="utf-8") as f:
                        f.write(line)
                        f.flush()
                        if self.durability == "sync":
                            os.fsync(f.fileno())           # batch 는 fsync 생략(처리량↑)
        return ev

    def flush(self) -> None:
        """buffer 모드의 미기록 레코드를 파일에 내리고 fsync. 다른 모드에서도 안전(no-op에 가까움)."""
        with self._lock:
            if self.path and self._pending:
                with open(self.path, "a", encoding="utf-8") as f:
                    for ev in self._pending:
                        f.write(self._canon_bytes(ev).decode("utf-8") + "\n")   # canonical(P5)
                    f.flush()
                    os.fsync(f.fileno())
                self._pending = []

    def close(self) -> None:
        self.flush()

    def entries(self) -> list[dict[str, Any]]:
        if self.path and os.path.exists(self.path):
            out: list[dict[str, Any]] = []
            with open(self.path, encoding="utf-8") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln:
                        out.append(json.loads(ln))
            if self._pending:                 # buffer 모드: 아직 파일에 안 쓴 레코드도 포함(정합성)
                out.extend(self._pending)
            return out
        return list(self._mem)

    def entries_iter(self):
        """감사 로그를 **한 줄씩** 파싱해 yield(전량 메모리 로드 없이 대용량 검증, 축9)."""
        if self.path and os.path.exists(self.path):
            with open(self.path, encoding="utf-8") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln:
                        yield json.loads(ln)
            for ev in self._pending:
                yield ev
        else:
            for ev in self._mem:
                yield ev

    def verify_chain_stream(self) -> tuple[bool, Optional[int], str]:
        """entries_iter 로 스트리밍 검증 — O(1) 메모리. 대용량 로그에서 verify_chain 대체(축9)."""
        prev = ""
        i = -1
        for i, e in enumerate(self.entries_iter()):
            if "hash" not in e or "prev" not in e:
                return False, i, "해시 필드 없음(체인 아님)"
            if e.get("seq") != i:
                return False, i, f"seq 불연속(기대 {i}, 실제 {e.get('seq')})"
            if e["prev"] != prev:
                return False, i, "prev 링크 단절(삭제/삽입/재배열 의심)"
            if self._hash(e) != e["hash"]:
                return False, i, "해시 불일치(내용 변조)"
            prev = e["hash"]
        return True, None, "무결"

    def counts(self) -> dict[str, int]:
        c: dict[str, int] = {}
        for e in self.entries():
            c[e["action"]] = c.get(e["action"], 0) + 1
        return c

    def verify_chain(self, entries: Optional[list[dict[str, Any]]] = None
                     ) -> tuple[bool, Optional[int], str]:
        """체인 검증. 반환 (ok, 첫 이상 인덱스 or None, 사유).

        검출: 해시 변조, prev 링크 단절(삭제/삽입/재배열), seq 불연속.
        """
        es = entries if entries is not None else self.entries()
        prev = ""
        for i, e in enumerate(es):
            if "hash" not in e or "prev" not in e:
                return False, i, "해시 필드 없음(체인 아님)"
            if e.get("seq") != i:
                return False, i, f"seq 불연속(기대 {i}, 실제 {e.get('seq')})"
            if e["prev"] != prev:
                return False, i, "prev 링크 단절(삭제/삽입/재배열 의심)"
            if self._hash(e) != e["hash"]:
                return False, i, "해시 불일치(내용 변조)"
            prev = e["hash"]
        return True, None, "무결"
