"""대규모 그래프 직렬화 — 스트리밍 NDJSON + Neo4j Cypher export.

Graph.to_json 은 전체를 하나의 dict 로 만들어 한 번에 직렬화한다(거대 그래프에서 메모리 스파이크).
여기서는 레코드 단위로 흘려 쓰고 읽어 **피크 메모리를 유계**로 만들고(그래프 자체 크기 외 추가
버퍼 없음), Neo4j 승격 경로(Cypher MERGE)를 제공한다.

- stream_ndjson(graph, path)   : 엔티티/간선을 한 줄에 하나씩 JSONL 로 기록
- load_ndjson(path) -> Graph   : JSONL 을 다시 그래프로(엔티티 먼저, 간선 나중 — link 규약)
- to_cypher(graph) -> iter[str]: Neo4j MERGE 문 스트림(cypher-shell 파이프용)
- write_cypher(graph, path)    : 위를 파일로

NDJSON 레코드: {"t":"E","d":<entity.to_dict()>} 또는 {"t":"L","d":<edge.to_dict()>}.
"""
from __future__ import annotations

import glob
import gzip
import hashlib
import io
import json
import re
import os
from typing import Iterator

from .model import Entity, Edge, Graph


def _open(path: str, mode: str):
    """.gz 면 gzip 으로, 아니면 일반. 텍스트 모드 UTF-8."""
    if path.endswith(".gz"):
        return io.TextIOWrapper(gzip.open(path, mode.replace("t", "") + "b"),
                                encoding="utf-8")
    return open(path, mode, encoding="utf-8")


def stream_ndjson(graph: Graph, path: str) -> int:
    """엔티티→간선 순으로 한 줄씩 기록(메모리 유계). .gz 경로면 gzip 스트리밍. 레코드 수 반환."""
    n = 0
    with _open(path, "wt") as f:
        for e in graph.entities:
            f.write(json.dumps({"t": "E", "d": e.to_dict()}, ensure_ascii=False))
            f.write("\n")
            n += 1
        for ed in graph.edges:
            f.write(json.dumps({"t": "L", "d": ed.to_dict()}, ensure_ascii=False))
            f.write("\n")
            n += 1
    return n


def iter_ndjson(path: str) -> Iterator[dict]:
    """파일을 한 줄씩 파싱해 레코드를 흘린다(.gz 자동, 전체를 메모리에 올리지 않음)."""
    with _open(path, "rt") as f:
        for ln in f:
            ln = ln.strip()
            if ln:
                yield json.loads(ln)


def load_ndjson(path: str) -> Graph:
    """JSONL → Graph. 엔티티를 먼저 넣고 간선을 나중에 link(끝점 존재 규약)."""
    g = Graph()
    pending_edges: list[dict] = []
    for rec in iter_ndjson(path):
        t = rec.get("t")
        if t == "E":
            g.add(Entity.from_dict(rec["d"]))
        elif t == "L":
            pending_edges.append(rec["d"])
    for d in pending_edges:
        g.link(Edge.from_dict(d))
    return g


def _shard(key: str, shards: int) -> int:
    return int(hashlib.md5(key.encode("utf-8")).hexdigest(), 16) % shards


def shard_ndjson(graph: Graph, dir_path: str, shards: int = 4,
                 gzip_out: bool = True) -> dict:
    """엔티티/간선을 shards 개 파일로 분할 기록(프로세스별 병렬 로드 가능).

    entities-<i>.ndjson[.gz] / edges-<i>.ndjson[.gz]. 엔티티는 key 해시, 간선은 src 해시로 분배.
    로드 시 모든 entity 샤드를 먼저, 그 뒤 edge 샤드(끝점 존재 규약). 반환 {entities, edges, shards}.
    """
    os.makedirs(dir_path, exist_ok=True)
    ext = ".ndjson.gz" if gzip_out else ".ndjson"
    ef = [_open(os.path.join(dir_path, f"entities-{i}{ext}"), "wt") for i in range(shards)]
    lf = [_open(os.path.join(dir_path, f"edges-{i}{ext}"), "wt") for i in range(shards)]
    ne = nl = 0
    try:
        for e in graph.entities:
            ef[_shard(e.key, shards)].write(
                json.dumps({"t": "E", "d": e.to_dict()}, ensure_ascii=False) + "\n")
            ne += 1
        for ed in graph.edges:
            lf[_shard(ed.src, shards)].write(
                json.dumps({"t": "L", "d": ed.to_dict()}, ensure_ascii=False) + "\n")
            nl += 1
    finally:
        for f in ef + lf:
            f.close()
    return {"entities": ne, "edges": nl, "shards": shards}


def _parse_shard_file(path: str):
    """샤드 파일 하나를 파싱해 (entity_dicts, edge_dicts) 반환. ProcessPool 워커(톱레벨)."""
    ents, edges = [], []
    for rec in iter_ndjson(path):
        t = rec.get("t")
        if t == "E":
            ents.append(rec["d"])
        elif t == "L":
            edges.append(rec["d"])
    return ents, edges


def parallel_load_shards(dir_path: str, workers: int = 4,
                         use_processes: bool = True) -> Graph:
    """샤드 파싱(CPU json)을 워커로 병렬화, Graph 조립은 메인(dedup 단일스레드).

    엔티티 샤드를 먼저 파싱·삽입, 그 뒤 간선 샤드(끝점 존재 규약). use_processes=False 면 스레드.
    """
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
    epaths = sorted(glob.glob(os.path.join(dir_path, "entities-*.ndjson*")))
    lpaths = sorted(glob.glob(os.path.join(dir_path, "edges-*.ndjson*")))
    Executor = ProcessPoolExecutor if use_processes else ThreadPoolExecutor
    g = Graph()
    with Executor(max_workers=max(1, workers)) as ex:
        for ents, _ in ex.map(_parse_shard_file, epaths):
            for d in ents:
                g.add(Entity.from_dict(d))
        for _, edges in ex.map(_parse_shard_file, lpaths):
            for d in edges:
                g.link(Edge.from_dict(d))
    return g


def stream_load_shards(dir_path: str, workers: int = 4) -> Graph:
    """경량 병렬 로드 — 스레드가 샤드를 **라인 단위 스트리밍**(per-shard 리스트/IPC 없이)
    락 보호 그래프에 직접 삽입. 피크 메모리 유계(한 번에 한 레코드). 엔티티→간선 2단계.

    parallel_load_shards(process) 대비: IPC/피클링 0, 메모리 가벼움. json 은 GIL 바운드라
    CPU 병렬성은 낮지만 gzip 해제·I/O 는 겹친다(가벼움·안정성 우선 경로)."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    g = Graph()
    lock = threading.Lock()
    epaths = sorted(glob.glob(os.path.join(dir_path, "entities-*.ndjson*")))
    lpaths = sorted(glob.glob(os.path.join(dir_path, "edges-*.ndjson*")))

    def load_entities(path):
        for rec in iter_ndjson(path):
            if rec.get("t") == "E":
                e = Entity.from_dict(rec["d"])
                with lock:
                    g.add(e)

    def load_edges(path):
        for rec in iter_ndjson(path):
            if rec.get("t") == "L":
                ed = Edge.from_dict(rec["d"])
                with lock:
                    g.link(ed)

    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        list(ex.map(load_entities, epaths))
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        list(ex.map(load_edges, lpaths))
    return g


def push_to_neo4j(graph: Graph, run, *, batch_size: int = 1000, retries: int = 3,
                  base_delay: float = 0.1, sleep=None, **cy_kw) -> dict:
    """to_cypher_batch 를 run(statement, parameters) 콜러블로 트랜잭션 단위 적재.

    run 예(neo4j 파이썬 드라이버):
        with driver.session() as s:
            push_to_neo4j(g, lambda stmt, params: s.execute_write(lambda tx: tx.run(stmt, **params)))
    예외 시 지터 지수백오프로 최대 retries 재시도(일시 장애 흡수). sleep 은 테스트 주입용.
    반환 {batches, statements_run, retried}.
    """
    import random
    import time as _t
    slp = sleep or _t.sleep
    batches = runs = retried = 0
    for b in to_cypher_batch(graph, batch_size=batch_size, **cy_kw):
        batches += 1
        for attempt in range(retries + 1):
            try:
                run(b["statement"], b["parameters"])
                runs += 1
                break
            except Exception:
                if attempt >= retries:
                    raise
                retried += 1
                slp(base_delay * (2 ** attempt) * (0.5 + random.random()))
    return {"batches": batches, "statements_run": runs, "retried": retried}


def load_ndjson_dir(dir_path: str) -> Graph:
    """shard_ndjson 로 나눈 디렉터리를 로드(엔티티 샤드 전체 → 간선 샤드 전체)."""
    g = Graph()
    for p in sorted(glob.glob(os.path.join(dir_path, "entities-*.ndjson*"))):
        for rec in iter_ndjson(p):
            if rec.get("t") == "E":
                g.add(Entity.from_dict(rec["d"]))
    for p in sorted(glob.glob(os.path.join(dir_path, "edges-*.ndjson*"))):
        for rec in iter_ndjson(p):
            if rec.get("t") == "L":
                g.link(Edge.from_dict(rec["d"]))
    return g


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _ident(name: str, what: str) -> str:
    """Cypher 라벨/관계타입 식별자 검증(리뷰 P1). 값은 파라미터라이즈되지만 label/rel_type 은
    쿼리 문자열에 직접 들어가므로, 외부입력이면 injection 위험. 안전한 식별자만 허용."""
    if not _IDENT_RE.match(name or ""):
        raise ValueError(f"안전하지 않은 {what} 식별자: {name!r} (허용: [A-Za-z_][A-Za-z0-9_]*)")
    return name


def to_cypher_batch(graph: Graph, batch_size: int = 1000,
                    entity_label: str = "Asset", rel_type: str = "LINK"
                    ) -> Iterator[dict]:
    """파라미터라이즈드 배치 — {statement, parameters}. 값은 전부 $rows 로(injection-safe),
    label/rel_type 은 식별자 검증(리뷰 P1). 간선에 evidence_lower/upper/decision 도 보존해
    Python 그래프와 Neo4j 그래프의 통계적 의미가 일치하게 한다(리뷰 P1)."""
    entity_label = _ident(entity_label, "entity_label")
    rel_type = _ident(rel_type, "rel_type")
    ents = graph.entities
    node_stmt = (f"UNWIND $rows AS row "
                 f"MERGE (n:{entity_label} {{key: row.key}}) "
                 f"SET n.type=row.type, n.value=row.value, "
                 f"n.certainty=row.certainty, n.confidence=row.confidence")
    for i in range(0, len(ents), batch_size):
        rows = [{"key": e.key, "type": e.type.value, "value": e.value,
                 "certainty": e.certainty.value, "confidence": e.confidence}
                for e in ents[i:i + batch_size]]
        yield {"statement": node_stmt, "parameters": {"rows": rows}}
    edges = graph.edges
    edge_stmt = (f"UNWIND $rows AS row "
                 f"MATCH (a:{entity_label} {{key: row.src}}), "
                 f"(b:{entity_label} {{key: row.dst}}) "
                 f"MERGE (a)-[r:{rel_type} {{relation: row.relation}}]->(b) "
                 f"SET r.certainty=row.certainty, r.confidence=row.confidence, "
                 f"r.evidence_lower=row.evidence_lower, r.evidence_upper=row.evidence_upper, "
                 f"r.decision=row.decision, r.evidence_count=row.evidence_count")
    for i in range(0, len(edges), batch_size):
        rows = [{"src": ed.src, "dst": ed.dst, "relation": ed.relation,
                 "certainty": ed.certainty.value, "confidence": ed.confidence,
                 "evidence_lower": getattr(ed, "evidence_lower", None),
                 "evidence_upper": getattr(ed, "evidence_upper", None),
                 "decision": getattr(ed, "decision", None),
                 "evidence_count": len(ed.evidence)}
                for ed in edges[i:i + batch_size]]
        yield {"statement": edge_stmt, "parameters": {"rows": rows}}


def _cy(s) -> str:
    """Cypher 문자열 리터럴 이스케이프(백슬래시·작은따옴표)."""
    return str(s).replace("\\", "\\\\").replace("'", "\\'")


def _num(x) -> str:
    return "null" if x is None else repr(float(x))


def to_cypher(graph: Graph, entity_label: str = "Asset",
              rel_type: str = "LINK") -> Iterator[str]:
    """Neo4j MERGE 문 스트림. 노드 key 로 MERGE(중복 병합), 간선은 (relation) 별로 MERGE."""
    entity_label = _ident(entity_label, "entity_label")
    rel_type = _ident(rel_type, "rel_type")
    for e in graph.entities:
        yield (f"MERGE (n:{entity_label} {{key:'{_cy(e.key)}'}}) "
               f"SET n.type='{_cy(e.type.value)}', n.value='{_cy(e.value)}', "
               f"n.certainty='{_cy(e.certainty.value)}', "
               f"n.confidence={_num(e.confidence)};")
    for ed in graph.edges:
        # 증거구간/decision 을 batch export 와 동일하게 보존(리뷰 P1: 세 export 경로가 같은 의미
        # 그래프를 만들어야 한다). decision 은 없으면 null.
        dec = getattr(ed, "decision", None)
        dec_lit = "null" if dec is None else f"'{_cy(dec)}'"
        yield (f"MATCH (a:{entity_label} {{key:'{_cy(ed.src)}'}}), "
               f"(b:{entity_label} {{key:'{_cy(ed.dst)}'}}) "
               f"MERGE (a)-[r:{rel_type} {{relation:'{_cy(ed.relation)}'}}]->(b) "
               f"SET r.certainty='{_cy(ed.certainty.value)}', "
               f"r.confidence={_num(ed.confidence)}, "
               f"r.evidence_lower={_num(getattr(ed, 'evidence_lower', None))}, "
               f"r.evidence_upper={_num(getattr(ed, 'evidence_upper', None))}, "
               f"r.decision={dec_lit}, r.evidence_count={len(ed.evidence)};")


def write_cypher(graph: Graph, path: str, **kw) -> int:
    """to_cypher 를 파일로. 기록한 문(statement) 수 반환."""
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for stmt in to_cypher(graph, **kw):
            f.write(stmt + "\n")
            n += 1
    return n
