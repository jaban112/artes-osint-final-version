"""사람 축 OSINT — 공개출처 유출 노출(breach exposure) 파악. HIBP 모델(합법·인가·감사 전제).

설계 원칙(사용자·정책 합의):
  - **식별자는 보여준다**: 유출된 이메일/아이디(=검색한 selector, 그리고 같은 레코드에 함께 있는
    다른 아이디)를 당사자에게 노출한다 → 당사자가 "이 아이디가 진짜 내 것인가"를 확인할 수 있다.
    (유출 여부만 알면 소용없다 — 어느 식별자가 걸렸는지 알아야 조치한다.)
  - **자격증명은 절대 안 본다**: 비밀번호·해시·secret 은 authz.redact_credentials 로 전량 제거.
    presence(존재)/count(개수)/breach 메타(이름·날짜·데이터클래스)만 남긴다.
  - **거버넌스**: 인가 scope(consent/legal/self-audit/osint-public)에서 person_allowed 이고 그 selector 가
    인가됐을 때만 조회. 매 조회 감사(scope.check). '대규모'는 인가된 selector 집합에 한해서만.

corpus 는 운영자가 공급한다(이 모듈은 유출 데이터를 내장하지 않는다 — 메커니즘만 제공). corpus 형식:
  { identifier(email/username) : [ {breach, date, data_classes:[...], identifiers:[...], ...}, ... ] }
records 안의 자격증명 필드는 로드 시 즉시 redact 된다. 순수 stdlib.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .authz import redact_credentials, normalize_selector
from .model import Graph, Entity, Edge, EntityType, Certainty, Evidence

REL_EXPOSED_IN = "유출노출(공개출처)"          # 식별자 → breach
REL_SAME_RECORD = "동일레코드식별자(확인용)"    # 이메일 ↔ 같은 유출 레코드의 아이디(당사자 확인용)


# breach 레코드 **allowlist**(리뷰 P7): 오직 이 키들만 corpus 에서 살아남는다 → 자격증명은 어떤 이름으로
# 와도(비-allowlist) 로드 시점에 제거된다. 이것이 '문서화된 보장'(denylist 는 2차 방어일 뿐).
_BREACH_ALLOWED = {"breach", "name", "title", "date", "added", "modified", "data_classes",
                   "dataclasses", "identifiers", "description", "domain", "source", "count",
                   "pwn_count", "pwncount", "same_subject", "subject"}


@dataclass
class BreachPresenceSource:
    """운영자 공급 유출 corpus 에 대한 presence 조회.

    보장(P7): corpus 로드 시 각 레코드를 **allowlist** 로 필터(안전 키만) + redact_credentials 2차 방어.
    → 비밀번호·해시 등은 어떤 필드명으로 와도 저장본에 남지 않는다(denylist 우회 불가)."""
    corpus: dict = field(default_factory=dict)

    def __post_init__(self):
        clean = {}
        for ident, recs in (self.corpus or {}).items():
            key = normalize_selector(str(ident))
            out = []
            for r in recs:
                allowed = {k: v for k, v in dict(r).items() if str(k).strip().lower() in _BREACH_ALLOWED}
                out.append(redact_credentials(allowed))   # allowlist(1차) + denylist 재귀(2차)
            clean[key] = out
        self.corpus = clean

    def lookup(self, identifier: str) -> dict:
        """식별자의 유출 노출 요약. presence/count/breach 메타/(단일주체) 함께 노출된 식별자만.

        P8(제3자 spill 방지): linked_identifiers 는 레코드가 same_subject=True 로 '이 레코드의 식별자는
        모두 동일 주체'임을 명시한 경우에만 노출한다. 미명시 레코드의 동석 식별자는 제3자일 수 있어
        withheld 로 카운트만(경고). corpus 스키마 계약: 레코드=단일 주체(같이 넣으려면 same_subject=True)."""
        key = normalize_selector(str(identifier))
        recs = self.corpus.get(key, [])
        breaches = []
        linked_ids = set()
        withheld = 0
        for r in recs:
            breaches.append({"breach": r.get("breach", r.get("name", "?")), "date": r.get("date"),
                             "data_classes": r.get("data_classes") or r.get("dataclasses") or []})
            same_subject = bool(r.get("same_subject", False))   # 기본 False → 보수적(spill 방지)
            for other in r.get("identifiers", []):
                on = normalize_selector(str(other))
                if not on or on == key:
                    continue
                if same_subject:
                    linked_ids.add(other)          # 단일주체 명시 → 당사자 확인용 아이디로 노출
                else:
                    withheld += 1                  # 제3자일 수 있음 → 노출 안 함(카운트만)
        out = {"identifier": identifier, "present": bool(recs), "breach_count": len(recs),
               "breaches": breaches, "linked_identifiers": sorted(linked_ids),
               "note": "식별자·breach 메타만. 비밀번호/해시 등 자격증명은 정책상 제외(allowlist)."}
        if withheld:
            out["withheld_cooccurring_identifiers"] = withheld
            out["third_party_warning"] = (f"{withheld}개 동석 식별자는 same_subject 미명시라 보류(제3자 "
                                          f"spill 방지, 리뷰 P8). 단일주체면 corpus 레코드에 same_subject:true.")
        return out


def _ident_entity_type(identifier: str) -> EntityType:
    return EntityType.EMAIL if "@" in identifier else EntityType.USERNAME


class PersonRecon:
    """인가된 사람 selector 집합에 대해 공개출처 유출 노출을 파악한다(식별자 확인 가능, 자격증명 제외).

    scope 는 AuthorizationScope(person_allowed 이어야 함). source 는 BreachPresenceSource.
    매 조회 scope.check 로 인가 재검증 + 감사. 결과는 Graph(식별자 엔티티 + breach 노출 간선 +
    동일레코드 식별자 교차링크). 당사자가 '이 아이디가 내 것인가'를 그래프에서 확인할 수 있다."""

    def __init__(self, scope, source: "Optional[BreachPresenceSource]" = None, *,
                 username_source: "Optional[UsernamePresenceSource]" = None,
                 email_enrich: bool = False, mx_resolver=None,
                 keyserver_source: "Optional[KeyserverSource]" = None):
        self.scope = scope
        self.source = source
        self.username_source = username_source   # 아이디 공개 프로필 존재 조회(선택)
        self.email_enrich = email_enrich         # 이메일 공개 enrichment(gravatar/disposable/mx, 선택)
        self.mx_resolver = mx_resolver
        self.keyserver_source = keyserver_source # PGP 공개키서버(이메일→공개키/UID, 선택)
        self.graph = Graph()
        self.skipped: list = []
        self.findings: list = []
        self.enrichments: list = []

    def run(self, selectors) -> Graph:
        from .authz import AuthorizationError
        if self.scope is None or not self.scope.person_allowed():
            # 인가 없거나 사람 조회 불허 → 아무것도 조회하지 않는다(사인 무단 조회 금지).
            for s in selectors:
                self.skipped.append((s, "사람 selector: 인가 scope(person_allowed) 필요"))
            return self.graph
        for sel in selectors:
            et = _ident_entity_type(sel)
            try:
                self.scope.check(sel, et.value, collector="breach-presence")   # 인가 재검증 + 감사
            except AuthorizationError:
                self.skipped.append((sel, "미인가(인가목록에 없음)"))
                continue
            res = self.source.lookup(sel) if self.source is not None else {
                "identifier": sel, "present": False, "breach_count": 0, "breaches": [],
                "linked_identifiers": []}
            ident = Entity(type=et, value=sel, certainty=Certainty.CONFIRMED,
                           evidence=[Evidence("입력", "인가된 사람 selector")],
                           attrs={"breach_present": res["present"], "breach_count": res["breach_count"]})
            # role/functional 계정 분류(개인 아님 플래그) + 전화 메타(결정적, 네트워크 없음)
            ident.attrs["role_account"] = classify_identifier_role(sel)["is_role_account"]
            _digits = _re.sub(r"\D", "", sel)
            if "@" not in sel and len(_digits) >= 7 and _re.match(r"^\+?[0-9()\-.\s]+$", sel):
                pi = phone_intel(sel)
                ident.attrs.update({"phone_valid": pi["valid_format"], "phone_country": pi["country"]})
            self.graph.add(ident)
            # PGP 공개키서버(선택) — 이메일→공개키 지문 + 같은 키 UID(동일 주체 별칭)
            if self.keyserver_source is not None and et == EntityType.EMAIL:
                ks = self.keyserver_source.lookup(sel)
                for k in ks.get("keys", []):
                    kent = self.graph.add(Entity(
                        type=EntityType.ACCOUNT, value=f"pgpkey:{k['fingerprint']}",
                        certainty=Certainty.CONFIRMED,
                        evidence=[Evidence("keyserver", f"공개키 {k['fingerprint']}")],
                        attrs={"kind": "pgp_public_key", "created": k.get("created")}))
                    self.graph.link(Edge(src=ident.key, dst=kent.key, relation=REL_PUBLICKEY,
                                         certainty=Certainty.CONFIRMED,
                                         evidence=[Evidence("keyserver", f"{sel} 공개키")]))
                for other in ks.get("same_subject_emails", []):   # 같은 키의 다른 이메일 = 동일 주체
                    oe = self.graph.add(Entity(type=EntityType.EMAIL, value=other,
                                               certainty=Certainty.UNCONFIRMED,
                                               evidence=[Evidence("keyserver", "같은 공개키 UID")]))
                    self.graph.link(Edge(src=ident.key, dst=oe.key, relation=REL_KEY_UID,
                                         certainty=Certainty.CONFIRMED,
                                         evidence=[Evidence("keyserver", f"{sel} 와 같은 공개키의 UID")]))
            # 아이디 공개 프로필 존재 조회(선택) — 인가 아이디만, 공개 존재여부만
            if self.username_source is not None and et == EntityType.USERNAME:
                up = self.username_source.lookup(sel)
                for hit in up.get("present_on", []):
                    pent = self.graph.add(Entity(
                        type=EntityType.ACCOUNT, value=f"{hit['site']}:{sel}", certainty=Certainty.CONFIRMED,
                        evidence=[Evidence("username-presence", hit["url"])],
                        attrs={"kind": "profile", "site": hit["site"], "url": hit["url"]}))
                    self.graph.link(Edge(src=ident.key, dst=pent.key, relation=REL_PROFILE_ON,
                                         certainty=Certainty.CONFIRMED,
                                         evidence=[Evidence("username-presence",
                                                   f"{sel} 공개 프로필: {hit['url']}")]))
                ident.attrs["public_profiles"] = len(up.get("present_on", []))
            # 이메일 공개 enrichment(선택) — gravatar/disposable/mx(공개·비민감)
            if self.email_enrich and et == EntityType.EMAIL:
                enr = email_enrichment(sel, mx_resolver=self.mx_resolver)
                self.enrichments.append(enr)
                ident.attrs.update({"disposable": enr["disposable"], "mx_present": enr["mx_present"],
                                    "gravatar_hash": enr["gravatar_hash"]})
                if enr["gravatar_hash"]:
                    gent = self.graph.add(Entity(
                        type=EntityType.ACCOUNT, value=f"gravatar:{enr['gravatar_hash']}",
                        certainty=Certainty.CONFIRMED,
                        evidence=[Evidence("email-enrich", enr["gravatar_profile_url"])],
                        attrs={"kind": "gravatar", "avatar_url": enr["gravatar_avatar_url"]}))
                    self.graph.link(Edge(src=ident.key, dst=gent.key, relation=REL_GRAVATAR,
                                         certainty=Certainty.CONFIRMED,
                                         evidence=[Evidence("email-enrich",
                                                   f"{sel} 공개 아바타(Gravatar)")]))
            for b in res["breaches"]:
                bent = Entity(type=EntityType.ACCOUNT, value=f"breach:{b['breach']}",
                              certainty=Certainty.CONFIRMED,
                              evidence=[Evidence("breach-presence", f"유출: {b['breach']}")],
                              attrs={"kind": "breach", "date": b.get("date"),
                                     "data_classes": b.get("data_classes", [])})
                stored_b = self.graph.add(bent)          # 저장된 엔티티의 정규화 key 를 링크에 사용
                self.graph.link(Edge(src=ident.key, dst=stored_b.key, relation=REL_EXPOSED_IN,
                                     certainty=Certainty.CONFIRMED,
                                     evidence=[Evidence("breach-presence",
                                               f"{sel} 이(가) {b['breach']} 에 노출(식별자만)")]))
            # 당사자 확인용: 같은 레코드에 함께 노출된 다른 식별자를 링크(자격증명 아님)
            for other in res["linked_identifiers"]:
                oe = Entity(type=_ident_entity_type(other), value=other, certainty=Certainty.UNCONFIRMED,
                            evidence=[Evidence("breach-presence", "동일 유출 레코드의 식별자")])
                self.graph.add(oe)
                self.graph.link(Edge(src=ident.key, dst=oe.key, relation=REL_SAME_RECORD,
                                     certainty=Certainty.UNCONFIRMED,
                                     evidence=[Evidence("breach-presence",
                                               f"{sel} 와 같은 유출 레코드에 있던 식별자(본인 확인용)")]))
            self.findings.append(res)
        return self.graph

    def report(self) -> dict:
        exposed = [f for f in self.findings if f["present"]]
        return {"checked": len(self.findings), "exposed": len(exposed),
                "skipped": len(self.skipped),
                "findings": self.findings,
                "enrichments": self.enrichments,
                "note": ("식별자·breach 메타/공개 프로필·gravatar 만 보고(당사자가 자기 아이디/이메일 "
                         "확인 가능). 비밀번호 등 자격증명은 정책상 제외.")}


# =========================================================================== #
# 추가 사람 축 도구(공개출처·인가·감사·자격증명 없음). Maltego/Maigret 계열의 합법 부분만.
# =========================================================================== #
import hashlib as _hashlib
import re as _re

REL_PROFILE_ON = "공개프로필존재"          # 아이디 → 사이트(공개 프로필)
REL_GRAVATAR = "공개아바타(Gravatar)"      # 이메일 → 공개 아바타
REL_SAME_PERSON = "동일인후보(신호공유)"    # 식별자 ↔ 식별자(확정 아님 — 후보)

# 아이디 존재 조회용 공개 사이트 URL 템플릿(Maigret/Sherlock 모델의 합법 부분). {u}=username.
# 운영자가 교체·확장 가능. 프로필 페이지 존재 여부(공개)만 본다 — 스크레이핑/자격증명 없음.
DEFAULT_USERNAME_SITES = {
    "github": "https://github.com/{u}",
    "gitlab": "https://gitlab.com/{u}",
    "reddit": "https://www.reddit.com/user/{u}",
    "medium": "https://medium.com/@{u}",
    "keybase": "https://keybase.io/{u}",
    "hackernews": "https://news.ycombinator.com/user?id={u}",
    "dev.to": "https://dev.to/{u}",
    "pypi": "https://pypi.org/user/{u}",
    "npm": "https://www.npmjs.com/~{u}",
    "dockerhub": "https://hub.docker.com/u/{u}",
    "telegram": "https://t.me/{u}",
    "instagram": "https://www.instagram.com/{u}",
    "x": "https://x.com/{u}",
    "youtube": "https://www.youtube.com/@{u}",
    "tiktok": "https://www.tiktok.com/@{u}",
}

# 일회용/임시 이메일 도메인(부분 목록) — 이메일이 실제 개인인지 판별에 유용(공개 사실).
_DISPOSABLE_EMAIL_DOMAINS = {
    "mailinator.com", "guerrillamail.com", "10minutemail.com", "tempmail.com",
    "temp-mail.org", "throwawaymail.com", "yopmail.com", "trashmail.com",
    "getnada.com", "maildrop.cc", "dispostable.com", "fakeinbox.com", "sharklasers.com",
}

_USERNAME_OK = _re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
_EMAIL_FMT = _re.compile(r"^[^@\s]+@[a-z0-9.-]+\.[a-z]{2,}$", _re.I)


def username_candidate_urls(username: str, sites: Optional[dict] = None) -> dict:
    """아이디의 공개 프로필 후보 URL(네트워크 없이 결정적으로 구성). {site: url}.
    '어디에 있을 수 있나' — 실제 존재 확인은 UsernamePresenceSource(probe 주입)로."""
    sites = sites or DEFAULT_USERNAME_SITES
    u = (username or "").strip().lstrip("@")
    if not _USERNAME_OK.match(u):
        return {}
    return {name: tmpl.replace("{u}", u) for name, tmpl in sites.items()}


@dataclass
class UsernamePresenceSource:
    """아이디 공개 프로필 존재 조회(Maigret/Sherlock 모델의 합법 부분).

    probe(url) -> bool|None: 그 URL 에 공개 프로필이 존재하는가(True/False), None=미확인. 주입식이라
    오프라인 테스트 가능(기본 None → 후보 URL 만 반환, 존재는 unchecked). 실제 probe 는 SafeOutbound 로
    HTTP presence(200=존재, 404=없음)만 본다 — 페이지 내용 스크레이핑·자격증명 없음. 인가 selector 만."""
    sites: dict = field(default_factory=lambda: dict(DEFAULT_USERNAME_SITES))
    probe: Optional[object] = None      # callable(url)->bool|None

    def lookup(self, username: str) -> dict:
        cands = username_candidate_urls(username, self.sites)
        present_on, unchecked = [], []
        for site, url in cands.items():
            hit = self.probe(url) if callable(self.probe) else None
            if hit is True:
                present_on.append({"site": site, "url": url})
            elif hit is None:
                unchecked.append({"site": site, "url": url})
        return {"username": username, "candidate_count": len(cands),
                "present_on": present_on, "unchecked": unchecked,
                "checked": self.probe is not None,
                "note": "공개 프로필 존재 여부만(페이지 내용·자격증명 없음). 인가 아이디만 조회."}

    async def lookup_async(self, username: str, aprobe, *, concurrency: int = 16) -> dict:
        """사이트들을 **동시 probe**(성능). aprobe(url)->bool|None(코루틴). 세마포어로 동시성 제한.

        15+ 사이트를 순차로 치면 느리다 — gather 로 병렬화(네트워크 바운드에서 큰 이득). presence 만."""
        import asyncio
        cands = username_candidate_urls(username, self.sites)
        sem = asyncio.Semaphore(max(1, concurrency))

        async def one(site, url):
            async with sem:
                try:
                    return site, url, await aprobe(url)
                except Exception:
                    return site, url, None
        results = await asyncio.gather(*[one(s, u) for s, u in cands.items()])
        present_on = [{"site": s, "url": u} for (s, u, hit) in results if hit is True]
        unchecked = [{"site": s, "url": u} for (s, u, hit) in results if hit is None]
        return {"username": username, "candidate_count": len(cands),
                "present_on": present_on, "unchecked": unchecked, "checked": True,
                "note": "동시 probe(성능). 공개 프로필 존재 여부만."}


def gravatar_hash(email: str) -> str:
    """이메일의 Gravatar 해시(정규화 후 md5) — Gravatar 설계상 공개 식별자(비밀 아님)."""
    return _hashlib.md5((email or "").strip().lower().encode("utf-8")).hexdigest()


def email_enrichment(email: str, *, mx_resolver=None) -> dict:
    """이메일의 공개·비민감 enrichment — '진짜·활성 이메일인가' 확인용(자격증명 없음).

    - 형식 유효성, 도메인, 일회용(disposable) 여부(공개 목록)
    - Gravatar 공개 아바타/프로필 URL(이메일→md5, Gravatar 는 공개 설계)
    - MX 존재(mx_resolver 주입 시; None 이면 미확인) — 도메인이 메일 수신 가능한가
    비밀번호·계정내용 등은 다루지 않는다."""
    e = (email or "").strip().lower()
    valid = bool(_EMAIL_FMT.match(e))
    domain = e.rsplit("@", 1)[-1] if "@" in e else ""
    gh = gravatar_hash(e) if valid else ""
    mx = None
    if valid and domain and callable(mx_resolver):
        try:
            mx = bool(mx_resolver(domain))
        except Exception:
            mx = None
    return {"email": email, "valid_format": valid, "domain": domain,
            "disposable": domain in _DISPOSABLE_EMAIL_DOMAINS,
            "gravatar_hash": gh,
            "gravatar_avatar_url": (f"https://www.gravatar.com/avatar/{gh}" if gh else ""),
            "gravatar_profile_url": (f"https://www.gravatar.com/{gh}" if gh else ""),
            "mx_present": mx,
            "note": "공개·비민감 enrichment(Gravatar 공개, disposable 판별, MX). 자격증명 없음."}


def same_person_candidates(sigmap: dict,
                           threshold: float = 1e-4, use_cp_upper: bool = True,
                           max_bucket: int = 256, order_correct: bool = True,
                           background=None, deconfound: "Optional[str]" = None,
                           min_stratum: int = 3, fdr: str = "") -> list:
    """식별자들이 공유하는 **희소 공개신호**로 '동일인 후보' 쌍을 낸다(확정 아님 — 후보).

    **인프라 same-operator 엔진(OperatorIndex)을 그대로 재사용**한다(성능·정확도):
      - 역인덱스 → 값 공유 **후보쌍만** 비교(O(n²) 회피). generic 억제(max_bucket). order-statistic 보정.
      - CP-upper. background(독립 배경 모집단 유병률).
    추가(강화):
      - deconfound=<confounder kind>: 플랫폼 등 교란자 층에서 **조건부** coincidence(같은 플랫폼 기본신호로
        엮이는 오탐 제거). deconfound.deconfounded_clusters 재사용, fallback_ratio 도 함께.
      - fdr='bh'|'by': 다중 후보쌍에 **FDR 통제**(BH 독립/BY 임의종속) — q_value 로 오탐률 관리.

    ⚠️ 참조 모집단 유병률은 **background=BackgroundCorpus** 로만 공급한다. 소표본 in-sample df 를
    임의 대형 N 으로 나눠 rarity 를 부풀리는 것(anti-conservative, 오탐↑)은 지원하지 않는다.

    sigmap = {identifier: {signal_kind: set(values)}} — 공개 신호(자격증명·생체 아님).
    반환 [{a,b,coincidence,shared,relation,candidate,(q_value)}]. ⚠️ 결과는 **후보** — 확정 아님."""
    if deconfound:                       # 교란자 층 조건부(플랫폼 confounding 제거)
        from .deconfound import deconfounded_clusters
        dc = deconfounded_clusters(sigmap, deconfound, threshold=threshold,
                                   min_stratum=min_stratum, max_bucket=max_bucket)
        pairs = [{"a": e["a"], "b": e["b"], "coincidence": e["coincidence"], "shared": None}
                 for e in dc["edges"]]
        meta = {"deconfounded": True, "fallback_ratio": dc["fallback_ratio"]}
    else:
        from .infra_recon import OperatorIndex
        kinds = tuple(sorted({k for s in sigmap.values() for k in s})) or ("_",)
        idx = OperatorIndex(n_signals=len(kinds), signal_kinds=kinds, max_bucket=max_bucket,
                            track_values=True, judge_cp=False)
        for ident, sig in sigmap.items():
            idx.add(ident, {k: set(v) for k, v in sig.items()})
        pairs = idx.coincidence_pairs(threshold=threshold, use_cp_upper=use_cp_upper,
                                      order_correct=order_correct, background=background)
        meta = {"deconfounded": False}
    out = [{"a": p["a"], "b": p["b"], "coincidence": p["coincidence"], "shared": p.get("shared"),
            "relation": REL_SAME_PERSON, "candidate": True, **meta} for p in pairs]
    if fdr:                              # 다중검정 FDR 통제(후보쌍 오탐률)
        from .fdr import fdr_edges
        fe = fdr_edges([(c["a"], c["b"], c["coincidence"]) for c in out], alpha=threshold, method=fdr)
        keep = {(e["a"], e["b"]): e["q_value"] for e in fe["edges"]}
        out = [{**c, "q_value": keep[(c["a"], c["b"])]} for c in out if (c["a"], c["b"]) in keep]
    return sorted(out, key=lambda x: x["coincidence"])


# =========================================================================== #
# 추가 배치 2 — 공개출처 사람 축 도구(전화 메타·PGP 공개키·CT 이메일 SAN·git 커밋·role 분류).
# 전부 공개·비민감·인가·감사. 개인키/자격증명/생체/제3자 spill 없음.
# =========================================================================== #
REL_PUBLICKEY = "공개키(PGP)"              # 이메일 → 공개키 지문
REL_KEY_UID = "동일키UID(동일주체)"         # 이메일 ↔ 같은 공개키의 다른 UID(동일 주체)
REL_CERT_SAN = "인증서SAN(S/MIME)"          # 이메일 → 인증서
REL_COMMIT_EMAIL = "공개커밋이메일"          # 아이디 → 공개 git 커밋 author 이메일
REL_LINKED_ACCOUNT = "공개연결계정(Gravatar)"  # 이메일 → gravatar 공개 연결 계정

# 국가 전화 calling code(주요국 부분표) — 전화 형식/국가 판별용(결정적, 네트워크 없음). 소유자 조회 아님.
_CALLING_CODES = {
    "1": "US/CA", "7": "RU/KZ", "20": "EG", "27": "ZA", "30": "GR", "31": "NL", "32": "BE",
    "33": "FR", "34": "ES", "36": "HU", "39": "IT", "40": "RO", "41": "CH", "44": "GB",
    "45": "DK", "46": "SE", "47": "NO", "48": "PL", "49": "DE", "51": "PE", "52": "MX",
    "54": "AR", "55": "BR", "56": "CL", "57": "CO", "60": "MY", "61": "AU", "62": "ID",
    "63": "PH", "64": "NZ", "65": "SG", "66": "TH", "81": "JP", "82": "KR", "84": "VN",
    "86": "CN", "90": "TR", "91": "IN", "92": "PK", "93": "AF", "94": "LK", "95": "MM",
    "234": "NG", "351": "PT", "352": "LU", "353": "IE", "358": "FI", "380": "UA", "420": "CZ",
    "421": "SK", "852": "HK", "886": "TW", "971": "AE", "972": "IL", "966": "SA", "852": "HK",
}
# role/functional 이메일 로컬파트(개인 아님 — targeting 오남용 방지에 유용).
_ROLE_LOCALPARTS = {
    "info", "admin", "administrator", "support", "help", "contact", "sales", "billing",
    "noreply", "no-reply", "donotreply", "postmaster", "webmaster", "abuse", "security",
    "hostmaster", "root", "hello", "team", "office", "mail", "marketing", "hr", "jobs",
    "careers", "press", "media", "legal", "privacy", "service", "notifications", "notify",
}


# 국가별 국번(national number) 기대 자릿수 범위(주요국) — '형식상 그럴듯한가' 정밀 판정용(결정적).
_NATIONAL_LEN = {
    "US/CA": (10, 10), "KR": (9, 10), "JP": (9, 10), "GB": (9, 10), "DE": (10, 11), "FR": (9, 9),
    "CN": (11, 11), "IN": (10, 10), "AU": (9, 9), "BR": (10, 11), "RU/KZ": (10, 10), "ES": (9, 9),
    "IT": (9, 11), "NL": (9, 9), "SG": (8, 8), "HK": (8, 8), "TW": (9, 9), "ID": (9, 12),
    "PH": (10, 10), "VN": (9, 10), "TH": (9, 9), "MY": (9, 10), "AE": (9, 9), "IL": (9, 9),
}


def phone_intel(phone: str) -> dict:
    """전화번호의 공개·비민감 메타(결정적 파싱, 네트워크 없음). **소유자 조회 아님** — 형식·국가만.

    E.164 형태(+국가코드 국번)를 파싱해 국가, 국번(national number), 형식 유효성 + 국가별 국번 자릿수까지
    보고 **plausible**(그럴듯함)를 정밀 판정한다. 통신사(HLR) 조회는 유료·민감이라 하지 않는다(정직)."""
    raw = (phone or "").strip()
    plus = raw.lstrip().startswith("+")
    digits = _re.sub(r"\D", "", raw)
    country = None
    national = digits
    if plus:                                  # +국가코드: longest-prefix 로 국가 판정
        for ln in (3, 2, 1):
            if len(digits) > ln and digits[:ln] in _CALLING_CODES:
                country = _CALLING_CODES[digits[:ln]]
                national = digits[ln:]
                break
    valid = 7 <= len(digits) <= 15            # E.164 전체 길이 범위
    # 국가별 국번 자릿수까지 맞아야 '그럴듯'(정확도↑): 국가 미상이면 형식만으로 판단(보수적 True).
    rng = _NATIONAL_LEN.get(country or "")
    plausible = valid and (rng is None or rng[0] <= len(national) <= rng[1])
    return {"phone": phone, "e164": ("+" + digits) if plus else digits,
            "valid_format": valid, "plausible": plausible, "has_country_code": plus,
            "country": country, "national_number": national, "national_len": len(national),
            "expected_national_len": (list(rng) if rng else None),
            "note": "형식·국가·국번 자릿수만(결정적). 통신사/소유자 조회 안 함(정직 — HLR 은 유료·민감)."}


def classify_identifier_role(identifier: str) -> dict:
    """식별자가 개인인지 role/functional 계정인지(info@·noreply@ 등). 개인 targeting 오남용 방지에 유용."""
    v = (identifier or "").strip().lower()
    local = v.split("@", 1)[0] if "@" in v else v
    local_base = _re.split(r"[._-]", local)[0] if local else ""
    is_role = local in _ROLE_LOCALPARTS or local_base in _ROLE_LOCALPARTS
    return {"identifier": identifier, "is_role_account": is_role,
            "kind": "role/functional" if is_role else "likely-individual",
            "note": "role 계정(info@ 등)은 개인이 아니므로 개인 대상 조사에서 구분/제외 가능."}


@dataclass
class KeyserverSource:
    """PGP 공개키서버(keys.openpgp.org 모델) — 이메일→**공개키** 지문/UID. 개인키는 절대 다루지 않는다.

    lookup(email) -> [{fingerprint, uids:[email...], created}] 주입식(오프라인 테스트). 같은 공개키의
    다른 UID 는 **동일 주체**(키 소유자가 등록한 자기 신원)이므로 same_subject 별칭으로 노출."""
    lookup_fn: Optional[object] = None        # callable(email)->list[dict]

    def lookup(self, email: str) -> dict:
        keys = list(self.lookup_fn(email)) if callable(self.lookup_fn) else []
        out_keys, linked = [], set()
        e = normalize_selector(email)
        for k in keys:
            fp = str(k.get("fingerprint", "")).strip()
            uids = [normalize_selector(str(u)) for u in k.get("uids", []) if u]
            out_keys.append({"fingerprint": fp, "uids": sorted(set(uids)), "created": k.get("created")})
            for u in uids:
                if u and u != e and "@" in u:
                    linked.add(u)              # 같은 키의 다른 이메일 = 동일 주체(공개키 소유자)
        return {"email": email, "present": bool(out_keys), "keys": out_keys,
                "same_subject_emails": sorted(linked),
                "note": "공개키 지문/UID 만(개인키 없음). 같은 키의 UID 는 동일 주체."}


@dataclass
class CTEmailSANSource:
    """Certificate Transparency 이메일 SAN(S/MIME 인증서) — 이메일→인증서 공개 메타(공개출처).

    lookup(email) -> [{issuer, not_before, not_after, serial}] 주입식. 인증서는 공개 로그. 개인키 없음."""
    lookup_fn: Optional[object] = None

    def lookup(self, email: str) -> dict:
        certs = list(self.lookup_fn(email)) if callable(self.lookup_fn) else []
        safe = [{"issuer": c.get("issuer"), "not_before": c.get("not_before"),
                 "not_after": c.get("not_after"), "serial": c.get("serial")} for c in certs]
        return {"email": email, "present": bool(safe), "certificates": safe,
                "note": "공개 CT 로그의 인증서 메타만(발급자·유효기간·시리얼). 개인키 없음."}


@dataclass
class GitCommitIdentitySource:
    """공개 git 커밋 author 이메일 — 아이디↔이메일 공개 연결(GitHub 등이 공개 노출).

    lookup_fn(username) -> [author_email...] 주입식. 공개 커밋 메타의 author 이메일만(공개). 커밋 내용 아님."""
    lookup_fn: Optional[object] = None

    def lookup(self, username: str) -> dict:
        emails = [normalize_selector(str(e)) for e in (self.lookup_fn(username) if callable(self.lookup_fn) else []) if e]
        emails = sorted({e for e in emails if "@" in e})
        return {"username": username, "commit_emails": emails, "present": bool(emails),
                "note": "공개 커밋 author 이메일만(아이디↔이메일 공개 연결). 커밋 내용/자격증명 없음."}


def gravatar_profile(email: str, *, fetch_fn=None) -> dict:
    """Gravatar 공개 프로필 확장 — 이메일→공개 연결 계정/URL(Gravatar 프로필은 공개 설계).

    fetch_fn(profile_url)->dict(공개 프로필 JSON) 주입식. 공개 accounts(연결 계정)·이름만. 비밀 없음."""
    gh = gravatar_hash(email)
    url = f"https://www.gravatar.com/{gh}.json" if gh else ""
    prof = {}
    if url and callable(fetch_fn):
        try:
            prof = fetch_fn(url) or {}
        except Exception:
            prof = {}
    entries = (prof.get("entry") or [{}])
    e0 = entries[0] if entries else {}
    accounts = [{"domain": a.get("domain"), "username": a.get("username"), "url": a.get("url")}
                for a in (e0.get("accounts") or [])]
    return {"email": email, "gravatar_hash": gh, "profile_url": f"https://www.gravatar.com/{gh}",
            "display_name": e0.get("displayName"), "linked_accounts": accounts,
            "note": "Gravatar 공개 프로필의 연결 계정/표시명만(공개). 비밀 없음."}


# =========================================================================== #
# 추가 배치 3 — 인프라+사람 **통합 신원 해소**(identity resolution / 피벗).
# 여러 공개출처 링크·상관 후보를 하나의 그래프로 합쳐 connected-component = 신원 클러스터.
# identity-bearing(신원부여) 관계만 union — 식별자↔사이트/breach 같은 비신원 엣지는 무시(오병합 방지).
# 확정(near-bijective 공개사실 브리지) vs 후보(통계 상관만)를 정직하게 구분해 보고.
# =========================================================================== #
# near-bijective 공개 사실(강한 브리지) — 같은 유출레코드 식별자, 같은 PGP 키 UID, 공개 커밋 author,
# Gravatar 공개 연결계정. 이들은 "같은 주체"를 공개 사실로 잇는다.
_DETERMINISTIC_BRIDGES = frozenset({REL_SAME_RECORD, REL_KEY_UID, REL_COMMIT_EMAIL, REL_LINKED_ACCOUNT})
# 통계 상관(약한 브리지) — 희소 신호 공유 동일인 후보(확정 아님).
_STATISTICAL_BRIDGES = frozenset({REL_SAME_PERSON})
_IDENTITY_BRIDGES = _DETERMINISTIC_BRIDGES | _STATISTICAL_BRIDGES


def resolve_identities(edges, *, correlation_pairs=None, min_coincidence: "Optional[float]" = None,
                       min_bridge_types: int = 1, extra_bridges=None) -> list:
    """공개출처 링크 + 동일인 상관 후보를 **한 그래프**로 합쳐 connected-component = 신원 클러스터(피벗).

    인프라↔사람 통합: 이메일/아이디 노드가 두 축에 함께 나타나면 자연히 한 요소로 합쳐진다(예: 도메인
    WHOIS 연락 이메일이 사람 축 selector 이기도 하면 두 축을 잇는다). extra_bridges 로 same-operator
    같은 인프라 관계를 브리지에 추가할 수 있다.

    정확도(오병합 방지):
      - **identity-bearing 관계만** union — 식별자↔사이트(REL_PROFILE_ON)·식별자↔breach(REL_EXPOSED_IN)·
        이메일↔아바타(REL_GRAVATAR) 같은 비신원 엣지는 무시(사이트 사용자 전원이 한 사람이 되는 붕괴 방지).
      - min_coincidence: 통계 상관엣지는 coincidence<=이 값일 때만 브리지로 인정(약한 상관 배제).
      - min_bridge_types: 한 쌍을 병합하려면 서로 다른 브리지 관계종류가 이 수 이상(단일신호 오병합 저항).

    edges: [(a,b,relation)] 또는 [{a,b,relation}]. correlation_pairs: same_person_candidates 반환형.
    반환 [{members,size,bridges,deterministic,confidence,min_coincidence}] — deterministic=True 는
    ≥1개 near-bijective 공개사실 브리지로 묶임(확정), False 는 통계 상관만(후보). ⚠️ 통계만인 클러스터는 후보."""
    from collections import defaultdict
    from .graph_analytics import connected_components
    bridges = set(_IDENTITY_BRIDGES) | set(extra_bridges or ())
    pair_types: dict = defaultdict(set)      # (a,b) -> {relation, ...}
    pair_coinc: dict = {}                    # (a,b) -> min coincidence(통계 브리지)
    for e in (edges or ()):
        if isinstance(e, dict):
            a, b, rel = e.get("a"), e.get("b"), e.get("relation")
        else:
            a, b, rel = e[0], e[1], e[2]
        if a is None or b is None or a == b or rel not in bridges:
            continue
        pair_types[tuple(sorted((a, b)))].add(rel)
    for p in (correlation_pairs or ()):
        a, b, c = p.get("a"), p.get("b"), p.get("coincidence")
        if a is None or b is None or a == b:
            continue
        if min_coincidence is not None and (c is None or c > min_coincidence):
            continue                          # 약한 상관은 브리지로 안 씀
        key = tuple(sorted((a, b)))
        pair_types[key].add(p.get("relation", REL_SAME_PERSON))
        if c is not None:
            pair_coinc[key] = min(pair_coinc.get(key, 1.0), c)
    adj: dict = defaultdict(set)
    confirmed: list = []
    nodes: set = set()
    for key, types in pair_types.items():
        nodes.update(key)
        if len(types) >= min_bridge_types:    # 충분한 브리지 종류로만 병합
            a, b = key
            adj[a].add(b); adj[b].add(a)
            confirmed.append((a, b, sorted(types)))
    for n in nodes:
        adj.setdefault(n, set())
    comps = connected_components({k: sorted(v) for k, v in adj.items()})
    out = []
    for comp in comps:
        if len(comp) < 2:
            continue
        cs = set(comp)
        rels: set = set()
        det = False
        mc = None
        for (a, b, types) in confirmed:
            if a in cs and b in cs:
                rels.update(types)
                if any(t in _DETERMINISTIC_BRIDGES for t in types):
                    det = True
                k = tuple(sorted((a, b)))
                if k in pair_coinc:
                    mc = pair_coinc[k] if mc is None else min(mc, pair_coinc[k])
        out.append({"members": sorted(comp), "size": len(comp), "bridges": sorted(rels),
                    "deterministic": det,
                    "confidence": "확인(공개사실 브리지)" if det else "후보(통계 상관만)",
                    "min_coincidence": mc})
    return sorted(out, key=lambda c: (-c["size"], c["members"]))
