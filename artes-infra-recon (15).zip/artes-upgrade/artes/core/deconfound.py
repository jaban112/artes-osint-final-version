"""교란자 조건부 coincidence — "공유 제공자 ≠ 동일 운영자". same-operator 최대 오탐원 완화.

문제: coincidence 는 공유 신호를 독립 증거로 곱한다. 하지만 두 도메인이 신호를 많이 공유하는
가장 흔한 이유는 같은 운영자가 아니라 **같은 제공자**(Cloudflare/AWS…)다. 제공자 P 가 공통 원인
(confounder): P → 신호공유, P → 둘 다 P 고객. 신호공유와 동일운영자엔 인과가 없는데 상관만 있어
∏(작은 q) 로 거짓 정밀도 폭탄 오탐이 난다.

해법(층화 조건부확률): 전역 df 대신 **관측된 교란자로 층화한 조건부** q(v│P) 를 쓴다.
  q(v│P) = (그 값을 가진 층-P 도메인 수 − 1) / (|층 P| − 1)
- 제공자 기본신호(P 고객이면 다 공유) → q≈1 → 잔차 증거 0. 오탐 사라짐.
- 층 P 안에서도 드문 신호 → 여전히 강한 증거.

■ 정직한 범위(리뷰 P9): 이건 **완결된 인과 디컨파운딩이 아니라, 관측된 교란자(들)로 조건화한
  conditional coincidence** 다. (1) 관측 안 된 교란자는 못 잡는다. (2) 여러 교란자가 동시에
  작용하면 그 **공동(joint) 층**으로 조건화해야 하는데, 이제 confounder_kind 를 여러 개 주면
  공유 교란자들의 **교집합 층**으로 공동 조건화한다(단일→여러 교란자 확장). (3) min_stratum 은
  정리에서 유도된 값이 아니라 **정책값**(층이 작으면 조건부 추정이 불안정 → 전역 폴백)이다 —
  이 점을 숨기지 않는다. 조건부확률 계산 자체는 정확(층 안 빈도)하다.

sigmap = {domain_key: {kind: set(values)}} (signals.gather_signals 출력). 순수 stdlib.
"""
from __future__ import annotations

import math
from collections import defaultdict


class Deconfounder:
    """교란자(들)로 층화한 조건부 coincidence. confounder_kind 는 str 또는 여러 축의 목록.

    여러 축을 주면 공유 교란자들의 **교집합 층**으로 공동 조건화한다(예: ['cloud_provider','asn']).
    """

    def __init__(self, sigmap: dict, confounder_kind):
        self.sig = sigmap
        self.ck = frozenset((confounder_kind,) if isinstance(confounder_kind, str)
                            else confounder_kind)
        self.N = len(sigmap)
        self.strata: dict = defaultdict(set)     # (kind,value) → 그 값을 가진 도메인 집합(=층)
        self.kv: dict = defaultdict(set)          # (kind,value) → 도메인 집합(전역)
        for d, s in sigmap.items():
            for k in self.ck:
                for cv in s.get(k, ()):
                    self.strata[(k, str(cv))].add(d)
            for k, vs in s.items():
                for v in vs:
                    self.kv[(k, str(v))].add(d)

    def _shared(self, a: str, b: str):
        """공유 (kind,value): shared=비교란 축, conf=교란 축(kind,value) 목록."""
        sa, sb = self.sig.get(a, {}), self.sig.get(b, {})
        shared, conf = [], []
        for k in set(sa) | set(sb):
            inter = {str(v) for v in sa.get(k, ())} & {str(v) for v in sb.get(k, ())}
            if k in self.ck:
                conf.extend((k, v) for v in inter)
            else:
                shared.extend((k, v) for v in inter)
        return shared, conf

    def _collapse(self, shared):
        """종속 축 붕괴(중첩 넷블록·IP파생·세트 double-count 제거) — signals.collapse_shared 재사용."""
        from .signals import collapse_shared
        return collapse_shared(shared, lambda k, v: len(self.kv[(k, str(v))]))

    def _global_coincidence(self, shared) -> float:
        if not shared or self.N < 2:
            return 1.0
        logp = 0.0
        for (k, v) in self._collapse(shared):
            q = (len(self.kv[(k, str(v))]) - 1) / (self.N - 1)
            if q <= 0.0:                          # df==1 → 우연 공유 확률 정확히 0
                return 0.0
            logp += math.log(min(1.0, q))
        return math.exp(logp)

    def _joint_stratum(self, conf):
        """공유 교란자들의 **교집합 층**(전부 공유하는 도메인) — 공동 조건화."""
        stratum = None
        for cv in conf:
            s = self.strata[cv]
            stratum = set(s) if stratum is None else (stratum & s)
        return stratum or set()

    def coincidence(self, a: str, b: str, stratified: bool = True,
                    min_stratum: int = 3) -> float:
        """a,b 의 공유 신호로 우연일치확률(공개 API — float 만). 계층 사용 여부는 coincidence_meta."""
        return self.coincidence_meta(a, b, stratified, min_stratum)[0]

    def coincidence_meta(self, a: str, b: str, stratified: bool = True,
                         min_stratum: int = 3) -> tuple:
        """(p, used_stratified) 반환. stratified=True 면 공유 교란자(들) 공동 층에서 조건부.

        공유 교란자가 있으면 그 **교집합 층**에서 q(v│층) 로 계산 → 제공자 기본 신호는 잔차 0.
        없거나 층이 min_stratum(정책값) 미만이면 전역 coincidence 로 폴백(used_stratified=False).
        폴백을 관측 가능하게 만들어 "디컨파운딩됐다고 표시되지만 실제로는 전역이었다"를 드러낸다(리뷰 P1).
        """
        shared, conf = self._shared(a, b)
        if not shared:
            return 1.0, False
        if stratified and conf:
            stratum = self._joint_stratum(conf)               # 여러 교란자면 교집합(공동 조건화)
            size = len(stratum)
            if size >= min_stratum:
                logp = 0.0
                for (k, v) in self._collapse(shared):
                    dfc = len(stratum & self.kv[(k, str(v))])
                    q = (dfc - 1) / (size - 1) if size > 1 else 1.0
                    if q <= 0.0:
                        return 0.0, True
                    logp += math.log(min(1.0, q))
                return math.exp(logp), True
        return self._global_coincidence(shared), False

    def confounder_of(self, a: str, b: str):
        """a,b 가 공유하는 교란자 값들(kind:value). 판정 근거 설명용."""
        _, conf = self._shared(a, b)
        return sorted(f"{k}:{v}" for (k, v) in conf)


def deconfounded_edges(sigmap: dict, pairs, confounder_kind,
                       min_stratum: int = 3) -> list:
    """후보 쌍들에 대해 (raw 전역 coincidence, 디컨파운딩 coincidence) 비교 리포트.

    디컨파운딩이 raw 보다 크면(=증거 약화) 그 강한 근거가 실은 제공자 탓이었다는 뜻.
    """
    dc = Deconfounder(sigmap, confounder_kind)
    out = []
    for (a, b) in pairs:
        raw = dc.coincidence(a, b, stratified=False)
        adj = dc.coincidence(a, b, stratified=True, min_stratum=min_stratum)
        out.append({"a": a, "b": b, "raw": raw, "deconfounded": adj,
                    "provider": dc.confounder_of(a, b),
                    "provider_explained": adj > raw})
    return sorted(out, key=lambda x: x["deconfounded"])


class _UF:
    def __init__(self):
        self.p: dict = {}

    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[ra] = rb


def deconfounded_clusters(sigmap: dict, confounder_kind, threshold: float = 1e-6,
                          min_stratum: int = 3, max_bucket: int = 64) -> dict:
    """**디컨파운딩을 클러스터링 판정에 직접 적용**(사후 리포트 아님, 리뷰 P2).

    파이프라인: 신호맵 → (역인덱스로 공유신호 후보쌍 생성, generic 값은 max_bucket 억제) →
    각 후보쌍의 **층화 조건부 coincidence**(교란자 공동 층 안) 계산 → threshold 이하만 union.
    즉 "제공자 때문에 같이 보이는 쌍"은 애초에 간선이 안 생겨 클러스터에 안 들어간다.

    반환 {clusters:[[dom...]], edges:[{a,b,coincidence}], suppressed_generic:int}.
    """
    from collections import defaultdict
    dc = Deconfounder(sigmap, confounder_kind)
    ck = dc.ck
    # 관측성(리뷰 P1): 요청한 교란자 중 실제 신호맵에 존재하는 것만이 조건화에 쓰인다.
    # 요청은 했지만 데이터에 없으면 '적용됐다'가 아니라 사실상 전역이다.
    available = {k for s in sigmap.values() for k in s if k in ck}
    inv: dict = defaultdict(set)                 # (kind,value) → 도메인들(비교란 축만)
    for d, s in sigmap.items():
        for k, vs in s.items():
            if k in ck:
                continue
            for v in vs:
                inv[(k, str(v))].add(d)
    cand: set = set()
    suppressed = 0
    for kv, doms in inv.items():
        if len(doms) > max_bucket:               # generic 값 억제(후보 폭발 방지)
            suppressed += 1
            continue
        dl = sorted(doms)
        for i in range(len(dl)):
            for j in range(i + 1, len(dl)):
                cand.add((dl[i], dl[j]))
    uf = _UF()
    for d in sigmap:
        uf.find(d)
    edges = []
    strat_pairs = 0                              # 실제 층화 조건부로 계산된 후보쌍 수
    fallback_pairs = 0                           # 층이 없거나 min_stratum 미만 → 전역 폴백
    for (a, b) in cand:
        p, used_strat = dc.coincidence_meta(a, b, stratified=True, min_stratum=min_stratum)
        if used_strat:
            strat_pairs += 1
        else:
            fallback_pairs += 1
        if p <= threshold:                       # 디컨파운딩된 근거가 충분히 강한 쌍만 연결
            uf.union(a, b)
            edges.append({"a": a, "b": b, "coincidence": p})
    groups: dict = defaultdict(set)
    for d in sigmap:
        groups[uf.find(d)].add(d)
    clusters = sorted([sorted(m) for m in groups.values() if len(m) >= 2],
                      key=lambda m: (-len(m), m))
    total_pairs = strat_pairs + fallback_pairs
    fallback_ratio = (fallback_pairs / total_pairs) if total_pairs else 0.0
    return {"clusters": clusters, "edges": sorted(edges, key=lambda e: e["coincidence"]),
            "suppressed_generic": suppressed,
            # 관측성: 요청 vs 실제 사용된 교란자, 그리고 층화가 실제로 작동한 비율
            "requested_confounders": sorted(ck),
            "available_confounders": sorted(available),
            "effective": bool(available) and strat_pairs > 0,
            "stratified_pairs": strat_pairs,
            "global_fallback_pairs": fallback_pairs,
            # 리뷰 P3: 폴백 비율을 1급 지표로 — "이 결과의 X% 는 실제론 디컨파운딩 안 됨"(희소 provider 쌍).
            # 층이 min_stratum 미만이라 전역 폴백된 비율. 높으면 결과를 디컨파운딩됐다고 신뢰하면 안 된다.
            "fallback_ratio": round(fallback_ratio, 4),
            "fallback_note": (f"후보쌍의 {fallback_ratio*100:.1f}% 는 층 부족으로 전역 폴백(실제 디컨파운딩 안 됨)"
                              if fallback_pairs else "전 쌍 층화 성공(폴백 없음)")}


def sensitivity_analysis(sigmap: dict, confounder_kind, threshold: float = 1e-6,
                         min_stratum_grid=(3, 10, 30, 100), max_bucket: int = 64) -> dict:
    """min_stratum 정책값을 바꿔가며 클러스터 결과가 얼마나 흔들리는지 보고한다(강화 축11).

    min_stratum=3 은 '정책값'일 뿐 통계적 근거가 있는 값이 아니다(리뷰 지적). 3/10/30/100 로
    스윕해 (클러스터 수, 층화쌍 수, 전역폴백 수, effective)가 어떻게 변하는지 제시하면 결과의
    **민감도**를 정직하게 드러낸다. 층이 작을수록(min_stratum↓) 조건부 추정이 불안정하다.

    반환 {grid:[{min_stratum, cluster_count, stratified_pairs, global_fallback_pairs, effective}],
          stable: bool(클러스터 수가 그리드 전체에서 동일한가), note}.
    """
    rows = []
    counts = set()
    for ms in min_stratum_grid:
        r = deconfounded_clusters(sigmap, confounder_kind, threshold=threshold,
                                  min_stratum=ms, max_bucket=max_bucket)
        rows.append({"min_stratum": ms, "cluster_count": len(r["clusters"]),
                     "stratified_pairs": r["stratified_pairs"],
                     "global_fallback_pairs": r["global_fallback_pairs"],
                     "fallback_ratio": r["fallback_ratio"],   # 리뷰 P3: 폴백 비율(실제 미디컨파운딩 비중)
                     "effective": r["effective"]})
        counts.add(len(r["clusters"]))
    stable = len(counts) == 1
    return {"grid": rows, "stable": stable,
            "note": ("클러스터 수가 min_stratum 전 구간에서 동일 → 결론이 정책값에 둔감(견고)"
                     if stable else
                     "클러스터 수가 min_stratum 에 따라 변함 → 결론이 정책값에 민감(주의)")}
