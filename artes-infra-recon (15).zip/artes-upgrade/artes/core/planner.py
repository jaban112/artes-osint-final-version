"""능동 조사 계획 — "다음에 뭘 조회할지"를 정보이득으로 정하는 뇌.

지금까지 엔진은 수동 fan-out(전부 다 쏨)이었다. 여기서는 가설(예: "X·Y 동일 운영자인가")의
불확실성을 베이즈 belief 로 두고, 각 후보 조회가 그 불확실성을 얼마나 줄일지(**기대 정보이득 =
상호정보 I(H;O)**)를 계산해, 가장 크게 줄이는 조회부터 고른다. 답에 이르는 3~5개만 쏘고 멈춘다.

정리 기반(휴리스틱 아님):
- 기대 정보이득 = H(belief) − E_o[H(posterior)] = I(H; O) ≥ 0 (상호정보, 항상 비음성).
- 조건부독립 관측에 대해 정보이득 집합함수는 **submodular** → greedy 선택이 최적의 (1−1/e)≈63%
  이상을 보장(Nemhauser; Krause–Guestrin 센서배치). 즉 '다음 질문 고르기'가 증명된 하한을 갖는다.

Action 은 결과별 우도 P(o|H), P(o|¬H) 로 정의(수집기 지식/보정에서 채움). 실행 시 관측하면
adaptive_step 으로 belief 를 갱신하고 재계획(적응 greedy). 순수 stdlib.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field


def binary_entropy(p: float) -> float:
    """이진 엔트로피 H(p) (bits). H(0)=H(1)=0, H(0.5)=1."""
    if p <= 0.0 or p >= 1.0:
        return 0.0
    return -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


@dataclass
class Action:
    """후보 조회. outcomes: {결과라벨: (P(o|H), P(o|¬H))}. cost>0 는 조회 비용(정보이득/비용용)."""
    name: str
    outcomes: dict
    cost: float = 1.0

    def __post_init__(self):
        # 입력 검증(리뷰 P1): 확률은 유한하고 [0,1], 비용>0, 합=1. planner 가 수학적 보장을
        # 내세우므로 합만 1 이면 음수/>1 확률·cost=0 을 통과시키던 것을 막는다.
        if self.cost is None or not math.isfinite(self.cost) or self.cost <= 0:
            raise ValueError(f"cost 는 유한 양수여야 함: {self.cost}")
        for label, (p, q) in self.outcomes.items():
            for name, v in (("P(o|H)", p), ("P(o|¬H)", q)):
                if not math.isfinite(v) or not (0.0 <= v <= 1.0):
                    raise ValueError(f"{name}[{label}] 은 유한 [0,1] 이어야 함: {v}")
        sh = sum(p for p, _ in self.outcomes.values())
        sn = sum(q for _, q in self.outcomes.values())
        if not (abs(sh - 1.0) < 1e-6 and abs(sn - 1.0) < 1e-6):
            raise ValueError(f"outcome 확률합이 1 이 아님: H={sh}, ¬H={sn}")


def posterior(belief: float, action: Action, outcome: str) -> float:
    """관측 outcome 후 P(H) 사후(Bayes)."""
    pH, pN = action.outcomes[outcome]
    num = belief * pH
    den = num + (1 - belief) * pN
    return num / den if den > 0 else belief


def _expected_entropy(belief: float, subset) -> float:
    """관측이 H 조건부독립일 때, subset 을 모두 관측한 뒤의 기대 사후 엔트로피(정확 열거)."""
    if not subset:
        return binary_entropy(belief)
    labels = [list(a.outcomes.keys()) for a in subset]
    total = 0.0
    for combo in itertools.product(*labels):
        LH = 1.0
        LN = 1.0
        for a, o in zip(subset, combo):
            pH, pN = a.outcomes[o]
            LH *= pH
            LN *= pN
        pc = belief * LH + (1 - belief) * LN
        if pc <= 0:
            continue
        bpost = belief * LH / pc
        total += pc * binary_entropy(bpost)
    return total


def info_gain(belief: float, subset) -> float:
    """기대 정보이득 = H(belief) − E[H(posterior)] = I(H; 관측). 항상 ≥ 0."""
    if isinstance(subset, Action):
        subset = [subset]
    return binary_entropy(belief) - _expected_entropy(belief, list(subset))


def rank_actions(belief: float, actions, by_cost: bool = False) -> list:
    """단일 액션 정보이득(또는 이득/비용) 내림차순."""
    scored = []
    for a in actions:
        ig = info_gain(belief, a)
        scored.append((a, ig, ig / a.cost if a.cost else ig))
    key = (lambda t: t[2]) if by_cost else (lambda t: t[1])
    return sorted(scored, key=key, reverse=True)


def greedy_select(belief: float, actions, k: int, by_cost: bool = False) -> list:
    """submodular greedy 로 k개 액션 집합 선택. 각 단계 한계이득 최대 액션 추가.

    보장 범위(리뷰 P13, 정직하게): (1−1/e) 보장은 **cardinality 제약(정확히 k개 선택)** +
    단조·submodular 정보이득에 대한 표준 greedy 에만 성립한다(by_cost=False). by_cost=True 는
    한계이득/비용 비율 greedy 로, **비용 예산(knapsack)** 최적화의 (1−1/e) 보장을 일반적으로 주지
    않는다(그 보장엔 Sviridenko 의 부분열거 변형이 필요). 즉 by_cost 는 실용적 휴리스틱이며 여기
    'budget' 은 대개 **액션 개수**(비용 예산이 아님). 이 구분을 문서에서 흐리지 않는다.
    반환: [(action, marginal_gain)] 선택 순.
    """
    remaining = list(actions)
    chosen: list = []
    chosen_actions: list = []
    base_eh = _expected_entropy(belief, [])
    while remaining and len(chosen) < k:
        best = None
        best_mg = -1.0
        cur_eh = _expected_entropy(belief, chosen_actions)
        for a in remaining:
            eh = _expected_entropy(belief, chosen_actions + [a])
            mg = cur_eh - eh                     # 한계 정보이득(엔트로피 감소)
            score = mg / a.cost if by_cost and a.cost else mg
            if score > best_mg:
                best_mg = score
                best = a
        chosen.append((best, cur_eh - _expected_entropy(belief, chosen_actions + [best])))
        chosen_actions.append(best)
        remaining.remove(best)
    return chosen


def adaptive_step(belief: float, action: Action, observed: str) -> float:
    """실행 후 실제 관측 outcome 으로 belief 갱신(적응 greedy 루프용)."""
    return posterior(belief, action, observed)


def _posterior_stats(belief: float, subset, target_confidence: float) -> dict:
    """계획 subset 의 모든 도달가능 관측조합을 열거해 사후확신도 분포 통계(정확).

    confidence(조합) = max(post, 1-post). 반환:
      expected_confidence = Σ p(조합)·confidence
      worst_case_confidence = min_{p>0} confidence  (최악 관측에서의 확신도 — 보장값)
      p_reach = Σ_{confidence≥target} p(조합)  (목표 확신도 이상일 확률)
    """
    if not subset:
        c = max(belief, 1 - belief)
        return {"expected_confidence": c, "worst_case_confidence": c,
                "p_reach": 1.0 if c >= target_confidence else 0.0}
    labels = [list(a.outcomes.keys()) for a in subset]
    exp_c = 0.0
    worst = 1.0
    p_reach = 0.0
    for combo in itertools.product(*labels):
        LH = LN = 1.0
        for a, o in zip(subset, combo):
            pH, pN = a.outcomes[o]
            LH *= pH
            LN *= pN
        pc = belief * LH + (1 - belief) * LN
        if pc <= 0:
            continue
        post = belief * LH / pc
        conf = max(post, 1 - post)
        exp_c += pc * conf
        worst = min(worst, conf)
        if conf >= target_confidence:
            p_reach += pc
    return {"expected_confidence": exp_c, "worst_case_confidence": worst, "p_reach": p_reach}


def plan_until(belief: float, actions, target_confidence: float = 0.95,
               budget: int = 8, by_cost: bool = False) -> dict:
    """목표까지 비적응 계획. **기대 정보와 보장 확신도를 분리해서 보고**(리뷰 P3).

    중요: 기대 사후 엔트로피가 낮다(≤ H(target))고 해서 실제 사후확신도가 target 이상이라고
    **보장되지 않는다** — 어떤 관측 조합에서는 확신도가 낮을 수 있다. 그래서 다음을 나눠 낸다:
      - expected_info_reached : E[H(post)] ≤ H(target)  (평균적으로 정보가 충분한가)
      - guaranteed           : worst_case_confidence ≥ target  (최악 관측에서도 목표 이상인가)
      - p_reach_threshold    : 사후확신도가 target 이상일 확률
    'reached' 는 하위호환으로 expected_info_reached 와 동일(평균 기준)이며 보장이 아니다.
    """
    target_H = binary_entropy(target_confidence)
    order = greedy_select(belief, actions, budget, by_cost=by_cost)
    plan = []
    chosen_actions = []
    for a, _mg in order:
        chosen_actions.append(a)
        plan.append((a.name, round(info_gain(belief, chosen_actions), 6)))
        if _expected_entropy(belief, chosen_actions) <= target_H:
            break
    eh = _expected_entropy(belief, chosen_actions)
    ps = _posterior_stats(belief, chosen_actions, target_confidence)
    exp_reached = eh <= target_H
    return {"plan": plan, "expected_entropy": eh, "start_entropy": binary_entropy(belief),
            "expected_info_reached": exp_reached,
            "reached": exp_reached,                      # 하위호환(= expected_info, 보장 아님)
            "expected_confidence": ps["expected_confidence"],
            "worst_case_confidence": ps["worst_case_confidence"],
            "guaranteed": ps["worst_case_confidence"] >= target_confidence,
            "p_reach_threshold": ps["p_reach"],
            "target_confidence": target_confidence}
