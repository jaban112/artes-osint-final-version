"""시간축 — 캠페인/동시버스트(co-burst) 탐지. 정적 신호가 못 보는 조율 인프라를 타이밍으로.

핵심: 도메인 다수가 좁은 시간창에 함께 등록/cert발급/first-seen 되면 우연이 아니라 조율된
스핀업(피싱킷·봇넷·캠페인)일 수 있다. 이게 우연인지 **유효한(valid) p-value** 로 판정한다.

■ 왜 예전 방식(cluster_span/total_span)을 버렸나 — 통계적 결함
  단일연결 클러스터의 '관측된 span'을 창폭으로 쓰고 그걸로 이항 p 를 계산하면, (1) 창폭이
  사전지정이 아니라 데이터로 정해지고(post-selection), (2) 여러 창을 훑어 가장 몰린 곳을 고른 뒤
  p 를 계산하는 look-elsewhere 문제가 보정되지 않는다. 실측: 균일 귀무에서 α=0.05 인데 FPR≈35%.
  → **유의수준을 지키지 못하는 검정.** 표현이 아니라 모형을 바꿔야 하는 문제였다.

■ 올바른 설계(두 가지, 둘 다 정직)
  (A) 사전지정 고정창 W 하나에 대한 **정확 이항 검정**: 관측기간 T, n개 이벤트가 균일이면 창 안
      개수 X ~ Binomial(n, W/T). P(X≥k) = I_{W/T}(k, n−k+1) (정규화 불완전베타, 정확). 스캔 없음.
  (B) 창 위치를 훑어 '가장 몰린 창'을 찾는 **스캔 통계량**: 검정통계량 S = 폭 W 창의 최대 개수.
      S 의 귀무분포는 닫힌형이 지저분(스캔통계량, Naus). 그래서 **몬테카를로 유효검정**을 쓴다 —
      귀무(균일 n점)에서 B회 S 를 뽑고 p=(1+#{S_b≥S_obs})/(1+B). 이 추정량은 **정확히 유효**하다:
      귀무에서 P(p≤α) ≤ α (Besag–Clifford 1991; 교환가능성에서 순위검정). 근사·휴리스틱 아님.
  MC 추정치 자체의 유한표본 오차는 verify_cp 의 CP 구간으로 함께 보고한다.

coburst_clusters/temporal_pairs 는 이제 '어느 도메인이 같이 몰렸나'를 **묶기용**으로만 쓴다(유의성
판정은 스캔 p-value 가 담당). verify_cp.reg_incomplete_beta / cp_interval 재사용. 순수 stdlib.
"""
from __future__ import annotations

import random
from typing import Iterable, Optional

from .verify_cp import reg_incomplete_beta, cp_interval


# --------------------------------------------------------------------------- #
# 정확 이항 꼬리(사전지정 창용) + 사건 정렬
# --------------------------------------------------------------------------- #
def binomial_tail_ge(k: int, n: int, p: float) -> float:
    """P(X ≥ k), X~Binomial(n,p). 정확 = I_p(k, n-k+1). (P(X≥1)=1-(1-p)^n 등과 일치.)"""
    if k <= 0:
        return 1.0
    if k > n:
        return 0.0
    if p <= 0.0:
        return 0.0
    if p >= 1.0:
        return 1.0
    return reg_incomplete_beta(k, n - k + 1, p)


def _times(events) -> list:
    if isinstance(events, dict):
        vals = [t for t in events.values() if t is not None]
    else:
        vals = [t for (_, t) in events if t is not None]
    return sorted(float(t) for t in vals)


def _items(events) -> list:
    """(key, time) 정렬 목록 — 멤버 추출용."""
    if isinstance(events, dict):
        it = [(k, t) for k, t in events.items() if t is not None]
    else:
        it = [(k, t) for (k, t) in events if t is not None]
    return sorted(it, key=lambda kv: float(kv[1]))


# --------------------------------------------------------------------------- #
# (A) 사전지정 고정창 — 정확 이항 검정 (스캔 아님)
# --------------------------------------------------------------------------- #
def window_pvalue(k: int, n: int, window: float, total_span: float) -> float:
    """사전지정 폭 window 창에 k개가 들어올 확률의 정확 상한. 스캔 없음(창을 미리 정한 경우만 유효)."""
    if total_span <= 0 or n <= 1 or window <= 0:
        return 1.0
    p = min(1.0, window / total_span)
    return binomial_tail_ge(k, n, p)


# --------------------------------------------------------------------------- #
# (B) 스캔 통계량 — 폭 W 창의 최대 개수 + 몬테카를로 유효 p-value
# --------------------------------------------------------------------------- #
def max_window_count(times: list, window: float) -> int:
    """정렬된 시각들에서 폭 window 반열림창 [t, t+window) 의 최대 사건 수. 투포인터 O(n).

    가장 몰린 창은 항상 어떤 사건 시각에서 시작하도록 밀 수 있으므로 사건-앵커 스윕으로 충분(정확)."""
    n = len(times)
    if n == 0:
        return 0
    best = 1
    j = 0
    for i in range(n):
        if j < i:
            j = i
        while j + 1 < n and times[j + 1] - times[i] < window:
            j += 1
        cnt = j - i + 1
        if cnt > best:
            best = cnt
    return best


def _window_members(items: list, window: float) -> list:
    """최대 개수를 달성하는 (첫) 창의 멤버 키들."""
    times = [float(t) for _, t in items]
    n = len(times)
    best, bi, bj = 0, 0, 0
    j = 0
    for i in range(n):
        if j < i:
            j = i
        while j + 1 < n and times[j + 1] - times[i] < window:
            j += 1
        cnt = j - i + 1
        if cnt > best:
            best, bi, bj = cnt, i, j
    return sorted(k for k, _ in items[bi:bj + 1])


def scan_pvalue_mc(events, window: float, n_mc: int = 1999, seed: int = 0,
                   alpha: float = 0.05, observation_start: "float|None" = None,
                   observation_end: "float|None" = None) -> dict:
    """폭 window 스캔통계량(최대창개수)의 몬테카를로 유효 p-value.

    귀무: n개 이벤트가 **관측기간에 균일**. B=n_mc 회 재표본에서 S_b 를 뽑아
    p = (1 + #{S_b ≥ S_obs}) / (1 + B). **P(p≤α) ≤ α 를 정확히 보장**(Besag–Clifford).
    seed 고정 → 재현가능. MC 추정 오차는 CP 구간(ci)으로 함께 보고.

    관측기간(강화 축10): observation_start/observation_end 를 **명시**하면 귀무를 그 사전지정 구간
    [start,end] 위 균일분포로 둔다 → null 이 데이터에 의존하지 않아 검정이 엄밀해진다. 미지정 시엔
    관측된 [t0,t1] span 을 쓰는데, 이는 '관측 span 에 조건부'라는 점을 null 필드에 명시한다.

    반환 {pvalue, mc_exceedances, mc_pvalue, observed, n, window, span, observation_window, null,
          n_mc, ci:[lo,hi], pvalue_ci:[lo,hi], members}.
    """
    times = _times(events)
    n = len(times)
    explicit = observation_start is not None and observation_end is not None
    if explicit:
        lo_t, hi_t = float(observation_start), float(observation_end)
        span = hi_t - lo_t
        null = "uniform(observation_start, observation_end) [사전지정]"
        obs_window = [lo_t, hi_t]
    else:
        lo_t = times[0] if n >= 2 else 0.0
        span = (times[-1] - times[0]) if n >= 2 else 0.0
        null = "uniform(t0, t1) [관측 span 에 조건부 — 사전지정 창이면 더 엄밀]"
        obs_window = "data-derived"
    base = {"pvalue": 1.0, "mc_exceedances": 0, "mc_pvalue": 1.0, "observed": n, "n": n,
            "window": window, "span": span, "observation_window": obs_window, "null": null,
            "n_mc": n_mc, "ci": [0.0, 1.0], "pvalue_ci": [0.0, 1.0], "members": []}
    if n < 2 or span <= 0 or window <= 0 or window >= span:
        return base                                   # 몰릴 여지 없음 → 유의 아님
    obs = max_window_count(times, window)
    rng = random.Random(seed)
    ge = 0
    for _ in range(n_mc):
        if explicit:
            sample = sorted(lo_t + rng.uniform(0.0, span) for _ in range(n))
        else:
            # 데이터유도 창(리뷰 P4): 관측이 [t0,t1] 양 끝점을 정확히 찍으므로 null 도 끝점 고정 + 내부
            # n-2 점만 재표본해야 range 편향(재표본 범위 ≈ span·(n-1)/(n+1))이 사라진다 → 검정력 회복.
            if n <= 2:
                sample = sorted(lo_t + rng.uniform(0.0, span) for _ in range(n))
            else:
                interior = sorted(lo_t + rng.uniform(0.0, span) for _ in range(n - 2))
                sample = [lo_t] + interior + [lo_t + span]
        if max_window_count(sample, window) >= obs:
            ge += 1
    p = (1 + ge) / (1 + n_mc)
    lo, hi = cp_interval(ge, n_mc, alpha)             # MC 추정치의 유한표본 CI
    items = _items(events)
    base.update({"pvalue": p, "mc_pvalue": p, "mc_exceedances": ge, "observed": obs,
                 "ci": [lo, hi], "pvalue_ci": [lo, hi],
                 "members": _window_members(items, window)})
    return base


# --------------------------------------------------------------------------- #
# 묶기 전용(유의성 판정 아님): 단일연결 시간 클러스터 / 같은-버스트 쌍
# --------------------------------------------------------------------------- #
def coburst_clusters(events, window: float) -> list:
    """단일연결 시간 클러스터(연속 간격 ≤ window). **묶기용**일 뿐, 이걸로 유의성 판정하지 말 것.
    (관측 span 이 window 보다 훨씬 커질 수 있어 p-value 근거로 쓰면 안 됨 — scan_pvalue_mc 사용.)"""
    items = _items(events)
    if not items:
        return []
    clusters, cur = [], [items[0]]
    for prev, nxt in zip(items, items[1:]):
        if nxt[1] - prev[1] <= window:
            cur.append(nxt)
        else:
            clusters.append(cur)
            cur = [nxt]
    clusters.append(cur)
    return clusters


def temporal_pairs(events, window: float):
    """같은 버스트 클러스터 안의 모든 쌍(묶기용 후보 간선). 유의성은 scan_pvalue_mc 로 별도 판정."""
    pairs = []
    for cl in coburst_clusters(events, window):
        if len(cl) < 2:
            continue
        keys = sorted(k for k, _ in cl)
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                pairs.append((keys[i], keys[j]))
    return pairs


# --------------------------------------------------------------------------- #
# 캠페인 리포트 — 스캔 유효 p-value 기반(look-elsewhere 보정됨)
# --------------------------------------------------------------------------- #
def campaign_report(events, window: float, alpha: float = 1e-3,
                    n_mc: int = 1999, seed: int = 0,
                    observation_start: "float|None" = None,
                    observation_end: "float|None" = None) -> list:
    """폭 window 스캔통계량의 몬테카를로 유효 p-value 로 캠페인 판정.

    스캔통계량(최대창개수)의 귀무분포가 '여러 창을 봤다'는 것 자체를 이미 반영하므로 별도
    다중검정 보정이 필요 없다(그게 스캔통계량의 요점). p < alpha 면 캠페인 1건으로 보고.
    observation_start/end 를 주면 사전지정 관측창 위 균일 null 로 더 엄밀(강화 축10).

    반환 [] 또는 [{members, size, window, pvalue, pvalue_ci, span}] (유의할 때 1건).
    """
    r = scan_pvalue_mc(events, window, n_mc=n_mc, seed=seed,
                       observation_start=observation_start, observation_end=observation_end)
    if r["pvalue"] < alpha:
        return [{"members": r["members"], "size": r["observed"], "window": window,
                 "pvalue": r["pvalue"], "pvalue_ci": r["ci"], "span": r["span"]}]
    return []
