"""배경 참조 모집단(background reference population) — IDF df 를 **타겟 그래프와 분리**한다(강화 축1).

지금까지 coincidence 의 df 는 스캔 중인 타겟 그래프 자신에서 나왔다. 그러면 df 가 '관측된 표적 집합'의
빈도라 post-selection 이고, "이 값이 세상에서 얼마나 희소한가"라는 배경 확률과 다르다. BackgroundCorpus 는
독립적으로 수집된 참조 모집단의 df(v)/N 을 제공한다. 코퍼스가 없으면 타겟 그래프로 폴백하되 그 사실을
`source="target-self"` 로 **정직하게 표시**한다(사후확률 아님을 계속 명시).

수치는 전부 정확: 미관측 값(df=0)의 유병률은 CP 상한(cp_upper(0,N) ≈ 3/N, rule of three)으로 보수화 —
'배경에서 한 번도 못 본 값'을 우연일치확률 0 으로 과신하지 않는다(그건 표본 부족이지 불가능이 아니다).
순수 stdlib.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
from typing import Optional

from .verify_cp import cp_upper


class BackgroundCorpus:
    """참조 모집단의 (kind,value)->df 와 N. coincidence 에 배경 유병률 q 를 공급한다."""

    def __init__(self, df: dict, n: int, *, source: str = "corpus",
                 epoch: Optional[float] = None, label: str = ""):
        self._df = {(str(k[0]), str(k[1])): int(v) for k, v in df.items()}
        self.n = max(1, int(n))
        self.source = source              # "corpus" | "target-self"(폴백) — 정직 표기
        self.epoch = epoch if epoch is not None else time.time()
        self.label = label

    @classmethod
    def from_signal_map(cls, sigmap: dict, *, source: str = "corpus",
                        label: str = "") -> "BackgroundCorpus":
        """{domain: {kind: iterable[value]}} 참조 코퍼스에서 df 를 센다."""
        from collections import defaultdict
        df: dict = defaultdict(int)
        for _dom, sig in sigmap.items():
            seen = set()
            for k, vals in sig.items():
                for v in vals:
                    kv = (str(k), str(v))
                    if kv not in seen:        # 도메인당 값은 1번만(df = document frequency)
                        df[kv] += 1
                        seen.add(kv)
        return cls(dict(df), n=len(sigmap), source=source, label=label)

    def df(self, kind: str, value) -> int:
        return self._df.get((str(kind), str(value)), 0)

    def q(self, kind: str, value, *, alpha: float = 0.05) -> float:
        """배경 유병률 q(v) = P(임의 도메인이 값 v 를 가짐). 미관측(df=0)은 CP 상한으로 보수화.

        df>0: q = df/N (점추정). df=0: q = cp_upper(0,N,alpha) (rule of three, 표본부족 반영).
        보수적으로 항상 CP 상한을 쓰고 싶으면 q_upper 를 사용."""
        d = self.df(kind, value)
        if d <= 0:
            return cp_upper(0, self.n, alpha)     # 미관측 → 상한(≈3/N), 0 으로 과신 안 함
        return min(1.0, d / self.n)

    def q_upper(self, kind: str, value, *, alpha: float = 0.05) -> float:
        """유한표본 오차까지 보수화한 유병률 상한 CP_upper(df, N)."""
        return cp_upper(self.df(kind, value), self.n, alpha)

    def coincidence(self, reps, *, conservative: bool = True, alpha: float = 0.05) -> float:
        """대표 (kind,value) 목록의 배경 우연일치확률 = ∏ q(v). 독립 가정(패밀리 붕괴 후 적용 권장).

        conservative=True → q_upper(유한표본 상한), False → 점추정 df/N. 반환 작을수록 강한 근거."""
        logp = 0.0
        for (k, v) in reps:
            qq = self.q_upper(k, v, alpha=alpha) if conservative else self.q(k, v, alpha=alpha)
            if qq <= 0.0:
                return 0.0
            logp += math.log(min(1.0, qq))
        return math.exp(logp) if reps else 1.0

    @property
    def corpus_hash(self) -> str:
        """코퍼스 내용 주소 해시 — 재현성/run manifest 용. df 테이블 + N + source."""
        body = {"n": self.n, "source": self.source,
                "df": sorted((f"{k[0]}|{k[1]}", v) for k, v in self._df.items())}
        return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:16]

    def manifest(self) -> dict:
        """run manifest 에 넣을 배경 모집단 요약(정직 표기 포함)."""
        return {"source": self.source, "n_background": self.n,
                "distinct_values": len(self._df), "epoch": round(self.epoch, 3),
                "corpus_hash": self.corpus_hash, "label": self.label,
                "note": ("타겟 그래프 자기참조(배경≠독립). 진짜 배경 유병률 아님"
                         if self.source == "target-self" else "독립 참조 모집단")}


def target_self_corpus(sigmap: dict) -> BackgroundCorpus:
    """독립 코퍼스가 없을 때의 폴백 — 타겟 그래프 자신을 배경으로(정직 표기 source='target-self')."""
    return BackgroundCorpus.from_signal_map(sigmap, source="target-self",
                                            label="fallback: target graph as its own background")
