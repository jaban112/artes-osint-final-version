"""보정·평가·conformal — 판정이 '정직한지'를 측정으로 증명하는 층.

이 툴의 차별점은 수집량이 아니라 (a) 틀린 연결을 얼마나 안 만드나(정밀도)와 (b) 확신도가 정직한가
(보정)이다. 여기서 그걸 '주장'이 아니라 '측정'으로:

- precision/recall/F1 + 각각의 Clopper–Pearson 신뢰하한(표본이 작아도 정직).
- reliability_bins / ece: "95% 라 말할 때 실제 95% 맞나"를 구간별 경험정확도로 측정(+CP CI).
- split-conformal: 라벨 보정셋으로, '같은운영자로 선언 시 진짜 쌍의 ≥1-α 포함'을 **분포무관·유한표본**
  으로 보장하는 임계값. conformal p-value 도 제공. (근사·경험값 아님 — 교환가능성 정리.)

라벨(ground-truth: 어느 쌍이 실제 동일운영자인지)이 있어야 실측된다. 없으면 하네스 자체는 합성
라벨로 검증(테스트가 그렇게 한다). verify_cp 의 정확 CP 를 재사용.
"""
from __future__ import annotations

import math
from typing import Iterable

from .verify_cp import cp_lower, cp_upper


def _norm_pair(p) -> tuple:
    a, b = p
    return (a, b) if a <= b else (b, a)


def confusion(pred_pairs: Iterable, true_pairs: Iterable) -> tuple:
    """(tp, fp, fn) — 예측 쌍 집합 vs 정답 쌍 집합."""
    P = {_norm_pair(p) for p in pred_pairs}
    T = {_norm_pair(p) for p in true_pairs}
    return len(P & T), len(P - T), len(T - P)


def precision_recall(tp: int, fp: int, fn: int, alpha: float = 0.05) -> dict:
    """정밀도·재현율·F1 + CP 신뢰하한(정밀도=tp/(tp+fp), 재현율=tp/(tp+fn))."""
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": prec, "recall": rec, "f1": f1,
        "precision_lower": cp_lower(tp, tp + fp, alpha) if (tp + fp) else 0.0,
        "recall_lower": cp_lower(tp, tp + fn, alpha) if (tp + fn) else 0.0,
    }


def evaluate(pred_pairs: Iterable, true_pairs: Iterable, alpha: float = 0.05) -> dict:
    tp, fp, fn = confusion(pred_pairs, true_pairs)
    return precision_recall(tp, fp, fn, alpha)


def reliability_bins(pairs: Iterable, n_bins: int = 10, alpha: float = 0.05) -> list:
    """pairs=[(confidence∈[0,1], label∈{0,1})] → 구간별 (평균확신도, 경험정확도, CP 상·하한)."""
    buckets: list[list] = [[] for _ in range(n_bins)]
    for c, y in pairs:
        c = min(1.0, max(0.0, float(c)))
        b = min(n_bins - 1, int(c * n_bins))
        buckets[b].append((c, int(y)))
    out = []
    for i, b in enumerate(buckets):
        if not b:
            continue
        k = sum(y for _, y in b)
        n = len(b)
        out.append({
            "bin": i, "n": n,
            "mean_conf": sum(c for c, _ in b) / n,
            "empirical": k / n,
            "emp_lower": cp_lower(k, n, alpha),
            "emp_upper": cp_upper(k, n, alpha),
        })
    return out


def ece(pairs: Iterable, n_bins: int = 10) -> float:
    """Expected Calibration Error = Σ (n_b/N)·|평균확신도_b − 경험정확도_b|. 0 이면 완벽 보정."""
    bins = reliability_bins(pairs, n_bins)
    total = sum(b["n"] for b in bins) or 1
    return sum(b["n"] / total * abs(b["mean_conf"] - b["empirical"]) for b in bins)


def conformal_threshold(cal_scores_true, alpha: float = 0.1,
                        lower_is_positive: bool = True) -> float:
    """Split-conformal 임계값. cal_scores_true = 라벨된 '진짜 동일운영자' 쌍들의 점수.

    lower_is_positive=True(점수 작을수록 동일운영자, 예: coincidence 확률): 임계값 τ 를
    ⌈(1-α)(n+1)⌉-번째 '작은' 점수로 잡으면, 새 진짜 쌍의 점수 ≤ τ 일 확률 ≥ 1-α (교환가능성).
    즉 'score ≤ τ 면 동일운영자로 선언' 시 재현율 ≥ 1-α 를 **분포무관·유한표본** 보장.

    경계(리뷰 P0): k=⌈(1-α)(n+1)⌉ 가 n 을 넘으면(α<1/(n+1)) **유한 임계값으로는 1-α 커버리지가
    불가능**하다. 예전엔 rank 를 n 으로 clamp 해 최댓값을 τ 로 썼는데, 새 교환가능 점이 그 값을
    넘을 확률이 ~1/(n+1) 라 실제 커버리지는 n/(n+1)<1-α 로 떨어졌다(n=5,α=0.1 → 0.833).
    올바른 처리는 τ=+∞(전수 채택) — 그래야 1-α 보장이 유지된다(표본이 부족하면 정직하게 전수 채택).
    """
    s = sorted(float(x) for x in cal_scores_true)
    n = len(s)
    k = math.ceil((1 - alpha) * (n + 1))
    if k > n:                                  # 유한 임계값으로 1-α 보장 불가 → 전수 채택(±∞)
        return math.inf if lower_is_positive else -math.inf
    if lower_is_positive:
        return s[k - 1]                        # k-번째 작은 값
    return s[n - k]                            # 큰 쪽에서 대칭


def conformal_pvalue(score: float, cal_scores_true, lower_is_positive: bool = True) -> float:
    """conformal p-value: 이 점수가 '진짜 동일운영자' 분포와 얼마나 부합하나(작을수록 이질).
    p = (1 + #{cal 이 score 만큼 또는 더 '비동일운영자스러운'}) / (n+1)."""
    s = list(cal_scores_true)
    n = len(s)
    if n == 0:
        return 1.0
    if lower_is_positive:                   # 큰 점수일수록 비동일운영자스러움
        cnt = sum(1 for x in s if x >= score)
    else:
        cnt = sum(1 for x in s if x <= score)
    return (1 + cnt) / (n + 1)


# --------------------------------------------------------------------------- #
# Mondrian(그룹 조건부) conformal — 그룹별 커버리지 보장(강화 축12)
# --------------------------------------------------------------------------- #
def mondrian_thresholds(cal_scores_by_group: dict, alpha: float = 0.1,
                        lower_is_positive: bool = True) -> dict:
    """그룹별로 독립적인 conformal 임계값. 각 그룹 g 안에서 커버리지 ≥ 1-α 를 보장한다.

    marginal conformal 은 '전체'에서만 1-α 를 보장하고 특정 그룹(예: 특정 provider)에서는 미달할 수
    있다. Mondrian(class-conditional) conformal 은 각 그룹의 보정점수로 그 그룹의 τ_g 를 따로 잡아
    **그룹 조건부 커버리지**를 보장한다. 반환 {group: τ_g}(표본 부족 그룹은 conformal_threshold 규칙에
    따라 ±∞)."""
    return {g: conformal_threshold(scores, alpha=alpha, lower_is_positive=lower_is_positive)
            for g, scores in cal_scores_by_group.items()}


def mondrian_decide(score: float, group, thresholds: dict,
                    lower_is_positive: bool = True) -> bool:
    """그룹 조건부 임계값으로 positive 판정. 그룹 미학습이면 보수적으로 reject(positive 아님)."""
    tau = thresholds.get(group)
    if tau is None:
        return False
    return score <= tau if lower_is_positive else score >= tau


# --------------------------------------------------------------------------- #
# Conformal Risk Control (CRC) — 기대손실 E[L] ≤ α 를 유한표본에서 통제(강화 축12)
# --------------------------------------------------------------------------- #
def crc_controls(cal_losses, alpha: float, loss_bound: float = 1.0) -> dict:
    """고정 λ 의 보정 손실들로 CRC 보장 여부 판정.

    Angelopoulos et al.(2023) Conformal Risk Control: 손실 L∈[0,B], 단조. 유한표본 보장은
        (n·R̂ + B)/(n+1) ≤ α  ⟹  E[L_test] ≤ α
    (R̂ = 보정셋 평균손실). 이 부등식이 성립하면 그 λ 는 위험을 통제한다. 반환 지표 dict."""
    losses = [float(x) for x in cal_losses]
    n = len(losses)
    if n == 0:
        return {"empirical_risk": 0.0, "crc_bound": loss_bound, "controls": loss_bound <= alpha,
                "n": 0, "loss_bound": loss_bound}
    rhat = sum(losses) / n
    bound = (n * rhat + loss_bound) / (n + 1)
    return {"empirical_risk": rhat, "crc_bound": bound, "controls": bound <= alpha,
            "n": n, "loss_bound": loss_bound}


def crc_select_lambda(lambdas, loss_at_lambda, alpha: float, loss_bound: float = 1.0):
    """단조 grid 에서 위험을 통제하는 λ 를 고른다. loss_at_lambda(λ)->보정 손실 리스트.

    표준 CRC: 손실이 λ 에 대해 단조 비증가라고 가정하고, (n·R̂(λ)+B)/(n+1) ≤ α 를 만족하는 가장
    '공격적인'(작은) λ 를 택한다. 통제하는 λ 가 없으면 None(전수 보수 채택). 반환 (λ*, 지표)."""
    chosen = None
    info = None
    for lam in lambdas:
        c = crc_controls(loss_at_lambda(lam), alpha, loss_bound=loss_bound)
        if c["controls"]:
            chosen, info = lam, c
            break
    return chosen, info
