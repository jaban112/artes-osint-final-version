"""인프라-자산 recon 오케스트레이션 — 도메인·IP·ASN·CIDR·URL 자산 + (인가된) 사람 selector.

경계(거버넌스 게이팅 — 타입 차단이 아님): 합법 OSINT 는 공개출처를 인가·감사 안에서 활용한다.
이메일·전화·아이디·이름 등 사람 selector 는 **데이터 타입으로 막지 않는다**. 대신 AuthorizationScope 가
합법근거(consent/legal/self-audit/osint-public)와 정확 인가로 게이팅하고, 실행시점 재검증+전 조회 감사한다
(infra_only=threat-intel-infra 근거에선 여전히 자산만). 사람 축 유출 노출은 person_osint.PersonRecon 로,
**식별자(이메일·아이디)는 당사자 확인용으로 노출하되 비밀번호 등 자격증명은 authz.redact_credentials 로
전량 제외**한다. RDAP 등록자 처리도 이 인가 틀 안에서만.

구성:
  * InfraTarget / classify_infra   — 자산 타입 판별
  * classify_person                — 사람 selector 타입 판별(인가 scope 가 조회 허용 여부 결정)
  * InfraSource (어댑터 프로토콜)   — 주입가능 async http 로 오프라인 검증 가능
  * 어댑터: CertTransparency(crt.sh), RDAPDomain, RDAPIp, DoHDNS,
            ASNPrefixes(RIPEstat), IPToASN(RIPEstat)
  * InfraRecon                     — scheduler(전역 거버너) 위 재귀확장 + authz 게이트
  * correlate_same_operator        — 공유 NS/IP/ASN/레지스트라를 독립근거로 세어 CP 게이트로
                                     same-operator 를 '정확 하한'으로 판정(휴리스틱 금지)

Entity/Edge/Graph 는 artes.core.model 을 그대로 쓴다. 간선은 Graph.link 로 넣는다
(근거 없는 연결 거부 규약). 모든 간선 끝점은 _k() 로 엔티티 키와 정확히 일치시킨다.
"""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional

from .model import Entity, Edge, EntityType, Certainty, Evidence, Graph, _normalize


def _k(t: EntityType, v: str) -> str:
    """엔티티 키(모델 정규화 규약과 동일). 간선 끝점을 엔티티 키와 일치시킨다."""
    return f"{t.value}:{_normalize(t, v)}"


# --------------------------------------------------------------------------- #
# 자산 타입 판별 + 사람 selector 거부
# --------------------------------------------------------------------------- #
class InfraType(str, Enum):
    DOMAIN = "domain"
    IP = "ip"
    ASN = "asn"
    CIDR = "cidr"
    URL = "url"


_DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)([a-z0-9-]{1,63}(?<!-)\.)+[a-z]{2,63}$", re.I)
_ASN_RE = re.compile(r"^as(\d{1,10})$", re.I)


def classify_infra(value: str) -> Optional[InfraType]:
    """자산 타입 판별. 사람 selector(이메일/전화/아이디/이름 등)면 None(거부)."""
    v = (value or "").strip()
    if not v:
        return None
    if "@" in v:                                 # 이메일 → 거부
        return None
    if v.lower().startswith(("http://", "https://")):
        return InfraType.URL
    if _ASN_RE.match(v):                         # 'AS' 접두 있는 것만 ASN (순수 숫자 거부)
        return InfraType.ASN
    try:
        ipaddress.ip_address(v)
        return InfraType.IP
    except ValueError:
        pass
    if "/" in v:
        try:
            ipaddress.ip_network(v, strict=False)
            return InfraType.CIDR
        except ValueError:
            pass
    if _DOMAIN_RE.match(v):
        return InfraType.DOMAIN
    return None                                  # 이름·아이디·전화 등 → 자산 아님


_INFRA_TO_ENTITY = {
    InfraType.DOMAIN: EntityType.DOMAIN,
    InfraType.IP: EntityType.IP,
    InfraType.ASN: EntityType.ASN,
    InfraType.CIDR: EntityType.HOST,   # 모델에 CIDR 타입 없음 → HOST + attrs.kind=cidr
    InfraType.URL: EntityType.URL,
}

_EMAIL_RE = re.compile(r"^[^@\s]+@[a-z0-9.-]+\.[a-z]{2,}$", re.I)
_PHONE_RE = re.compile(r"^\+?[0-9][0-9()\-.\s]{5,}[0-9]$")
_HANDLE_RE = re.compile(r"^@?[a-z0-9_.]{2,32}$", re.I)


def classify_person(value: str) -> Optional[EntityType]:
    """사람 selector 타입 판별(합법 OSINT — 데이터 타입 차단이 아니라 거버넌스 게이팅용).

    이메일/전화/아이디(핸들)/성명(공백 포함)/site:handle(계정) 을 구분한다. 인프라가 아닌 것만 여기로
    온다(seed_one 이 InfraTarget.parse 실패 후 호출). 실제 조회 허용은 AuthorizationScope 가 결정."""
    v = (value or "").strip()
    if not v:
        return None
    if classify_infra(v) is not None:            # 인프라(도메인·IP·ASN·CIDR·URL)면 사람 selector 아님
        return None
    if _EMAIL_RE.match(v):
        return EntityType.EMAIL
    if ":" in v and not v.lower().startswith(("http", "as")):   # instagram:hong123 형태 = 계정
        site, _, handle = v.partition(":")
        if site and handle and _HANDLE_RE.match(handle):
            return EntityType.ACCOUNT
    digits = re.sub(r"\D", "", v)
    if _PHONE_RE.match(v) and 7 <= len(digits) <= 15:
        return EntityType.PHONE
    if v.startswith("@") or (_HANDLE_RE.match(v) and " " not in v):
        return EntityType.USERNAME
    if " " in v and re.fullmatch(r"[^\d@/]+", v):               # 공백 포함 + 숫자/기호 없음 = 성명
        return EntityType.NAME
    return None


@dataclass(frozen=True)
class InfraTarget:
    type: InfraType
    value: str

    @property
    def normalized(self) -> str:
        v = self.value.strip()
        if self.type in (InfraType.DOMAIN, InfraType.URL):
            return v.lower().rstrip(".")
        if self.type == InfraType.ASN:
            return "AS" + re.sub(r"\D", "", v)
        return v

    @classmethod
    def parse(cls, value: str) -> Optional["InfraTarget"]:
        t = classify_infra(value)
        return cls(t, value) if t else None


# --------------------------------------------------------------------------- #
# HTTP 레이어는 nethttp.py 로 분리(리뷰 P1: infra_recon 비대화 완화). 하위호환 위해 재수출.
# --------------------------------------------------------------------------- #
from .nethttp import (  # noqa: F401
    HTTPResp, HttpGet, default_http_get, close_http, CachingHTTP, PolitenessHTTP,
    RequestLimiter, SSRFGuard, is_blocked_ip, _default_resolver, _HostLimiter,
    _urllib_get, _aiohttp_get, _AIOHTTP_SESSIONS, _UA,
)

# --------------------------------------------------------------------------- #
# 스코프 확대 생성기 (인프라 자산만)
# --------------------------------------------------------------------------- #
def iter_cidr_hosts(cidr: str, limit: int = 65536):
    """CIDR → 호스트 IP 제너레이터(네트워크/브로드캐스트 제외, v4). 대규모 스윕용(메모리 유계)."""
    net = ipaddress.ip_network(cidr, strict=False)
    for i, ip in enumerate(net.hosts()):
        if i >= limit:
            break
        yield str(ip)


def expand_cidr_to_hosts(cidr: str, limit: int = 4096) -> list[str]:
    """CIDR → 호스트 IP 목록(리스트). 소규모/명시적 용도. 대규모는 iter_cidr_hosts."""
    return list(iter_cidr_hosts(cidr, limit=limit))


def subdomain_candidates(domain: str, words) -> list[str]:
    """도메인의 하위도메인 후보 생성(자기 자산 열거). words 리스트 → w.domain."""
    d = domain.strip().lower().rstrip(".")
    seen, out = set(), []
    for w in words:
        w = str(w).strip().lower().strip(".")
        if not w:
            continue
        cand = f"{w}.{d}"
        if cand not in seen and _DOMAIN_RE.match(cand):
            seen.add(cand)
            out.append(cand)
    return out


# 소형 내장 워드리스트(데모/테스트용; 실전은 파일 주입). 흔한 인프라 서브도메인.
COMMON_SUBDOMAINS = [
    "www", "mail", "smtp", "imap", "pop", "ns1", "ns2", "mx", "webmail", "remote",
    "vpn", "api", "dev", "staging", "test", "app", "admin", "portal", "cdn", "static",
    "assets", "img", "media", "blog", "shop", "store", "git", "gitlab", "jenkins",
    "ci", "docs", "status", "grafana", "kibana", "prometheus", "db", "sql", "redis",
    "cache", "auth", "sso", "login", "id", "account", "dashboard", "beta", "demo",
]


# --------------------------------------------------------------------------- #
# 어댑터
# --------------------------------------------------------------------------- #
@dataclass
class FetchResult:
    source: str
    entities: list[Entity] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    ok: bool = True
    error: str = ""
    rate_limited: bool = False


class InfraSource:
    name: str = "infra-base"
    accepts: set[InfraType] = set()
    host: str = ""

    async def fetch(self, target: InfraTarget, http: HttpGet) -> FetchResult:
        raise NotImplementedError


def _ev(source: str, detail: str, url: str = "") -> list[Evidence]:
    return [Evidence(source=source, detail=detail, url=url)]


class CertTransparency(InfraSource):
    """crt.sh 인증서 투명성 로그 → 하위도메인 + 발급자(자산 attr). 도메인만."""
    name = "crt.sh"
    accepts = {InfraType.DOMAIN}
    host = "crt.sh"

    async def fetch(self, target, http):
        d = target.normalized
        url = f"https://crt.sh/?q=%25.{d}&output=json"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            rows = r.json() or []
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: dict[str, Entity] = {}
        edges: list[Edge] = []
        for row in rows:
            issuer = (row.get("issuer_name") or "").strip()
            cid = str(row.get("id") or "").strip()   # crt.sh 인증서 id — 물리 인증서 식별
            names = list((row.get("name_value") or "").split("\n"))
            names.append(row.get("common_name") or "")
            for nm in names:
                nm = nm.strip().lower().lstrip("*.")
                if not nm or not _DOMAIN_RE.match(nm):
                    continue
                if nm == d or nm.endswith("." + d):
                    e = ents.get(nm)
                    if e is None:
                        e = Entity(type=EntityType.DOMAIN, value=nm,
                                   certainty=Certainty.CONFIRMED,
                                   evidence=_ev(self.name, f"{d} 인증서 SAN", url),
                                   attrs={"issuers": [], "cert_ids": []})
                        ents[nm] = e
                        if nm != d:
                            edges.append(Edge(src=_k(EntityType.DOMAIN, d),
                                              dst=_k(EntityType.DOMAIN, nm),
                                              relation="하위도메인",
                                              certainty=Certainty.CONFIRMED,
                                              evidence=_ev(self.name, "CT 로그", url)))
                    if issuer and issuer not in e.attrs["issuers"]:
                        e.attrs["issuers"].append(issuer)
                    # 같은 물리 인증서에 여러 도메인이 SAN 으로 올라오면, 각 도메인을 독립
                    # 쿼리해도 동일 cert id 가 양쪽에 나타난다 → 교차하면 공유인증서(독립 신호).
                    if cid and cid not in e.attrs["cert_ids"]:
                        e.attrs["cert_ids"].append(cid)
        return FetchResult(self.name, entities=list(ents.values()), edges=edges)


class DoHDNS(InfraSource):
    """DNS-over-HTTPS(Cloudflare) → A/AAAA/NS/MX/CNAME. 도메인만."""
    name = "doh-dns"
    accepts = {InfraType.DOMAIN}
    host = "cloudflare-dns.com"
    _TYPES = ["A", "AAAA", "NS", "MX", "CNAME", "TXT"]
    _NUM = {1: "A", 2: "NS", 5: "CNAME", 15: "MX", 28: "AAAA", 16: "TXT", 12: "PTR"}

    async def fetch(self, target, http):
        import asyncio
        d = target.normalized
        ents: dict[str, Entity] = {}
        edges: list[Edge] = []
        spf_includes: set[str] = set()
        txt_tokens: dict[str, str] = {}
        try:
            from .signals import _VERIFICATION_VENDORS as _VENDORS
        except Exception:
            _VENDORS = []
        any_ok = False

        async def _q(qt):
            url = f"https://cloudflare-dns.com/dns-query?name={d}&type={qt}"
            return qt, url, await http(url)

        # 레코드 타입들을 동시에(도메인당 N왕복 → 1왕복 지연). 실패 격리.
        results = await asyncio.gather(*[_q(qt) for qt in self._TYPES],
                                       return_exceptions=True)
        for item in results:
            if isinstance(item, Exception):
                continue
            qt, url, r = item
            if r.status == 429:
                return FetchResult(self.name, ok=False, error="429", rate_limited=True)
            if r.status != 200 or not r.text:
                continue
            any_ok = True
            try:
                ans = (r.json() or {}).get("Answer", []) or []
            except Exception:
                continue
            for a in ans:
                if self._NUM.get(a.get("type")) == "TXT":
                    txt = (a.get("data") or "").strip().strip('"')
                    tl = txt.lower()
                    if "v=spf1" in tl:      # SPF include → 공유 메일인프라 신호
                        for m in re.findall(r"include:([^\s\"]+)", txt, re.I):
                            spf_includes.add(m.strip().lower().rstrip("."))
                    else:                   # 검증 토큰(vendor=token) → 벤더별 독립 축
                        for vend in _VENDORS:
                            if tl.startswith(vend.lower() + "="):
                                txt_tokens[vend] = txt[len(vend) + 1:].strip()
                                break
                    continue
                rt = self._NUM.get(a.get("type"), str(a.get("type")))
                data = (a.get("data") or "").strip().rstrip(".")
                if not data:
                    continue
                if rt in ("A", "AAAA"):
                    if data not in ents:
                        ents[data] = Entity(type=EntityType.IP, value=data,
                                            certainty=Certainty.CONFIRMED,
                                            evidence=_ev(self.name, f"{d} {rt}", url))
                    edges.append(Edge(src=_k(EntityType.DOMAIN, d),
                                      dst=_k(EntityType.IP, data),
                                      relation="해석됨(A)", certainty=Certainty.CONFIRMED,
                                      evidence=_ev(self.name, f"{rt} 레코드", url)))
                elif rt in ("NS", "MX", "CNAME"):
                    host = data.split()[-1].lower().rstrip(".")   # MX "10 mail.x" → mail.x
                    if not _DOMAIN_RE.match(host):
                        continue
                    if host not in ents:
                        ents[host] = Entity(type=EntityType.DOMAIN, value=host,
                                            certainty=Certainty.CONFIRMED,
                                            evidence=_ev(self.name, f"{d} {rt}", url),
                                            attrs={"role": rt.lower()})
                    rel = {"NS": "네임서버", "MX": "메일서버", "CNAME": "별칭"}[rt]
                    edges.append(Edge(src=_k(EntityType.DOMAIN, d),
                                      dst=_k(EntityType.DOMAIN, host),
                                      relation=rel, certainty=Certainty.CONFIRMED,
                                      evidence=_ev(self.name, f"{rt} 레코드", url)))
        if not any_ok:
            return FetchResult(self.name, ok=False, error="no answer")
        out_ents = list(ents.values())
        if spf_includes or txt_tokens:
            # 쿼리 도메인 attr(seed 엔티티에 병합): SPF include + TXT 검증 토큰 → same-operator 축.
            at: dict[str, Any] = {}
            if spf_includes:
                at["spf_includes"] = sorted(spf_includes)
            if txt_tokens:
                at["txt_tokens"] = txt_tokens
            out_ents.append(Entity(type=EntityType.DOMAIN, value=d,
                                   certainty=Certainty.CONFIRMED,
                                   evidence=_ev(self.name, "TXT(SPF/검증토큰)", ""),
                                   attrs=at))
        return FetchResult(self.name, entities=out_ents, edges=edges)


class RDAPDomain(InfraSource):
    """RDAP 도메인 → 네임서버 + 레지스트라(조직) + 상태. 등록자 사람 vCard 제외."""
    name = "rdap-domain"
    accepts = {InfraType.DOMAIN}
    host = "rdap.org"

    async def fetch(self, target, http):
        d = target.normalized
        url = f"https://rdap.org/domain/{d}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            obj = r.json() or {}
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: list[Entity] = []
        edges: list[Edge] = []
        for ns in obj.get("nameservers", []) or []:
            h = (ns.get("ldhName") or "").strip().lower().rstrip(".")
            if h and _DOMAIN_RE.match(h):
                ents.append(Entity(type=EntityType.DOMAIN, value=h,
                                   certainty=Certainty.CONFIRMED,
                                   evidence=_ev(self.name, "RDAP 네임서버", url),
                                   attrs={"role": "ns"}))
                edges.append(Edge(src=_k(EntityType.DOMAIN, d),
                                  dst=_k(EntityType.DOMAIN, h),
                                  relation="네임서버", certainty=Certainty.CONFIRMED,
                                  evidence=_ev(self.name, "RDAP", url)))
        for ent in obj.get("entities", []) or []:
            if "registrar" in (ent.get("roles") or []):
                org = _vcard_org_only(ent)
                if org:
                    ents.append(Entity(type=EntityType.ORG, value=org,
                                       certainty=Certainty.CONFIRMED,
                                       evidence=_ev(self.name, "RDAP 레지스트라", url),
                                       attrs={"role": "registrar"}))
                    edges.append(Edge(src=_k(EntityType.DOMAIN, d),
                                      dst=_k(EntityType.ORG, org),
                                      relation="레지스트라", certainty=Certainty.CONFIRMED,
                                      evidence=_ev(self.name, "RDAP", url)))
        return FetchResult(self.name, entities=ents, edges=edges)


class RDAPIp(InfraSource):
    """RDAP IP → CIDR·네트워크명(조직)·origin ASN. 사람 vCard 제외."""
    name = "rdap-ip"
    accepts = {InfraType.IP}
    host = "rdap.org"

    async def fetch(self, target, http):
        ip = target.normalized
        url = f"https://rdap.org/ip/{ip}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            obj = r.json() or {}
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: list[Entity] = []
        edges: list[Edge] = []
        for c in obj.get("cidr0_cidrs", []) or []:
            pfx = c.get("v4prefix") or c.get("v6prefix")
            ln = c.get("length")
            if pfx and ln is not None:
                cidr = f"{pfx}/{ln}"
                ents.append(Entity(type=EntityType.HOST, value=cidr,
                                   certainty=Certainty.CONFIRMED,
                                   evidence=_ev(self.name, "RDAP CIDR", url),
                                   attrs={"kind": "cidr"}))
                edges.append(Edge(src=_k(EntityType.IP, ip),
                                  dst=_k(EntityType.HOST, cidr),
                                  relation="속한 대역", certainty=Certainty.CONFIRMED,
                                  evidence=_ev(self.name, "RDAP", url)))
        name = (obj.get("name") or "").strip()
        if name:
            ents.append(Entity(type=EntityType.ORG, value=name,
                               certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, "RDAP 네트워크명", url),
                               attrs={"role": "netblock-owner"}))
            edges.append(Edge(src=_k(EntityType.IP, ip),
                              dst=_k(EntityType.ORG, name),
                              relation="네트워크 소유", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "RDAP", url)))
        for asn in obj.get("arin_originas0_originautnums", []) or []:
            av = f"AS{asn}"
            ents.append(Entity(type=EntityType.ASN, value=av,
                               certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, "RDAP origin ASN", url)))
            edges.append(Edge(src=_k(EntityType.IP, ip),
                              dst=_k(EntityType.ASN, av),
                              relation="origin ASN", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "RDAP", url)))
        return FetchResult(self.name, entities=ents, edges=edges)


class ASNPrefixes(InfraSource):
    """RIPEstat announced-prefixes → ASN 이 광고하는 CIDR."""
    name = "ripestat-asn-prefixes"
    accepts = {InfraType.ASN}
    host = "stat.ripe.net"

    async def fetch(self, target, http):
        asn = re.sub(r"\D", "", target.normalized)
        url = f"https://stat.ripe.net/data/announced-prefixes/data.json?resource=AS{asn}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            data = (r.json() or {}).get("data", {}) or {}
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: list[Entity] = []
        edges: list[Edge] = []
        av = f"AS{asn}"
        for p in data.get("prefixes", []) or []:
            cidr = (p.get("prefix") or "").strip()
            if not cidr:
                continue
            try:
                ipaddress.ip_network(cidr, strict=False)
            except ValueError:
                continue
            ents.append(Entity(type=EntityType.HOST, value=cidr,
                               certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, f"AS{asn} 광고 대역", url),
                               attrs={"kind": "cidr"}))
            edges.append(Edge(src=_k(EntityType.ASN, av),
                              dst=_k(EntityType.HOST, cidr),
                              relation="광고", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "RIPEstat", url)))
        return FetchResult(self.name, entities=ents, edges=edges)


class IPToASN(InfraSource):
    """RIPEstat network-info → IP 의 ASN·prefix."""
    name = "ripestat-ip-asn"
    accepts = {InfraType.IP}
    host = "stat.ripe.net"

    async def fetch(self, target, http):
        ip = target.normalized
        url = f"https://stat.ripe.net/data/network-info/data.json?resource={ip}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            data = (r.json() or {}).get("data", {}) or {}
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: list[Entity] = []
        edges: list[Edge] = []
        pfx = (data.get("prefix") or "").strip()
        if pfx:
            ents.append(Entity(type=EntityType.HOST, value=pfx,
                               certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, "RIPEstat prefix", url),
                               attrs={"kind": "cidr"}))
            edges.append(Edge(src=_k(EntityType.IP, ip),
                              dst=_k(EntityType.HOST, pfx),
                              relation="속한 대역", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "RIPEstat", url)))
        for asn in data.get("asns", []) or []:
            av = f"AS{asn}"
            ents.append(Entity(type=EntityType.ASN, value=av,
                               certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, "RIPEstat ASN", url)))
            edges.append(Edge(src=_k(EntityType.IP, ip),
                              dst=_k(EntityType.ASN, av),
                              relation="origin ASN", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "RIPEstat", url)))
        return FetchResult(self.name, entities=ents, edges=edges)


class HackerTargetHostSearch(InfraSource):
    """HackerTarget hostsearch(CSV 'host,ip') → 하위도메인 + A레코드. passive-DNS 독립 출처."""
    name = "hackertarget"
    accepts = {InfraType.DOMAIN}
    host = "api.hackertarget.com"

    async def fetch(self, target, http):
        d = target.normalized
        url = f"https://api.hackertarget.com/hostsearch/?q={d}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        ents: dict[str, Entity] = {}
        edges: list[Edge] = []
        for line in r.text.splitlines():
            parts = line.strip().split(",")
            if len(parts) != 2:
                continue                    # "API count exceeded" 등 에러라인 무시
            host, ip = parts[0].strip().lower().rstrip("."), parts[1].strip()
            if not _DOMAIN_RE.match(host):
                continue
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                continue
            ents[ip] = Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "passive-DNS A", url))
            ents[host] = Entity(type=EntityType.DOMAIN, value=host,
                                certainty=Certainty.CONFIRMED,
                                evidence=_ev(self.name, "passive-DNS host", url))
            edges.append(Edge(src=_k(EntityType.DOMAIN, host), dst=_k(EntityType.IP, ip),
                              relation="해석됨(A)", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "passive-DNS", url)))
            if host != d and host.endswith("." + d):
                edges.append(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, host),
                                  relation="하위도메인", certainty=Certainty.CONFIRMED,
                                  evidence=_ev(self.name, "passive-DNS", url)))
        return FetchResult(self.name, entities=list(ents.values()), edges=edges)


class AlienVaultPDNS(InfraSource):
    """OTX AlienVault passive DNS(JSON) → 하위도메인 + A레코드. passive-DNS 독립 출처."""
    name = "otx-pdns"
    accepts = {InfraType.DOMAIN}
    host = "otx.alienvault.com"

    async def fetch(self, target, http):
        d = target.normalized
        url = f"https://otx.alienvault.com/api/v1/indicators/domain/{d}/passive_dns"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            recs = (r.json() or {}).get("passive_dns", []) or []
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents: dict[str, Entity] = {}
        edges: list[Edge] = []
        for rec in recs:
            host = (rec.get("hostname") or "").strip().lower().rstrip(".")
            ip = (rec.get("address") or "").strip()
            if not _DOMAIN_RE.match(host):
                continue
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                continue
            ents[ip] = Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "passive-DNS A", url))
            ents[host] = Entity(type=EntityType.DOMAIN, value=host,
                                certainty=Certainty.CONFIRMED,
                                evidence=_ev(self.name, "passive-DNS host", url))
            edges.append(Edge(src=_k(EntityType.DOMAIN, host), dst=_k(EntityType.IP, ip),
                              relation="해석됨(A)", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "passive-DNS", url)))
            if host != d and host.endswith("." + d):
                edges.append(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, host),
                                  relation="하위도메인", certainty=Certainty.CONFIRMED,
                                  evidence=_ev(self.name, "passive-DNS", url)))
        return FetchResult(self.name, entities=list(ents.values()), edges=edges)


def _reverse_ptr(ip: str) -> str:
    """IP → PTR 조회 이름(v4 in-addr.arpa / v6 ip6.arpa)."""
    obj = ipaddress.ip_address(ip)
    if obj.version == 4:
        return ".".join(reversed(ip.split("."))) + ".in-addr.arpa"
    nib = obj.exploded.replace(":", "")
    return ".".join(reversed(nib)) + ".ip6.arpa"


class DMARCLookup(InfraSource):
    """_dmarc.<domain> TXT → DMARC rua/ruf 보고 엔드포인트(mailto 호스트). 공유 = 같은 메일관리."""
    name = "dmarc"
    accepts = {InfraType.DOMAIN}
    host = "cloudflare-dns.com"

    async def fetch(self, target, http):
        d = target.normalized
        r = await http(f"https://cloudflare-dns.com/dns-query?name=_dmarc.{d}&type=TXT")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            ans = (r.json() or {}).get("Answer", []) or []
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        rep: set[str] = set()
        for a in ans:
            if a.get("type") != 16:
                continue
            txt = (a.get("data") or "").strip().strip('"')
            if "v=dmarc1" not in txt.lower():
                continue
            for m in re.findall(r"ru[af]=([^;]+)", txt, re.I):
                for addr in m.split(","):
                    addr = addr.strip()
                    if "mailto:" in addr.lower() and "@" in addr:
                        rep.add(addr.split("@")[-1].strip().lower().rstrip("."))
        if not rep:
            return FetchResult(self.name, ok=False, error="no dmarc")
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "DMARC 보고 엔드포인트", ""),
                     attrs={"dmarc": sorted(rep)})
        return FetchResult(self.name, entities=[ent])


class ReverseDNS(InfraSource):
    """IP → PTR 호스트 + ptr_domain(끝 2라벨 = 코스한 호스팅 키). 공유 = 같은 호스팅 제공자."""
    name = "ptr"
    accepts = {InfraType.IP}
    host = "cloudflare-dns.com"

    async def fetch(self, target, http):
        ip = target.normalized
        try:
            rev = _reverse_ptr(ip)
        except ValueError:
            return FetchResult(self.name, ok=False, error="bad ip")
        r = await http(f"https://cloudflare-dns.com/dns-query?name={rev}&type=PTR")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            ans = (r.json() or {}).get("Answer", []) or []
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        hostname = ""
        for a in ans:
            if a.get("type") == 12 and a.get("data"):
                hostname = a["data"].strip().lower().rstrip(".")
                break
        if not hostname:
            return FetchResult(self.name, ok=False, error="no ptr")
        parts = hostname.split(".")
        ptr_domain = ".".join(parts[-2:]) if len(parts) >= 2 else hostname
        ent = Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "역DNS PTR", ""),
                     attrs={"ptr": hostname, "ptr_domain": ptr_domain})
        return FetchResult(self.name, entities=[ent])


def spki_pin(der: bytes) -> str:
    """인증서 DER → SubjectPublicKeyInfo SHA-256 핀. 서로 다른 인증서라도 같은 키면 같은 핀
    (강한 same-operator 신호). cryptography 없으면 전체 인증서 해시로 폴백(약한 핀)."""
    import hashlib
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import serialization
        cert = x509.load_der_x509_certificate(der)
        spki = cert.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo)
        return "spki:" + hashlib.sha256(spki).hexdigest()
    except Exception:
        return "cert:" + hashlib.sha256(der).hexdigest()


async def _default_tls_probe(host: str, *, port: int = 443, timeout: float = 8.0):
    """실제 TLS 핸드셰이크로 리프 인증서 DER 획득. 테스트는 probe 주입으로 대체."""
    import asyncio
    import ssl

    def _get():
        try:
            pem = ssl.get_server_certificate((host, port), timeout=timeout)
            return ssl.PEM_cert_to_DER_cert(pem)
        except Exception:
            return None

    return await asyncio.get_event_loop().run_in_executor(None, _get)


class TLSProbe(InfraSource):
    """도메인 TLS 리프 인증서 → SPKI 핀(attr spki). 비용이 커서 default 아님(옵트인).

    두 도메인이 같은 SPKI 핀 = 같은 공개키 = 강한 동일운영자 신호(다른 인증서여도).
    """
    name = "tls-spki"
    accepts = {InfraType.DOMAIN}
    host = ""

    def __init__(self, probe=None):
        self.probe = probe          # async (host) -> DER bytes | None

    async def fetch(self, target, http):
        d = target.normalized
        der = await (self.probe or _default_tls_probe)(d)
        if not der:
            return FetchResult(self.name, ok=False, error="no cert")
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "TLS SPKI 핀", ""),
                     attrs={"spki": spki_pin(der)})
        return FetchResult(self.name, entities=[ent])


async def _default_favicon_fetch(host: str, *, timeout: float = 8.0):
    """https://host/favicon.ico 바이트. 테스트는 fetch_bytes 주입으로 대체."""
    import asyncio
    try:
        import aiohttp
    except ImportError:
        return None

    async def _get():
        try:
            conn = aiohttp.TCPConnector(limit_per_host=8)
            async with aiohttp.ClientSession(connector=conn) as s:
                async with s.get(f"https://{host}/favicon.ico",
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                    if r.status != 200:
                        return None
                    return await r.read()
        except Exception:
            return None
    return await _get()


class FaviconHash(InfraSource):
    """favicon.ico 해시(md5) → 공유 favicon = 같은 스택/운영자 신호. 옵트인(추가 GET)."""
    name = "favicon"
    accepts = {InfraType.DOMAIN}
    host = ""

    def __init__(self, fetch_bytes=None):
        self.fetch_bytes = fetch_bytes      # async (host) -> bytes | None

    async def fetch(self, target, http):
        import hashlib
        d = target.normalized
        raw = await (self.fetch_bytes or _default_favicon_fetch)(d)
        if not raw:
            return FetchResult(self.name, ok=False, error="no favicon")
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "favicon 해시", ""),
                     attrs={"favicon": hashlib.md5(raw).hexdigest()})
        return FetchResult(self.name, entities=[ent])


class HTTPHeaderFP(InfraSource):
    """HTTP 응답 헤더 지문(Server + 헤더 이름 순서/집합 해시). 값은 제외(프라이버시). 옵트인."""
    name = "http-fp"
    accepts = {InfraType.DOMAIN}
    host = ""

    async def fetch(self, target, http):
        import hashlib
        d = target.normalized
        r = await http(f"https://{d}/")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status < 0:
            return FetchResult(self.name, ok=False, error="net")
        headers = r.headers or {}
        server = (headers.get("Server") or headers.get("server") or "").strip()
        names = sorted(k.lower() for k in headers.keys())
        fp = hashlib.md5(("|".join(names) + "||" + server).encode("utf-8")).hexdigest()
        attrs = {"httpfp": fp}
        if server:
            attrs["server"] = server
        # 헤더 dict(소문자 키) 저장 → signals 의 hdr_* 축들이 값으로 사용.
        low = {k.lower(): v for k, v in headers.items()}
        if low:
            attrs["http_headers"] = low
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "HTTP 헤더 지문", ""), attrs=attrs)
        return FetchResult(self.name, entities=[ent])


def tls_behavior_digest(observations) -> str:
    """JARM 계열 능동-TLS 행동지문(결정적 집계). observations = 여러 ClientHello 응답의
    (tls_version, cipher, ext_fingerprint) 튜플 목록. 같은 TLS 스택은 같은 digest.

    주의: Salesforce JARM 과 **바이트 동일하지 않다**(정식 JARM 압축 규칙 대신 정규 해시 집계).
    같은 관측을 넣으면 같은 값이 나오는 결정적 지문일 뿐 — 공유하면 같은 스택 신호로 쓴다.
    """
    import hashlib
    canon = "|".join(
        f"{(o[0] if len(o) > 0 else '')}:{(o[1] if len(o) > 1 else '')}:{(o[2] if len(o) > 2 else '')}"
        for o in observations)
    return "tlsfp:" + hashlib.sha256(canon.encode("utf-8")).hexdigest()[:60]


class TLSBehaviorProbe(InfraSource):
    """능동-TLS 행동지문(JARM 계열) → attr tlsfp. 여러 ClientHello 를 보내야 해 비용 큼(옵트인).

    probe(host) 는 지문 문자열을 직접 반환하거나(예: 실제 jarm 라이브러리),
    관측 튜플 목록을 반환하면 tls_behavior_digest 로 집계한다. 테스트는 probe 주입.
    """
    name = "tls-behavior"
    accepts = {InfraType.DOMAIN}
    host = ""

    def __init__(self, probe=None):
        self.probe = probe          # async (host) -> str | list[tuple]

    async def fetch(self, target, http):
        d = target.normalized
        if self.probe is None:
            return FetchResult(self.name, ok=False, error="no probe(옵트인)")
        val = await self.probe(d)
        if not val:
            return FetchResult(self.name, ok=False, error="no tlsfp")
        fp = val if isinstance(val, str) else tls_behavior_digest(val)
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "TLS 행동지문", ""), attrs={"tlsfp": fp})
        return FetchResult(self.name, entities=[ent])


def _vcard_org_only(entity: dict) -> str:
    """RDAP entity vCard 에서 조직/이름 텍스트만. 사람 연락처(email/tel/adr)는 안 읽음."""
    v = entity.get("vcardArray")
    if not (isinstance(v, list) and len(v) == 2 and isinstance(v[1], list)):
        return (entity.get("handle") or "").strip()
    fn = org = ""
    for item in v[1]:
        if not (isinstance(item, list) and len(item) >= 4):
            continue
        key, val = item[0], item[3]
        if key == "org":
            org = val if isinstance(val, str) else (val[0] if isinstance(val, list) and val else "")
        elif key == "fn":
            fn = val if isinstance(val, str) else ""
        # email/tel/adr 등은 의도적으로 무시(사람 PII 미수집)
    return (org or fn or entity.get("handle") or "").strip()


def default_infra_sources() -> list[InfraSource]:
    return [CertTransparency(), DoHDNS(), RDAPDomain(), RDAPIp(),
            ASNPrefixes(), IPToASN(), HackerTargetHostSearch(), AlienVaultPDNS()]


# --------------------------------------------------------------------------- #
# 오케스트레이터
# --------------------------------------------------------------------------- #
_EXPANDABLE_INFRA = {EntityType.DOMAIN, EntityType.IP, EntityType.ASN}


class InfraRecon:
    """인프라 자산 recon. scheduler 전역 거버너 위 재귀확장, authz.infra_only 게이트."""

    def __init__(self, sources: Optional[list[InfraSource]] = None,
                 http: Optional[HttpGet] = None, *, scope=None, governor=None,
                 depth: int = 2, max_jobs: int = 200000, max_seconds: float = 600.0,
                 concurrency: int = 128, cache: bool = True,
                 max_requests: Optional[int] = None, ssrf_guard: Optional[bool] = None,
                 politeness_interval: float = 0.0, politeness_retries: int = 3):
        self.sources = sources or default_infra_sources()
        # 프로덕션 HTTP 파이프라인(리뷰 P1: politeness 를 기본 경로에 실제로 연결):
        #   Caching → Politeness(per-host rate + 429/5xx 백오프) → RequestLimiter(전역 요청 상한)
        #   → SSRFGuard(hop별 사설IP 차단) → 실제 HTTP.
        # 주입 http(테스트)는 테스트가 통제하므로 이 래핑을 우회(그대로 사용) — 오프라인 테스트 무해.
        real_net = http is None
        base_http = http or default_http_get
        self.request_limiter = None
        self.politeness = None
        if real_net:
            if ssrf_guard is None:
                ssrf_guard = True
            if ssrf_guard:
                base_http = SSRFGuard(base_http)             # innermost: 커넥션 직전 검증
            self.request_limiter = RequestLimiter(base_http, max_requests or concurrency)
            base_http = self.request_limiter                 # 전역 실제-요청 상한
            self.politeness = PolitenessHTTP(base_http, min_interval=politeness_interval,
                                             retries=politeness_retries)
            base_http = self.politeness                      # per-host 예의 + 재시도
        elif ssrf_guard:                                     # 주입 http 라도 명시 요청 시 가드
            base_http = SSRFGuard(base_http)
            self.request_limiter = RequestLimiter(base_http, max_requests or concurrency)
            base_http = self.request_limiter
        # 대량 스윕 속도: TTL 캐시 + single-flight 로 중복조회 0(캐시 히트는 요청/가드/politeness 우회).
        self.http_cache: Optional[CachingHTTP] = CachingHTTP(base_http) if cache else None
        self.http = self.http_cache or base_http
        self.scope = scope
        self.depth = depth
        self.max_jobs = max_jobs
        self.max_seconds = max_seconds
        self.concurrency = max(1, concurrency)
        self._governor = governor
        self.graph = Graph()
        self.skipped: list[tuple[str, str]] = []   # (value, reason)
        # 범위 밖(out-of-scope) 발견물 — 그래프에 넣지 않고 여기 별도 기록(리뷰 P0: authz 그래프 누수).
        # scope 밖 엔티티가 그래프→IDF N→클러스터→export 를 오염시키던 문제를 닫는다.
        self.out_of_scope: list[tuple[str, str]] = []   # (value, type)

    # --- 대량 스코프 스윕(인프라 자산만) --------------------------------- #
    async def sweep_subdomains(self, domain: str, words=None) -> Graph:
        """도메인의 하위도메인 후보 수백~수천 개를 병렬 확인(자기 자산 열거)."""
        cands = subdomain_candidates(domain, words or COMMON_SUBDOMAINS)
        return await self.run_iter(iter([domain, *cands]))

    async def sweep_cidr(self, cidr: str, limit: int = 65536) -> Graph:
        """CIDR 대역의 호스트 IP 전수를 병렬 RDAP/ASN 스윕. 제너레이터 스트리밍 →
        /16(65k) 규모도 업프런트 materialize 없이."""
        return await self.run_iter(iter_cidr_hosts(cidr, limit=limit))

    def _sources_for(self, itype: InfraType) -> list[InfraSource]:
        return [s for s in self.sources if itype in s.accepts]

    @staticmethod
    def _entity_infra_type(ent: Entity) -> Optional[InfraType]:
        return {EntityType.DOMAIN: InfraType.DOMAIN, EntityType.IP: InfraType.IP,
                EntityType.ASN: InfraType.ASN}.get(ent.type)

    @staticmethod
    def _target_for(ent: Entity) -> Optional["InfraTarget"]:
        """엔티티 → 실제 조회 타깃. URL 은 호스트(도메인/IP)로, CIDR(HOST kind=cidr)는 네트워크
        주소 IP 로 라우팅해 소스가 실제로 fan-out 되게 한다(리뷰 P15: URL/CIDR seed 미실행 버그)."""
        t = ent.type
        if t == EntityType.DOMAIN:
            return InfraTarget(InfraType.DOMAIN, ent.value)
        if t == EntityType.IP:
            return InfraTarget(InfraType.IP, ent.value)
        if t == EntityType.ASN:
            return InfraTarget(InfraType.ASN, ent.value)
        if t == EntityType.URL:
            from urllib.parse import urlparse
            raw = ent.value if "://" in ent.value else "http://" + ent.value
            host = (urlparse(raw).hostname or "").strip().lower()
            if not host:
                return None
            try:
                ipaddress.ip_address(host)
                return InfraTarget(InfraType.IP, host)
            except ValueError:
                return InfraTarget(InfraType.DOMAIN, host)
        if t == EntityType.HOST and (ent.attrs or {}).get("kind") == "cidr":
            try:
                net = ipaddress.ip_network(ent.value, strict=False)
            except ValueError:
                return None
            return InfraTarget(InfraType.IP, str(net.network_address))
        return None

    def _fetch_authed(self, src, target, ent):
        """실행 시점(큐 대기 후 실제 조회 직전)에 인가를 **재검증**하고 감사에 기록한다(리뷰 P0).

        enqueue 시점의 is_authorized 는 값싼 사전필터일 뿐이다 — 잡이 큐에서 대기하는 동안 scope 가
        만료되거나(TOCTOU) 범위가 바뀔 수 있다. scope.check() 는 (1) 만료/범위밖이면 실제 요청 전에
        AuthorizationError 를 던져 조회를 막고, (2) 통과·차단 모두를 'query'/'blocked' 로 감사에
        남긴다 → '무엇을 언제 조회했나'가 실제 요청 경계에서 기록된다(그간 is_authorized 만 써서 실제
        쿼리가 감사에 안 남던 문제 수정). scope 가 없으면(대부분의 단위테스트) 동작은 이전과 동일."""
        async def run():
            if self.scope is not None:
                from .authz import AuthorizationError
                try:
                    self.scope.check(ent.value, ent.type.value, collector=src.name)
                except AuthorizationError:
                    return None       # 실행시점 미인가(만료/범위밖) → 실제 조회 스킵(감사에 blocked)
            return await src.fetch(target, self.http)
        return run()

    async def run(self, seeds: list[str]) -> Graph:
        """유한 seed 목록 편의 실행 — 내부적으로 run_iter 로 위임."""
        return await self.run_iter(list(seeds))

    async def run_iter(self, seeds_iterable, hwm: Optional[int] = None) -> Graph:
        """대규모 지연 스트리밍 인테이크. seeds 를 제너레이터로 받아 업프런트 materialize 없이
        용량(hwm)만큼만 밀어넣는다 → /16(65k)·수십만 후보도 메모리·큐 폭발 없이.

        hwm(high-water mark): 미결 잡 상한. 이 밑으로 떨어질 때만 seed 를 더 당겨온다.
        """
        from .scheduler import AdaptiveConcurrency, GlobalScheduler, Job

        gov = self._governor or AdaptiveConcurrency(
            start=min(16, self.concurrency), min_limit=1, max_limit=self.concurrency)
        sch = GlobalScheduler(gov, max_jobs=self.max_jobs, max_seconds=self.max_seconds)
        done: set[tuple[str, str]] = set()
        depth_of: dict[str, int] = {}
        hwm = hwm or max(32, self.concurrency * 4)

        def enqueue(entities) -> int:
            n = 0
            for ent in entities:
                tgt = self._target_for(ent)        # URL→호스트, CIDR→네트워크IP 로 라우팅
                if tgt is None:
                    continue
                it = tgt.type
                if self.scope is not None and not self.scope.is_authorized(ent.value, ent.type.value):
                    continue
                for src in self._sources_for(it):
                    sig = (src.name, ent.key)
                    if sig in done:
                        continue
                    done.add(sig)
                    if sch.submit(Job(
                        make=(lambda s=src, tt=tgt, ev=ent: self._fetch_authed(s, tt, ev)),
                        host=src.host or src.name,
                        key=(src.name, ent.key, depth_of.get(ent.key, 0)),
                        is_drop=lambda res: bool(getattr(res, "rate_limited", False)),
                    )):
                        n += 1
            return n

        def seed_one(raw: str) -> int:
            t = InfraTarget.parse(raw)
            if t is None:
                # 사람 selector(email/phone/username/name/account) — 데이터 타입을 막지 않는다.
                # 합법 OSINT: 인가 scope 가 person_allowed 이고 그 selector 가 명시 인가됐을 때만 조회.
                pt = classify_person(raw)
                if pt is not None:
                    pval = _normalize(pt, raw)
                    if self.scope is None:
                        # scope 없음(무범위 실행) → 사람 selector 는 조회하지 않는다(인가 없이 사인 조회 금지).
                        self.skipped.append((raw, "사람 selector: 인가 scope 필요(무범위 거부)"))
                        return 0
                    if not self.scope.person_allowed():
                        self.skipped.append((raw, "사람 selector: 이 근거(basis)에선 미허용(infra_only)"))
                        return 0
                    if not self.scope.is_authorized(pval, pt.value):
                        self.skipped.append((raw, "사람 selector: 인가목록에 없음(정확 인가 필요)"))
                        return 0
                    ent = Entity(type=pt, value=raw, certainty=Certainty.CONFIRMED,
                                 evidence=_ev("입력", "인가된 사람 selector"))
                    stored = self.graph.add(ent)
                    depth_of.setdefault(stored.key, 0)
                    return enqueue([stored])
                self.skipped.append((raw, "자산·사람 selector 아님(형식 불명)"))
                return 0
            etype = _INFRA_TO_ENTITY[t.type]
            # URL 은 전체 문자열이 아니라 **호스트**로 인가 검사(리뷰 P1). CIDR 는 네트워크 자체로.
            authz_val, authz_type = t.normalized, etype.value
            if t.type == InfraType.URL:
                from urllib.parse import urlparse
                raw_u = t.normalized if "://" in t.normalized else "http://" + t.normalized
                host = (urlparse(raw_u).hostname or "").strip("[]")
                if host:
                    try:
                        ipaddress.ip_address(host)
                        authz_val, authz_type = host, EntityType.IP.value
                    except ValueError:
                        authz_val, authz_type = host, EntityType.DOMAIN.value
            if self.scope is not None and not self.scope.is_authorized(authz_val, authz_type):
                self.skipped.append((raw, "미인가"))
                return 0
            attrs = {"kind": "cidr"} if t.type == InfraType.CIDR else {}
            ent = Entity(type=etype, value=t.normalized, certainty=Certainty.CONFIRMED,
                         evidence=_ev("입력", "사용자 입력 자산"), attrs=attrs)
            stored = self.graph.add(ent)
            depth_of.setdefault(stored.key, 0)
            return enqueue([stored])

        seed_it = iter(seeds_iterable)
        state = {"pending": 0, "exhausted": False}

        import time as _time
        # max_seconds<=0(또는 None) = 무제한(스케줄러와 동일 semantics, 리뷰 P1). 예전엔 0 이면
        # deadline=now 라 즉시 인테이크 중단 → 계층마다 0 의 뜻이 달랐다. 이제 통일한다.
        deadline = (_time.monotonic() + self.max_seconds
                    if self.max_seconds and self.max_seconds > 0 else None)

        def topup() -> None:
            # 용량 여유가 있을 때만 seed 를 더 당겨온다(큐/메모리 유계 유지).
            # max_seconds 초과 시 새 seed 인테이크 중단 → scheduler 뿐 아니라 '전체 스캔'이 예산 준수.
            while not state["exhausted"] and state["pending"] < hwm:
                if sch.at_capacity():             # max_jobs 소진/마감 → 무한 generator 소모 방지(리뷰 P1)
                    state["exhausted"] = True
                    break
                if deadline is not None and _time.monotonic() >= deadline:
                    state["exhausted"] = True     # 예산 소진 → 더 이상 seed 를 당기지 않음
                    break
                try:
                    raw = next(seed_it)
                except StopIteration:
                    state["exhausted"] = True
                    break
                state["pending"] += seed_one(raw)

        topup()
        if state["pending"] == 0 and state["exhausted"]:
            sch.close()

        async for r in sch.run_stream():
            state["pending"] -= 1
            if r.ok and r.value is not None and getattr(r.value, "ok", False):
                res: FetchResult = r.value
                _, _src_ent_key, d = r.key
                new_ents: list[Entity] = []
                # 범위 밖 발견물은 **그래프에 넣지 않는다**(리뷰 P0). scope 인가된 것만 추가 →
                # IDF N·클러스터·export 오염 차단. 차단분은 out_of_scope + 감사에 기록.
                allowed_keys: set = set()
                for e in res.entities:
                    if self.scope is not None and not self.scope.is_authorized(e.value, e.type.value):
                        self.out_of_scope.append((e.value, e.type.value))
                        continue
                    stored = self.graph.add(e)
                    allowed_keys.add(stored.key)
                    if stored.key not in depth_of:
                        depth_of[stored.key] = d + 1
                        new_ents.append(stored)
                for edge in res.edges:
                    # 양 끝점이 모두 그래프에 있어야 링크(범위 밖 끝점이면 자연히 제외됨).
                    self.graph.link(edge)
                if d + 1 <= self.depth:
                    expand = [e for e in new_ents if e.type in _EXPANDABLE_INFRA]
                    if expand:
                        state["pending"] += enqueue(expand)
            topup()                       # 결과 소비할 때마다 여유만큼 seed 리필
            if state["pending"] <= 0 and state["exhausted"]:
                sch.close()
        return self.graph


# --------------------------------------------------------------------------- #
# same-operator 상관 — 공유 인프라 신호를 독립근거로 세어 CP 게이트
# --------------------------------------------------------------------------- #
# 독립 신호축. 축을 늘릴수록 n 이 커져 CP 하한이 조여진다(같은 k/n 비율이라도).
# spf=공유 SPF include, spki=공유 TLS 공개키 핀, favicon=공유 favicon 해시,
# httpfp=공유 HTTP 헤더 지문, netblock=공유 /24 넷블록, tlsfp=공유 TLS 행동지문,
# dmarc=공유 DMARC 보고 엔드포인트, ptr=공유 역DNS PTR 도메인(호스팅).
_SIGNAL_KINDS = ("ns", "ip", "asn", "registrar", "mx", "co_cert", "spf", "spki",
                 "favicon", "httpfp", "netblock", "tlsfp", "dmarc", "ptr")

# 관계 라벨(리뷰 P0): CP kind-count 는 '신호 공유' 보조지표지 확정된 동일운영자 판정이 아니다.
# 그래서 그래프 relation 을 "신호공유(동일운영자후보)"로 명명 — downstream 이 edge.relation 만 보고
# 확정 attribution 으로 오독하지 못하게. IDF/디컨파운딩 클러스터가 권위 판정이다.
SAME_OPERATOR_SIGNAL_REL = "신호공유(동일운영자후보)"


def _netblock(ip_key: str) -> str:
    """ip:<addr> → 넷블록 키(v4 /24, v6 /64). co-residency 신호용."""
    addr = ip_key.split(":", 1)[1] if ":" in ip_key else ip_key
    try:
        ipobj = ipaddress.ip_address(addr)
    except ValueError:
        return ""
    pref = 24 if ipobj.version == 4 else 64
    net = ipaddress.ip_network(f"{addr}/{pref}", strict=False)
    return str(net)


def _gather_domain_signals(graph: Graph):
    """도메인별 인프라 신호 집합. 반환 (sig[domkey][kind]->set, 대상 도메인키 목록)."""
    from collections import defaultdict
    sig: dict[str, dict[str, set]] = defaultdict(lambda: defaultdict(set))
    ents = {e.key: e for e in graph.entities}

    ip2asn: dict[str, set] = defaultdict(set)
    for edge in graph.edges:
        src = ents.get(edge.src)
        if edge.relation == "origin ASN" and src is not None and src.type == EntityType.IP:
            ip2asn[edge.src].add(edge.dst)
    # ip 키 → PTR 도메인(ReverseDNS 가 IP 엔티티 attr 로 채움) → 도메인 신호로 접기.
    ip2ptr: dict[str, str] = {}
    for e in graph.entities:
        if e.type == EntityType.IP and (e.attrs or {}).get("ptr_domain"):
            ip2ptr[e.key] = str(e.attrs["ptr_domain"])

    for edge in graph.edges:
        src = ents.get(edge.src)
        if src is None or src.type != EntityType.DOMAIN:
            continue
        if edge.relation == "네임서버":
            sig[edge.src]["ns"].add(edge.dst)
        elif edge.relation == "레지스트라":
            sig[edge.src]["registrar"].add(edge.dst)
        elif edge.relation == "메일서버":
            sig[edge.src]["mx"].add(edge.dst)
        elif edge.relation == "해석됨(A)":
            sig[edge.src]["ip"].add(edge.dst)
            nb = _netblock(edge.dst)                  # 공유 /24 넷블록(co-hosting) 신호
            if nb:
                sig[edge.src]["netblock"].add(nb)
            if edge.dst in ip2ptr:                    # 공유 PTR 도메인(호스팅) 신호
                sig[edge.src]["ptr"].add(ip2ptr[edge.dst])
            for asn_key in ip2asn.get(edge.dst, ()):
                sig[edge.src]["asn"].add(asn_key)

    # attr 기반 신호(엔티티 1회 순회): co_cert(공유 인증서 id)·spf(공유 include)·spki(공유 핀).
    for e in graph.entities:
        if e.type != EntityType.DOMAIN:
            continue
        at = e.attrs or {}
        for c in at.get("cert_ids") or []:
            sig[e.key]["co_cert"].add(str(c))
        for inc in at.get("spf_includes") or []:
            sig[e.key]["spf"].add(str(inc))
        if at.get("spki"):
            sig[e.key]["spki"].add(str(at["spki"]))
        if at.get("favicon"):
            sig[e.key]["favicon"].add(str(at["favicon"]))
        if at.get("httpfp"):
            sig[e.key]["httpfp"].add(str(at["httpfp"]))
        if at.get("tlsfp"):
            sig[e.key]["tlsfp"].add(str(at["tlsfp"]))
        for rep in at.get("dmarc") or []:
            sig[e.key]["dmarc"].add(str(rep))
    return sig, sorted(sig.keys())


def correlate_same_operator(graph: Graph, gate=None,
                            n_signals: Optional[int] = None,
                            signal_kinds: tuple = _SIGNAL_KINDS,
                            link: bool = True) -> list[Edge]:
    """두 도메인이 공유하는 독립 인프라 신호 수를 k, 축 수를 n 으로 CP 게이트에 넣어 판정.

    ⚠️ 스크리닝 전용(리뷰 P2). 이 CP-kind-count 경로는 '14축 중 k축 공유'를 이항 성공률로 보는데,
    축들이 교환가능하지도(IP공유≫헤더공유) 독립도(IP⇒netblock⇒ptr) 않아 cp_lower(k,n) 에 same-operator
    확률로서의 깔끔한 해석이 없다. 게다가 default tau=0.80 은 작은 n 에서 달성 불가할 수 있다
    (n=14 → 14/14 라도 lower=0.768<0.80 → 절대 confirm 안 됨; 이는 보수성이지 버그 아님).
    **권위 판정은 IDF-coincidence + deconfounded_clusters(fast_clusters, threshold 1e-6)를 쓰라.**
    이 함수/operator_clusters 가 내는 confidence 는 랭킹·결정용이 아니라 후보 스크리닝 신호일 뿐이다.
    achievable ceiling 은 verify_cp.max_confirmable_lower(n, alpha) 로 확인 가능.
    휴리스틱 점수 없음. n_signals 미지정 시 len(signal_kinds). link=True 면 살아남은 간선을 graph.link.
    """
    if gate is None:
        from .verify_cp import VerificationGate
        gate = VerificationGate(tau=0.80, floor=0.10, alpha=0.05)
    n = n_signals if n_signals is not None else len(signal_kinds)

    sig, domains = _gather_domain_signals(graph)
    out: list[Edge] = []
    for i in range(len(domains)):
        for j in range(i + 1, len(domains)):
            a, b = domains[i], domains[j]
            shared = 0
            bits = []
            for kind in signal_kinds:
                inter = sig[a].get(kind, set()) & sig[b].get(kind, set())
                if inter:
                    shared += 1
                    bits.append(f"{kind}:{len(inter)}")
            if shared == 0:
                continue
            edge = Edge(src=a, dst=b, relation=SAME_OPERATOR_SIGNAL_REL,
                        certainty=Certainty.UNCONFIRMED,
                        evidence=_ev("same-operator",
                                     f"공유 인프라 신호 {shared}/{n} ({', '.join(bits)}) — "
                                     f"신호공유 보조지표(확정 attribution 아님)"))
            judged = gate.apply_to_edge(edge, k=shared, n=n)
            if judged is not None:
                out.append(judged)
                if link:
                    graph.link(judged)
    return out


# 소스 → upstream 독립성 클래스. 같은 원천을 재게시하는 소스는 같은 클래스(1표)로 붕괴한다.
# 예: crt.sh·certspotter·certstream 은 전부 공개 CT 로그를 읽음 → 독립 확증 아님(리뷰 P10).
_SOURCE_UPSTREAM = {
    "crt.sh": "ct-logs", "certspotter": "ct-logs", "certstream": "ct-logs",
    "doh-dns": "dns-live", "reverse-dns": "dns-live",
    "hackertarget": "passive-dns-hackertarget", "alienvault-otx": "passive-dns-otx",
    "rdap-domain": "registry-rdap", "rdap-ip": "registry-rdap", "asn-prefixes": "registry-rdap",
    "ip-to-asn": "bgp", "peeringdb": "peeringdb",
    "shodan-internetdb": "shodan", "censys-hosts": "censys",
    "wayback-cdx": "wayback", "urlhaus": "abuse.ch", "abuse.ch": "abuse.ch",
    "favicon": "http-probe", "http-fp": "http-probe", "tech-fp": "http-probe",
    "tls-behavior": "tls-probe", "dmarc": "dns-live",
}


def source_upstream_class(name: str) -> str:
    """소스 이름 → upstream 독립성 클래스(미등록은 자기 자신). corroborate 의 k 계산에 사용."""
    return _SOURCE_UPSTREAM.get(name, name)


def corroborate_resolution(graph: Graph, gate=None, n_sources: int = 3) -> list[dict]:
    """A레코드(해석됨(A)) 간선을 독립 출처 수로 CP 확증. 여러 passive-DNS/DoH 소스가 같은
    domain→ip 를 확인하면 Graph.link 가 증거를 합쳐 출처 수(k)가 오르고, n_sources 를 n 으로
    CP 하한을 매긴다 → '3개 독립 소스 확인 = 확정' 을 점수 아닌 정확 하한으로.

    n_sources 기본 3(DoH·HackerTarget·OTX). apply=True 로 엣지 confidence 를 하한으로 갱신.
    """
    if gate is None:
        from .verify_cp import VerificationGate
        gate = VerificationGate(tau=0.90, floor=0.05, alpha=0.05)
    from .verify_cp import corroborate_edges
    res_edges = [e for e in graph.edges if e.relation == "해석됨(A)"]
    # 독립성 붕괴 적용: 같은 upstream 재게시 소스는 1표(리뷰 P10). 진짜 독립 소스만 k 로 센다.
    return corroborate_edges(res_edges, gate, n_sources=n_sources, apply=True,
                             independence_of=source_upstream_class)


# --------------------------------------------------------------------------- #
# 운영자 클러스터링 — 확정된 same-operator 간선으로 자산을 운영자별로 묶는다.
# --------------------------------------------------------------------------- #
class _UnionFind:
    def __init__(self):
        self.p: dict[str, str] = {}

    def find(self, x: str) -> str:
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[ra] = rb


def operator_clusters(graph: Graph, min_lower: float = 0.0,
                      only_confirmed: bool = False) -> list[dict]:
    """신호공유(동일운영자후보) 간선으로 도메인을 클러스터링. 각 클러스터를 잇는 간선의 최소 CP 하한 보고.

    min_lower     : 이 정확 하한 이상인 간선만 사용(0 이면 전부).
    only_confirmed : True 면 CONFIRMED 승격된 간선만 사용(가장 엄격).

    주의(리뷰 정정): 보고하는 min_edge_lower 는 **클러스터를 연결하는 간선들**의 최소 CP 하한이지,
    모든 도메인 쌍(A–C 처럼 직접 간선이 없는 쌍 포함)의 최소값이 아니다. connected component 는
    A–B, B–C 로도 만들어지므로 A–C 의 강도는 보장하지 않는다 → 이름을 min_pairwise 가 아닌
    min_edge 로 둔다.
    """
    uf = _UnionFind()
    used: list[Edge] = []
    for e in graph.edges:
        if e.relation != SAME_OPERATOR_SIGNAL_REL:
            continue
        conf = e.confidence if e.confidence is not None else (
            1.0 if e.certainty == Certainty.CONFIRMED else 0.0)
        if only_confirmed and e.certainty != Certainty.CONFIRMED:
            continue
        if conf < min_lower:
            continue
        uf.union(e.src, e.dst)
        used.append(e)

    from collections import defaultdict
    groups: dict[str, set] = defaultdict(set)
    lows: dict[str, float] = defaultdict(lambda: 1.0)
    for e in used:
        r = uf.find(e.src)
        groups[r].update((e.src, e.dst))
        conf = e.confidence if e.confidence is not None else 1.0
        lows[r] = min(lows[r], conf)

    ents = {x.key: x for x in graph.entities}
    out = []
    for r, members in groups.items():
        if len(members) < 2:
            continue
        out.append({
            "members": sorted(members),
            "size": len(members),
            "min_edge_lower": round(lows[r], 4),   # 연결 간선의 최소 CP 하한(모든 쌍의 최소 아님)
            "values": sorted(ents[k].value for k in members if k in ents),
        })
    out.sort(key=lambda c: (-c["size"], -c["min_edge_lower"]))
    return out


# --------------------------------------------------------------------------- #
# 증분 same-operator — 역인덱스로 후보쌍만, 전체 O(n²) 재계산 없이
# --------------------------------------------------------------------------- #
class OperatorIndex:
    """도메인을 하나씩 add 하며 same-operator 를 증분 갱신.

    신호값 역인덱스(kind→value→{domains})로, 새 도메인은 '같은 신호값을 공유하는' 후보들과만
    비교한다(전체 쌍 재계산 없음). 쌍별 공유 kind 수를 증분 유지 → CP 판정, CONFIRMED 만 union.
    거대 그래프/스트리밍에서 correlate_same_operator 의 배치 재계산을 대체한다.
    """
    def __init__(self, gate=None, n_signals: Optional[int] = None,
                 signal_kinds: tuple = _SIGNAL_KINDS, max_bucket: int = 4096,
                 on_confirm=None, track_values: bool = True, judge_cp: bool = True):
        from .verify_cp import VerificationGate
        self.gate = gate or VerificationGate(tau=0.8, floor=0.1, alpha=0.05)
        self.kinds = tuple(signal_kinds)
        self.kindset = set(self.kinds)
        self.n = n_signals or len(self.kinds)
        self.judge_cp = judge_cp              # False 면 CP 판정 생략(coincidence 전용, 더 빠름)
        self.ts: dict = {}                    # (kind,vkey,dom) → 관측 시각(freshness prune 용)
        # max_bucket: 한 (kind,value)를 이보다 많은 도메인이 공유하면 '제네릭'으로 보고 더는
        # 쌍을 만들지 않는다(예: 대형 CDN NS). O(cap²) 로 유계 → 축이 100개여도 빠름(IDF식).
        self.max_bucket = max_bucket
        self.on_confirm = on_confirm          # 실시간: 쌍 확정 시 on_confirm(a,b) 호출
        self.track_values = track_values      # 공유 (kind,value) 기록(IDF 우연일치용)
        self.index: dict[str, dict[str, set]] = {}
        self.pair_kinds: dict[frozenset, set] = {}
        self.pair_vals: dict[frozenset, set] = {}
        self.uf = _UnionFind()
        self.domains: set[str] = set()
        self._verdicts: dict[frozenset, tuple] = {}
        self._confirmed: set = set()
        # 결정성(리뷰 P1): df>max_bucket 인 값은 '제네릭'으로 영구승격 → 삽입순서와 무관하게 쌍 기여 0.
        self._generic: set = set()                 # 제네릭으로 승격된 (kind, vkey)
        self._val_pairs: dict = {}                 # (kind, vkey) → 그 값이 만든 pair 집합(승격 시 undo)

    def add(self, dom: str, sig: dict, ts: Optional[float] = None) -> list:
        """도메인 하나와 신호(dict kind->iterable[value])를 반영. 이번에 새로 '확정'된 쌍 목록 반환.

        ts: 관측 시각(freshness prune 용, 선택). 스트리밍: 도메인 도착마다 호출 → 확정 즉시
        on_confirm 콜백/반환값으로 통지.
        """
        from .verify_cp import VERDICT_CONFIRMED
        self.domains.add(dom)
        self.uf.find(dom)
        affected: set = set()
        for kind, vals in sig.items():           # sig 에 있는 축만 순회(sparse → 빠름)
            if kind not in self.kindset:
                continue
            idx = self.index.setdefault(kind, {})
            for val in vals:
                vkey = str(val)
                if ts is not None:
                    self.ts[(kind, vkey, dom)] = ts
                bucket = idx.setdefault(vkey, set())
                if (kind, vkey) in self._generic:    # 이미 제네릭 → df만 세고 쌍 기여 0(결정성)
                    bucket.add(dom)
                    continue
                for other in bucket:                 # 아직 비제네릭: 기존 멤버와 쌍 생성(값 기록)
                    if other == dom:
                        continue
                    pair = frozenset((dom, other))
                    ks = self.pair_kinds.setdefault(pair, set())
                    if kind not in ks:
                        ks.add(kind)
                        affected.add(pair)
                    if self.track_values:
                        self.pair_vals.setdefault(pair, set()).add((kind, vkey))
                    self._val_pairs.setdefault((kind, vkey), set()).add(pair)
                bucket.add(dom)
                if len(bucket) > self.max_bucket:    # 방금 임계 초과 → 영구 제네릭 승격 + undo
                    self._demote_value(kind, vkey, affected)
        if not self.judge_cp:
            return []
        newly: list = []
        for pair in affected:
            k = len(self.pair_kinds[pair])
            v = self.gate.judge(k, self.n)
            self._verdicts[pair] = (k, v)
            if v.verdict == VERDICT_CONFIRMED and pair not in self._confirmed:
                self._confirmed.add(pair)
                a, b = sorted(pair)
                self.uf.union(a, b)
                newly.append((a, b))
                if self.on_confirm is not None:
                    self.on_confirm(a, b)
        return newly

    def prune(self, before_ts: float) -> int:
        """관측 시각이 before_ts 미만인 신호를 버킷/쌍에서 결정적으로 제거하고 재구성.

        freshness: TTL 지난 값은 증거에서 빠진다(휴리스틱 가중이 아니라 '유효기간 안/밖'의 하드 컷).
        제거된 신호 수 반환. 이후 pairs/clusters/coincidence 는 신선한 신호만 반영한다.
        """
        stale = [key for key, t in self.ts.items() if t < before_ts]
        for (kind, vkey, dom) in stale:
            b = self.index.get(kind, {}).get(vkey)
            if b is not None:
                b.discard(dom)
                if not b:
                    del self.index[kind][vkey]
            del self.ts[(kind, vkey, dom)]
        if stale:
            self._rebuild_pairs()
        return len(stale)

    def _demote_value(self, kind: str, vkey: str, affected: set) -> None:
        """(kind,vkey) 를 제네릭으로 영구승격하고, 그 값이 만든 쌍 기여를 **결정적으로 제거**한다.

        df>max_bucket 인 값은 삽입순서와 무관하게 쌍 기여 0 이어야 한다(리뷰 P1). 이 값으로 만든
        모든 쌍에서 (kind,vkey) 를 빼고, 그 kind 가 다른 값으로도 지지되지 않으면 kind 를 제거,
        지지 kind 가 0 이면 쌍 자체를 삭제한다. 확정됐던 쌍이 사라지면 UF 를 _confirmed 로부터 재구성."""
        self._generic.add((kind, vkey))
        dropped_confirmed = False
        for pair in self._val_pairs.pop((kind, vkey), ()):
            pv = self.pair_vals.get(pair)
            if pv is not None:
                pv.discard((kind, vkey))
                still = any(k == kind for (k, _v) in pv)
            else:
                still = False                      # track_values 꺼짐 → 보수적으로 미지지 취급
            if not still:
                pk = self.pair_kinds.get(pair)
                if pk is not None:
                    pk.discard(kind)
                    if not pk:                     # 지지 kind 0 → 쌍 소멸
                        self.pair_kinds.pop(pair, None)
                        self.pair_vals.pop(pair, None)
                        affected.discard(pair)
                        self._verdicts.pop(pair, None)
                        if pair in self._confirmed:
                            self._confirmed.discard(pair)
                            dropped_confirmed = True
        if dropped_confirmed:                      # UF 는 un-union 불가 → _confirmed 로부터 재구성
            self.uf = _UnionFind()
            for d in self.domains:
                self.uf.find(d)
            for p in self._confirmed:
                a, b = tuple(p)
                self.uf.union(a, b)

    def _rebuild_pairs(self) -> None:
        """현재 버킷 상태에서 쌍 구조(pair_kinds/pair_vals/verdicts/uf/generic)를 재구성."""
        from .verify_cp import VERDICT_CONFIRMED
        self.pair_kinds = {}
        self.pair_vals = {}
        self._verdicts = {}
        self._confirmed = set()
        self._val_pairs = {}
        self.uf = _UnionFind()
        for d in self.domains:
            self.uf.find(d)
        for kind, buckets in self.index.items():
            for vkey, bucket in buckets.items():
                # 제네릭은 **영구 승격**(docstring 계약, 리뷰 P1). prune 로 버킷이 max_bucket 이하로
                # 줄어도 한번 제네릭이 된 값은 다시 쌍을 만들지 않는다 — 안 그러면 freshness prune 후
                # 과거 제네릭 값이 되살아나 증거를 재생성(정책 semantics 충돌)한다.
                if (kind, vkey) in self._generic or len(bucket) > self.max_bucket:
                    self._generic.add((kind, vkey))   # 결정적: 제네릭 유지
                    continue
                members = sorted(bucket)
                for i in range(len(members)):
                    for j in range(i + 1, len(members)):
                        pair = frozenset((members[i], members[j]))
                        self.pair_kinds.setdefault(pair, set()).add(kind)
                        if self.track_values:
                            self.pair_vals.setdefault(pair, set()).add((kind, vkey))
                        self._val_pairs.setdefault((kind, vkey), set()).add(pair)
        if not self.judge_cp:
            return
        for pair, ks in self.pair_kinds.items():
            v = self.gate.judge(len(ks), self.n)
            self._verdicts[pair] = (len(ks), v)
            if v.verdict == VERDICT_CONFIRMED:
                self._confirmed.add(pair)
                a, b = tuple(pair)
                self.uf.union(a, b)

    def pairs(self, min_lower: float = 0.0) -> list[dict]:
        out = []
        for pair, (k, v) in self._verdicts.items():
            if v.lower >= min_lower:
                a, b = sorted(pair)
                out.append({"a": a, "b": b, "k": k, "n": self.n,
                            "verdict": v.verdict, "lower": round(v.lower, 6)})
        return sorted(out, key=lambda x: -x["lower"])

    def clusters(self) -> list[list[str]]:
        from collections import defaultdict
        groups: dict[str, set] = defaultdict(set)
        for d in self.domains:
            groups[self.uf.find(d)].add(d)
        return sorted(([sorted(m) for m in groups.values() if len(m) >= 2]),
                      key=lambda m: (-len(m), m))

    # --- IDF 우연일치 판정: 공유 값의 희소도(df)로 우연확률 계산 ---------- #
    def coincidence_pairs(self, threshold: float = 1e-6, use_cp_upper: bool = False,
                          by_family: bool = False, order_correct: bool = False,
                          background=None) -> list[dict]:
        """공유 (kind,value) 들의 최종 df 로 우연일치확률을 계산, threshold 이하만 반환.
        희소값 공유일수록 확률이 급락 → same-operator 근거 강함. track_values=True 필요.
        by_family=True(강화 축2): 같은 관측 이벤트에서 파생된 축들을 패밀리당 1개로 붕괴해
        co-derived 신호가 독립 증거처럼 곱해지는 double-count 를 제거(더 보수적·정확).
        order_correct=True(강화 축14): 'kind 내 최소 df 선택' post-selection 을 1-(1-q)^m 로 보정.
        background(강화 축1): BackgroundCorpus 를 주면 rarity(df/N)를 **독립 배경 모집단**에서 가져온다
        (타겟 그래프 자기참조 대신). 후보쌍 생성은 타겟 기반, q 는 배경 유병률(미관측=CP상한)."""
        from .verify_cp import coincidence_prob, coincidence_prob_selected
        from .signals import collapse_shared, collapse_shared_counts
        if background is not None:
            N = background.n
            df_of = lambda k, v: background.df(k, v)
        else:
            N = len(self.domains)
            df_of = lambda k, v: len(self.index.get(k, {}).get(v, ()))
        out = []
        for pair, kv in self.pair_vals.items():
            if background is not None:                 # 배경 모집단 유병률로 coincidence(미관측=rule of three)
                reps = collapse_shared(kv, df_of, by_family=by_family)
                p = background.coincidence(reps, conservative=use_cp_upper)
            elif order_correct:
                reps_m = collapse_shared_counts(kv, df_of, by_family=by_family)
                p = coincidence_prob_selected([(df_of(k, v), m) for (k, v, m) in reps_m],
                                              N, use_cp_upper=use_cp_upper)
            else:
                reps = collapse_shared(kv, df_of, by_family=by_family)
                p = coincidence_prob([df_of(k, v) for (k, v) in reps], N, use_cp_upper=use_cp_upper)
            if p <= threshold:
                a, b = sorted(pair)
                out.append({"a": a, "b": b, "shared": len(kv), "coincidence": p})
        return sorted(out, key=lambda x: x["coincidence"])

    def coincidence_clusters(self, threshold: float = 1e-6, use_cp_upper: bool = False,
                             by_family: bool = False, order_correct: bool = False,
                             background=None) -> list[list[str]]:
        from collections import defaultdict
        uf = _UnionFind()
        for d in self.domains:
            uf.find(d)
        for pr in self.coincidence_pairs(threshold, use_cp_upper, by_family=by_family,
                                         order_correct=order_correct, background=background):
            uf.union(pr["a"], pr["b"])
        groups: dict[str, set] = defaultdict(set)
        for d in self.domains:
            groups[uf.find(d)].add(d)
        return sorted([sorted(m) for m in groups.values() if len(m) >= 2],
                      key=lambda m: (-len(m), m))


def incremental_same_operator(graph: Graph, gate=None,
                              n_signals: Optional[int] = None,
                              signal_kinds: tuple = _SIGNAL_KINDS) -> OperatorIndex:
    """그래프의 도메인 신호를 모아 OperatorIndex 에 하나씩 넣는다(배치 correlate 와 동치 결과).
    스트리밍/거대 그래프에서는 add 를 직접 호출해 증분 유지하면 재계산이 없다."""
    idx = OperatorIndex(gate=gate, n_signals=n_signals, signal_kinds=signal_kinds)
    sig, domains = _gather_domain_signals(graph)
    for dkey in domains:
        idx.add(dkey, {k: set(v) for k, v in sig[dkey].items()})
    return idx


def fast_same_operator(graph: Graph, gate=None, specs=None,
                       max_bucket: int = 64) -> OperatorIndex:
    """100-축 신호 레지스트리 + 역인덱스로 same-operator 를 계산. 전체 쌍을 보지 않으므로
    (값 공유 후보만), 축이 100개여도 12축 all-pairs 보다 빠르다. 제네릭 값은 max_bucket 으로 억제.

    반환 OperatorIndex — .pairs()/.clusters() 로 결과를 본다."""
    from .signals import gather_signals, SIGNAL_SPECS
    specs = specs or SIGNAL_SPECS
    kinds = tuple(s.name for s in specs)
    idx = OperatorIndex(gate=gate, n_signals=len(kinds), signal_kinds=kinds,
                        max_bucket=max_bucket)
    for d, sig in gather_signals(graph, specs).items():
        idx.add(d, sig)
    return idx


def fast_clusters(graph: Graph, threshold: float = 1e-6, specs=None,
                  use_cp_upper: bool = True, max_bucket: int = 64,
                  parallel_workers: int = 1, by_family: bool = False,
                  order_correct: bool = False, background=None) -> list[list[str]]:
    """축수-무관 IDF 우연일치 판정을 '기본'으로 same-operator 클러스터를 낸다.

    coincidence 는 총 축수에 흔들리지 않으므로(공유값의 희소도만 봄) 축을 마음껏 늘려도 판정이
    안정적이다. CP kind-count 판정은 생략(judge_cp=False)해 더 빠르다. 기본 스펙은 EXTENDED(168축).
    by_family=True(강화 축2): 관측-패밀리 붕괴로 co-derived 신호 double-count 제거(더 보수적).
    """
    from .signals import gather_signals, gather_signals_parallel, EXTENDED_SPECS
    specs = specs or EXTENDED_SPECS
    kinds = tuple(s.name for s in specs)
    idx = OperatorIndex(n_signals=len(kinds), signal_kinds=kinds,
                        max_bucket=max_bucket, track_values=True, judge_cp=False)
    sigmap = (gather_signals_parallel(graph, specs, workers=parallel_workers)
              if parallel_workers > 1 else gather_signals(graph, specs))
    for d, sig in sigmap.items():
        idx.add(d, sig)
    return idx.coincidence_clusters(threshold=threshold, use_cp_upper=use_cp_upper,
                                    by_family=by_family, order_correct=order_correct,
                                    background=background)
