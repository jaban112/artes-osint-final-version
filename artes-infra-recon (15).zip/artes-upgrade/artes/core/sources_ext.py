"""확장 OSINT 소스 — 자산/인프라 축만(사람 축 없음). 전부 주입식 http, 오프라인 테스트 가능.

포함:
  1) CertStreamIngest  : CT 실시간 스트림 파서. 발급 '시각'을 뽑아 temporal(캠페인) 로 먹인다.
  2) PeeringDBSource   : ASN → 조직/네트워크명(정밀 귀속 앵커, ASN 보다 사람이 읽는 소유자).
  3) TechFingerprint   : Wappalyzer 계열 스택 탐지(헤더/HTML/스크립트/쿠키/meta 규칙). → tech 축.
  4) AbuseChSSLBL/ThreatFox : abuse.ch 위협 인텔. 악성 인증서 SHA1·IOC 피드 매칭 → threat 축.
  5) favicon_mmh3 / shodan_favicon_query : Shodan favicon 피벗(mmh3 순수구현). 자산발견 배수기.

전부 인프라·자산 평판/구성 신호다. 사람 대량 비식별화는 하지 않는다(경계 유지).
"""
from __future__ import annotations

import base64
import re
from typing import Iterable, Optional

from .model import Entity, Edge, Evidence, EntityType, Certainty
from .infra_recon import InfraSource, FetchResult, InfraType, _k, _ev, _DOMAIN_RE


# =========================================================================== #
# 1) CertStream — CT 실시간 스트림 → 도메인 + 발급시각(temporal 입력)
# =========================================================================== #
class CertStreamIngest:
    """CertStream WebSocket 메시지 파서(네트워크 없음 — 메시지 dict 를 주입).

    메시지 형식:
      {"message_type":"certificate_update",
       "data":{"leaf_cert":{"all_domains":[...],"not_before":...,
                            "fingerprint":"AA:BB:...","issuer":{"O":"..."}},
               "seen": <unix_ts>}}

    반환 이벤트 (domain, seen_ts, fingerprint, issuer). first_seen 은 도메인별 최소 seen.
    → temporal.campaign_report(ingest.first_seen(), window=...) 로 대량 동시-발급 캠페인 탐지.
    """

    def __init__(self, domain_suffixes: Optional[Iterable[str]] = None):
        # 관심 도메인 접미사(관측범위 한정). None 이면 전부.
        self.suf = tuple(s.lower().lstrip(".") for s in (domain_suffixes or ()))
        self.events: list[tuple] = []          # (domain, ts, fp, issuer)
        self._first: dict[str, float] = {}

    def _keep(self, dom: str) -> bool:
        if not self.suf:
            return True
        return any(dom == s or dom.endswith("." + s) for s in self.suf)

    def ingest(self, messages: Iterable[dict]) -> int:
        n = 0
        for m in messages:
            if m.get("message_type") != "certificate_update":
                continue
            data = m.get("data", {}) or {}
            leaf = data.get("leaf_cert", {}) or {}
            ts = float(data.get("seen") or leaf.get("not_before") or 0.0)
            fp = (leaf.get("fingerprint") or "").replace(":", "").lower()
            issuer = ((leaf.get("issuer") or {}).get("O") or "").strip()
            for dom in leaf.get("all_domains", []) or []:
                dom = str(dom).strip().lower().lstrip("*.")
                if not dom or not _DOMAIN_RE.match(dom) or not self._keep(dom):
                    continue
                self.events.append((dom, ts, fp, issuer))
                if ts and (dom not in self._first or ts < self._first[dom]):
                    self._first[dom] = ts
                n += 1
        return n

    def first_seen(self) -> dict:
        """{domain: 최초관측 unix_ts} — temporal 캠페인 탐지 입력."""
        return dict(self._first)

    def graph_updates(self):
        """관측 도메인 엔티티(발급시각·지문 attr). 스트림은 '존재/시각' 사실만 — 관계는 별도 확증."""
        by: dict[str, Entity] = {}
        for dom, ts, fp, issuer in self.events:
            e = by.get(dom)
            if e is None:
                e = Entity(type=EntityType.DOMAIN, value=dom, certainty=Certainty.CONFIRMED,
                           evidence=_ev("certstream", "CT 스트림 관측"),
                           attrs={"first_seen": ts, "cert_fps": [], "issuers": []})
                by[dom] = e
            if ts and (not e.attrs.get("first_seen") or ts < e.attrs["first_seen"]):
                e.attrs["first_seen"] = ts
            if fp and fp not in e.attrs["cert_fps"]:
                e.attrs["cert_fps"].append(fp)
            if issuer and issuer not in e.attrs["issuers"]:
                e.attrs["issuers"].append(issuer)
        return list(by.values())


# =========================================================================== #
# 2) PeeringDB — ASN → 조직/네트워크명
# =========================================================================== #
def parse_peeringdb_net(doc: dict) -> dict:
    """PeeringDB /api/net → {asn: {'name','aka','org_id'}}. (네트워크 없음 — 응답 주입.)"""
    out = {}
    for rec in doc.get("data", []) or []:
        asn = rec.get("asn")
        if asn is None:
            continue
        out[int(asn)] = {"name": (rec.get("name") or "").strip(),
                         "aka": (rec.get("aka") or "").strip(),
                         "org_id": rec.get("org_id")}
    return out


class PeeringDBSource(InfraSource):
    """ASN → 조직명(PeeringDB). ASN 엔티티에 attrs['net_org'] 부여 → 정밀 귀속/교란자 라벨."""
    name = "peeringdb"
    accepts = {InfraType.ASN}
    host = "peeringdb.com"

    async def fetch(self, target, http):
        asn = re.sub(r"(?i)^as", "", target.normalized).strip()
        if not asn.isdigit():
            return FetchResult(self.name, ok=False, error="asn 아님")
        url = f"https://www.peeringdb.com/api/net?asn={asn}"
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            m = parse_peeringdb_net(r.json() or {})
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        info = m.get(int(asn))
        if not info:
            return FetchResult(self.name, ok=False, error="net 없음")
        ent = Entity(type=EntityType.ASN, value=f"AS{asn}", certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "PeeringDB net", url),
                     attrs={"net_org": info["name"], "aka": info["aka"]})
        return FetchResult(self.name, entities=[ent])


# =========================================================================== #
# 3) TechFingerprint — Wappalyzer 계열 스택 탐지
# =========================================================================== #
# 규칙: {tech: {headers:{name:regex}, html:[regex], scripts:[regex], cookies:[regex],
#              meta:{name:regex}, implies:[tech,...]}}. 전부 대소문자 무시. 정확 정규매칭.
_TECH_RULES = {
    "WordPress": {"html": [r"wp-content", r"wp-includes"], "meta": {"generator": r"WordPress"},
                  "implies": ["PHP", "MySQL"]},
    "Drupal": {"headers": {"x-generator": r"Drupal"}, "meta": {"generator": r"Drupal"},
               "implies": ["PHP"]},
    "Joomla": {"meta": {"generator": r"Joomla"}, "implies": ["PHP"]},
    "Shopify": {"headers": {"x-shopify-stage": r".", "x-sorting-hat-shopid": r"."},
                "html": [r"cdn\.shopify\.com"]},
    "Magento": {"cookies": [r"^X-Magento"], "html": [r"/static/version\d+"], "implies": ["PHP"]},
    "React": {"html": [r"data-reactroot", r"__REACT_DEVTOOLS"], "scripts": [r"react(\.min)?\.js"]},
    "Vue.js": {"html": [r"data-v-[0-9a-f]{8}"], "scripts": [r"vue(\.min)?\.js"]},
    "Angular": {"html": [r"ng-version=", r"ng-app"], "scripts": [r"angular(\.min)?\.js"]},
    "Next.js": {"html": [r"/_next/static", r'id="__next"'], "implies": ["React", "Node.js"]},
    "Nuxt.js": {"html": [r"/_nuxt/", r'id="__nuxt"'], "implies": ["Vue.js", "Node.js"]},
    "jQuery": {"scripts": [r"jquery(-|\.)\d", r"jquery(\.min)?\.js"]},
    "Bootstrap": {"scripts": [r"bootstrap(\.min)?\.js"], "html": [r'class="[^"]*\bcontainer-fluid\b']},
    "Cloudflare": {"headers": {"cf-ray": r".", "server": r"cloudflare"}},
    "Nginx": {"headers": {"server": r"nginx"}},
    "Apache": {"headers": {"server": r"apache"}},
    "Microsoft-IIS": {"headers": {"server": r"iis", "x-aspnet-version": r"."}, "implies": [".NET"]},
    "LiteSpeed": {"headers": {"server": r"litespeed"}},
    "PHP": {"headers": {"x-powered-by": r"php", "set-cookie": r"phpsessid"}},
    "Node.js": {"headers": {"x-powered-by": r"express"}},
    "Ruby on Rails": {"headers": {"x-powered-by": r"phusion passenger"},
                      "cookies": [r"^_.*_session"], "html": [r'name="csrf-param" content="authenticity_token"']},
    "Django": {"cookies": [r"^(csrftoken|sessionid)$"], "implies": ["Python"]},
    "Google Analytics": {"scripts": [r"google-analytics\.com/(ga|analytics)\.js",
                                     r"googletagmanager\.com/gtag/js"]},
    "Google Tag Manager": {"scripts": [r"googletagmanager\.com/gtm\.js"], "html": [r"GTM-[A-Z0-9]+"]},
    "Varnish": {"headers": {"via": r"varnish", "x-varnish": r"."}},
    "Fastly": {"headers": {"x-served-by": r"cache-.*fastly", "x-fastly-request-id": r"."}},
    "Akamai": {"headers": {"x-akamai-transformed": r".", "server": r"akamaighost"}},
}


def _rx(p):
    return re.compile(p, re.I)


_TECH_COMPILED = {
    t: {"headers": {k.lower(): _rx(v) for k, v in r.get("headers", {}).items()},
        "html": [_rx(x) for x in r.get("html", [])],
        "scripts": [_rx(x) for x in r.get("scripts", [])],
        "cookies": [_rx(x) for x in r.get("cookies", [])],
        "meta": {k.lower(): _rx(v) for k, v in r.get("meta", {}).items()},
        "implies": r.get("implies", [])}
    for t, r in _TECH_RULES.items()
}

_META_RE = re.compile(r'<meta[^>]+name=["\']([^"\']+)["\'][^>]+content=["\']([^"\']*)["\']', re.I)
_SCRIPT_RE = re.compile(r'<script[^>]+src=["\']([^"\']+)["\']', re.I)


def detect_tech(headers: dict, html: str = "", set_cookies: Optional[list] = None) -> set:
    """헤더/HTML/스크립트/쿠키/meta 에서 기술 스택 탐지(정확 규칙매칭). implies 로 전이확장."""
    low_h = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    cookies = list(set_cookies or [])
    # Set-Cookie 는 헤더에도 있을 수 있음
    if "set-cookie" in low_h:
        cookies.append(low_h["set-cookie"])
    metas = {n.lower(): c for n, c in _META_RE.findall(html or "")}
    scripts = _SCRIPT_RE.findall(html or "")
    found = set()
    for tech, r in _TECH_COMPILED.items():
        hit = False
        for hk, rx in r["headers"].items():
            if hk in low_h and rx.search(low_h[hk]):
                hit = True; break
        if not hit:
            for rx in r["html"]:
                if html and rx.search(html):
                    hit = True; break
        if not hit:
            for rx in r["scripts"]:
                if any(rx.search(s) for s in scripts):
                    hit = True; break
        if not hit:
            for rx in r["cookies"]:
                if any(rx.search(c) for c in cookies):
                    hit = True; break
        if not hit:
            for mk, rx in r["meta"].items():
                if mk in metas and rx.search(metas[mk]):
                    hit = True; break
        if hit:
            found.add(tech)
    # implies 전이 폐쇄
    changed = True
    while changed:
        changed = False
        for tech in list(found):
            for imp in _TECH_COMPILED.get(tech, {}).get("implies", []):
                if imp not in found:
                    found.add(imp); changed = True
    return found


class TechFingerprint(InfraSource):
    """도메인 홈페이지 → 기술 스택 집합(attr 'tech_stack'). 드문 스택 공유 = 동일 운영자 신호."""
    name = "tech-fp"
    accepts = {InfraType.DOMAIN}
    host = ""

    async def fetch(self, target, http):
        d = target.normalized
        r = await http(f"https://{d}/")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status < 0:
            return FetchResult(self.name, ok=False, error="net")
        headers = r.headers or {}
        sc = headers.get("set-cookie") or headers.get("Set-Cookie")
        cookies = [sc] if sc else []
        tech = detect_tech(headers, r.text or "", cookies)
        if not tech:
            return FetchResult(self.name, ok=False, error="no tech")
        ent = Entity(type=EntityType.DOMAIN, value=d, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "기술 스택 지문", f"https://{d}/"),
                     attrs={"tech_stack": sorted(tech)})
        return FetchResult(self.name, entities=[ent])


# =========================================================================== #
# 4) abuse.ch — SSLBL(악성 인증서 SHA1) + ThreatFox(IOC)
# =========================================================================== #
class AbuseChSSLBL:
    """abuse.ch SSL Blacklist. CSV(sslbl.csv) 를 주입 → 악성 인증서 SHA1 지문 집합.

    형식(주석 # 제외): Listingdate,SHA1,Listingreason  → SHA1 소문자 집합.
    """

    def __init__(self):
        self.bad: dict[str, str] = {}       # sha1 → reason

    def load_csv(self, text: str) -> int:
        c = 0
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 2 and re.fullmatch(r"[0-9a-fA-F]{40}", parts[1]):
                self.bad[parts[1].lower()] = parts[2] if len(parts) >= 3 else "SSLBL"
                c += 1
        return c

    def check(self, sha1: str) -> Optional[str]:
        return self.bad.get((sha1 or "").replace(":", "").lower())


class ThreatFox:
    """abuse.ch ThreatFox IOC 피드. export JSON 주입 → {ioc_value: {malware, type, confidence}}.

    형식(공식 export): {"<id>":[{"ioc_value","ioc_type","malware_printable","confidence_level"}], ...}
    또는 {"data":[...]} / [...] 도 허용.
    """

    def __init__(self):
        self.ioc: dict[str, dict] = {}

    def load(self, doc) -> int:
        rows = []
        if isinstance(doc, dict):
            if "data" in doc and isinstance(doc["data"], list):
                rows = doc["data"]
            else:
                for v in doc.values():
                    rows.extend(v if isinstance(v, list) else [v])
        elif isinstance(doc, list):
            rows = doc
        c = 0
        for r in rows:
            if not isinstance(r, dict):
                continue
            val = (r.get("ioc_value") or r.get("ioc") or "").strip().lower()
            if not val:
                continue
            self.ioc[val] = {"malware": r.get("malware_printable") or r.get("malware") or "",
                             "type": r.get("ioc_type") or "",
                             "confidence": r.get("confidence_level")}
            c += 1
        return c

    def check(self, value: str) -> Optional[dict]:
        return self.ioc.get((value or "").strip().lower())


class AbuseChSource(InfraSource):
    """도메인/IP/인증서지문을 abuse.ch 위협 인텔에 대조 → attr 'threat'(+ MALWARE 엔티티/간선).

    sslbl/threatfox 는 미리 로드된 인스턴스를 주입(오프라인). 네트워크 갱신은 별도.
    """
    name = "abuse.ch"
    accepts = {InfraType.DOMAIN, InfraType.IP}
    host = "abuse.ch"

    def __init__(self, sslbl: Optional[AbuseChSSLBL] = None,
                 threatfox: Optional[ThreatFox] = None):
        self.sslbl = sslbl
        self.tf = threatfox

    async def fetch(self, target, http):
        v = target.normalized
        threats = []
        tf_hit = self.tf.check(v) if self.tf else None
        if tf_hit:
            threats.append(f"threatfox:{tf_hit.get('malware') or tf_hit.get('type') or 'ioc'}")
        # 인증서 지문 대조(도메인 attr 에 cert_fps 가 있으면 호출측에서 넘겨줌 — 여기선 IOC 만)
        if not threats:
            return FetchResult(self.name, ok=False, error="no match")
        ekind = EntityType.DOMAIN if target.type == InfraType.DOMAIN else EntityType.IP
        ent = Entity(type=ekind, value=v, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "abuse.ch IOC 매칭"),
                     attrs={"threat": threats})
        mal = Entity(type=EntityType.MALWARE, value=threats[0], certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "위협 인텔"))
        edge = Edge(src=_k(ekind, v), dst=_k(EntityType.MALWARE, threats[0]),
                    relation="위협연관", certainty=Certainty.CONFIRMED,
                    evidence=_ev(self.name, "abuse.ch"))
        return FetchResult(self.name, entities=[ent, mal], edges=[edge])


def screen_certs_against_sslbl(sigmap_or_graph, sslbl: AbuseChSSLBL) -> list:
    """그래프/신호맵의 인증서 SHA1 지문(cert_fps)을 SSLBL 에 대조 → [(domain, sha1, reason)]."""
    hits = []
    ents = getattr(sigmap_or_graph, "entities", None)
    if ents is not None:                     # Graph
        for e in ents:
            for fp in (e.attrs or {}).get("cert_fps", []) or []:
                reason = sslbl.check(fp)
                if reason:
                    hits.append((e.value, fp, reason))
    else:                                    # dict {domain: {kind:set}}
        for dom, sig in sigmap_or_graph.items():
            for fp in sig.get("cert_fp", set()):
                reason = sslbl.check(fp)
                if reason:
                    hits.append((dom, fp, reason))
    return hits


# =========================================================================== #
# 5) Shodan favicon 피벗 — mmh3 순수구현(자산 발견 배수기)
# =========================================================================== #
def _rotl32(x: int, r: int) -> int:
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def murmur3_x86_32(data: bytes, seed: int = 0) -> int:
    """MurmurHash3 x86_32(부호 없는 32비트). Shodan http.favicon.hash 계산의 코어."""
    c1, c2 = 0xCC9E2D51, 0x1B873593
    length = len(data)
    h1 = seed & 0xFFFFFFFF
    rounded = length & ~0x03
    for i in range(0, rounded, 4):
        k1 = (data[i] | (data[i + 1] << 8) | (data[i + 2] << 16) | (data[i + 3] << 24)) & 0xFFFFFFFF
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = _rotl32(k1, 15)
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
        h1 = _rotl32(h1, 13)
        h1 = (h1 * 5 + 0xE6546B64) & 0xFFFFFFFF
    k1 = 0
    tail = length & 0x03
    if tail == 3:
        k1 ^= data[rounded + 2] << 16
    if tail >= 2:
        k1 ^= data[rounded + 1] << 8
    if tail >= 1:
        k1 ^= data[rounded]
        k1 = (k1 * c1) & 0xFFFFFFFF
        k1 = _rotl32(k1, 15)
        k1 = (k1 * c2) & 0xFFFFFFFF
        h1 ^= k1
    h1 ^= length
    h1 ^= h1 >> 16
    h1 = (h1 * 0x85EBCA6B) & 0xFFFFFFFF
    h1 ^= h1 >> 13
    h1 = (h1 * 0xC2B2AE35) & 0xFFFFFFFF
    h1 ^= h1 >> 16
    return h1


def _to_signed32(u: int) -> int:
    return u - 0x100000000 if u & 0x80000000 else u


def favicon_mmh3(raw: bytes) -> int:
    """Shodan 방식 favicon 해시: base64(줄바꿈 76자마다) 인코딩 후 mmh3 x86_32 (부호 있는 32비트)."""
    b64 = base64.encodebytes(raw)            # 76자마다 \n + 끝에 \n (Shodan 과 동일)
    return _to_signed32(murmur3_x86_32(b64))


def shodan_favicon_query(raw: bytes) -> str:
    """favicon 바이트 → Shodan 검색식. '이 favicon 을 쓰는 모든 호스트' 피벗(키 호출 없이 식만 생성)."""
    return f"http.favicon.hash:{favicon_mmh3(raw)}"
