"""전역 병렬 오케스트레이션 코어 — frontier 전체를 하나의 흐름으로 포화까지.

기존 Engine.run 은 반복(depth)마다 `asyncio.Semaphore(concurrency)` 를 새로 만들고
`as_completed` 로 배리어를 친다. 즉 깊이 경계마다 "그 반복의 마지막 도구가 끝날 때까지"
다음 반복이 못 나간다 — 느린 도구 하나가 계단마다 전체를 세운다.

이 모듈은 두 가지를 준다:

1) AdaptiveConcurrency — 자원 포화점까지 동시성을 **자동으로** 올리는 거버너.
   무한 병렬은 없다(README 설계원칙과 동일). 대신 관측된 성공/드롭 신호로 AIMD 제어:
   - 성공 + 포화상태 → 가법 증가(천천히 상한을 탐색)
   - 드롭(타임아웃·429·연결오류) → 승법 감소(즉시 물러섬)
   경계는 **증명가능하게** [min_limit, max_limit] 안에 갇힌다(테스트로 검증).
   원격 서비스의 진짜 포화점은 사전에 알 수 없으므로 동작점(operating point)은 적응적이다
   — 이건 근사를 확정인 척하는 게 아니라, 알 수 없는 값을 관측으로 좇는 제어 문제다.

2) GlobalScheduler — 코루틴 팩토리 스트림을 전역 거버너 + per-host politeness 아래
   돌리고, 완료되는 대로 결과를 흘린다(streaming). 한 잡의 예외는 격리(전체 안 죽음).
   frontier 확장이 진행 중에도 새 잡을 밀어넣을 수 있어(dynamic submit) 깊이 배리어가
   사라진다 — 이게 처리량의 실제 이득이다.

순수 asyncio. 외부 의존 0. de-anon 표면을 늘리지 않는다 — 인가된 수집기를 인가된
표적에 대해 **빠르게** 돌리는 실행층일 뿐이다.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Awaitable, Callable, Iterable, Optional


# --------------------------------------------------------------------------- #
# 1) 적응형 동시성 거버너 (AIMD, 증명가능 bounded)
# --------------------------------------------------------------------------- #
class AdaptiveConcurrency:
    """포화까지 자동으로 여닫는 동시성 게이트.

    불변식(테스트로 강제):
      * 항상  min_limit <= limit <= max_limit
      * on_drop 은 limit 를 절대 올리지 않는다(단조 감소)
      * on_success 는 limit 를 절대 내리지 않는다(단조 증가)
      * 동시 in_flight 는 어느 시점에도 max_limit 를 넘지 않는다
        (신규 진입은 in_flight >= limit 이면 차단되고, limit <= max_limit)
    """

    def __init__(
        self,
        start: int = 8,
        *,
        min_limit: int = 1,
        max_limit: int = 256,
        increase: float = 1.0,   # 라운드당 가법 증가량(포화 시)
        beta: float = 0.7,       # 드롭 시 승법 감소 계수 (0<beta<1)
    ) -> None:
        if not (1 <= min_limit <= start <= max_limit):
            raise ValueError("must satisfy 1 <= min_limit <= start <= max_limit")
        if not (0.0 < beta < 1.0):
            raise ValueError("beta must be in (0,1)")
        if increase <= 0.0:
            raise ValueError("increase must be > 0")
        self._min = int(min_limit)
        self._max = int(max_limit)
        self._inc = float(increase)
        self._beta = float(beta)
        self._limit = float(start)   # 실수로 유지하되 승인은 정수 바닥값 기준
        self.in_flight = 0
        self._cond = asyncio.Condition()
        # 관측용 지표(감사/튜닝)
        self.max_in_flight = 0
        self.total_acquired = 0
        self.total_drops = 0

    @property
    def limit(self) -> int:
        """현재 유효 동시성(정수). 항상 [min,max]."""
        v = int(self._limit)
        if v < self._min:
            v = self._min
        if v > self._max:
            v = self._max
        return v

    async def acquire(self) -> None:
        async with self._cond:
            while self.in_flight >= self.limit:
                await self._cond.wait()
            self.in_flight += 1
            self.total_acquired += 1
            if self.in_flight > self.max_in_flight:
                self.max_in_flight = self.in_flight

    async def complete(self, *, dropped: bool) -> None:
        """정확히 acquire() 한 번당 한 번 호출. dropped=True 면 물러서고, 아니면 포화 시 전진."""
        async with self._cond:
            saturated = self.in_flight >= self.limit  # 이번 완료 전 대기압이 있었나
            self.in_flight -= 1
            if self.in_flight < 0:  # 방어(호출 규약 위반 감지)
                self.in_flight = 0
                raise RuntimeError("complete() called more times than acquire()")
            if dropped:
                self.total_drops += 1
                self._limit = max(float(self._min), self._limit * self._beta)
            elif saturated and self._limit < self._max:
                # 포화 상태에서만 상한을 탐색(가법 증가). limit 이 클수록 라운드당 +1 근사.
                self._limit = min(float(self._max), self._limit + self._inc / self._limit)
            self._cond.notify_all()

    def snapshot(self) -> dict[str, Any]:
        return {
            "limit": self.limit,
            "in_flight": self.in_flight,
            "max_in_flight": self.max_in_flight,
            "acquired": self.total_acquired,
            "drops": self.total_drops,
            "min": self._min,
            "max": self._max,
        }


# --------------------------------------------------------------------------- #
# 2) per-host politeness 훅 (독립 실행용 최소 구현; 기존 core.politeness 로 대체 가능)
# --------------------------------------------------------------------------- #
class HostRateLimiter:
    """호스트별 최소 간격(토큰버킷 단순형). core.politeness.RateLimiter 와 호환 시그니처."""

    def __init__(self, min_interval: float = 0.0) -> None:
        self.min_interval = min_interval
        self._last: dict[str, float] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    def _lock(self, host: str) -> asyncio.Lock:
        lk = self._locks.get(host)
        if lk is None:
            lk = self._locks[host] = asyncio.Lock()
        return lk

    async def acquire(self, host: str) -> None:
        if self.min_interval <= 0 or not host:
            return
        async with self._lock(host):
            now = time.monotonic()
            wait = self.min_interval - (now - self._last.get(host, 0.0))
            if wait > 0:
                await asyncio.sleep(wait)
            self._last[host] = time.monotonic()


# --------------------------------------------------------------------------- #
# 3) 잡/결과 모델
# --------------------------------------------------------------------------- #
@dataclass
class Job:
    """실행 단위. make() 는 호출 시점에 awaitable 을 만드는 팩토리(지연 생성)."""
    make: Callable[[], Awaitable[Any]]
    host: str = ""                       # politeness 키(빈 값이면 rate-limit 생략)
    key: Any = None                      # 호출측 상관용(예: (collector, entity.key))
    is_drop: Callable[[Any], bool] = lambda r: False  # 결과가 '드롭'인지 판정(429 등)


@dataclass
class Result:
    key: Any
    host: str
    ok: bool
    value: Any = None
    error: str = ""
    elapsed: float = 0.0
    dropped: bool = False


# --------------------------------------------------------------------------- #
# 4) 전역 스케줄러
# --------------------------------------------------------------------------- #
class GlobalScheduler:
    """전역 거버너 + per-host politeness 아래 잡 스트림을 돌리고 결과를 흘린다.

    * 실패격리: 잡의 예외는 Result(ok=False)로 잡히고 전체를 죽이지 않는다.
    * 스트리밍: 완료 순서대로 yield.
    * 동적 제출: 스트림이 끝나기 전에 submit()으로 새 잡 추가 가능(깊이 배리어 제거).
    * 예산: max_seconds / max_jobs 상한(초과 시 미출발 잡은 취소).
    """

    def __init__(
        self,
        governor: Optional[AdaptiveConcurrency] = None,
        *,
        limiter: Optional[HostRateLimiter] = None,
        max_jobs: int = 0,          # 0 = 무제한
        max_seconds: float = 0.0,   # 0 = 무제한
    ) -> None:
        self.gov = governor or AdaptiveConcurrency()
        self.limiter = limiter or HostRateLimiter()
        self.max_jobs = max_jobs
        self.max_seconds = max_seconds
        self._q: asyncio.Queue[Optional[Job]] = asyncio.Queue()
        self._closed = False
        self._submitted = 0
        self._started = 0.0

    def submit(self, job: Job) -> bool:
        """잡 추가. 예산 초과/마감 후면 False."""
        if self._closed:
            return False
        if self.max_jobs and self._submitted >= self.max_jobs:
            return False
        self._submitted += 1
        self._q.put_nowait(job)
        return True

    def at_capacity(self) -> bool:
        """더 이상 잡을 받을 수 없나(마감 or max_jobs 소진). _submitted 는 단조증가라 영구적.
        인테이크(topup)가 이걸 보고 seed 당기기를 멈춰야 무한 generator 소모를 막는다(리뷰 P1)."""
        return self._closed or bool(self.max_jobs and self._submitted >= self.max_jobs)

    def close(self) -> None:
        """더 이상 제출 없음을 알림 — 큐가 비면 스트림 종료."""
        if not self._closed:
            self._closed = True
            self._q.put_nowait(None)  # sentinel

    async def _one(self, job: Job, out: asyncio.Queue) -> None:
        # 거버너 슬롯은 pump 가 태스크 생성 직전에 미리 잡는다(워커풀). 여기선 슬롯을 이미
        # 쥔 상태 — 그래서 동시 태스크 수가 limit 로 묶이고, notify_all thundering herd 가
        # 사라진다(과거엔 잡마다 태스크가 즉시 생겨 전부 acquire 에서 대기 → O(n²)).
        await self.limiter.acquire(job.host)
        t0 = time.perf_counter()
        dropped = False
        try:
            val = await job.make()
            dropped = bool(job.is_drop(val))
            res = Result(key=job.key, host=job.host, ok=True, value=val,
                         elapsed=time.perf_counter() - t0, dropped=dropped)
        except asyncio.TimeoutError:
            dropped = True
            res = Result(key=job.key, host=job.host, ok=False, error="timeout",
                         elapsed=time.perf_counter() - t0, dropped=True)
        except asyncio.CancelledError:
            # 스케줄러 종료/예산초과로 취소됨 — 거버너 정리 후 조용히 빠짐(결과 미방출)
            await self.gov.complete(dropped=True)
            raise
        except Exception as e:  # 실패격리: 어떤 예외도 전체를 죽이지 않는다
            res = Result(key=job.key, host=job.host, ok=False,
                         error=f"{type(e).__name__}: {e}",
                         elapsed=time.perf_counter() - t0, dropped=False)
        # 정상/타임아웃/기타예외 경로: 거버너에 완료 신호 후 결과 방출
        await self.gov.complete(dropped=dropped)
        await out.put(res)

    async def run_stream(self, seed: Iterable[Job] = ()) -> AsyncIterator[Result]:
        """seed 잡들로 시작. 진행 중 submit()으로 추가 가능. 결과를 완료 순 yield."""
        self._started = time.perf_counter()
        for j in seed:
            self.submit(j)

        out: asyncio.Queue = asyncio.Queue()
        running: set[asyncio.Task] = set()
        DONE = object()
        state = {"drained": False, "active": 0, "finished": False}

        def maybe_finish() -> None:
            # 더 나올 결과 없음(펌프 소진 + 실행 태스크 0)이면 소비자에게 종료 센티넬 1회.
            if state["drained"] and state["active"] == 0 and not state["finished"]:
                state["finished"] = True
                out.put_nowait(DONE)

        async def worker(job: Job) -> None:
            try:
                await self._one(job, out)
            finally:
                state["active"] -= 1
                maybe_finish()

        async def pump() -> None:
            while True:
                if self.max_seconds and (time.perf_counter() - self._started) >= self.max_seconds:
                    break
                try:
                    # 폴링 아님: put(제출/close 센티넬)이 즉시 깨운다. 타임아웃은 방어적 재확인.
                    job = await asyncio.wait_for(self._q.get(), timeout=0.5)
                except asyncio.TimeoutError:
                    if self._closed and self._q.empty():
                        break
                    continue
                if job is None:  # close() 센티넬
                    break
                # 슬롯을 먼저 확보(throttle) → 확보 직후 태스크 생성(사이에 await 없음).
                await self.gov.acquire()
                state["active"] += 1
                t = asyncio.create_task(worker(job))
                running.add(t)
                t.add_done_callback(running.discard)
            state["drained"] = True
            maybe_finish()

        pump_task = asyncio.create_task(pump())
        try:
            while True:
                res = await out.get()      # 폴링 없음 — 결과/센티넬에 즉시 반응
                if res is DONE:
                    break
                yield res
        finally:
            pump_task.cancel()
            for t in list(running):
                t.cancel()
            await asyncio.gather(pump_task, *running, return_exceptions=True)

    async def map(self, jobs: Iterable[Job]) -> list[Result]:
        """정적 잡 집합 편의 실행 — 전부 모아 반환(순서 보장 안 함)."""
        js = list(jobs)
        results: list[Result] = []
        for j in js:
            self.submit(j)
        self.close()
        async for r in self.run_stream():
            results.append(r)
        return results
