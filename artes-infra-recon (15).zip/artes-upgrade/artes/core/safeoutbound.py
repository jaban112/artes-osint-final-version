"""SafeOutbound — 모든 능동 outbound(HTTP·TLS·favicon·DNS 등)의 **단일 안전 기층**(강화 축7).

지금까지 HTTP 는 Caching→Politeness→RequestLimiter→SSRFGuard→HTTP 파이프라인을 통과하지만, TLS/favicon
같은 능동 probe 는 별도 네트워크 경로라 이 보증을 자동으로 상속하지 못했다. SafeOutbound 는 모든 probe 를
하나의 관문으로 통과시킨다:

    authorization(+audit) → RequestLimiter(동시성/총량) → Politeness(per-host) → SSRF → transport

새 probe 를 register_probe(kind, transport) 로 붙이면 위 보증을 **자동 상속**한다 → 보안 검토가 1곳으로 준다.
scope 가 있으면 실제 요청 직전 scope.check() 로 재검증하고 통과/차단을 감사에 남긴다(축2·P0 실행시점 authz 와
동일 원칙). 순수 stdlib(+선택 aiohttp/cryptography 는 transport 안에서만).
"""
from __future__ import annotations

from typing import Callable, Optional

from .nethttp import (HTTPResp, RequestLimiter, SSRFGuard, PolitenessHTTP,
                      default_http_get, DEFAULT_MAX_BODY_BYTES)


class SafeOutbound:
    """모든 outbound probe 의 공통 안전 기층. probe 종류별 transport 를 등록해 같은 관문을 공유한다."""

    def __init__(self, *, scope=None, max_concurrency: int = 128,
                 max_total: Optional[int] = None, politeness_interval: float = 0.0,
                 politeness_retries: int = 3, ssrf: bool = True,
                 max_body_bytes: int = DEFAULT_MAX_BODY_BYTES,
                 http_transport: Optional[Callable] = None):
        self.scope = scope
        self.max_body_bytes = max_body_bytes
        self._pol_interval = politeness_interval
        self._pol_retries = politeness_retries
        # HTTP transport 파이프라인(축8 body cap 포함). 주입 없으면 프로덕션 기본.
        base = http_transport or (lambda u: default_http_get(u, max_body_bytes=max_body_bytes))
        if ssrf:
            base = SSRFGuard(base)
        self.limiter = RequestLimiter(base, max_concurrency=max_concurrency, max_total=max_total)
        self.politeness = PolitenessHTTP(self.limiter, min_interval=politeness_interval,
                                         retries=politeness_retries)
        self._http = self.politeness
        self._probes: dict = {"http": self._http}   # kind → guarded transport(coroutine fn)
        self._ssrf = ssrf

    def register_probe(self, kind: str, transport: Callable, *, guard_ssrf: bool = True) -> None:
        """새 probe transport 등록 — RequestLimiter/Politeness/SSRF/authz 를 자동 상속한다.

        transport(target)->awaitable[HTTPResp-ish]. guard_ssrf=True 면 SSRF 도 앞에 끼운다."""
        t = SSRFGuard(transport) if (guard_ssrf and self._ssrf) else transport
        lim = RequestLimiter(t, max_concurrency=self.limiter.max_concurrency,
                             max_total=self.limiter.max_total)
        self._probes[kind] = PolitenessHTTP(lim, min_interval=self._pol_interval,
                                            retries=self._pol_retries)

    def _authz_ok(self, target: str, etype: str, collector: str) -> bool:
        """실행시점 authz 재검증 + 감사. scope 없으면 항상 통과(테스트/무범위)."""
        if self.scope is None:
            return True
        from .authz import AuthorizationError
        try:
            self.scope.check(target, etype, collector=collector)
            return True
        except AuthorizationError:
            return False

    async def fetch(self, url: str, *, kind: str = "http",
                    authz_selector: Optional[str] = None, authz_etype: str = "domain",
                    collector: str = "safeoutbound") -> HTTPResp:
        """kind 종류의 guarded 요청. authz_selector 로 실행시점 인가 재검증(감사 기록)."""
        sel = authz_selector or url
        if not self._authz_ok(sel, authz_etype, collector):
            return HTTPResp(status=-3, url=url)      # 미인가 → 정책 거부(-3, 재시도 아님)
        probe = self._probes.get(kind)
        if probe is None:
            raise ValueError(f"등록되지 않은 probe kind: {kind!r}")
        return await probe(url)

    def stats(self) -> dict:
        return {"max_concurrency": self.limiter.max_concurrency,
                "max_total": self.limiter.max_total,
                "total_requests": self.limiter.total,
                "peak_in_flight": self.limiter.peak,
                "rejected_over_budget": self.limiter.rejected_over_budget,
                "probes": sorted(self._probes),
                "ssrf": self._ssrf, "max_body_bytes": self.max_body_bytes}
