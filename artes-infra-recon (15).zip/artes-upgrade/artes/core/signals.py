"""선언적 same-operator 신호 레지스트리 — 정확히 100개 축.

핵심: 신호를 100개로 늘려도 상관(correlation)은 **더 빨라진다**. 이유는 OperatorIndex 가
전체 도메인 쌍을 보지 않고, 같은 신호 '값'을 공유하는 후보 쌍만 보기 때문(역인덱스). 신호가
sparse 하면 축이 100개든 12개든 검사하는 쌍 수는 '실제로 값을 공유하는 쌍' 뿐이다. 게다가
아주 흔한 값(예: 대형 CDN NS)은 제네릭으로 억제(OperatorIndex.max_bucket)해 O(cap²) 로 묶는다.

여기서는 값을 만들지 않는다(휴리스틱 아님) — 이미 수집된 DNS/cert/HTTP/PTR 사실에서 도메인별로
'해당 축의 값 집합'을 뽑을 뿐이다. 대부분 축은 대부분 도메인에서 비어 있다(sparse) — 그게 정상.

축 구성(총 100): 코어(DNS·넷블록 다중 prefix·cert 필드·PTR 등) + TXT 검증 벤더 토큰 + 보안 헤더.
"""
from __future__ import annotations

import functools
import ipaddress
from typing import Callable

from .model import Graph, EntityType


# --------------------------------------------------------------------------- #
# 파생 헬퍼
# --------------------------------------------------------------------------- #
def _ip_of(ip_key: str) -> str:
    return ip_key.split(":", 1)[1] if ":" in ip_key else ip_key


@functools.lru_cache(maxsize=100000)
def _netblock(ip_key: str, prefix: int) -> str:
    """ip:<addr> → nb<prefix>:<network>. 정수 마스킹(빠름, ipaddress 재파싱 없음). 메모이즈."""
    ip = _ip_of(ip_key)
    try:
        obj = ipaddress.ip_address(ip)
    except ValueError:
        return ""
    if obj.version == 4:
        mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF
        net = int(obj) & mask
        return f"nb{prefix}:{ipaddress.IPv4Address(net)}/{prefix}"
    p = min(prefix * 2, 128)
    mask = (((1 << 128) - 1) << (128 - p)) & ((1 << 128) - 1)
    net = int(obj) & mask
    return f"nb{prefix}:{ipaddress.IPv6Address(net)}/{p}"


def _last_two_labels(host_key: str) -> str:
    """마지막 두 레이블 반환(정직한 이름 — 리뷰 P2). 진짜 registrable domain 아님:
    example.co.uk / foo.city.kawasaki.jp 같은 다단계 접미사는 PSL 없이 정확히 못 낸다.
    ns/mx 묶음 신호용 근사(같은 마지막-두-레이블 = 같은 제공자족일 가능성)일 뿐이다.
    stdlib-only 유지 위해 PSL 미도입. 정확 registrable 이 필요하면 publicsuffix2 주입 지점."""
    h = host_key.split(":", 1)[1] if ":" in host_key else host_key
    parts = h.rstrip(".").split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else h


_registrable = _last_two_labels   # 하위호환 별칭(기존 참조 유지)


# 알려진 TXT 검증 토큰 벤더(각각 독립 축) — 값 = 해당 토큰.
_VERIFICATION_VENDORS = [
    "google-site-verification", "facebook-domain-verification", "apple-domain-verification",
    "ms", "docusign", "stripe-verification", "atlassian-domain-verification",
    "adobe-idp-site-verification", "adobe-sign-verification", "amazonses",
    "brave-ledger-verification", "cisco-ci-domain-verification", "citrix-verification-code",
    "detectify-verification", "dropbox-domain-verification", "globalsign-domain-verification",
    "have-i-been-pwned-verification", "keybase-site-verification", "logmein-verification-code",
    "mailru-verification", "mongodb-site-verification", "onetrust-domain-verification",
    "openai-domain-verification", "pardot", "pinterest-site-verification",
    "postman-domain-verification", "protonmail-verification", "sendinblue-code",
    "shopify-verification", "slack-domain-verification", "spycloud-domain-verification",
    "statuspage-domain-verification", "tiktok-developers-site-verification",
    "twilio-domain-verification", "webexdomainverification", "wmail-verification",
    "workplace-domain-verification", "yandex-verification", "zoom-domain-verification",
    "notion-domain-verification",
]

# 보안/식별 HTTP 헤더(각각 독립 축) — 값 = 헤더 값(또는 존재 지표).
_SECURITY_HEADERS = [
    "strict-transport-security", "content-security-policy", "x-frame-options",
    "x-content-type-options", "referrer-policy", "permissions-policy",
    "x-xss-protection", "cross-origin-opener-policy", "cross-origin-embedder-policy",
    "cross-origin-resource-policy", "x-permitted-cross-domain-policies", "expect-ct",
    "report-to", "nel", "x-cache", "cf-ray", "x-served-by", "via",
    "x-amz-cf-id", "x-azure-ref", "x-powered-by", "server-timing",
]


class _Spec:
    __slots__ = ("name", "fn")

    def __init__(self, name: str, fn: Callable):
        self.name = name
        self.fn = fn

    def extract(self, ctx) -> set:
        return self.fn(ctx)


# 확장 패밀리(EXTENDED): 더 많은 축. 전부 sparse — 역인덱스라 축 수가 늘어도 상관은 안 느려진다.
_EXT_LIST_ATTRS = [  # 도메인 attr(list) → 각 값이 신호값
    ("caa", "caa"), ("cookie", "cookie_names"), ("txt_all", "txt_all"),
    ("ns_all", "ns_all"), ("open_ports", "open_ports"), ("cpe", "cpe"),
    ("jarm_ext", "jarm_ext"), ("asn_path", "asn_path"),
    ("tech", "tech_stack"),      # sources_ext.TechFingerprint — 드문 스택 공유 = 동일 운영자
    ("threat", "threat"),        # sources_ext.AbuseChSource — 같은 위협/캠페인 연관
    ("cert_fp", "cert_fps"),     # sources_ext.CertStreamIngest — 물리 인증서 SHA1(공유=동일 발급)
]
_EXT_IP_ATTRS = [  # IP attr(scalar) → 도메인의 A레코드 IP 를 통해 전파되는 축
    ("cloud_provider", "cloud_provider"),   # providers.annotate_providers — deconfound 교란자 층
]
_EXT_IPLIST_ATTRS = [  # IP attr(list) → A레코드 IP 를 통해 전파(sources_net: Shodan/Censys)
    ("port", "open_ports"),      # 열린 포트(공격표면; 공유 = 유사 구성)
    ("ipcpe", "cpe"),            # IP 레벨 소프트웨어 CPE(도메인 tech 축과 구분)
    ("cve", "cve"),              # 알려진 취약점 ID(자산 위험; 공유 = 동일 스택/미패치)
]
_EXT_SCALAR_ATTRS = [  # 도메인 attr(scalar)
    ("dnssec", "dnssec"), ("ds", "ds_digest"), ("dnskey", "dnskey"),
    ("cert_keysize", "cert_keysize"), ("cert_version", "cert_version"),
    ("cert_serial", "cert_serial"), ("soa_rname", "soa_rname"),
    ("soa_serial_bucket", "soa_serial_bucket"), ("ns_count", "ns_count"),
    ("mx_pref", "mx_pref"), ("ttl_bucket", "ttl_bucket"), ("wildcard", "wildcard"),
    ("ipv6", "has_aaaa"), ("http_ver", "http_version"), ("alt_svc", "alt_svc"),
    ("etag_style", "etag_style"), ("cookie_flags", "cookie_flags"),
    ("title_hash", "title_hash"), ("robots_hash", "robots_hash"),
    ("sitemap", "sitemap_url"), ("mx_provider", "mx_provider"),
    ("cdn", "cdn"), ("waf", "waf"), ("analytics", "analytics_id"),
]
_EXT_HEADERS = [  # 추가 HTTP 헤더 축(값 지문)
    "content-type", "content-language", "vary", "age", "accept-ranges",
    "x-request-id", "x-runtime", "x-aspnet-version", "x-generator", "x-drupal-cache",
    "x-litespeed-cache", "x-pingback", "link", "content-encoding", "x-download-options",
    "x-ua-compatible", "x-dns-prefetch-control", "x-turbo-charged-by", "x-backend",
    "fastly-debug-digest", "x-timer", "x-cacheable", "x-varnish", "x-akamai-transformed",
]


def make_specs(vendors=_VERIFICATION_VENDORS, headers=_SECURITY_HEADERS,
               nb4_prefixes=(30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16),
               list_attrs=None, scalar_attrs=None, ipattrs=None, iplist_attrs=None,
               extra_headers=(), synthetic: int = 0) -> list:
    """신호 스펙 목록을 파라미터로 구성. 축을 늘려도(값이 sparse 하면) 상관은 안 느려진다."""
    S: list[_Spec] = []

    def add(name, fn):
        S.append(_Spec(name, fn))

    add("ns", lambda c: set(c["ns"]))
    add("mx", lambda c: set(c["mx"]))
    add("cname", lambda c: set(c["cname"]))
    add("a_ip", lambda c: set(c["aip"]))
    add("registrar", lambda c: set(c["reg"]))
    add("ns_reg", lambda c: {_registrable(x) for x in c["ns"]})
    add("mx_reg", lambda c: {_registrable(x) for x in c["mx"]})
    for p in nb4_prefixes:
        add(f"nb{p}", (lambda pp: (lambda c: {_netblock(ip, pp) for ip in c["aip"]} - {""}))(p))
    for name, attr in ([("co_cert", "cert_ids"), ("spf", "spf_includes"),
                        ("dmarc", "dmarc"), ("san", "san_domains")] + (list_attrs or [])):
        add(name, (lambda a: (lambda c: set(c["attrs"].get(a) or [])))(attr))
    for name, attr in ([("spki", "spki"), ("favicon", "favicon"), ("httpfp", "httpfp"),
                        ("server", "server"), ("tlsfp", "tlsfp"), ("issuer", "cert_issuer"),
                        ("keytype", "cert_keytype"), ("sigalg", "cert_sigalg"),
                        ("valbucket", "cert_valbucket"), ("sanbucket", "cert_sanbucket"),
                        ("soa_mname", "soa_mname"), ("http_status", "http_status"),
                        ("redirect", "redirect_domain"), ("gtm", "gtm"), ("ga", "ga")]
                       + (scalar_attrs or [])):
        add(name, (lambda a: (lambda c: {c["attrs"][a]} if c["attrs"].get(a) else set()))(attr))
    for name, attr in ([("ptr", "ptr_domain"), ("ptr_host", "ptr")] + (ipattrs or [])):
        add(name, (lambda a: (lambda c: {c["ip2attr"].get(ip, {}).get(a)
                                         for ip in c["aip"]
                                         if c["ip2attr"].get(ip, {}).get(a)}))(attr))
    # IP attr(list) → 도메인의 A레코드 IP들을 통해 각 값이 신호값(포트·CPE·CVE 전파)
    for name, attr in (iplist_attrs or []):
        add(name, (lambda a: (lambda c: {v for ip in c["aip"]
                                         for v in (c["ip2attr"].get(ip, {}).get(a) or [])}))(attr))
    for v in vendors:
        add(f"txt_{v}", (lambda vv: (lambda c: {c["attrs"].get("txt_tokens", {}).get(vv)}
                                     if c["attrs"].get("txt_tokens", {}).get(vv) else set()))(v))
    for h in list(headers) + list(extra_headers):
        add(f"hdr_{h}", (lambda hh: (lambda c: {c["attrs"].get("http_headers", {}).get(hh)}
                                     if c["attrs"].get("http_headers", {}).get(hh) else set()))(h))
    for i in range(synthetic):   # 벤치용 sparse 합성 축(항상 비어 있음 → 축당 오버헤드만 측정)
        add(f"syn{i}", (lambda ii: (lambda c: set()))(i))
    return S


SIGNAL_SPECS = make_specs()[:100]                       # 정확히 100 축(기본)
SIGNAL_KINDS_100 = tuple(s.name for s in SIGNAL_SPECS)
assert len(SIGNAL_KINDS_100) == 100, len(SIGNAL_KINDS_100)

# 확장 레지스트리(수백 축) — 실 패밀리 추가. 역인덱스라 여전히 빠름.
EXTENDED_SPECS = make_specs(list_attrs=_EXT_LIST_ATTRS, scalar_attrs=_EXT_SCALAR_ATTRS,
                            ipattrs=_EXT_IP_ATTRS, iplist_attrs=_EXT_IPLIST_ATTRS,
                            extra_headers=_EXT_HEADERS)
EXTENDED_KINDS = tuple(s.name for s in EXTENDED_SPECS)

# 신호 레지스트리 버전/개수는 스펙에서 **자동 계산**한다(리뷰 P1: 문서·주석에 100/161/168 이 혼재하던
# drift 제거). 문서·재현성 메타데이터는 이 값을 인용해야 한다.
SIGNAL_VERSION = "artes-signals-v1.0"
BASE_SIGNAL_COUNT = len(SIGNAL_SPECS)          # 100
EXTENDED_SIGNAL_COUNT = len(EXTENDED_SPECS)    # 168


# --------------------------------------------------------------------------- #
# 관측 패밀리(observation family) — 한 관측에서 파생된 축은 독립 증거가 아니다(강화 축2)
# --------------------------------------------------------------------------- #
# 한 번의 HTTP 응답에서 server/etag/cookie/title/… 이 함께 나오고, 한 인증서에서 issuer/spki/san/…
# 이 함께 나온다. 이들을 독립 q_v 로 곱하면 '한 번의 우연 일치'가 여러 번인 것처럼 부풀려진다(리뷰의
# 최대 통계 약점). family_of(kind) 로 각 축을 그 관측 이벤트에 매핑한다.
def family_of(kind: str) -> str:
    """축 이름 → 관측 패밀리. prefix 규칙 + 명시 매핑(EXTENDED 축까지 커버)."""
    if kind.startswith("hdr_"):
        return "http_response"       # 모든 HTTP 헤더 = 한 응답
    if kind.startswith("nb"):
        return "a_record"            # 모든 넷블록 = A레코드 IP 하나에서 파생
    if kind.startswith("txt_"):
        return "dns_txt"             # TXT 레코드 하나의 벤더 토큰들
    if kind in ("co_cert", "san", "spki", "issuer", "keytype", "sigalg",
                "valbucket", "sanbucket", "cert_serial"):
        return "certificate"         # 한 인증서
    if kind in ("server", "httpfp", "http_status", "http_ver", "alt_svc", "etag_style",
                "cookie_flags", "title_hash", "robots_hash", "sitemap", "redirect",
                "cdn", "waf", "analytics", "gtm", "ga", "favicon"):
        return "http_response"       # 한 번의 HTTP fetch
    if kind in ("a_ip",):
        return "a_record"
    if kind in ("ptr", "ptr_host"):
        return "ptr"                 # 역방향 DNS
    if kind in ("ns", "mx", "cname", "ns_reg", "mx_reg", "soa_mname", "soa_rname",
                "soa_serial_bucket", "ns_count", "mx_pref", "ttl_bucket", "wildcard",
                "ipv6", "spf", "dmarc", "mx_provider"):
        return "dns_zone"            # 존/네임서버 설정
    if kind in ("registrar",):
        return "registration"
    if kind in ("tlsfp",):
        return "tls_handshake"
    if kind in ("port", "ipcpe", "cve") or kind.endswith("_ports") or kind.endswith("_cpe"):
        return "ip_scan"             # Shodan/Censys 스캔 관측
    return f"axis:{kind}"            # 미분류 축은 자기 자신이 곧 패밀리(독립 취급, 보수적)


SIGNAL_FAMILIES = {k: family_of(k) for k in EXTENDED_KINDS}


def signal_set_hash(specs: list = EXTENDED_SPECS) -> str:
    """신호 레지스트리의 내용 주소 해시 — (버전, 정렬된 (kind,family) 목록). 재현성 메타데이터용:
    축을 추가/제거/재분류하면 이 해시가 바뀌어 '어떤 신호셋으로 낸 결과인가'가 고정된다(리뷰 P1)."""
    import hashlib
    import json
    body = {"version": SIGNAL_VERSION,
            "kinds": sorted((s.name, family_of(s.name)) for s in specs)}
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:16]


SIGNAL_SET_HASH = signal_set_hash()


def pad_specs(base: list, to_n: int) -> list:
    """base 를 합성 sparse 축으로 to_n 개까지 늘린다(스케일 벤치 전용)."""
    if len(base) >= to_n:
        return base[:to_n]
    extra = make_specs(vendors=(), headers=(), nb4_prefixes=(),
                       synthetic=to_n - len(base))
    # 앞부분 코어 중복 제거: synthetic 만 취함
    syn = [s for s in extra if s.name.startswith("syn")]
    return base + syn[:to_n - len(base)]


# --------------------------------------------------------------------------- #
# 의존성 붕괴 — 종속 신호를 독립 증거로 곱하는 double-counting 제거(리뷰 P0)
# --------------------------------------------------------------------------- #
# IP 를 정확히 공유하면 그 IP 에서 파생되는 모든 축은 결정적으로 따라온다(독립 증거 아님).
_IP_DERIVED = {"ptr", "ptr_host", "asn", "asn_path", "cloud_provider", "port", "ipcpe", "cve"}


def _nb_prefix(kind: str):
    return int(kind[2:]) if kind.startswith("nb") and kind[2:].isdigit() else None


def collapse_families(reps, df_of):
    """대표 (kind,value) 목록을 **관측 패밀리별로** 다시 축약한다(강화 축2).

    collapse_shared 가 kind 레벨 종속(a_ip⇒파생, nb 중첩, ns⇒ns_reg)을 제거한 뒤에도, 서로 다른
    kind 이지만 **같은 관측 이벤트**에서 나온 축들(예: server+etag+cookie = 한 HTTP 응답,
    issuer+spki+san = 한 인증서)은 독립 증거가 아니다. 각 패밀리에서 가장 희소한(df 최소) 대표 1개만
    남긴다 → '한 번의 우연 일치'를 여러 번으로 세지 않는다. df_of(kind,value)->df.
    반환: 패밀리당 1개로 줄인 대표 목록."""
    best: dict = {}
    for (k, v) in reps:
        fam = family_of(k)
        d = df_of(k, v)
        if fam not in best or d < best[fam][1]:
            best[fam] = ((k, v), d)
    return [kv for (kv, _d) in best.values()]


def collapse_shared(kv, df_of, by_family: bool = False):
    """공유 (kind,value) 집합을 **독립 대표들**로 축약(∏q 전에). df_of(kind,value)->df.
    by_family=True 면 kind 레벨 축약 뒤 관측-패밀리 축약(collapse_families)까지 적용(강화 축2).

    coincidence = ∏ q_v 는 각 (kind,value)가 독립이라는 가정에서만 정확한데, 실제 축들은
    강하게 종속된다(nb30⊃…⊃nb16 중첩, a_ip⇒모든 넷블록/ASN/provider/PTR, ns⇒ns_reg,
    같은 kind 의 NS 세트). 이들을 곱하면 증거가 부풀려진다(리뷰 지적). 규칙(전부 결정적 함의):
      1) 같은 kind 다중값 → 가장 희소한(df 최소) 값 1개만(세트를 독립 관측 여러 개로 세지 않음).
      2) 넷블록 중첩 → a_ip 공유 시 nb* 전부 제거; 아니면 가장 특정한(prefix 최대) nb 1개만.
      3) 등록가능 도메인은 전체의 함수 → ns 공유 시 ns_reg 제거, mx 공유 시 mx_reg 제거.
      4) 정확한 IP 공유 → PTR/ASN/provider/port/cpe/cve 등 IP 파생축 전부 제거(그 IP에 결정됨).
    반환: 대표 (kind,value) 목록. 이 대표들의 df 만 곱한다.
    """
    by_kind: dict = {}
    for (k, v) in kv:
        d = df_of(k, v)
        if k not in by_kind or d < by_kind[k][1]:
            by_kind[k] = (v, d)                      # 규칙1: kind 당 가장 희소한 값
    kinds = {k: vd[0] for k, vd in by_kind.items()}
    nb_kinds = [k for k in kinds if _nb_prefix(k) is not None]
    if "a_ip" in kinds:                              # 규칙2a: 정확 IP 가 모든 넷블록을 함의
        for k in nb_kinds:
            kinds.pop(k, None)
    elif nb_kinds:                                   # 규칙2b: 가장 특정한 넷블록만
        finest = max(nb_kinds, key=_nb_prefix)
        for k in nb_kinds:
            if k != finest:
                kinds.pop(k, None)
    if "ns" in kinds:                                # 규칙3
        kinds.pop("ns_reg", None)
    if "mx" in kinds:
        kinds.pop("mx_reg", None)
    if "a_ip" in kinds:                              # 규칙4
        for k in list(kinds):
            if k in _IP_DERIVED:
                kinds.pop(k, None)
    reps = [(k, kinds[k]) for k in kinds]
    if by_family:                                    # 규칙5(강화): 관측-패밀리당 1개로
        reps = collapse_families(reps, df_of)
    return reps


def collapse_shared_counts(kv, df_of, by_family: bool = False):
    """collapse_shared 와 동일하되 각 대표에 **선택 후보 수 m** 을 붙여 반환(강화 축14: order-statistic).

    규칙1 은 같은 kind 의 여러 공유값 중 df 최소를 고른다 — 이는 'm개 중 가장 유리한 것'을 고른
    post-selection 이다. 그 kind 가 원래 몇 개 값을 공유했는지(m)를 함께 돌려주면, coincidence 계산에서
    q → 1-(1-q)^m 로 선택편향을 보정할 수 있다(coincidence_prob_selected). 반환 [(kind, value, m)]."""
    from collections import defaultdict
    m_of_kind: dict = defaultdict(int)
    for (k, _v) in kv:
        m_of_kind[k] += 1
    reps = collapse_shared(kv, df_of, by_family=by_family)
    return [(k, v, max(1, m_of_kind.get(k, 1))) for (k, v) in reps]


def _context_maps(graph: Graph):
    """그래프를 1회 순회해 도메인별 관계 맵을 만든다(gather 의 공통 전처리)."""
    from collections import defaultdict
    ents = {e.key: e for e in graph.entities}
    aip = defaultdict(set); ns = defaultdict(set); mx = defaultdict(set)
    cname = defaultdict(set); reg = defaultdict(set)
    ip2attr = {e.key: (e.attrs or {}) for e in graph.entities if e.type == EntityType.IP}
    for ed in graph.edges:
        s = ents.get(ed.src)
        if s is None or s.type != EntityType.DOMAIN:
            continue
        rel = ed.relation
        if rel == "해석됨(A)":
            aip[ed.src].add(ed.dst)
        elif rel == "네임서버":
            ns[ed.src].add(ed.dst)
        elif rel == "메일서버":
            mx[ed.src].add(ed.dst)
        elif rel == "별칭":
            cname[ed.src].add(ed.dst)
        elif rel == "레지스트라":
            reg[ed.src].add(ed.dst)
    domains = [e for e in graph.entities if e.type == EntityType.DOMAIN]
    return {"aip": aip, "ns": ns, "mx": mx, "cname": cname, "reg": reg,
            "ip2attr": ip2attr, "domains": domains}


def _apply_specs(ent, maps, specs) -> dict:
    """도메인 엔티티 1개에 스펙을 적용해 {kind: set(values)} 반환(비어있는 축 생략)."""
    d = ent.key
    ctx = {"aip": maps["aip"].get(d, ()), "ns": maps["ns"].get(d, ()),
           "mx": maps["mx"].get(d, ()), "cname": maps["cname"].get(d, ()),
           "reg": maps["reg"].get(d, ()), "attrs": ent.attrs or {},
           "ip2attr": maps["ip2attr"]}
    sig = {}
    for spec in specs:
        vals = spec.extract(ctx)
        if vals:
            sig[spec.name] = set(vals)
    return sig


def gather_signals(graph: Graph, specs: list = SIGNAL_SPECS) -> dict:
    """도메인별 {kind: set(values)} (비어있는 축은 생략 → sparse). 단일 패스."""
    maps = _context_maps(graph)
    out: dict = {}
    for e in maps["domains"]:
        sig = _apply_specs(e, maps, specs)
        if sig:
            out[e.key] = sig
    return out


def gather_signals_parallel(graph: Graph, specs: list = SIGNAL_SPECS,
                            workers: int = 4) -> dict:
    """스펙 적용을 도메인 청크로 스레드 병렬(읽기전용). 맵 구축은 1회. gather_signals 와 동치.

    수백 축 × 수만 도메인에서 추출 단계를 병렬화한다(그래프는 변경하지 않으므로 스레드 안전)."""
    from concurrent.futures import ThreadPoolExecutor
    maps = _context_maps(graph)
    doms = maps["domains"]
    if workers <= 1 or len(doms) < 256:
        return {e.key: s for e in doms if (s := _apply_specs(e, maps, specs))}
    chunk = max(1, (len(doms) + workers - 1) // workers)
    chunks = [doms[i:i + chunk] for i in range(0, len(doms), chunk)]

    def work(part):
        return {e.key: s for e in part if (s := _apply_specs(e, maps, specs))}

    out: dict = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for part_out in ex.map(work, chunks):
            out.update(part_out)
    return out
