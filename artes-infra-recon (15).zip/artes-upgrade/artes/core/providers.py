"""클라우드 제공자 식별 — IP → 제공자(AWS/GCP/Azure/Cloudflare/Fastly…) 정확 최장프리픽스 매칭.

왜 축이 아니라 **인프라 자체**인가: 두 도메인이 신호를 많이 공유하는 최대 오탐원은 "같은 운영자"가
아니라 "같은 클라우드/CDN"이다(deconfound.py 참고). 지금까지 교란자로 ASN 을 썼는데, ASN 은
너무 거칠다(AS16509 = AWS 전체). 제공자의 **공개 IP 범위**(AWS ip-ranges.json, GCP cloud.json,
Azure ServiceTags, Cloudflare ips-v4/v6)를 직접 넣으면 훨씬 정밀한 교란자 층을 얻는다.

정확성: 최장프리픽스 매칭을 **이진 트라이**로 한다(휴리스틱/근사 아님). 주소 비트를 따라 내려가며
프리픽스가 끝나는 노드에 제공자를 심고, 조회는 지나온 노드 중 '가장 깊은 제공자 노드'를 취한다.
겹치는 범위(예: 큰 블록 안의 작은 블록)에서도 항상 가장 구체적인 소유자를 돌려준다. v4/v6 분리.

오프라인 우선: 네트워크로 안 가져온다. 공개 범위 파일 포맷 파서를 제공(inject) — load_aws/gcp/
azure/cloudflare + 범용 add_prefix. 씨앗 테이블(seed_db)로 무설정 즉시 사용도 가능. 순수 stdlib.

annotate_providers(graph, db) 는 IP 엔티티에 attrs['cloud_provider'] 를 심어, signals 의
ipattr 축('cloud_provider')이 도메인→A레코드IP→제공자로 자동 전파 → deconfound 교란자로 투입.
"""
from __future__ import annotations

import ipaddress
from typing import Optional


class _Trie:
    """비트 이진 트라이(한 주소패밀리). 노드=[child0, child1, provider|None]. 최장프리픽스."""

    __slots__ = ("bits", "root", "n")

    def __init__(self, bits: int):
        self.bits = bits                 # 32(v4) or 128(v6)
        self.root = [None, None, None]
        self.n = 0

    def add(self, network: int, prefixlen: int, provider: str) -> None:
        node = self.root
        for i in range(prefixlen):
            b = (network >> (self.bits - 1 - i)) & 1
            if node[b] is None:
                node[b] = [None, None, None]
            node = node[b]
        if node[2] is None:
            self.n += 1
        node[2] = provider               # 더 구체적 프리픽스가 나중에 덮어도 트라이 깊이로 구분됨

    def match(self, addr: int) -> Optional[str]:
        node = self.root
        best = node[2]
        for i in range(self.bits):
            b = (addr >> (self.bits - 1 - i)) & 1
            node = node[b]
            if node is None:
                break
            if node[2] is not None:
                best = node[2]           # 더 깊은(=더 구체적) 소유자로 갱신
        return best


class ProviderDB:
    """제공자 IP 범위 데이터베이스. add_prefix 로 채우고 match(ip) 로 최장프리픽스 조회."""

    def __init__(self):
        self.v4 = _Trie(32)
        self.v6 = _Trie(128)

    def __len__(self):
        return self.v4.n + self.v6.n

    def add_prefix(self, cidr: str, provider: str) -> bool:
        try:
            net = ipaddress.ip_network(cidr.strip(), strict=False)
        except ValueError:
            return False
        if net.version == 4:
            self.v4.add(int(net.network_address), net.prefixlen, provider)
        else:
            self.v6.add(int(net.network_address), net.prefixlen, provider)
        return True

    def match(self, ip: str) -> Optional[str]:
        ip = ip.split(":", 1)[1] if ip.count(":") == 1 and not _looks_v6(ip) else ip
        try:
            obj = ipaddress.ip_address(ip)
        except ValueError:
            return None
        return (self.v4 if obj.version == 4 else self.v6).match(int(obj))

    # ---- 공개 범위 파일 파서(inject; 네트워크 호출 안 함) --------------------- #
    def load_aws(self, doc: dict) -> int:
        """AWS ip-ranges.json: {'prefixes':[{'ip_prefix','region','service'}], 'ipv6_prefixes':[{'ipv6_prefix'}]}."""
        c = 0
        for p in doc.get("prefixes", []):
            cidr = p.get("ip_prefix")
            svc = p.get("service", "")
            tag = "AWS" if svc in ("AMAZON", "EC2", "") else f"AWS/{svc}"
            if cidr and self.add_prefix(cidr, tag):
                c += 1
        for p in doc.get("ipv6_prefixes", []):
            cidr = p.get("ipv6_prefix")
            if cidr and self.add_prefix(cidr, "AWS"):
                c += 1
        return c

    def load_gcp(self, doc: dict) -> int:
        """GCP cloud.json: {'prefixes':[{'ipv4Prefix'|'ipv6Prefix', 'service'}]}."""
        c = 0
        for p in doc.get("prefixes", []):
            cidr = p.get("ipv4Prefix") or p.get("ipv6Prefix")
            svc = p.get("service", "")
            tag = "GCP" if svc in ("Google Cloud", "", "GCE") else f"GCP/{svc}"
            if cidr and self.add_prefix(cidr, tag):
                c += 1
        return c

    def load_azure(self, doc: dict) -> int:
        """Azure ServiceTags: {'values':[{'name','properties':{'addressPrefixes':[...]}}]}."""
        c = 0
        for v in doc.get("values", []):
            name = v.get("name", "Azure")
            tag = "Azure" if name.lower().startswith(("azure", "cloud")) else f"Azure/{name}"
            for cidr in (v.get("properties", {}) or {}).get("addressPrefixes", []):
                if self.add_prefix(cidr, tag):
                    c += 1
        return c

    def load_lines(self, text: str, provider: str) -> int:
        """줄바꿈 구분 CIDR 목록(Cloudflare ips-v4/ips-v6, Fastly public-ip-list 등)."""
        c = 0
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#") and self.add_prefix(line, provider):
                c += 1
        return c


def _looks_v6(s: str) -> bool:
    return s.count(":") >= 2


# 씨앗 DB — 유명 CDN/클라우드의 대표 앵커 범위(무설정 즉시 사용; 전체 아님, 공개파일 로드 권장).
_SEED = {
    "Cloudflare": ["104.16.0.0/13", "172.64.0.0/13", "173.245.48.0/20", "103.21.244.0/22",
                   "103.22.200.0/22", "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20",
                   "188.114.96.0/20", "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15",
                   "131.0.72.0/22", "2606:4700::/32"],
    "Fastly": ["151.101.0.0/16", "199.232.0.0/16", "2a04:4e40::/32"],
    "AWS": ["3.0.0.0/9", "13.32.0.0/15", "52.0.0.0/11", "54.144.0.0/12", "18.32.0.0/11",
            "99.77.128.0/18", "2600:1f00::/24"],
    "GCP": ["34.0.0.0/9", "35.184.0.0/13", "104.196.0.0/14", "130.211.0.0/16", "2600:1900::/28"],
    "Azure": ["13.64.0.0/11", "20.0.0.0/8", "40.64.0.0/10", "52.224.0.0/11", "2603:1000::/24"],
    "Akamai": ["23.32.0.0/11", "23.192.0.0/11", "104.64.0.0/10", "184.24.0.0/13", "2600:1400::/24"],
}


def seed_db() -> ProviderDB:
    """대표 앵커 범위만 담은 즉시-사용 DB. 정밀 교란자는 공개 범위 파일을 load_* 로 채워라."""
    db = ProviderDB()
    for prov, cidrs in _SEED.items():
        for c in cidrs:
            db.add_prefix(c, prov)
    return db


def annotate_providers(graph, db: ProviderDB) -> int:
    """그래프의 IP 엔티티에 attrs['cloud_provider'] 를 심는다. signals 의 ipattr 축이 전파한다.

    반환: 주석 달린 IP 수. 도메인 신호축 'cloud_provider' = 그 도메인 A레코드 IP들의 제공자 집합
    → deconfound(confounder_kind='cloud_provider') 로 ASN 보다 정밀한 교란자 층 사용 가능.
    """
    from .model import EntityType
    n = 0
    for e in graph.entities:
        if e.type != EntityType.IP:
            continue
        ip = e.value
        prov = db.match(ip)
        if prov:
            if e.attrs is None:
                e.attrs = {}
            # 서브서비스 태그는 교란자 층으로는 상위 제공자로 접어 쓰는 편이 안전(층 과분할 방지)
            e.attrs["cloud_provider"] = prov
            e.attrs["cloud_provider_top"] = prov.split("/", 1)[0]
            n += 1
    return n
