"""다중검정 보정(FDR) — 후보쌍을 독립 threshold 하지 말고 오탐률을 통제한다(강화 축4).

지금은 각 후보쌍의 coincidence(= P(공유 | 무관) = H0 하의 정확 p-value)를 개별 임계값과 비교한다.
후보쌍이 많으면(N²급) 순전히 우연으로도 임계 이하가 다수 나온다 — 다중검정 문제. 여기서:

  - Benjamini–Hochberg(BH): 독립/PRDS 가정에서 FDR ≤ α 를 보장하는 step-up.
  - Benjamini–Yekutieli(BY): **임의 종속**에서도 FDR ≤ α (조화수 c(m)=Σ1/i 로 보수화). 신호가 겹치는
    후보쌍들은 종속이므로 인프라 상관에는 BY 가 이론적으로 안전하다.
  - BH/BY 조정 p-value(q-value): 각 검정의 최소 FDR. 임계 대신 q-value 를 보고하면 해석이 명확하다.

전부 정확(정리 기반, 휴리스틱 없음). 순수 stdlib.
"""
from __future__ import annotations

from typing import List, Sequence, Tuple


def _harmonic(m: int) -> float:
    return sum(1.0 / i for i in range(1, m + 1))


def bh_adjusted(pvalues: Sequence[float]) -> List[float]:
    """Benjamini–Hochberg 조정 p-value(q-value). 단조(step-up) 보정, 값 ∈ [0,1]. 순서 보존."""
    m = len(pvalues)
    if m == 0:
        return []
    order = sorted(range(m), key=lambda i: pvalues[i])
    adj = [0.0] * m
    prev = 1.0
    # 큰 p 부터 거꾸로: q_(i) = min(prev, p_(i) * m / rank)
    for rank in range(m, 0, -1):
        i = order[rank - 1]
        val = pvalues[i] * m / rank
        prev = min(prev, val)
        adj[i] = min(1.0, prev)
    return adj


def by_adjusted(pvalues: Sequence[float]) -> List[float]:
    """Benjamini–Yekutieli 조정 p-value — 임의 종속에서 FDR 통제(BH × 조화수 c(m))."""
    m = len(pvalues)
    if m == 0:
        return []
    c = _harmonic(m)
    return [min(1.0, q * c) for q in bh_adjusted(pvalues)]


def control_fdr(pvalues: Sequence[float], alpha: float = 0.05,
                method: str = "by") -> Tuple[List[bool], List[float]]:
    """FDR 통제. method='bh'(독립/PRDS) | 'by'(임의 종속). 반환 (rejected_mask, adjusted_pvalues).

    rejected[i]=True ⇔ 조정 p-value ≤ α ⇔ 그 검정을 유의(연결)로 채택하되 전체 FDR ≤ α 보장."""
    adj = by_adjusted(pvalues) if method == "by" else bh_adjusted(pvalues)
    rejected = [q <= alpha for q in adj]
    return rejected, adj


def fdr_edges(pairs_with_p, alpha: float = 0.05, method: str = "by") -> dict:
    """[(a,b,coincidence_p), ...] → FDR 통제된 간선만. 반환 {edges, rejected, adjusted, method, alpha}.

    coincidence_p 는 H0(무관) 하의 정확 p-value 이므로 그대로 FDR 에 넣을 수 있다."""
    pairs = list(pairs_with_p)
    ps = [float(p) for (_a, _b, p) in pairs]
    rejected, adj = control_fdr(ps, alpha=alpha, method=method)
    edges = [{"a": pairs[i][0], "b": pairs[i][1], "coincidence": ps[i], "q_value": adj[i]}
             for i in range(len(pairs)) if rejected[i]]
    edges.sort(key=lambda e: e["q_value"])
    return {"edges": edges, "n_candidates": len(pairs), "n_selected": len(edges),
            "method": method, "alpha": alpha,
            "note": ("BY: 임의 종속 FDR≤α" if method == "by" else "BH: 독립/PRDS FDR≤α")}
