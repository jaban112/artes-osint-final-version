"""HTTP 레이어 — infra_recon 에서 분리(리뷰 P1: 1,784줄 비대화 완화, 책임 분리).

주입가능 HTTP(오프라인 테스트용) + 프로덕션 파이프라인 구성요소:
  default_http_get  — aiohttp(풀링, 루프-스코프 세션) 우선, urllib 폴백. 리다이렉트 auto-follow 안 함.
  SSRFGuard         — 사설/특수 IP 차단 + 리다이렉트 hop 별 재검증.
  RequestLimiter    — 실제 outbound 요청 수 상한(세마포어; job 수 아님).
  PolitenessHTTP    — per-host 레이트리밋 + 429/5xx 지터 백오프 재시도.
  CachingHTTP       — TTL 캐시 + single-flight(중복조회 0).
전형 파이프라인: CachingHTTP(PolitenessHTTP(RequestLimiter(SSRFGuard(default_http_get)))).
순수 stdlib(+aiohttp 있으면 사용). infra_recon 이 하위호환으로 재수출한다.
"""
from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional


DEFAULT_MAX_BODY_BYTES = 2_000_000   # 2MB — recon 은 헤더/작은 JSON·HTML 만 필요. 초과분은 컷(축8).


@dataclass
class HTTPResp:
    status: int
    text: str = ""
    url: str = ""
    headers: dict = field(default_factory=dict)   # 응답 헤더(HTTP 지문용)
    truncated: bool = False                        # 본문이 max_body_bytes 로 잘렸는가(DoS 방어, 축8)

    def json(self) -> Any:
        import json as _j
        return _j.loads(self.text) if self.text else None

    @property
    def rate_limited(self) -> bool:
        return self.status == 429


HttpGet = Callable[[str], Awaitable[HTTPResp]]


_UA = "artes-infra/1.0"
import weakref as _weakref
# 이벤트루프 → ClientSession. WeakKeyDictionary 라 **루프가 GC 되면 세션 항목도 자동 제거**된다(강화 축:
# lifecycle). 예전엔 id(loop):session 를 plain dict 에 넣어 종료된 루프의 세션이 딕셔너리에 잔존
# (누수)했다. 루프 객체를 키로 두면 루프 수명에 세션 참조가 묶인다.
_AIOHTTP_SESSIONS: "_weakref.WeakKeyDictionary" = _weakref.WeakKeyDictionary()


async def _urllib_get(url: str, *, timeout: float = 15.0,
                      max_body_bytes: int = DEFAULT_MAX_BODY_BYTES) -> HTTPResp:
    """폴백: urllib 을 스레드풀에서(커넥션 재사용 없음, 느림). aiohttp 없을 때만.
    본문은 max_body_bytes 까지만 읽는다(초과 시 truncated=True, 축8)."""
    import asyncio
    import urllib.request
    import urllib.error

    class _NoRedirect(urllib.request.HTTPRedirectHandler):
        # 리다이렉트를 따라가지 않는다(SSRFGuard 가 hop 별 검증하며 따라감). 3xx 를 그대로 반환.
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None

    def _get() -> HTTPResp:
        req = urllib.request.Request(
            url, headers={"User-Agent": _UA, "Accept": "application/json"})
        opener = urllib.request.build_opener(_NoRedirect)
        try:
            with opener.open(req, timeout=timeout) as r:
                raw = r.read(max_body_bytes + 1)           # +1 로 초과 감지(축8)
                truncated = len(raw) > max_body_bytes
                if truncated:
                    raw = raw[:max_body_bytes]
                return HTTPResp(status=getattr(r, "status", 200),
                                text=raw.decode("utf-8", "replace"), url=url,
                                headers=dict(r.headers), truncated=truncated)
        except urllib.error.HTTPError as e:
            return HTTPResp(status=e.code, text="", url=url,
                            headers=dict(getattr(e, "headers", {}) or {}))
        except Exception:
            return HTTPResp(status=-1, text="", url=url)

    return await asyncio.get_event_loop().run_in_executor(None, _get)


async def _aiohttp_get(url: str, *, timeout: float = 15.0,
                       max_body_bytes: int = DEFAULT_MAX_BODY_BYTES) -> HTTPResp:
    """풀링 HTTP — keep-alive + per-host 커넥션 상한. 세션은 **현재 이벤트루프에 스코프**된다.

    리다이렉트는 여기서 따라가지 않는다(allow_redirects=False) — SSRFGuard 가 hop 별로 검증하며
    따라가야 안전하기 때문(리뷰 P1: redirect-aware SSRF). 3xx 는 Location 헤더째 반환된다."""
    import asyncio
    import aiohttp
    loop = asyncio.get_running_loop()
    sess = _AIOHTTP_SESSIONS.get(loop)          # 루프 객체를 키로(WeakKeyDictionary → 자동 수명관리)
    if sess is None or sess.closed:
        conn = aiohttp.TCPConnector(limit=512, limit_per_host=16,
                                    ttl_dns_cache=300, enable_cleanup_closed=True)
        sess = aiohttp.ClientSession(
            connector=conn, headers={"User-Agent": _UA, "Accept": "application/json"})
        _AIOHTTP_SESSIONS[loop] = sess
    try:
        async with sess.get(url, timeout=aiohttp.ClientTimeout(total=timeout),
                            allow_redirects=False) as resp:
            # 본문을 max_body_bytes+1 까지만 읽어 초과를 감지(전체를 메모리에 올리지 않음, 축8).
            raw = await resp.content.read(max_body_bytes + 1)
            truncated = len(raw) > max_body_bytes
            if truncated:
                raw = raw[:max_body_bytes]
            return HTTPResp(status=resp.status,
                            text=raw.decode("utf-8", errors="replace"), url=url,
                            headers={k: v for k, v in resp.headers.items()},
                            truncated=truncated)
    except asyncio.TimeoutError:
        return HTTPResp(status=-2, text="", url=url)   # -2 = timeout
    except Exception:
        return HTTPResp(status=-1, text="", url=url)


async def close_http() -> None:
    """모든 루프-스코프 풀 세션 정리(장시간 프로세스 종료 시)."""
    for s in list(_AIOHTTP_SESSIONS.values()):
        try:
            if not s.closed:
                await s.close()
        except Exception:
            pass
    _AIOHTTP_SESSIONS.clear()


async def default_http_get(url: str, *, timeout: float = 15.0,
                           max_body_bytes: int = DEFAULT_MAX_BODY_BYTES) -> HTTPResp:
    """프로덕션 기본 HTTP. aiohttp(풀링) 우선, 없으면 urllib 폴백. 테스트는 주입으로 대체.
    본문은 max_body_bytes 까지만 읽는다(초과 시 truncated=True) — 응답 크기 공격 방어(축8)."""
    try:
        import aiohttp  # noqa: F401
    except ImportError:
        return await _urllib_get(url, timeout=timeout, max_body_bytes=max_body_bytes)
    return await _aiohttp_get(url, timeout=timeout, max_body_bytes=max_body_bytes)


# --------------------------------------------------------------------------- #
# 실제 요청 레이어 통제 — job 수가 아니라 '실제 outbound 요청 수'를 통제(리뷰 P5) + SSRF 방어(P6)
# --------------------------------------------------------------------------- #
class RequestLimiter:
    """실제 outbound HTTP 요청을 통제. scheduler 는 source 'job' 을 통제하지만 한 job 이
    내부에서 여러 요청(예: DoHDNS 6종)을 gather 하므로, 실제 요청은 이 레이어에서 통제해야
    상한이 '요청 기준'으로 성립한다.

    두 예산은 서로 다른 개념이다(리뷰 P1):
    - max_concurrency : **동시** 실행 요청 상한(세마포어). 예전 이름 max_requests 는 '동시' 상한인데
      '총' 상한처럼 읽혀 오해를 샀다 → 이름을 바로잡음(max_requests 는 하위호환 별칭으로 계속 받음).
    - max_total       : 이 limiter 를 통과할 수 있는 **총** 요청 수 하드캡(None=무제한). 초과 시 실제
      요청 없이 status=-4(예산 소진, 재시도 대상 아님) 반환.
    """

    def __init__(self, inner: HttpGet, max_concurrency: int = 128, *,
                 max_requests: "Optional[int]" = None, max_total: "Optional[int]" = None):
        import asyncio
        if max_requests is not None:                 # 하위호환 별칭(동시 상한을 의미했음)
            max_concurrency = max_requests
        self.inner = inner
        self.max_concurrency = max(1, max_concurrency)
        self._sem = asyncio.Semaphore(self.max_concurrency)
        self.max_requests = self.max_concurrency     # 하위호환 속성(= 동시 상한)
        self.max_total = max_total
        self.in_flight = 0
        self.peak = 0
        self.total = 0
        self.reserved = 0            # 진입 시점 예약(세마포어 밖). 대량 병렬에서도 총 예산이 먹게(리뷰 P1)
        self.rejected_over_budget = 0

    async def __call__(self, url: str, **kw) -> HTTPResp:
        # 총 예산 체크·예약을 **await 이전**에(단일스레드 asyncio → 원자적). 예전엔 체크가 세마포어 밖,
        # 증가가 안이라 gather 로 N개가 뜨면 전부 total=0 일 때 체크를 통과해 캡이 no-op 였다(리뷰 P1).
        if self.max_total is not None:
            if self.reserved >= self.max_total:
                self.rejected_over_budget += 1
                return HTTPResp(status=-4, url=url)  # 총 요청 예산 소진(재시도 아님; _transient 제외)
            self.reserved += 1                        # 예약(진입 즉시) → 병렬에서도 정확히 max_total 만 통과
        async with self._sem:
            self.in_flight += 1
            self.total += 1
            self.peak = max(self.peak, self.in_flight)
            try:
                return await self.inner(url, **kw)
            finally:
                self.in_flight -= 1


def is_blocked_ip(ip: str) -> bool:
    """SSRF 차단 대상 IP인가 — 사설/루프백/링크로컬/예약/멀티캐스트/미지정 + CGNAT(100.64/10)."""
    try:
        obj = ipaddress.ip_address(ip)
    except ValueError:
        return True                       # 파싱 불가 → 보수적으로 차단
    if (obj.is_private or obj.is_loopback or obj.is_link_local or obj.is_reserved
            or obj.is_multicast or obj.is_unspecified):
        return True
    if obj.version == 4 and ipaddress.ip_address(ip) in ipaddress.ip_network("100.64.0.0/10"):
        return True                       # 캐리어급 NAT
    return False


def _default_resolver(host: str):
    import socket
    return {ai[4][0] for ai in socket.getaddrinfo(host, None)}


class SSRFGuard:
    """active probe SSRF 방어(리뷰 P6): 호스트가 리터럴이든 DNS 결과든 사설/특수 IP 로 향하면 차단.

    **리다이렉트 인식**(리뷰 P1): 하위 http 는 리다이렉트를 따라가지 않고(allow_redirects=False)
    3xx 를 반환하며, 이 가드가 매 hop 의 Location 호스트를 재검증하며 따라간다(최대 max_redirects).
    그래서 `https://public → 302 → http://127.0.0.1/admin` 같은 우회가 차단된다.

    한계(정직하게): 검증 시점 해석 IP 와 실제 커넥션 IP 사이 TOCTOU(DNS 리바인딩)는 남는다.
    이건 **해석결과 preflight + hop 검증**이지 커넥션 IP 고정(connection pinning) 이 아니다.
    resolver 주입 가능(오프라인 테스트). 차단 시 실제 요청 없이 status=-3 반환. 실네트워크 경로 전용."""

    _REDIRECT = {301, 302, 303, 307, 308}

    def __init__(self, inner: "HttpGet", resolver=None, max_redirects: int = 5):
        self.inner = inner
        self.resolver = resolver or _default_resolver
        self.max_redirects = max_redirects

    def _host_blocked(self, url: str) -> bool:
        from urllib.parse import urlparse
        host = (urlparse(url).hostname or "").strip("[]")
        if not host:
            return True
        try:
            ipaddress.ip_address(host)             # 리터럴 IP
            ips = {host}
        except ValueError:
            try:
                ips = self.resolver(host)
            except Exception:
                return True                        # 해석 실패 → 차단
        return (not ips) or any(is_blocked_ip(ip) for ip in ips)

    async def __call__(self, url: str, **kw) -> HTTPResp:
        from urllib.parse import urljoin, urlparse
        cur = url
        for _hop in range(self.max_redirects + 1):
            if urlparse(cur).scheme not in ("http", "https"):   # scheme 허용목록(리뷰 P1: file:// 등 차단)
                return HTTPResp(status=-3, url=cur)
            if self._host_blocked(cur):
                return HTTPResp(status=-3, url=cur)       # 사설/특수 IP 향함 → 차단
            r = await self.inner(cur, **kw)
            if r.status in self._REDIRECT:                # 하위 http 는 auto-follow 안 함
                loc = (r.headers or {}).get("Location") or (r.headers or {}).get("location")
                if loc:
                    cur = urljoin(cur, loc)               # 다음 hop 재검증 후 진행
                    continue
            return r
        return HTTPResp(status=-3, url=cur)               # 리다이렉트 과다 → 차단


class CachingHTTP:
    """http_get 래퍼 — TTL 캐시 + single-flight. 대량 스윕에서 중복조회를 0 으로.

    같은 URL 이 캐시에 살아있으면 네트워크 0. 동시에 같은 URL 여러 개가 in-flight 면
    한 번만 실제로 나가고 나머지는 그 결과를 공유(single-flight) — 수백배 스코프에서
    같은 NS/ASN/prefix 재조회가 폭증해도 실제 요청 수는 고유 URL 수로 눌린다.
    """
    def __init__(self, inner: HttpGet, ttl: float = 300.0, negative_ttl: float = 30.0):
        self.inner = inner
        self.ttl = ttl
        self.negative_ttl = negative_ttl
        self._cache: dict[str, tuple[float, HTTPResp]] = {}
        self._inflight: dict[str, Any] = {}
        self.calls = 0     # 실제 하부 호출 수
        self.hits = 0      # 캐시/합류로 절약된 수

    async def __call__(self, url: str) -> HTTPResp:
        import asyncio
        loop = asyncio.get_event_loop()
        now = loop.time()
        c = self._cache.get(url)
        if c and c[0] > now:
            self.hits += 1
            return c[1]
        fut = self._inflight.get(url)
        if fut is not None:
            self.hits += 1
            return await fut
        fut = loop.create_future()
        self._inflight[url] = fut
        try:
            self.calls += 1
            resp = await self.inner(url)
            ttl = self.ttl if getattr(resp, "status", 0) == 200 else self.negative_ttl
            self._cache[url] = (loop.time() + ttl, resp)
            if not fut.done():
                fut.set_result(resp)
            return resp
        except asyncio.CancelledError:
            # 리더가 취소되면 follower 가 영원히 대기하던 버그 수정(리뷰 P1). future 도 취소해 전파.
            if not fut.done():
                fut.cancel()
            raise
        except Exception as e:
            if not fut.done():
                fut.set_exception(e)
            raise
        finally:
            self._inflight.pop(url, None)

    def stats(self) -> dict:
        return {"underlying_calls": self.calls, "saved": self.hits,
                "cached_urls": len(self._cache)}


class PolitenessHTTP:
    """prod HTTP 래퍼 — per-host 레이트리밋 + 지터 백오프 재시도(429/5xx/네트워크오류).

    임의 inner http_get 를 감싼다. 기존 core.politeness.POLICY 를 policy= 로 넘기면 그
    레이트리밋·백오프·재시도수를 그대로 쓴다(proc/politeness 래핑). CachingHTTP 와 조합 가능:
    CachingHTTP(PolitenessHTTP(inner, policy=POLICY)).
    """
    def __init__(self, inner: HttpGet, *, policy=None, retries: int = 3,
                 base_delay: float = 0.5, max_delay: float = 8.0,
                 min_interval: float = 0.0, limiter=None):
        self.inner = inner
        self.policy = policy
        if policy is not None:
            self.retries = getattr(policy, "retries", retries)
            self._limiter = policy.limiter          # .acquire(host)
            self._backoff = policy.backoff          # (attempt)->delay
        else:
            self.retries = retries
            self._limiter = limiter or _HostLimiter(min_interval)
            self._base, self._max = base_delay, max_delay
            self._backoff = self._default_backoff

    def _default_backoff(self, attempt: int) -> float:
        import random
        d = min(self._max, self._base * (2 ** attempt))
        return d * (0.5 + random.random())

    @staticmethod
    def _transient(r: HTTPResp) -> bool:
        # -1(연결오류)·-2(타임아웃)만 일시적. -3(SSRF/정책/리다이렉트 초과 = 보안 거부)은
        # 재시도 금지(리뷰 P1): 재시도해도 실제 요청은 안 나가고 결과도 안 바뀌는데 헛돈다.
        return r.status == 429 or r.status in (500, 502, 503, 504) or r.status in (-1, -2)

    async def __call__(self, url: str) -> HTTPResp:
        import asyncio
        from urllib.parse import urlparse
        host = urlparse(url).hostname or ""
        r = HTTPResp(status=-1, url=url)
        for attempt in range(self.retries + 1):
            await self._limiter.acquire(host)
            r = await self.inner(url)
            if self._transient(r) and attempt < self.retries:
                await asyncio.sleep(self._backoff(attempt))
                continue
            return r
        return r


class _HostLimiter:
    """PolitenessHTTP 기본 per-host 최소간격(core.politeness.RateLimiter 와 동일 시그니처)."""
    def __init__(self, min_interval: float = 0.0):
        self.min_interval = min_interval
        self._last: dict[str, float] = {}
        self._locks: dict[str, Any] = {}

    async def acquire(self, host: str) -> None:
        import asyncio
        import time as _t
        if self.min_interval <= 0 or not host:
            return
        lk = self._locks.get(host)
        if lk is None:
            lk = self._locks[host] = asyncio.Lock()
        async with lk:
            now = _t.monotonic()
            wait = self.min_interval - (now - self._last.get(host, 0.0))
            if wait > 0:
                await asyncio.sleep(wait)
            self._last[host] = _t.monotonic()
