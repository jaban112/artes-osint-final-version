"""인프라 자산 그래프의 결정적 구조 분석 — 정확 알고리즘만(휴리스틱 없음).

목적: same-operator 클러스터/자산 그래프에서 '구조적 사실'을 정확히 뽑는다.
- 핵심 인프라(중심성이 높은 자산), 취약 절단점(제거 시 인프라가 쪼개지는 자산/링크),
  운영자 클러스터의 밀집도/견고성(k-core).

전부 교과서 정확 알고리즘(사용자 기준: 근사·경험값 대신 정리 기반 확정):
- connected_components : 정확(BFS)
- articulation_points  : Tarjan 절단점(반복 DFS, low-link) — 정확
- bridges              : Tarjan 절단간선(반복 DFS) — 정확
- core_number / k_core : Batagelj–Zaveršnik 코어 분해 — 정확 O(V+E)
- betweenness          : Brandes 매개중심성(비가중) — 정확

무향 뷰로 본다(인프라 공유 관계는 대칭). relation/certainty 필터 가능.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Optional

from .model import Graph, Certainty


def adjacency(graph: Graph, relations: Optional[set] = None,
              confirmed_only: bool = False) -> dict:
    """무향 인접 dict{node: set(neighbors)} — 끝점이 모두 그래프에 존재하는 간선만."""
    ents = {e.key for e in graph.entities}
    adj: dict = defaultdict(set)
    for n in ents:
        adj[n]                      # 고립 노드도 키로 존재
    for e in graph.edges:
        if e.src not in ents or e.dst not in ents or e.src == e.dst:
            continue
        if relations is not None and e.relation not in relations:
            continue
        if confirmed_only and e.certainty is not Certainty.CONFIRMED:
            continue
        adj[e.src].add(e.dst)
        adj[e.dst].add(e.src)
    return dict(adj)


def connected_components(adj: dict) -> list[list[str]]:
    """연결 요소(BFS). 내림차순 크기."""
    seen: set = set()
    comps: list[list[str]] = []
    for start in adj:
        if start in seen:
            continue
        comp: list[str] = []
        dq = deque([start])
        seen.add(start)
        while dq:
            u = dq.popleft()
            comp.append(u)
            for v in adj[u]:
                if v not in seen:
                    seen.add(v)
                    dq.append(v)
        comps.append(sorted(comp))
    return sorted(comps, key=lambda c: (-len(c), c))


def articulation_points(adj: dict) -> set:
    """절단점(제거 시 연결요소 수가 느는 노드). 반복 Tarjan low-link. 정확."""
    disc: dict = {}
    low: dict = {}
    ap: set = set()
    timer = 0
    for root in adj:
        if root in disc:
            continue
        # 반복 DFS: 스택 프레임 = (node, parent, neighbor-iterator)
        root_children = 0
        stack = [(root, None, iter(adj[root]))]
        disc[root] = low[root] = timer
        timer += 1
        while stack:
            node, parent, it = stack[-1]
            advanced = False
            for w in it:
                if w == parent:
                    continue
                if w not in disc:
                    disc[w] = low[w] = timer
                    timer += 1
                    if node == root:
                        root_children += 1
                    stack.append((w, node, iter(adj[w])))
                    advanced = True
                    break
                else:
                    low[node] = min(low[node], disc[w])
            if not advanced:
                stack.pop()
                if stack:
                    par = stack[-1][0]
                    low[par] = min(low[par], low[node])
                    if par != root and low[node] >= disc[par]:
                        ap.add(par)
        if root_children > 1:
            ap.add(root)
    return ap


def bridges(adj: dict) -> list[tuple]:
    """절단간선(제거 시 연결요소 수가 느는 간선). 반복 Tarjan. 정확. (u,v) u<v 정규화."""
    disc: dict = {}
    low: dict = {}
    br: list[tuple] = []
    timer = 0
    for root in adj:
        if root in disc:
            continue
        stack = [(root, None, iter(adj[root]))]
        disc[root] = low[root] = timer
        timer += 1
        while stack:
            node, parent, it = stack[-1]
            advanced = False
            for w in it:
                if w == parent:
                    continue
                if w not in disc:
                    disc[w] = low[w] = timer
                    timer += 1
                    stack.append((w, node, iter(adj[w])))
                    advanced = True
                    break
                else:
                    low[node] = min(low[node], disc[w])
            if not advanced:
                stack.pop()
                if stack:
                    par = stack[-1][0]
                    low[par] = min(low[par], low[node])
                    if low[node] > disc[par]:
                        br.append(tuple(sorted((par, node))))
    return sorted(set(br))


def core_number(adj: dict) -> dict:
    """각 노드의 coreness(그 노드가 속하는 최대 k-core 의 k). 정확(peeling)."""
    return _core_peeling(adj)


def _core_peeling(adj: dict) -> dict:
    """표준 반복 peeling(정확): 현재 최소차수 노드를 반복 제거하며 coreness 확정."""
    deg = {v: len(adj[v]) for v in adj}
    core: dict = {}
    remaining = set(adj)
    cur = 0
    # 매 라운드 현재 그래프의 최소차수 = 그 노드들의 coreness 하한
    live_deg = dict(deg)
    while remaining:
        m = min(live_deg[v] for v in remaining)
        cur = max(cur, m)
        # cur 이하 차수 노드를 모두 벗겨냄
        peel = [v for v in remaining if live_deg[v] <= cur]
        changed = True
        while peel:
            v = peel.pop()
            if v not in remaining:
                continue
            core[v] = cur
            remaining.discard(v)
            for w in adj[v]:
                if w in remaining:
                    live_deg[w] -= 1
                    if live_deg[w] <= cur:
                        peel.append(w)
    return core


def k_core(adj: dict, k: int) -> set:
    """coreness >= k 인 노드 집합(k-core)."""
    core = _core_peeling(adj)
    return {v for v, c in core.items() if c >= k}


def betweenness(adj: dict, normalized: bool = True) -> dict:
    """Brandes 매개중심성(비가중, 무향). 정확. O(V·E)."""
    CB = {v: 0.0 for v in adj}
    for s in adj:
        stack = []
        pred = {w: [] for w in adj}
        sigma = {w: 0.0 for w in adj}
        sigma[s] = 1.0
        dist = {w: -1 for w in adj}
        dist[s] = 0
        dq = deque([s])
        while dq:
            v = dq.popleft()
            stack.append(v)
            for w in adj[v]:
                if dist[w] < 0:
                    dist[w] = dist[v] + 1
                    dq.append(w)
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)
        delta = {w: 0.0 for w in adj}
        while stack:
            w = stack.pop()
            for v in pred[w]:
                if sigma[w] > 0:
                    delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                CB[w] += delta[w]
    # 무향: 각 쌍 두 번 셈 → 1/2
    for v in CB:
        CB[v] /= 2.0
    if normalized:
        n = len(adj)
        scale = 1.0 / ((n - 1) * (n - 2) / 2.0) if n > 2 else 1.0
        for v in CB:
            CB[v] *= scale
    return CB


def induced_adjacency(graph: Graph, nodes: set, include_neighbors: bool = True,
                      relations: Optional[set] = None,
                      confirmed_only: bool = False) -> dict:
    """주어진 노드 집합(+선택적으로 그 이웃)으로 유도된 무향 인접 뷰.

    same-operator 클러스터(도메인들)는 보통 서로 직접 연결이 아니라 공유 인프라(NS·IP)를 통해
    이어진다 → include_neighbors=True 로 그 공유 자산까지 포함해야 구조(허브·절단점)가 드러난다.
    """
    full = adjacency(graph, relations=relations, confirmed_only=confirmed_only)
    keep = set(nodes)
    if include_neighbors:
        for n in list(nodes):
            keep.update(full.get(n, ()))
    sub: dict = {n: set() for n in keep}
    for n in keep:
        for m in full.get(n, ()):
            if m in keep:
                sub[n].add(m)
    return sub


def cluster_analytics(graph: Graph, clusters: list, top: int = 3,
                      **adj_kw) -> list[dict]:
    """same-operator 클러스터마다 구조 분석 — 공유 인프라 허브·절단(핵심) 자산·코어를 보고.

    clusters: 노드키 리스트들의 리스트(fast_clusters/coincidence_clusters 결과 등).
    """
    out: list[dict] = []
    for cl in clusters:
        sub = induced_adjacency(graph, set(cl), include_neighbors=True, **adj_kw)
        if not sub:
            continue
        core = _core_peeling(sub)
        bet = betweenness(sub)
        top_bet = [k for k, _ in sorted(bet.items(), key=lambda kv: -kv[1])[:top] if bet[k] > 0]
        maxk = max(core.values()) if core else 0
        out.append({
            "members": sorted(cl),
            "size": len(cl),
            "subgraph_nodes": len(sub),
            "hubs": top_bet,                                  # 공유 인프라 허브(중심성)
            "critical_assets": sorted(articulation_points(sub)),  # 절단점(제거 시 분열)
            "max_core": maxk,
        })
    return sorted(out, key=lambda c: -c["size"])


def snapshot_diff(old: Graph, new: Graph) -> dict:
    """두 스냅샷의 결정적 차이 — 시계열 인프라 변화 탐지(추가/삭제/**내용변경** 엔티티·간선).

    엔티티는 key, 간선은 (src,relation,dst) 로 **식별(identity)** 한다. 하지만 identity 가 같아도
    내용(엔티티: certainty/confidence/attrs/증거; 간선: certainty/confidence/증거구간/decision/증거)이
    바뀌면 그것도 변화다(리뷰 P1). 그래서 양쪽에 있는 key 는 content-address 다이제스트로 비교해
    *_changed 로 보고한다. 값 계산 없음(정확 집합 연산 + 정확 해시)."""
    from .repro import entity_digest, edge_digest
    o_ent = {e.key: entity_digest(e) for e in old.entities}
    n_ent = {e.key: entity_digest(e) for e in new.entities}
    o_edge = {(e.src, e.relation, e.dst): edge_digest(e) for e in old.edges}
    n_edge = {(e.src, e.relation, e.dst): edge_digest(e) for e in new.edges}

    ent_add = sorted(set(n_ent) - set(o_ent))
    ent_del = sorted(set(o_ent) - set(n_ent))
    ent_chg = sorted(k for k in (set(o_ent) & set(n_ent)) if o_ent[k] != n_ent[k])
    edge_add = sorted(set(n_edge) - set(o_edge))
    edge_del = sorted(set(o_edge) - set(n_edge))
    edge_chg = sorted(k for k in (set(o_edge) & set(n_edge)) if o_edge[k] != n_edge[k])
    return {
        "entities_added": ent_add,
        "entities_removed": ent_del,
        "entities_changed": ent_chg,       # identity 동일하지만 내용(증거/확신)이 달라진 것
        "edges_added": edge_add,
        "edges_removed": edge_del,
        "edges_changed": edge_chg,         # 예: confidence 0.4→0.9, decision unconfirmed→confirmed
        "summary": {"ent_added": len(ent_add), "ent_removed": len(ent_del),
                    "ent_changed": len(ent_chg),
                    "edge_added": len(edge_add), "edge_removed": len(edge_del),
                    "edge_changed": len(edge_chg),
                    "changed": bool(ent_add or ent_del or ent_chg
                                    or edge_add or edge_del or edge_chg)},
    }


def analyze(graph: Graph, relations: Optional[set] = None,
            confirmed_only: bool = False, top: int = 10) -> dict:
    """구조 요약: 연결요소·절단점·절단간선·최대 k-core·중심성 상위. 전부 정확."""
    adj = adjacency(graph, relations=relations, confirmed_only=confirmed_only)
    comps = connected_components(adj)
    core = _core_peeling(adj)
    maxk = max(core.values()) if core else 0
    bet = betweenness(adj)
    top_bet = sorted(bet.items(), key=lambda kv: -kv[1])[:top]
    ap = articulation_points(adj)
    br = bridges(adj)
    return {
        "nodes": len(adj),
        "edges": sum(len(v) for v in adj.values()) // 2,
        "components": len(comps),
        "largest_component": len(comps[0]) if comps else 0,
        "articulation_points": sorted(ap),
        "bridges": br,
        "max_core": maxk,
        "max_core_members": sorted(v for v, c in core.items() if c == maxk),
        "top_betweenness": [(k, round(v, 6)) for k, v in top_bet if v > 0],
    }
