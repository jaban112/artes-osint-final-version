"""귀속(attribution) 객체 모델 — evidence / candidate / decision 을 **분리**한다(강화 축13).

리뷰가 반복 지적한 혼동: score·confidence·certainty·decision·probability 가 한 Edge 에 뒤섞여 있어
"증거인가 결정인가"가 흐려진다. 여기서 세 계층을 명시적 값 객체로 나눈다:

    AttributionEvidence   — 관측된 증거만(공유신호·P(E|무관)·증거구간·k/n·배경출처). 결정 아님.
    CandidateRelation     — (a,b,관계종류) + 증거. **후보 가설**이지 확정 귀속이 아니다(이름부터).
    Decision              — 정책(임계값)으로 증거에서 유도한 판정(confirmed/unconfirmed/drop) + 근거.

핵심 규칙: 증거는 결정을 모른다. 결정은 정책과 함께 별도로 계산되고, 사용한 정책값을 스스로 기록한다.
사후확률을 날조하지 않는다 — posterior 는 보정된 LikelihoodModel 이 있을 때만 채운다. 순수 stdlib.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class AttributionEvidence:
    """관측된 증거. 결정 정보는 담지 않는다."""
    shared: tuple = ()                       # 공유 대표 (kind,value) 들(패밀리 붕괴 후 권장)
    p_evidence_given_unrelated: Optional[float] = None   # coincidence = P(E|무관), H0 p-value
    evidence_lower: Optional[float] = None   # 부수적 CP 증거구간(corroboration 등)
    evidence_upper: Optional[float] = None
    k_independent: Optional[int] = None      # 독립 확증 수
    n_sources: Optional[int] = None
    background_source: str = "unknown"       # corpus | target-self | none
    signal_set_hash: str = ""                # 어떤 신호셋으로 뽑은 증거인가(재현성)

    def strength(self) -> Optional[float]:
        """증거 강도의 단일 요약 = P(E|무관)(작을수록 강함). 사후확률 아님(명시)."""
        return self.p_evidence_given_unrelated


@dataclass(frozen=True)
class CandidateRelation:
    """동일운영자 **후보** 관계. 확정 귀속이 아니다 — 이름과 타입으로 그것을 강제한다."""
    a: str
    b: str
    kind: str = "same-operator-candidate"
    evidence: AttributionEvidence = field(default_factory=AttributionEvidence)

    def as_edge_relation(self) -> str:
        return "신호공유(동일운영자후보)"   # infra_recon.SAME_OPERATOR_SIGNAL_REL 과 일치


@dataclass(frozen=True)
class Decision:
    """정책으로 유도한 판정. 사용한 정책값을 스스로 기록해 '증거≠결정'을 지킨다."""
    verdict: str                              # confirmed | unconfirmed | drop
    policy: dict = field(default_factory=dict)
    rationale: str = ""
    posterior_prob: Optional[float] = None    # 보정 LR 있을 때만(없으면 None — 날조 금지)
    posterior_prob_upper: Optional[float] = None


def decide(candidate: CandidateRelation, *, coincidence_threshold: float,
           drop_threshold: Optional[float] = None,
           likelihood_model=None, prior_prob: float = 0.5) -> Decision:
    """증거 + 정책 → Decision. 증거의 P(E|무관) 을 임계값과 비교(H0 기각 = 후보 채택).

    coincidence_threshold : 이 이하면 '연결'(confirmed 후보). drop_threshold : 이 초과면 drop(근거 약함).
    likelihood_model      : 주입되면(보정된 경우) posterior 를 채운다. 없으면 posterior=None(정직).
    """
    ev = candidate.evidence
    p = ev.p_evidence_given_unrelated
    policy = {"coincidence_threshold": coincidence_threshold, "drop_threshold": drop_threshold,
              "prior_prob": prior_prob}
    if p is None:
        return Decision("unconfirmed", policy, "증거의 P(E|무관) 미상")
    if drop_threshold is not None and p > drop_threshold:
        verdict, why = "drop", f"P(E|무관)={p:.2e} > drop_threshold={drop_threshold:.2e} (근거 약함)"
    elif p <= coincidence_threshold:
        verdict, why = "confirmed", f"P(E|무관)={p:.2e} ≤ threshold={coincidence_threshold:.2e}"
    else:
        verdict, why = "unconfirmed", f"P(E|무관)={p:.2e} > threshold (연결 근거 부족)"
    post = post_up = None
    if likelihood_model is not None:
        r = likelihood_model.evaluate(list(ev.shared), prior_prob=prior_prob)
        post, post_up = r["posterior_prob"], r["posterior_prob_upper"]
    return Decision(verdict, policy, why, posterior_prob=post, posterior_prob_upper=post_up)
