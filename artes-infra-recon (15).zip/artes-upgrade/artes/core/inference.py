"""전 그래프 결합 확률추론 — 증거가 삼각 체인으로 전파되는 same-operator 추론.

지금까지는 쌍(pair)마다 독립 판정이었다. 하지만 a~b 강하고 b~c 강하면 a~c 도 (직접 증거가 없어도)
같은 운영자일 근거가 생긴다. 이 '증거 전파'가 쌍별 판정으로는 안 나오는 링크를 드러낸다.

정확 방법(휴리스틱 아님): 쌍별 증거강도(예: −log10(coincidence) = 증거 bits, 클수록 강함)를 간선
가중치로 둔 그래프에서, 두 노드 사이 **가장 신뢰할 수 있는 경로 = widest path(maximin)**:
체인은 가장 약한 고리만큼만 강하다(a~c 성립하려면 a~b '그리고' b~c 둘 다 성립) → 경로의 최소
간선강도, 그 중 최대. 이는 수정 Dijkstra 로 **정확**히 계산된다(근사 아님).

- transitive_strength(edges): 모든 도달 쌍의 widest-path 강도(직접+간접 통합).
- inferred_links(edges, threshold): 직접 증거는 약하지만 전파 강도가 threshold 이상인 '새로 추론된'
  same-operator 링크.
- operator_clusters(edges, threshold): 전파 강도 ≥ threshold 로 연결된 성분(운영자 군집).

순수 stdlib. 강도는 어떤 척도든 무방(bits, 확률→로그오즈 등) — 클수록 강한 증거면 된다.

■ 정직한 의미(리뷰 P12): widest-path 계산은 **정확**하지만, 그 결과는 그래프상의 **병목 증거강도
  (bottleneck evidence strength)**이지 보정된 확률 P(a,c 동일운영자)가 아니다. 알고리즘은 exact,
  semantics 는 calibrated probability 아님 — transitive_strength/inferred_links 의 값을 확률로
  읽지 말 것(evidence_strength/bottleneck_strength 로 이해). 확률로 바꾸려면 보정 데이터셋 필요.
"""
from __future__ import annotations

import heapq
import math
from collections import defaultdict


def coincidence_to_strength(coincidence_prob: float) -> float:
    """우연일치확률 → 증거 강도(bits). p 작을수록(우연 아님) 강함. strength = −log10(p)."""
    p = min(1.0, max(1e-300, coincidence_prob))
    return -math.log10(p)


def _adj(edges):
    """edges: [(u, v, strength)] → 무향 인접 {u: {v: strength}} (중복은 최대값)."""
    g = defaultdict(dict)
    for u, v, w in edges:
        if u == v:
            continue
        if v not in g[u] or w > g[u][v]:
            g[u][v] = w
            g[v][u] = w
    return g


def widest_path(edges, src: str) -> dict:
    """src 에서 각 노드까지 widest-path(경로 최소간선강도의 최대) 강도. 수정 Dijkstra, 정확.

    반환 {node: strength}. 도달 불가·자기 자신 제외.
    """
    g = _adj(edges)
    if src not in g:
        return {}
    best = {src: math.inf}
    heap = [(-math.inf, src)]        # 최대-widest 우선(음수로 max-heap)
    done: dict = {}
    while heap:
        negw, u = heapq.heappop(heap)
        w = -negw
        if u in done:
            continue
        done[u] = w
        for v, ew in g[u].items():
            cand = min(w, ew)         # 병목(가장 약한 고리)
            if cand > best.get(v, -math.inf):
                best[v] = cand
                heapq.heappush(heap, (-cand, v))
    done.pop(src, None)
    return done


def transitive_strength(edges) -> dict:
    """모든 도달 쌍의 widest-path 강도(직접+간접 통합). {(u,v): strength} u<v."""
    g = _adj(edges)
    out: dict = {}
    for src in g:
        for dst, w in widest_path(edges, src).items():
            key = (src, dst) if src <= dst else (dst, src)
            if w > out.get(key, -math.inf):
                out[key] = w
    return out


def inferred_links(edges, threshold: float) -> list:
    """직접 간선은 없거나 약한데, 전파(widest-path) 강도 ≥ threshold 인 '새로 추론된' 링크.

    반환 [{a, b, transitive, direct}] — transitive 는 경로 강도, direct 는 직접 간선 강도(없으면 None).
    """
    g = _adj(edges)
    ts = transitive_strength(edges)
    out = []
    for (a, b), w in ts.items():
        if w < threshold:
            continue
        direct = g.get(a, {}).get(b)
        if direct is None or direct < threshold:   # 직접으론 약/무, 전파로 강함
            out.append({"a": a, "b": b, "transitive": round(w, 6),
                        "direct": (round(direct, 6) if direct is not None else None)})
    return sorted(out, key=lambda x: -x["transitive"])


def operator_clusters(edges, threshold: float) -> list:
    """전파 강도 ≥ threshold 로 연결된 성분(운영자 군집). widest-path 기반."""
    ts = transitive_strength(edges)
    parent: dict = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    nodes = set()
    for (a, b), w in ts.items():
        nodes.add(a); nodes.add(b)
        if w >= threshold:
            union(a, b)
    groups: dict = defaultdict(set)
    for n in nodes:
        groups[find(n)].add(n)
    return sorted([sorted(m) for m in groups.values() if len(m) >= 2],
                  key=lambda m: (-len(m), m))
