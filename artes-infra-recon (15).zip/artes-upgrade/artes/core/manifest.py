"""Run manifest — 재현성의 완결(강화 축5).

repro.canonical_root(graph) 는 **그래프 내용**의 지문이다(graph_root). 하지만 같은 그래프라도
정책 임계값·신호 레지스트리 버전·배경 모집단·소프트웨어 버전·시간창이 다르면 **결정 맥락**이 다르다.
예: 같은 그래프에 coincidence_threshold=1e-6 vs 1e-3 → 클러스터가 달라진다.

RunManifest 는 이 전체 맥락을 해시해 run_root 를 만든다:

    run_root = H( graph_root, software_version, signal_set_hash, policy, background_hash,
                  time_window, source_config )

graph_root(내용) 와 run_root(맥락 포함)를 **분리**해서 보고한다 → "같은 결과"의 정의가 명확해진다.
순수 stdlib.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Optional


def _h(obj: Any) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


class RunManifest:
    """한 스캔 실행의 완전한 결정 맥락. run_root 로 '동일 실행'을 확정한다."""

    def __init__(self, *, graph_root: str, software_version: str,
                 signal_version: str = "", signal_set_hash: str = "",
                 policy: Optional[dict] = None, background_hash: str = "",
                 background_source: str = "", time_window: Optional[tuple] = None,
                 source_config: Optional[list] = None, extra: Optional[dict] = None):
        self.graph_root = graph_root
        self.software_version = software_version
        self.signal_version = signal_version
        self.signal_set_hash = signal_set_hash
        self.policy = dict(policy or {})
        self.background_hash = background_hash
        self.background_source = background_source
        self.time_window = tuple(time_window) if time_window else None
        self.source_config = sorted(source_config or [])
        self.extra = dict(extra or {})

    def _body(self) -> dict:
        return {
            "graph_root": self.graph_root,
            "software_version": self.software_version,
            "signal_version": self.signal_version,
            "signal_set_hash": self.signal_set_hash,
            "policy": self.policy,
            "background_hash": self.background_hash,
            "background_source": self.background_source,
            "time_window": list(self.time_window) if self.time_window else None,
            "source_config": self.source_config,
            "extra": self.extra,
        }

    @property
    def run_root(self) -> str:
        """맥락까지 포함한 실행 지문. 정책/신호셋/배경/버전 중 하나라도 바뀌면 변한다."""
        return _h(self._body())

    def to_dict(self) -> dict:
        d = self._body()
        d["run_root"] = self.run_root
        d["note"] = ("graph_root=그래프 내용 지문, run_root=결정맥락 포함 지문. "
                     "정책/신호셋/배경/버전이 바뀌면 graph 가 같아도 run_root 는 달라진다.")
        return d

    def same_run(self, other: "RunManifest") -> bool:
        return self.run_root == other.run_root


def build_manifest(graph, *, software_version: str, policy: dict,
                   background=None, time_window=None, source_config=None,
                   signal_specs=None) -> RunManifest:
    """그래프 + 정책 + (선택)배경/시간창/소스설정에서 RunManifest 를 조립한다."""
    from . import repro
    from . import signals as _sig
    specs = signal_specs if signal_specs is not None else _sig.EXTENDED_SPECS
    return RunManifest(
        graph_root=repro.canonical_root(graph),
        software_version=software_version,
        signal_version=_sig.SIGNAL_VERSION,
        signal_set_hash=_sig.signal_set_hash(specs),
        policy=policy,
        background_hash=(background.corpus_hash if background is not None else ""),
        background_source=(background.source if background is not None else "none"),
        time_window=time_window,
        source_config=source_config,
    )
