"""우도비(likelihood ratio) 프레임워크 — coincidence 를 증거통계로 승격(강화 축3).

coincidence = P(E | 무관) 만으로는 "같은 운영자일 확률"이 아니다. 베이즈적으로 필요한 건:

    LR = P(E | 동일운영자) / P(E | 무관)
    posterior_odds = prior_odds × LR
    P(동일 | E) = posterior_odds / (1 + posterior_odds)

여기서 P(E|무관) 은 배경 우연일치(이미 정확 계산). P(E|동일) 은 **라벨된 ground-truth 없이는 알 수 없다**
— 그래서 이 모듈은 추정기를 **주입 가능(pluggable)** 하게 두고, 기본값은 정직하게 처리한다:

  - 기본 p_same = 1.0(동일 운영자면 이 신호들을 항상 공유한다는 낙관적 상한) → LR_upper = 1/P(E|무관).
    이는 증거강도의 **상한**이지 calibrated LR 이 아니며, 반환 dict 에 calibrated=False 로 표기한다.
  - 라벨 데이터가 생기면 CalibratedLikelihood(p_same_fn, p_unrelated_fn) 로 교체 → calibrated=True.

즉 구조는 처음부터 옳고(사후오즈 = 사전오즈 × LR), 숫자만 데이터가 채운다. 사후확률을 날조하지 않는다.
순수 stdlib.
"""
from __future__ import annotations

from typing import Callable, Optional


def odds_to_prob(odds: float) -> float:
    return odds / (1.0 + odds) if odds >= 0 else 0.0


def prob_to_odds(p: float) -> float:
    p = min(max(p, 0.0), 1.0)
    return float("inf") if p >= 1.0 else p / (1.0 - p)


class LikelihoodModel:
    """P(E|동일)·P(E|무관) 추정기. 기본은 비보정 상한(p_same=1). reps=[(kind,value)] 를 받는다.

    p_unrelated(reps): 배경 우연일치확률(주입 — 보통 BackgroundCorpus.coincidence 또는 coincidence_prob).
    p_same(reps):      동일운영자일 때 이 신호들을 공유할 확률. 기본 1.0(상한). 보정되면 교체.
    """

    def __init__(self, p_unrelated: Callable, p_same: Optional[Callable] = None,
                 calibrated: bool = False):
        self._p_unrelated = p_unrelated
        self._p_same = p_same or (lambda reps: 1.0)   # 기본: 낙관적 상한 → LR 상한
        self.calibrated = calibrated

    def lr(self, reps) -> float:
        """LR = P(E|동일)/P(E|무관). p_unrelated=0(정확 0 근거)면 +inf(무한 강도)."""
        pu = self._p_unrelated(reps)
        ps = self._p_same(reps)
        if pu <= 0.0:
            return float("inf") if ps > 0 else 0.0
        return ps / pu

    def evaluate(self, reps, *, prior_prob: float = 0.5) -> dict:
        """LR·사후오즈·사후확률을 정직 라벨과 함께 반환. prior_prob 는 사전 P(동일)."""
        pu = self._p_unrelated(reps)
        ps = self._p_same(reps)
        lr = self.lr(reps)
        prior_odds = prob_to_odds(prior_prob)
        if lr == float("inf"):
            post_odds = float("inf")
            post = 1.0
        else:
            post_odds = prior_odds * lr
            post = odds_to_prob(post_odds)
        return {
            "p_evidence_given_unrelated": pu,
            "p_evidence_given_same": ps,
            "likelihood_ratio": lr,
            "prior_prob": prior_prob,
            "posterior_prob": post if self.calibrated else None,   # 비보정이면 사후확률 미표기
            "posterior_prob_upper": post,                          # 상한(p_same=1 기준)은 항상 제공
            "calibrated": self.calibrated,
            "interpretation": ("보정된 사후확률" if self.calibrated
                               else "LR·사후확률은 상한(p_same=1 가정) — 라벨 데이터로 보정 필요"),
        }


def upper_bound_model(p_unrelated: Callable) -> LikelihoodModel:
    """비보정 상한 모델(p_same=1). calibrated=False. 라벨 없이 쓸 수 있는 최선."""
    return LikelihoodModel(p_unrelated, p_same=lambda reps: 1.0, calibrated=False)


class CalibratedLikelihood(LikelihoodModel):
    """라벨된 ground-truth 로 학습한 P(E|동일)·P(E|무관) 추정기(도수/커널 등). calibrated=True.

    p_same_fn / p_unrelated_fn 는 각각 동일/무관 라벨 코퍼스에서 추정한 함수여야 한다.
    이 클래스는 그 계약을 형식화할 뿐 — 데이터가 있어야 의미가 산다."""

    def __init__(self, p_unrelated_fn: Callable, p_same_fn: Callable):
        super().__init__(p_unrelated_fn, p_same=p_same_fn, calibrated=True)
