"""재현성·provenance 완결 — 모든 결과가 raw 증거까지 추적되고, 같은 입력이면 비트 단위로 재현.

- evidence_hash/entity_digest/edge_digest: 내용 주소화(content-addressed) 다이제스트.
- canonical_root(graph): 순서-무관 Merkle 식 그래프 루트 해시. 같은 그래프 → 같은 루트,
  한 값이라도 바뀌면 루트가 바뀜(변조/드리프트 탐지). 재현성의 단일 지문.
- verify_reproducible(g1,g2): 두 실행이 동일 결과인지 루트 해시로 확정.
- provenance(graph, key): 엔티티/간선 하나를 raw 증거(source/detail/url/raw_ref + 해시)로 역추적.

감사 해시체인(authz.AuditLog)과 짝: '무엇을 언제 조회했나'(감사) + '결과가 무엇에서 나왔나'(provenance)
+ '같은 입력이면 같은 결과'(canonical_root) → 법적/감사 방어 완결. 순수 stdlib.
"""
from __future__ import annotations

import hashlib
import json

from .model import Graph


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def evidence_hash(ev) -> str:
    """Evidence → 다이제스트(source/detail/url/raw_ref)."""
    body = [getattr(ev, "source", ""), getattr(ev, "detail", ""),
            getattr(ev, "url", ""), getattr(ev, "raw_ref", "")]
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True))


def entity_digest(e) -> str:
    ev = sorted(evidence_hash(x) for x in getattr(e, "evidence", []))
    body = {"type": e.type.value, "value": e.value,
            "certainty": e.certainty.value, "confidence": e.confidence,
            "attrs": _canon(e.attrs or {}), "ev": ev}
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True))


def edge_digest(ed) -> str:
    ev = sorted(evidence_hash(x) for x in getattr(ed, "evidence", []))
    # 재현성 루트는 간선의 **통계적 의미**까지 포함해야 한다(리뷰 P0). certainty/confidence 만으로는
    # evidence 구간([lower,upper])이나 정책 결정(decision)이 바뀌어도 루트가 안 바뀌는 맹점이 생긴다.
    body = {"src": ed.src, "dst": ed.dst, "relation": ed.relation,
            "certainty": ed.certainty.value, "confidence": ed.confidence,
            "evidence_lower": getattr(ed, "evidence_lower", None),
            "evidence_upper": getattr(ed, "evidence_upper", None),
            "decision": getattr(ed, "decision", None), "ev": ev}
    return _sha(json.dumps(body, ensure_ascii=False, sort_keys=True))


def _canon(obj):
    """attrs 를 정렬 가능한 형태로(set→정렬 list 등)."""
    if isinstance(obj, dict):
        return {k: _canon(obj[k]) for k in sorted(obj, key=str)}
    if isinstance(obj, (set, frozenset)):
        return sorted((_canon(x) for x in obj), key=str)
    if isinstance(obj, (list, tuple)):
        return [_canon(x) for x in obj]
    return obj


def canonical_root(graph: Graph) -> str:
    """순서-무관 그래프 루트 해시(정렬된 엔티티·간선 다이제스트의 해시)."""
    ed = sorted(entity_digest(e) for e in graph.entities)
    ld = sorted(edge_digest(x) for x in graph.edges)
    return _sha(json.dumps({"entities": ed, "edges": ld}))


def verify_reproducible(g1: Graph, g2: Graph) -> bool:
    """두 실행이 동일 결과인가 — 루트 해시 일치로 확정."""
    return canonical_root(g1) == canonical_root(g2)


def provenance(graph: Graph, key: str) -> dict:
    """엔티티 또는 간선 key 를 raw 증거로 역추적. 간선 key 는 'src|relation|dst'."""
    for e in graph.entities:
        if e.key == key:
            return {"kind": "entity", "key": key, "type": e.type.value, "value": e.value,
                    "certainty": e.certainty.value, "confidence": e.confidence,
                    "digest": entity_digest(e),
                    "evidence": [{"source": x.source, "detail": x.detail, "url": x.url,
                                  "raw_ref": x.raw_ref, "hash": evidence_hash(x)}
                                 for x in e.evidence]}
    for ed in graph.edges:
        if ed.key == key:
            return {"kind": "edge", "key": key, "src": ed.src, "dst": ed.dst,
                    "relation": ed.relation, "certainty": ed.certainty.value,
                    "confidence": ed.confidence,
                    "evidence_lower": getattr(ed, "evidence_lower", None),
                    "evidence_upper": getattr(ed, "evidence_upper", None),
                    "decision": getattr(ed, "decision", None), "digest": edge_digest(ed),
                    "evidence": [{"source": x.source, "detail": x.detail, "url": x.url,
                                  "raw_ref": x.raw_ref, "hash": evidence_hash(x)}
                                 for x in ed.evidence]}
    return {}


def provenance_report(graph: Graph) -> dict:
    """전체 그래프의 재현성 지문 + 엔티티/간선별 다이제스트 색인."""
    return {
        "root": canonical_root(graph),
        "entities": {e.key: entity_digest(e) for e in graph.entities},
        "edges": {x.key: edge_digest(x) for x in graph.edges},
    }
