"""Clopper–Pearson 정확 검증 게이트 — 휴리스틱 신뢰도 대신 '증명가능한 하한'.

설계 철학(사용자 기준 그대로): "확실하지 않은 게 수식이 되면 뭔 소용이지?"
그래서 이 모듈은 **점추정 신뢰도를 만들지 않는다.** 대신:

  주장 X 가 n 개의 독립 소스 중 k 개에서 확인됐을 때, 참 성공률 p 의
  **정확(exact) 신뢰 하한** p_L 을 Clopper–Pearson(베타 분위수)로 구한다.
  이건 근사·부트스트랩·정규근사가 아니라 이항분포의 정확 구간이다.

판정 규약(결정적, AI 0회) — **증거(evidence)와 결정(decision)을 분리한다**(리뷰 P11):
  * p_L ≥ tau            → decision=CONFIRMED (정책결정: 하한이 tau 를 넘음)
  * 그 외                → decision=UNCONFIRMED
  * p_U < floor          → decision=DROP (상한조차 바닥 미만 = 근거 부족)
  어느 경우든 confidence 에는 항상 **정확 하한 p_L**(증거 강도)을 넣는다 — CONFIRMED 라고 1.0 을
  쓰지 않는다. 중요: CP 신뢰수준은 '반복표본에서 참 p 를 구간이 덮을 확률'의 커버리지 보장이지,
  "이 두 도메인이 같은 운영자일 확률"이 아니다. CONFIRMED 는 정책 임계 통과라는 결정일 뿐이며,
  보정된 사후확률 P(가설|증거)이 필요하면 우도비(LR)+보정 데이터셋이 있어야 한다(별도 트랙).

정확 불완전베타 I_x(a,b) 는 Lentz 연분수(Numerical Recipes betacf)로, 역함수는
단조성 위 이분법으로 machine-precision 까지. 외부 의존 0. scipy 있으면 테스트가 교차검증.
"""
from __future__ import annotations

import functools
import math
from dataclasses import dataclass
from typing import Optional

_TINY = 1e-300
_EPS = 1e-15


# --------------------------------------------------------------------------- #
# 정규화 불완전 베타 함수  I_x(a,b) = B(x;a,b)/B(a,b)
# --------------------------------------------------------------------------- #
def _betacf(a: float, b: float, x: float, itmax: int = 400) -> float:
    """연분수(Lentz). I_x 의 꼬리. a,b>0, 0<x<1."""
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < _TINY:
        d = _TINY
    d = 1.0 / d
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < _TINY:
            d = _TINY
        c = 1.0 + aa / c
        if abs(c) < _TINY:
            c = _TINY
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < _TINY:
            d = _TINY
        c = 1.0 + aa / c
        if abs(c) < _TINY:
            c = _TINY
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < _EPS:
            break
    return h


def reg_incomplete_beta(a: float, b: float, x: float) -> float:
    """I_x(a,b). 정확(연분수). 0<=x<=1, a,b>0."""
    if a <= 0 or b <= 0:
        raise ValueError("a,b must be > 0")
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    # bt = x^a (1-x)^b / B(a,b)
    bt = math.exp(a * math.log(x) + b * math.log1p(-x) - lbeta)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def _solve_ibeta(a: float, b: float, target: float) -> float:
    """I_x(a,b)=target 를 x∈(0,1) 에서 이분법으로. I_x 는 x 에 단조증가."""
    if target <= 0.0:
        return 0.0
    if target >= 1.0:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(200):  # 200 이분 → 2^-200, machine precision 훨씬 이전 수렴
        mid = 0.5 * (lo + hi)
        val = reg_incomplete_beta(a, b, mid)
        if val < target:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-16:
            break
    return 0.5 * (lo + hi)


# --------------------------------------------------------------------------- #
# Clopper–Pearson 정확 이항 신뢰구간
# --------------------------------------------------------------------------- #
@functools.lru_cache(maxsize=200000)
def cp_lower(k: int, n: int, alpha: float = 0.05) -> float:
    """양측 신뢰수준 1-alpha 의 정확 하한 p_L. 각 꼬리 alpha/2.

    정의: k>0 이면 I_{p_L}(k, n-k+1) = alpha/2 의 해. k=0 이면 0.
    (k,n,alpha) 만의 함수 → 메모이즈(대량 same-operator 판정에서 이분법 재계산 제거).
    """
    _validate(k, n, alpha)
    if k == 0:
        return 0.0
    return _solve_ibeta(k, n - k + 1, alpha / 2.0)


@functools.lru_cache(maxsize=200000)
def cp_upper(k: int, n: int, alpha: float = 0.05) -> float:
    """정확 상한 p_U. k<n 이면 I_{p_U}(k+1, n-k) = 1-alpha/2 의 해. k=n 이면 1. 메모이즈."""
    _validate(k, n, alpha)
    if k == n:
        return 1.0
    return _solve_ibeta(k + 1, n - k, 1.0 - alpha / 2.0)


def cp_interval(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    return cp_lower(k, n, alpha), cp_upper(k, n, alpha)


def _validate(k: int, n: int, alpha: float) -> None:
    if n <= 0:
        raise ValueError("n must be > 0")
    if not (0 <= k <= n):
        raise ValueError("require 0 <= k <= n")
    if not (0.0 < alpha < 1.0):
        raise ValueError("alpha must be in (0,1)")


# --------------------------------------------------------------------------- #
# 검증 게이트
# --------------------------------------------------------------------------- #
VERDICT_CONFIRMED = "confirmed"
VERDICT_UNCONFIRMED = "unconfirmed"
VERDICT_DROP = "drop"


@dataclass
class Verdict:
    verdict: str            # confirmed | unconfirmed | drop
    lower: float            # 정확 하한 p_L
    upper: float            # 정확 상한 p_U
    k: int
    n: int
    alpha: float
    tau: float
    floor: float

    def as_dict(self) -> dict:
        # 증거(evidence CI)와 결정(decision)을 분리해 노출 — 하한은 사후확률이 아니라 CP 증거 하한.
        return {
            "decision": self.verdict, "verdict": self.verdict,
            "evidence_lower": round(self.lower, 6), "evidence_upper": round(self.upper, 6),
            "lower": round(self.lower, 6), "upper": round(self.upper, 6),
            "decision_rule": f"lower>={self.tau} → confirmed; upper<{self.floor} → drop",
            "k": self.k, "n": self.n, "alpha": self.alpha, "tau": self.tau, "floor": self.floor,
            "note": "CP 커버리지 보장이며 P(가설|증거)가 아님",
        }


def coincidence_prob(dfs, n_domains: int, use_cp_upper: bool = False,
                     alpha: float = 0.05) -> float:
    """무관한 두 도메인이 공유된 값들을 '우연히 모두' 공유할 확률 = ∏ q_v.

    q_v = (df_v - 1)/(N - 1): 한 도메인이 값 v 를 가질 때 임의의 다른 도메인도 v 일 확률
    (df_v = 값 v 의 document frequency = 그 값을 가진 도메인 수, N = 전체 도메인 수).
    이것이 IDF 를 판정에 정직하게 반영한다 — 희소값(df 작음)은 곱을 급히 낮춰 강한 증거,
    제네릭값(df≈N)은 q≈1 로 증거력 0. 휴리스틱 가중치가 아니라 **축 독립 가정 하의 정확 확률**이다
    (리뷰 반영: 인프라 축은 강하게 종속되므로 이 값은 '모델 하 exact'지 현실 확률이 아니다 — family
    collapse 로 관측단위 종속은 제거하나 패밀리 간 잔차 종속(같은 벤더 등)은 남는다. 헤드라인 1e-26
    같은 수치를 '실제 same-operator 확률'로 읽지 말 것. 사후확률은 보정 LR+배경모집단 전엔 null).

    use_cp_upper=True 면 df 의 유한표본 오차를 CP 상한으로 보수화(q_v ≤ cp_upper(df_v,N)):
    df 를 과소평가해 증거를 부풀리지 않는다. 반환값이 작을수록 same-operator 근거가 강하다.

    표본 모형(강화, use_cp_upper 의 엄밀 정의): CP_upper 는 'df_v = 크기 N 표본에서 값 v 의 도수'가
    이항 Binomial(N, p_v) 을 따른다고 볼 때 유병률 p_v 의 상한이다. 즉 배경 모집단에서 N 개를
    표집했고 그 중 df_v 개가 v 였다는 sampling model 을 가정한다. 타겟 그래프를 자기배경으로 쓰면
    (background='target-self') 이 표본 모형이 성립하지 않으므로 CP_upper 는 '보수화 장치'일 뿐
    엄밀한 유병률 상한이 아니다 — 진짜 상한은 독립 BackgroundCorpus(축1)에서 온다.
    """
    import math
    if n_domains < 2:
        return 1.0
    logp = 0.0
    for df in dfs:
        df = max(1, min(int(df), n_domains))
        if use_cp_upper:
            q = cp_upper(df, n_domains, alpha)
        else:
            q = (df - 1) / (n_domains - 1)
        # df==1 → q==0: 그 값을 가진 도메인이 하나뿐 → 우연히 공유할 확률 '정확히 0'.
        # 예전엔 log 안전을 위해 1e-18 로 바닥을 깔아 exact-0 을 깨뜨렸음(리뷰 지적). 이제 정확히 0.
        if q <= 0.0:
            return 0.0
        logp += math.log(min(1.0, q))
    return math.exp(logp)


def max_confirmable_lower(n: int, alpha: float = 0.05) -> float:
    """n 축 전부 공유(k=n)일 때 달성 가능한 CP 하한 = cp_lower(n,n,alpha)(리뷰 P2 투명성).

    VerificationGate.tau 가 이 값보다 크면 그 n 에선 **어떤 입력도 CONFIRMED 가 안 된다**(보수적).
    correlate_same_operator 는 스크리닝 전용이므로 이는 함정이 아니라 의도된 보수성 — 이 헬퍼로
    '이 n 에서 confirm 가능한 tau 상한'을 미리 알 수 있다."""
    return cp_lower(n, n, alpha)


def order_statistic_correction(q: float, m: int) -> float:
    """m개 후보값 중 '가장 희소한(q 최소) 하나'를 골랐을 때의 post-selection 보정(강화 축14).

    collapse_shared 는 같은 kind(또는 패밀리)의 여러 공유값 중 df 가 최소인(=q 최소) 대표 1개만
    남긴다. 이때 그 q 를 그대로 쓰면 '관측 뒤 가장 유리한 값을 고른' 선택편향이 반영되지 않아
    증거가 과대평가된다. m개 독립 후보의 **최솟값**에 대한 정확한 tail 확률은 순서통계량으로
        P(min_i q_i ≤ q) = 1 - (1 - q)^m
    이다. 즉 '이만큼 희소한 값이 m개 중 적어도 하나 나올' 확률로 보정한다. m=1 이면 q 그대로.
    """
    q = min(max(q, 0.0), 1.0)
    if m <= 1:
        return q
    return 1.0 - (1.0 - q) ** m


def coincidence_prob_selected(reps_with_m, n_domains: int, use_cp_upper: bool = False,
                              alpha: float = 0.05) -> float:
    """order-statistic 보정 coincidence. reps_with_m = [(df, m), ...] — df 는 대표값 빈도,
    m 은 그 대표가 '선택된 후보 수'(같은 kind/패밀리에서 몇 개 중 최소를 골랐나). ∏ 보정 q.

    m=1 이면 coincidence_prob 와 동일. m>1 이면 그 축의 q 를 1-(1-q)^m 로 키워(=증거 약화) 선택
    편향을 정직하게 반영한다. 반환 작을수록 강한 근거."""
    import math
    if n_domains < 2:
        return 1.0
    logp = 0.0
    for (df, m) in reps_with_m:
        df = max(1, min(int(df), n_domains))
        q = cp_upper(df, n_domains, alpha) if use_cp_upper else (df - 1) / (n_domains - 1)
        q = order_statistic_correction(q, int(m))
        if q <= 0.0:
            return 0.0
        logp += math.log(min(1.0, q))
    return math.exp(logp)


class VerificationGate:
    """k/n 독립 corroboration → 결정적 판정. 점추정 신뢰도를 만들지 않는다.

    tau   : CONFIRMED 승격 문턱(정확 하한이 이 이상이어야 확정).
    floor : 유지 문턱(정확 상한이 이 미만이면 근거부족 → drop).
    alpha : 양측 유의수준(기본 0.05 → 95% 신뢰).
    """

    def __init__(self, tau: float = 0.90, floor: float = 0.10, alpha: float = 0.05):
        if not (0.0 < floor <= tau < 1.0):
            raise ValueError("require 0 < floor <= tau < 1")
        self.tau = tau
        self.floor = floor
        self.alpha = alpha

    def judge(self, k: int, n: int) -> Verdict:
        lo = cp_lower(k, n, self.alpha)
        hi = cp_upper(k, n, self.alpha)
        if lo >= self.tau:
            v = VERDICT_CONFIRMED
        elif hi < self.floor:
            v = VERDICT_DROP
        else:
            v = VERDICT_UNCONFIRMED
        return Verdict(v, lo, hi, k, n, self.alpha, self.tau, self.floor)

    # --- 그래프 모델 연동 (있으면) --------------------------------------- #
    def apply_to_edge(self, edge, k: int, n: int) -> Optional[object]:
        """Edge 에 판정 적용. CONFIRMED 승격 / 정확하한을 confidence 로 / drop 시 None.

        edge 는 artes.core.model.Edge 를 기대하지만, 결합을 피하려고 덕타이핑으로만
        접근한다(certainty, confidence, evidence 속성). drop 이면 None 반환(호출측이 제외).
        """
        verd = self.judge(k, n)
        try:
            from .model import Certainty, Evidence
        except Exception:  # 모델 없이도 동작
            Certainty = None
            Evidence = None

        if verd.verdict == VERDICT_DROP:
            return None
        if verd.verdict == VERDICT_CONFIRMED and Certainty is not None:
            edge.certainty = Certainty.CONFIRMED       # 결정(decision), 정책 임계 통과
        elif Certainty is not None:
            edge.certainty = Certainty.UNCONFIRMED
        # 증거(CP 구간)와 결정을 엣지에 분리 기록(리뷰 P0). confidence 는 증거 하한(사후확률 아님).
        edge.confidence = verd.lower
        for attr, val in (("evidence_lower", verd.lower), ("evidence_upper", verd.upper),
                          ("decision", verd.verdict)):
            if hasattr(edge, attr):
                setattr(edge, attr, val)
        if Evidence is not None and hasattr(edge, "evidence"):
            edge.evidence.append(Evidence(
                source="cp-gate",
                detail=(f"독립근거 {k}/{n} · 증거 CI95=[{verd.lower:.3f},{verd.upper:.3f}] "
                        f"· 결정={verd.verdict}(규칙 lower≥{self.tau}) · 사후확률 아님"),
            ))
        return edge


# --------------------------------------------------------------------------- #
# 일반 corroboration — 임의 엣지의 '독립 증거출처 수'를 CP 로 환산
# --------------------------------------------------------------------------- #
def corroborate_edges(edges, gate: "VerificationGate", n_sources: int,
                      apply: bool = True, relations=None,
                      ignore_sources=("cp-gate", "cp-corroborate", "입력"),
                      independence_of=None) -> list[dict]:
    """각 엣지의 서로 다른 evidence.source 수(k)를 독립 확증 수로, n_sources 를 n 으로 CP 판정.

    '3개 독립 DNS 소스가 모두 이 A레코드를 반환' 같은 다중출처 확증을 점수가 아니라
    정확 하한으로 환산한다. apply=True 면 엣지의 certainty/confidence 를 그 자리에서 갱신
    (CONFIRMED 또는 UNCONFIRMED+정확하한). Graph 는 삭제 API 가 없어 drop 은 제거하지 않고
    보고만 한다(호출측이 직렬화에서 거를 수 있게 dropped=True 로 표시).

    반환: 엣지별 [{edge, k, n, verdict, lower, upper, dropped}].
    """
    try:
        from .model import Certainty, Evidence
    except Exception:
        Certainty = Evidence = None

    relset = set(relations) if relations else None
    ig = set(ignore_sources)
    out: list[dict] = []
    for edge in edges:
        if relset is not None and getattr(edge, "relation", None) not in relset:
            continue
        srcs = {getattr(ev, "source", "") for ev in getattr(edge, "evidence", [])}
        srcs = {s for s in srcs if s and s not in ig}
        # 독립성 붕괴(리뷰 P10): 같은 upstream 을 재게시하는 소스들은 1표로 센다(가짜 합의 방지).
        # independence_of(source)->class 를 주면 서로 다른 '클래스' 수를 k 로(이름 수 아님).
        k = len({independence_of(s) for s in srcs}) if independence_of is not None else len(srcs)
        n = max(n_sources, k)
        verd = gate.judge(k, n)
        dropped = verd.verdict == VERDICT_DROP
        if apply and Certainty is not None:
            edge.certainty = (Certainty.CONFIRMED if verd.verdict == VERDICT_CONFIRMED
                              else Certainty.UNCONFIRMED)
            edge.confidence = verd.lower           # 증거 하한(CONFIRMED 라도 1.0 아님)
            for attr, val in (("evidence_lower", verd.lower), ("evidence_upper", verd.upper),
                              ("decision", verd.verdict)):
                if hasattr(edge, attr):
                    setattr(edge, attr, val)
            if hasattr(edge, "evidence"):
                # 멱등성(리뷰 P1): 재실행 시 이전 cp-corroborate 증거를 누적하지 않고 교체한다.
                # (같은 입력·같은 분석 두 번 → 같은 k·같은 단일 분석증거. cp-corroborate 는 위 ignore
                #  기본값에도 들어가 있어 k 집계에서 자기 증거를 세지 않는다.)
                edge.evidence[:] = [ev for ev in edge.evidence
                                    if getattr(ev, "source", "") != "cp-corroborate"]
                edge.evidence.append(Evidence(
                    source="cp-corroborate",
                    detail=(f"독립출처 {k}/{n} · 증거 CI95=[{verd.lower:.3f},{verd.upper:.3f}] "
                            f"· 결정={verd.verdict} · 사후확률 아님")))
        out.append({"edge": edge, "k": k, "n": n, "verdict": verd.verdict,
                    "lower": verd.lower, "upper": verd.upper, "dropped": dropped})
    return out
