"""네트워크 자산 공격표면 소스 — 인프라/자산 축만(사람 축 없음). 전부 주입식 http, 오프라인 테스트.

포함(전부 authz infra_only 게이트 뒤에서만; 인가된 자산 정찰용):
  1) ShodanInternetDB : IP → 열린포트·CPE·호스트명·CVE. 무료·키리스(internetdb.shodan.io).
  2) CensysHosts      : IP → 서비스/포트/소프트웨어(CPE)/cert 지문. (API 키 주입식; 오프라인 파서.)
  3) WaybackCDX       : 도메인 → 아카이브의 역사적 서브도메인·URL(자산 발견). 무료·키리스.
  4) URLhaus          : abuse.ch 악성 URL/호스트 피드 → threat 축(인프라 평판). CSV 덤프 주입.
  5) scan_secrets     : TruffleHog식 유출 시크릿 탐지(정규+엔트로피). **인가된 본인 레포** 방어용.

전부 자산 공격표면·평판·구성. 사람 대량 비식별화는 하지 않는다(경계 유지).
검증된 엔드포인트(2026): internetdb.shodan.io/{ip}(키리스), urlhaus.abuse.ch/downloads/csv_recent/.
"""
from __future__ import annotations

import math
import re
from typing import Optional
from urllib.parse import urlparse

from .model import Entity, Edge, Evidence, EntityType, Certainty
from .infra_recon import InfraSource, FetchResult, InfraType, _k, _ev, _DOMAIN_RE


def _ip_entity(ip: str, attrs: dict, source: str, detail: str) -> Entity:
    return Entity(type=EntityType.IP, value=ip, certainty=Certainty.CONFIRMED,
                  evidence=_ev(source, detail), attrs=attrs)


# =========================================================================== #
# 1) Shodan InternetDB (무료·키리스) — IP 공격표면
# =========================================================================== #
def parse_internetdb(doc: dict) -> dict:
    """internetdb.shodan.io 응답 → {ports, cpe, cve, hostnames, tags}. (전부 자산 attr.)"""
    return {
        "open_ports": [str(p) for p in (doc.get("ports") or [])],
        "cpe": [str(c) for c in (doc.get("cpes") or [])],
        "cve": [str(v) for v in (doc.get("vulns") or [])],
        "hostnames": [str(h).strip().lower() for h in (doc.get("hostnames") or []) if h],
        "tags": [str(t) for t in (doc.get("tags") or [])],
    }


class ShodanInternetDB(InfraSource):
    """IP → 열린포트·CPE·CVE·호스트명(Shodan InternetDB, 키 불필요). 자산 공격표면 주석."""
    name = "shodan-internetdb"
    accepts = {InfraType.IP}
    host = "internetdb.shodan.io"

    async def fetch(self, target, http):
        ip = target.normalized
        r = await http(f"https://internetdb.shodan.io/{ip}")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status == 404:
            return FetchResult(self.name, ok=False, error="no data")   # InternetDB 는 미관측 IP 404
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            a = parse_internetdb(r.json() or {})
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        attrs = {k: v for k, v in a.items() if v}
        if not attrs:
            return FetchResult(self.name, ok=False, error="empty")
        ent = _ip_entity(ip, attrs, self.name, "Shodan InternetDB")
        edges = []
        # 호스트명(PTR류) → 도메인 연결(자산 소유 추적). 사람 아님.
        ents = [ent]
        for h in a["hostnames"]:
            if _DOMAIN_RE.match(h):
                edges.append(Edge(src=_k(EntityType.IP, ip), dst=_k(EntityType.DOMAIN, h),
                                  relation="호스트명", certainty=Certainty.CONFIRMED,
                                  evidence=_ev(self.name, "InternetDB hostname")))
        return FetchResult(self.name, entities=ents, edges=edges)


# =========================================================================== #
# 2) Censys hosts (API 키 주입식) — IP 서비스/소프트웨어/cert
# =========================================================================== #
def parse_censys_host(doc: dict) -> dict:
    """Censys v2 /hosts/{ip} → {open_ports, cpe, cert_fps}. result.services[].{port,software,certificate}."""
    res = (doc.get("result") or doc)
    ports, cpe, certs = [], [], []
    for svc in res.get("services", []) or []:
        p = svc.get("port")
        if p is not None:
            ports.append(str(p))
        for sw in svc.get("software", []) or []:
            uri = sw.get("uniform_resource_identifier") or sw.get("cpe")
            if uri:
                cpe.append(str(uri))
        c = svc.get("certificate")
        if c:
            certs.append(str(c).lower())
    return {"open_ports": sorted(set(ports), key=lambda x: int(x) if x.isdigit() else 0),
            "cpe": sorted(set(cpe)), "cert_fps": sorted(set(certs))}


class CensysHosts(InfraSource):
    """IP → 서비스/포트/소프트웨어(CPE)/cert 지문(Censys). API 자격은 http 주입측에서(오프라인 파서 제공)."""
    name = "censys-hosts"
    accepts = {InfraType.IP}
    host = "search.censys.io"

    def __init__(self, api_id: Optional[str] = None, api_secret: Optional[str] = None):
        self.api_id, self.api_secret = api_id, api_secret   # 실제 basic-auth 는 http 주입 계층에서

    async def fetch(self, target, http):
        ip = target.normalized
        r = await http(f"https://search.censys.io/api/v2/hosts/{ip}")
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status == 401 or r.status == 403:
            return FetchResult(self.name, ok=False, error="auth 필요(키)")
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            a = parse_censys_host(r.json() or {})
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        attrs = {k: v for k, v in a.items() if v}
        if not attrs:
            return FetchResult(self.name, ok=False, error="empty")
        return FetchResult(self.name, entities=[_ip_entity(ip, attrs, self.name, "Censys host")])


# =========================================================================== #
# 3) Wayback CDX (무료·키리스) — 도메인의 역사적 서브도메인/URL
# =========================================================================== #
def parse_cdx(rows, domain: str) -> dict:
    """CDX json(첫 행은 헤더) → {subdomains:set, urls:set}. *.domain 스냅샷에서 자산 발굴."""
    subs, urls = set(), set()
    if not rows:
        return {"subdomains": subs, "urls": urls}
    start = 1 if (isinstance(rows[0], list) and rows[0] and str(rows[0][0]).lower() == "original") else 0
    dom = domain.lower().rstrip(".")
    for row in rows[start:]:
        original = row[0] if isinstance(row, list) else row
        if not original:
            continue
        try:
            host = (urlparse(original).hostname or "").lower().rstrip(".")
        except Exception:
            continue
        if host and (host == dom or host.endswith("." + dom)) and _DOMAIN_RE.match(host):
            subs.add(host)
            urls.add(str(original))
    return {"subdomains": subs, "urls": urls}


class WaybackCDX(InfraSource):
    """도메인 → 아카이브(web.archive.org CDX)의 역사적 서브도메인/URL. 잊힌 자산 발굴(키 불필요)."""
    name = "wayback-cdx"
    accepts = {InfraType.DOMAIN}
    host = "web.archive.org"

    def __init__(self, limit: int = 20000):
        self.limit = limit

    async def fetch(self, target, http):
        d = target.normalized
        url = (f"http://web.archive.org/cdx/search/cdx?url=*.{d}"
               f"&output=json&fl=original&collapse=urlkey&limit={self.limit}")
        r = await http(url)
        if r.status == 429:
            return FetchResult(self.name, ok=False, error="429", rate_limited=True)
        if r.status != 200 or not r.text:
            return FetchResult(self.name, ok=False, error=f"status {r.status}")
        try:
            parsed = parse_cdx(r.json() or [], d)
        except Exception as e:
            return FetchResult(self.name, ok=False, error=f"parse: {e}")
        ents, edges = [], []
        for sub in sorted(parsed["subdomains"]):
            if sub == d:
                continue
            ents.append(Entity(type=EntityType.DOMAIN, value=sub, certainty=Certainty.CONFIRMED,
                               evidence=_ev(self.name, "아카이브 역사적 관측"),
                               attrs={"archived": True}))
            edges.append(Edge(src=_k(EntityType.DOMAIN, d), dst=_k(EntityType.DOMAIN, sub),
                              relation="하위도메인", certainty=Certainty.CONFIRMED,
                              evidence=_ev(self.name, "Wayback CDX")))
        if not ents:
            return FetchResult(self.name, ok=False, error="no archived subdomains")
        return FetchResult(self.name, entities=ents, edges=edges)


# =========================================================================== #
# 4) URLhaus (abuse.ch) — 악성 URL/호스트 위협 피드
# =========================================================================== #
class URLhaus:
    """abuse.ch URLhaus CSV 덤프 → 악성 URL/호스트 집합. csv_recent/csv_online 주입.

    컬럼: id,dateadded,url,url_status,last_online,threat,tags,urlhaus_link,reporter (따옴표).
    """

    def __init__(self):
        self.by_host: dict[str, str] = {}      # host → threat
        self.by_url: dict[str, str] = {}        # url → threat

    def load_csv(self, text: str) -> int:
        import csv
        import io
        c = 0
        reader = csv.reader(io.StringIO("\n".join(
            ln for ln in text.splitlines() if ln and not ln.startswith("#"))))
        for row in reader:
            if len(row) < 6:
                continue
            url = row[2].strip()
            threat = row[5].strip() or "malware_url"
            if not url:
                continue
            self.by_url[url] = threat
            try:
                host = (urlparse(url).hostname or "").lower().rstrip(".")
            except Exception:
                host = ""
            if host:
                self.by_host.setdefault(host, threat)
            c += 1
        return c

    def check_host(self, host: str) -> Optional[str]:
        return self.by_host.get((host or "").strip().lower().rstrip("."))

    def check_url(self, url: str) -> Optional[str]:
        return self.by_url.get((url or "").strip())


class URLhausSource(InfraSource):
    """도메인/IP 를 URLhaus 악성 호스트 피드에 대조 → threat attr + MALWARE 간선(인프라 평판)."""
    name = "urlhaus"
    accepts = {InfraType.DOMAIN, InfraType.IP}
    host = "urlhaus.abuse.ch"

    def __init__(self, feed: Optional[URLhaus] = None):
        self.feed = feed

    async def fetch(self, target, http):
        if not self.feed:
            return FetchResult(self.name, ok=False, error="feed 미로드")
        v = target.normalized
        threat = self.feed.check_host(v)
        if not threat:
            return FetchResult(self.name, ok=False, error="no match")
        ekind = EntityType.DOMAIN if target.type == InfraType.DOMAIN else EntityType.IP
        ent = Entity(type=ekind, value=v, certainty=Certainty.CONFIRMED,
                     evidence=_ev(self.name, "URLhaus 악성 호스트"),
                     attrs={"threat": [f"urlhaus:{threat}"]})
        mal = Entity(type=EntityType.MALWARE, value=f"urlhaus:{threat}",
                     certainty=Certainty.CONFIRMED, evidence=_ev(self.name, "abuse.ch URLhaus"))
        edge = Edge(src=_k(ekind, v), dst=_k(EntityType.MALWARE, f"urlhaus:{threat}"),
                    relation="위협연관", certainty=Certainty.CONFIRMED, evidence=_ev(self.name, "URLhaus"))
        return FetchResult(self.name, entities=[ent, mal], edges=[edge])


# =========================================================================== #
# 5) 시크릿 스캐너 — 인가된 본인 레포의 유출 자격증명 탐지(방어)
# =========================================================================== #
# 정확 정규 + 엔트로피. 목적은 '유출된 것을 찾아 폐기'하는 방어. 매칭값은 마스킹해 보관.
# 값: (정규, 시크릿이 담긴 그룹번호). 0=전체매칭이 시크릿, 1=1번 그룹이 시크릿(접두어 group 은 non-capturing).
_SECRET_PATTERNS = {
    "aws_access_key": (re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"), 0),
    "aws_secret_key": (re.compile(r"(?i)aws_secret_access_key\s*[=:]\s*['\"]?([A-Za-z0-9/+=]{40})"), 1),
    "google_api_key": (re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), 0),
    "slack_token": (re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{10,}\b"), 0),
    "github_pat": (re.compile(r"\bghp_[0-9A-Za-z]{36}\b"), 0),
    "github_fine_pat": (re.compile(r"\bgithub_pat_[0-9A-Za-z_]{22,}\b"), 0),
    "stripe_secret": (re.compile(r"\b(?:sk|rk)_(?:live|test)_[0-9A-Za-z]{16,}\b"), 0),
    "private_key": (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"), 0),
    "jwt": (re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"), 0),
    "generic_secret_assign": (re.compile(
        r"(?i)(?:secret|token|passwd|password|api[_-]?key)\s*[=:]\s*['\"]([^'\"\s]{12,})['\"]"), 1),
}


def shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    from collections import Counter
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in Counter(s).values())


def _mask(secret: str) -> str:
    s = secret.strip()
    return s[:4] + "…" + s[-2:] + f"(len={len(s)})" if len(s) > 8 else "…(len=%d)" % len(s)


def scan_secrets(text: str, min_entropy: float = 3.5) -> list:
    """텍스트에서 유출 시크릿 후보 탐지. 반환 [{type, line, masked, entropy}]. 값은 마스킹(방어 목적).

    known 패턴은 무조건 채택; generic assign 은 엔트로피 문턱 이상만(오탐 억제).
    """
    out = []
    lines = text.splitlines()
    for i, line in enumerate(lines, 1):
        for kind, (rx, grp) in _SECRET_PATTERNS.items():
            for m in rx.finditer(line):
                val = m.group(grp) if grp else m.group(0)
                ent = shannon_entropy(val)
                if kind == "generic_secret_assign" and ent < min_entropy:
                    continue
                out.append({"type": kind, "line": i, "masked": _mask(val),
                            "entropy": round(ent, 2)})
    return out


def scan_repo_files(files: dict, min_entropy: float = 3.5) -> list:
    """{path: text} 를 스캔. 반환 [{path, ...finding}] — 인가된 레포 유출 점검(방어)."""
    findings = []
    for path, text in files.items():
        for f in scan_secrets(text, min_entropy=min_entropy):
            findings.append({"path": path, **f})
    return findings
