"""적대적 견고성 — 입력의 일부가 거짓말해도 하한이 성립하는 집계.

OSINT 데이터는 조작 가능하다: 스푸핑 레코드, sybil 계정, 오염된 passive DNS, 담합 소스.
여기서는 '최악의 f개가 적대적'이라는 가정 아래에서도 무너지지 않는 판정을 준다(breakdown point).

- robust_corroboration_lower(k,n,f): 최대 f개 확증이 가짜/담합이라 보고 유효 확증을 k-f 로 깎아
  CP 하한을 낸다 → 적대자가 f개를 심어도 하한은 진짜 확증만 반영.
- robust_coincidence(dfs,N,drop_worst): 가장 '유리한'(희소=강증거로 보이는) drop_worst 개 공유값을
  버리고 우연확률을 계산 → 적대자가 그만큼 희귀 신호를 심어도 증거를 부풀릴 수 없다.
- independence_collapse(groups): 상관(재게시·에코) 소스를 한 표로 묶어 '가짜 합의'를 막는다.

전부 결정적 worst-case 논증(정리 기반). verify_cp 재사용.
"""
from __future__ import annotations

import math
from typing import Iterable

from .verify_cp import cp_lower, cp_upper


# 오염 모델(강화 축15): CP(k-f, n) 를 '정확 하한'이라 부르려면 어떤 가정에서 커버리지가
# 성립하는지 명시해야 한다. 아래가 그 계약이다 — machine-inspectable.
CONTAMINATION_MODEL = {
    "name": "bounded f-deletion (worst-case adversarial corroboration)",
    "assumptions": [
        "관측된 k개 확증 중 최대 f개가 적대적(스푸핑/담합/에코)일 수 있다",
        "적대자는 확증을 '추가'만 할 수 있고, 진짜 확증을 '삭제'할 수는 없다(추가-only 모델)",
        "진짜 확증들은 독립 베르누이(coincidence 모델과 동일 가정)",
    ],
    "construction": "유효 확증 = max(0, k-f) 로 깎고 그 위에서 Clopper–Pearson 하한",
    "guarantee": ("추가-only 모델에서 진짜 확증 수 k_true ≥ k-f 이므로, CP_lower(k-f,n) 는 "
                  "k_true 에 대한 CP 하한을 지배한다 → 신뢰수준 1-α 에서 하한이 유지된다"),
    "breakdown_point": "f (이보다 많은 적대적 확증이 있으면 보장 깨짐)",
    "not_covered": "진짜 확증을 삭제하는 적대자(삭제 모델)는 별도 — 여기선 다루지 않음",
}


def robust_corroboration_lower(k: int, n: int, f: int = 1, alpha: float = 0.05) -> float:
    """최대 f개 확증이 적대적이라 가정 → 유효 확증 max(0,k-f) 로 CP 하한(적대 최악).

    오염 모델은 CONTAMINATION_MODEL 참조(추가-only, breakdown point=f). 이 가정에서만 '정확 하한'."""
    ke = max(0, k - f)
    return cp_lower(ke, n, alpha)


def robust_guarantee(k: int, n: int, f: int = 1, alpha: float = 0.05) -> dict:
    """이 (k,n,f)에서의 하한과 그 보장이 유효한 오염 모델을 함께 반환(정직 라벨). breakdown=f."""
    return {"lower": robust_corroboration_lower(k, n, f, alpha),
            "k": k, "n": n, "f": f, "alpha": alpha,
            "model": CONTAMINATION_MODEL["name"],
            "breakdown_point": f,
            "guarantee": CONTAMINATION_MODEL["guarantee"],
            "valid_if": "적대적 확증이 추가-only 이고 최대 f개일 때만 커버리지 1-α 보장"}


def robust_coincidence(dfs: Iterable[int], n_domains: int, drop_worst: int = 1,
                       use_cp_upper: bool = True, alpha: float = 0.05) -> float:
    """가장 유리한(q 가 가장 작은) drop_worst 개 공유값을 버리고 ∏ q_v 계산.

    적대자가 심을 수 있는 신호 수 ≤ drop_worst 라면, 그가 만든 '강해 보이는' 증거는 제거된 뒤라
    남은 진짜 신호만으로 판정된다(breakdown point = drop_worst). 반환 작을수록 강한 근거.
    """
    if n_domains < 2:
        return 1.0
    qs = []
    for df in dfs:
        df = max(1, min(int(df), n_domains))
        q = cp_upper(df, n_domains, alpha) if use_cp_upper else (df - 1) / (n_domains - 1)
        qs.append(min(1.0, max(0.0, q)))       # 0 허용(df==1 → q==0, 정확). 바닥 안 깖.
    qs.sort()                                  # 오름차순: 앞쪽이 가장 유리(가장 의심스러움)
    kept = qs[drop_worst:] if drop_worst < len(qs) else []
    if not kept:
        return 1.0                             # 진짜 근거가 안 남음 → 증거 없음
    if any(q <= 0.0 for q in kept):
        return 0.0                             # df==1 잔존 → 우연 공유 확률 정확히 0
    return math.exp(sum(math.log(q) for q in kept))


def independence_collapse(source_groups: Iterable[Iterable]) -> int:
    """상관 소스 묶음 목록 → 독립 그룹 수(각 그룹 1표). 재게시/에코의 가짜 합의 방지.

    source_groups: [[s1,s2],[s3],...] 처럼 상관 소스를 묶은 것. 반환 = 비어있지 않은 그룹 수.
    """
    return sum(1 for g in source_groups if list(g))


def robust_verdict(k: int, n: int, f: int = 1, tau: float = 0.9,
                   floor: float = 0.1, alpha: float = 0.05) -> dict:
    """f개 적대 가정 하의 CP 하한으로 CONFIRMED/UNCONFIRMED/DROP 판정."""
    lo = robust_corroboration_lower(k, n, f, alpha)
    hi = cp_upper(max(0, k - f), n, alpha)
    if lo >= tau:
        v = "confirmed"
    elif hi < floor:
        v = "drop"
    else:
        v = "unconfirmed"
    return {"verdict": v, "lower": lo, "upper": hi, "k": k, "n": n, "f": f}
