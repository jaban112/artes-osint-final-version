"""ARTES — 통합 OSINT 오케스트레이터.

합법·인가된 조사(본인 발자국 점검 / 동의받은 대상 / 위협인텔 연구)용.
"""
__version__ = "0.5.0"   # canonical version (pyproject 는 이 값과 일치시킬 것)
